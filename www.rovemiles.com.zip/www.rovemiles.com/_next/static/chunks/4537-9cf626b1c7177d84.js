! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "75d7d9dc-39ba-43bf-9af7-6818d72f1659", e._sentryDebugIdIdentifier = "sentry-dbid-75d7d9dc-39ba-43bf-9af7-6818d72f1659")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4537], {
        8772: (e, t, n) => {
            n.d(t, {
                NavbarProvider: () => c,
                Iz: () => u,
                v8: () => d
            });
            var r = n(95155),
                a = n(12115);
            let s = {
                    headerContent: null,
                    className: void 0,
                    containerClassName: void 0,
                    isExpanded: !1
                },
                i = (e, t) => {
                    switch (t.type) {
                        case "SET_HEADER_CONTENT":
                            return { ...e,
                                headerContent: t.payload
                            };
                        case "SET_NAVBAR_CLASSNAME":
                            return { ...e,
                                className: t.payload
                            };
                        case "SET_CONTAINER_CLASSNAME":
                            return { ...e,
                                containerClassName: t.payload
                            };
                        case "SET_IS_EXPANDED":
                            return { ...e,
                                isExpanded: t.payload
                            };
                        default:
                            return e
                    }
                },
                l = (0, a.createContext)(s),
                o = (0, a.createContext)(() => {}),
                c = e => {
                    let {
                        children: t
                    } = e, [n, c] = (0, a.useReducer)(i, s);
                    return (0, r.jsx)(l.Provider, {
                        value: n,
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "NavbarProvider",
                        "data-sentry-source-file": "index.tsx",
                        children: (0, r.jsx)(o.Provider, {
                            value: c,
                            "data-sentry-element": "unknown",
                            "data-sentry-source-file": "index.tsx",
                            children: t
                        })
                    })
                },
                d = () => (0, a.useContext)(l),
                u = () => (0, a.useContext)(o)
        },
        9514: (e, t, n) => {
            n.d(t, {
                default: () => g
            });
            var r = n(95155),
                a = n(12115),
                s = n(53483),
                i = n(52619),
                l = n.n(i),
                o = n(64269),
                c = n(78698),
                d = n(53380),
                u = n(8595),
                h = n(13141),
                m = n(17767),
                x = n(22390),
                f = n(38728),
                p = n(25950),
                y = n(56468);
            let v = e => {
                    let {
                        icon: t,
                        label: n,
                        onClick: a,
                        href: s,
                        active: i,
                        as: c = "button"
                    } = e, d = (0, r.jsxs)(c, {
                        className: (0, o.cn)("flex flex-col items-center justify-center h-[4.2rem] w-full gap-1 hover-hover:hover:text-white/80", i ? "text-white/80" : "text-white/50"),
                        onClick: a,
                        children: [t, (0, r.jsx)("span", {
                            className: "text-xs",
                            children: n
                        })]
                    });
                    return s ? (0, r.jsx)(l(), {
                        href: s,
                        className: "flex flex-1 flex-col items-center justify-center",
                        "data-sentry-element": "Link",
                        "data-sentry-component": "MobileNavigationButton",
                        "data-sentry-source-file": "mobile.tsx",
                        children: d
                    }) : d
                },
                b = () => {
                    let [e, t] = (0, a.useState)(!1);
                    return (0, r.jsxs)("div", {
                        className: "relative flex flex-1",
                        "data-sentry-component": "AuthButton",
                        "data-sentry-source-file": "mobile.tsx",
                        children: [(0, r.jsx)(v, {
                            icon: (0, r.jsx)(s.EgY, {
                                size: 18
                            }),
                            label: "Sign up",
                            onClick: () => t(e => !e),
                            "data-sentry-element": "MobileNavigationButton",
                            "data-sentry-source-file": "mobile.tsx"
                        }), (0, r.jsx)(c.H, {
                            isOpen: e,
                            onClose: () => t(!1),
                            "data-sentry-element": "AuthDialog",
                            "data-sentry-source-file": "mobile.tsx"
                        })]
                    })
                },
                g = () => {
                    let {
                        user: e
                    } = (0, f.A)(), {
                        activeTab: t
                    } = (0, p.F7)(), {
                        onLandingPage: n
                    } = (0, y.A)();
                    return (0, r.jsxs)("div", {
                        className: (0, o.cn)("sticky w-full bottom-0 z-50 transition-all duration-200 ease-in-out bg-[#141414] border-t border-[#fff]/10 flex sm:hidden flex-row justify-between items-center px-2 pb-[env(safe-area-inset-bottom)]", n && "fixed bottom-0 left-0 right-0"),
                        "data-sentry-component": "MobileNavbar",
                        "data-sentry-source-file": "mobile.tsx",
                        children: [!e && (0, r.jsx)(v, {
                            icon: (0, r.jsx)(u.A, {
                                size: 18
                            }),
                            label: "Rove",
                            href: "/",
                            active: n
                        }), (0, r.jsx)(v, {
                            icon: (0, r.jsx)(h.A, {
                                size: 18
                            }),
                            label: "Flights",
                            href: "/explore",
                            active: "flights" === t && !n,
                            "data-sentry-element": "MobileNavigationButton",
                            "data-sentry-source-file": "mobile.tsx"
                        }), (0, r.jsx)(v, {
                            icon: (0, r.jsx)(m.A, {
                                size: 18
                            }),
                            label: "Hotels",
                            href: "/explore/hotels",
                            active: "hotels" === t,
                            "data-sentry-element": "MobileNavigationButton",
                            "data-sentry-source-file": "mobile.tsx"
                        }), (0, r.jsx)(v, {
                            icon: (0, r.jsx)(x.A, {
                                size: 18
                            }),
                            label: "Shopping",
                            href: "/shopping",
                            active: "shopping" === t,
                            "data-sentry-element": "MobileNavigationButton",
                            "data-sentry-source-file": "mobile.tsx"
                        }), e && (0, r.jsxs)(r.Fragment, {
                            children: [(0, r.jsx)(v, {
                                icon: (0, r.jsx)(d.CqI, {
                                    size: 18
                                }),
                                label: "Transfer",
                                href: "/transfer-miles"
                            }), (0, r.jsx)(v, {
                                icon: (0, r.jsx)(s.EgY, {
                                    size: 18
                                }),
                                label: "Profile",
                                href: "/profile"
                            })]
                        }), !e && (0, r.jsx)(b, {})]
                    })
                }
        },
        11607: (e, t, n) => {
            n.d(t, {
                y: () => r
            });
            let r = n(75329).A.NEXT_PUBLIC_ENABLE_BANNER
        },
        15218: (e, t, n) => {
            n.d(t, {
                lZ: () => o
            });
            var r = n(95155),
                a = n(52619),
                s = n.n(a),
                i = n(12115),
                l = n(56041);
            let o = e => {
                let {
                    message: t,
                    linkText: n,
                    linkUrl: a,
                    onHeightChange: o,
                    trailingMessage: c
                } = e, d = (0, i.useRef)(null);
                return (0, i.useEffect)(() => {
                    let e = () => {
                        if (d.current) {
                            let e = d.current.offsetHeight;
                            document.documentElement.style.setProperty(l.J2, "".concat(e, "px")), null == o || o(e)
                        }
                    };
                    return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                }, [t, n, o]), (0, r.jsx)("div", {
                    ref: d,
                    className: "banner__container w-full flex items-center justify-center bg-[#292929] min-h-14 py-2 text-xs sm:text-sm text-[#ffffffcc] fixed top-0 left-0 right-0 z-[1000] px-1 sm:px-4",
                    "data-sentry-component": "Banner",
                    "data-sentry-source-file": "Banner.tsx",
                    children: (0, r.jsxs)("p", {
                        className: "text-center max-w-screen-lg",
                        children: [t, n && a && (0, r.jsx)("span", {
                            className: "inline-flex items-center",
                            children: (0, r.jsx)(s(), {
                                href: a,
                                className: "underline mr-1",
                                rel: "noopener noreferrer",
                                children: n
                            })
                        }), c && (0, r.jsx)("span", {
                            className: "inline-flex items-center",
                            children: c
                        })]
                    })
                })
            }
        },
        20342: (e, t, n) => {
            n.d(t, {
                default: () => A
            });
            var r = n(95155),
                a = n(52619),
                s = n.n(a),
                i = n(12115),
                l = n(15239);
            let o = e => {
                let {
                    width: t = 78,
                    height: n = 25
                } = e;
                return (0, r.jsx)(l.default, {
                    src: "/logo.png",
                    alt: "Logo",
                    width: t,
                    height: n,
                    unoptimized: !0,
                    priority: !0,
                    "data-sentry-element": "Image",
                    "data-sentry-component": "Logo",
                    "data-sentry-source-file": "Logo.tsx"
                })
            };
            var c = n(78698),
                d = n(53483),
                u = n(20063),
                h = n(51849),
                m = n(31475),
                x = n(8155),
                f = n(34217),
                p = n(53455);
            let y = () => (0, p.I)({
                queryKey: ["miles"],
                queryFn: async () => {
                    let e = await fetch("/api/miles");
                    if (!e.ok) throw Error("Failed to fetch miles");
                    return e.json()
                },
                staleTime: 6e4
            });
            var v = n(92033),
                b = n(38728),
                g = n(8772),
                w = n(64269),
                j = n(80285),
                N = n(56041),
                C = n(66947),
                S = n(42953),
                _ = n(56468);
            let E = () => {
                    let e = (0, u.useRouter)(),
                        t = (0, u.usePathname)();
                    return !("/error" === t || t.startsWith("/error")) && ["/profile", "/transfer-miles", "/shopping"].some(e => t === e || t.startsWith("".concat(e, "/"))) ? (0, r.jsx)("div", {
                        className: "pointer-events-auto flex items-center justify-center",
                        "data-sentry-component": "TopNavLinks",
                        "data-sentry-source-file": "index.tsx",
                        children: (0, r.jsxs)("nav", {
                            className: "flex space-x-10 text-sm text-white/70 items-center",
                            children: [(0, r.jsxs)("span", {
                                onClick: () => {
                                    e.push("/explore")
                                },
                                className: "hover:text-white transition-colors relative pb-[2px] cursor-pointer ".concat(t.includes("/flights") ? "text-white" : ""),
                                children: ["FLIGHTS", t.includes("/flights") && (0, r.jsx)("div", {
                                    className: "absolute bottom-0 left-0 right-0 h-[1px]",
                                    style: {
                                        background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                                    }
                                })]
                            }), (0, r.jsxs)("span", {
                                onClick: () => {
                                    e.push("/explore/hotels")
                                },
                                className: "hover:text-white transition-colors relative pb-[2px] cursor-pointer ".concat(t.includes("/hotels") ? "text-white" : ""),
                                children: ["HOTELS", t.includes("/hotels") && (0, r.jsx)("div", {
                                    className: "absolute bottom-0 left-0 right-0 h-[1px]",
                                    style: {
                                        background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                                    }
                                })]
                            }), (0, r.jsxs)("span", {
                                onClick: () => {
                                    e.push("/shopping")
                                },
                                className: "hover:text-white transition-colors relative pb-[2px] cursor-pointer ".concat(t.includes("/shopping") ? "text-white" : ""),
                                children: ["SHOPPING", t.includes("/shopping") && (0, r.jsx)("div", {
                                    className: "absolute bottom-0 left-0 right-0 h-[1px]",
                                    style: {
                                        background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                                    }
                                })]
                            })]
                        })
                    }) : null
                },
                P = e => {
                    let {
                        isOpen: t,
                        setIsOpen: n,
                        children: a
                    } = e, s = (0, u.useRouter)(), {
                        signOut: i
                    } = (0, b.A)();
                    return (0, r.jsxs)(m.AM, {
                        open: t,
                        onOpenChange: n,
                        "data-sentry-element": "Popover",
                        "data-sentry-component": "ProfileButtonOverlay",
                        "data-sentry-source-file": "index.tsx",
                        children: [(0, r.jsx)(m.Wv, {
                            "data-sentry-element": "PopoverTrigger",
                            "data-sentry-source-file": "index.tsx",
                            children: a
                        }), (0, r.jsx)(m.hl, {
                            className: "w-48 bg-[#101010] backdrop-blur-xl border border-[#636363]/60 p-1 rounded-xl m-3",
                            "data-sentry-element": "PopoverContent",
                            "data-sentry-source-file": "index.tsx",
                            children: (0, r.jsxs)("div", {
                                className: "flex flex-col gap-1 p-2",
                                children: [(0, r.jsx)("button", {
                                    className: "flex items-center px-3 py-1 text-sm text-white/80 hover:bg-white/5 rounded-lg",
                                    onClick: () => {
                                        s.push("/profile"), n(!1)
                                    },
                                    children: "Profile"
                                }), (0, r.jsx)("button", {
                                    className: "hidden sm:flex items-center px-3 py-1 text-sm text-white/80 hover:bg-white/5 rounded-lg",
                                    onClick: () => {
                                        s.push("/transfer-miles"), n(!1)
                                    },
                                    children: "Transfer Miles"
                                }), (0, r.jsx)("button", {
                                    className: "flex items-center px-3 py-1 text-sm text-white/80 hover:bg-white/5 rounded-lg",
                                    onClick: async () => {
                                        await i(), n(!1)
                                    },
                                    children: "Sign Out"
                                })]
                            })
                        })]
                    })
                },
                k = () => {
                    let [e, t] = (0, i.useState)(!1);
                    return (0, r.jsx)(P, {
                        isOpen: e,
                        setIsOpen: t,
                        "data-sentry-element": "ProfileButtonOverlay",
                        "data-sentry-component": "ProfileButton",
                        "data-sentry-source-file": "index.tsx",
                        children: (0, r.jsxs)("div", {
                            className: "w-8 h-8 flex items-center justify-center relative",
                            children: [(0, r.jsx)("div", {
                                className: "absolute inset-0 rounded-full border border-white/50 bg-[#101010]"
                            }), (0, r.jsx)(d.EgY, {
                                size: 20,
                                className: "text-white opacity-50",
                                "data-sentry-element": "GoPerson",
                                "data-sentry-source-file": "index.tsx"
                            })]
                        })
                    })
                },
                A = () => {
                    let [e, t] = (0, i.useState)(!1), {
                        data: n,
                        isLoading: a
                    } = y(), {
                        user: l,
                        isAuthenticated: d
                    } = (0, b.A)(), m = (0, u.useRouter)(), {
                        headerContent: p,
                        className: P,
                        containerClassName: A,
                        isExpanded: L
                    } = (0, g.v8)(), {
                        onLandingPage: T
                    } = (0, _.A)(), D = (0, S.A)(), I = (0, j.b2)() && d;
                    return (0, r.jsx)("div", {
                        className: (0, w.cn)("sticky top-0 left-0 right-0 pointer-events-none border-b border-[#636363]/60 bg-[#0D0D0D] z-[1010] transition-all duration-200 h-auto", T && "bg-[#0E0E0E]/45 fixed backdrop-blur-xl", T && !L && (D ? "sm:h-[79px]" : "sm:h-[138px]"), A),
                        style: {
                            top: I ? N.Pb : 0
                        },
                        "data-sentry-component": "Navbar",
                        "data-sentry-source-file": "index.tsx",
                        children: (0, r.jsxs)("div", {
                            className: (0, w.cn)("max-w-7xl mx-auto px-4 sm:py-6 w-full flex justify-between items-center", p && "items-start", T && "sm:pt-5 sm:pb-1", P),
                            children: [(0, r.jsx)("div", {
                                className: (0, w.cn)("pointer-events-auto hidden sm:block", T && "relative top-1.5"),
                                children: (0, r.jsx)(s(), {
                                    href: "/",
                                    className: "flex items-center",
                                    "data-sentry-element": "Link",
                                    "data-sentry-source-file": "index.tsx",
                                    children: (0, r.jsx)(o, {
                                        width: T ? 94 : 78,
                                        height: T ? 33 : 25,
                                        "data-sentry-element": "Logo",
                                        "data-sentry-source-file": "index.tsx"
                                    })
                                })
                            }), (0, r.jsx)("div", {
                                className: "absolute left-1/2 top-[50%] transform -translate-x-1/2 -translate-y-1/2 pointer-events-auto hidden sm:block",
                                children: (0, r.jsx)(E, {
                                    "data-sentry-element": "TopNavLinks",
                                    "data-sentry-source-file": "index.tsx"
                                })
                            }), p && (0, r.jsx)("div", {
                                className: "pointer-events-auto w-full navbar-content-enter",
                                children: p
                            }), (0, r.jsxs)("div", {
                                className: (0, w.cn)("pointer-events-auto hidden sm:block", T && "relative -top-0.5"),
                                children: [(0, r.jsx)("div", {
                                    className: "flex items-center space-x-4",
                                    children: l ? (0, r.jsxs)(r.Fragment, {
                                        children: [(0, r.jsx)("div", {
                                            className: "hidden xl:block",
                                            children: (0, r.jsx)(h.A, {
                                                size: "sm",
                                                xPadding: "double",
                                                onClick: () => m.push("/profile"),
                                                children: a || !n ? (0, r.jsx)("span", {
                                                    className: "inline-block w-[70px] text-center",
                                                    children: (0, r.jsx)(v.A, {
                                                        className: "animate-spin w-4 h-4 inline-block"
                                                    })
                                                }) : (0, r.jsxs)(C.o, {
                                                    className: "whitespace-nowrap text-sm",
                                                    children: [n.balance_available.toLocaleString(), " Miles"]
                                                })
                                            })
                                        }), (0, r.jsx)(k, {})]
                                    }) : T ? (0, r.jsx)("button", {
                                        onClick: () => {
                                            t(!0), (0, x.s)(x.b.SIGN_IN_CLICK)
                                        },
                                        className: "transition-all duration-300 py-2 px-7 rounded-full border border-white/40 bg-solid backdrop-blur-lg bg-transparent hover:bg-white/10 whitespace-nowrap text-base text-white",
                                        children: "Sign up"
                                    }) : (0, r.jsx)(h.A, {
                                        size: "sm",
                                        xPadding: "double",
                                        className: (0, w.cn)(f.q.classes.signIn, "whitespace-nowrap"),
                                        onClick: () => {
                                            t(!0), (0, x.s)(x.b.SIGN_IN_CLICK)
                                        },
                                        children: "Sign up"
                                    })
                                }), (0, r.jsx)(c.H, {
                                    isOpen: e,
                                    onClose: () => t(!1),
                                    "data-sentry-element": "AuthDialog",
                                    "data-sentry-source-file": "index.tsx"
                                })]
                            })]
                        })
                    })
                }
        },
        25950: (e, t, n) => {
            n.d(t, {
                F7: () => d,
                Ri: () => o,
                jT: () => c
            });
            var r = n(95155),
                a = n(8155),
                s = n(20063),
                i = n(12115);
            let l = (0, i.createContext)(void 0),
                o = [{
                    id: "flights",
                    label: "FLIGHTS",
                    paths: {
                        exact: ["/explore", "/flights"],
                        startsWith: ["/search/flights"]
                    },
                    trackingEvent: a.b.FLIGHT_MENU_CLICK,
                    navigationTo: "/explore"
                }, {
                    id: "hotels",
                    label: "HOTELS",
                    paths: {
                        exact: ["/explore/hotels"],
                        startsWith: ["/search/hotels"]
                    },
                    trackingEvent: a.b.HOTELS_MENU_CLICK,
                    navigationTo: "/explore/hotels"
                }, {
                    id: "shopping",
                    label: "SHOPPING",
                    paths: {
                        exact: [],
                        startsWith: ["/shopping"]
                    },
                    trackingEvent: a.b.FLIGHT_MENU_CLICK,
                    navigationTo: "/shopping"
                }],
                c = e => {
                    let {
                        children: t
                    } = e, n = (0, s.usePathname)(), a = (0, i.useMemo)(() => {
                        for (let e of o)
                            if (e.paths.exact.includes(n) || e.paths.startsWith.some(e => n.startsWith(e))) return e.id;
                        return "flights"
                    }, [n]);
                    return (0, r.jsx)(l.Provider, {
                        value: {
                            activeTab: a
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "TabSearchProvider",
                        "data-sentry-source-file": "TabSearchContext.tsx",
                        children: t
                    })
                },
                d = () => {
                    let e = (0, i.useContext)(l);
                    if (!e) throw Error("useTabSearch must be used within a TabSearchProvider");
                    return e
                }
        },
        27497: (e, t, n) => {
            n.d(t, {
                ClientRoot: () => p
            });
            var r = n(95155),
                a = n(77979),
                s = n(53350),
                i = n(6410),
                l = n(71408),
                o = n(56468),
                c = n(20063);
            let d = e => {
                let {
                    children: t
                } = e, n = (0, c.usePathname)(), {
                    onLandingPage: d
                } = (0, o.A)(), u = (0, s.d)("hidden");
                return (0, r.jsx)(i.P.div, {
                    className: (0, a.cn)("flex-grow relative", d && "absolute top-0 left-0 w-full h-full translate-x-0"),
                    style: {
                        overflow: u
                    },
                    "data-sentry-element": "unknown",
                    "data-sentry-component": "PageTransition",
                    "data-sentry-source-file": "PageTransition.tsx",
                    children: (0, r.jsx)(l.N, {
                        mode: "wait",
                        "data-sentry-element": "AnimatePresence",
                        "data-sentry-source-file": "PageTransition.tsx",
                        children: (0, r.jsx)(i.P.main, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: .5
                            },
                            onAnimationStart: () => u.set("hidden"),
                            onAnimationComplete: () => u.set("unset"),
                            className: "relative z-10",
                            "data-sentry-element": "unknown",
                            "data-sentry-source-file": "PageTransition.tsx",
                            children: t
                        }, n)
                    })
                })
            };
            var u = n(12115),
                h = n(27122);
            let m = e => {
                (0, u.useEffect)(() => {
                    var t, n;
                    if (!e) return void h.gV(null);
                    h.gV({
                        userId: e.id,
                        name: (null == (t = e.user_metadata) ? void 0 : t.first_name) ? "".concat(e.user_metadata.first_name, " ").concat((null == (n = e.user_metadata) ? void 0 : n.last_name) || "") : e.email
                    })
                }, [e])
            };
            var x = n(980),
                f = n(75329);

            function p(e) {
                let {
                    user: t,
                    children: n
                } = e;
                return (0, u.useEffect)(() => {
                    var e, n, r, a;
                    t && window.Atlas && window.Atlas.call("identify", {
                        userId: t.id,
                        name: (null == (e = t.user_metadata) ? void 0 : e.first_name) ? "".concat(t.user_metadata.first_name, " ").concat((null == (n = t.user_metadata) ? void 0 : n.last_name) || "") : t.email,
                        email: t.email ? t.email : null == (r = t.user_metadata) ? void 0 : r.email,
                        phone: t.phone ? t.phone : null == (a = t.user_metadata) ? void 0 : a.phone
                    })
                }, [t]), m(t), (0, x.A)(t), (0, u.useEffect)(() => {
                    var e, n;
                    t && window.ttq && window.ttq.identify({
                        external_id: t.id,
                        email: t.email || (null == (e = t.user_metadata) ? void 0 : e.email) || "",
                        phone_number: t.phone || (null == (n = t.user_metadata) ? void 0 : n.phone) || ""
                    })
                }, [t]), (0, u.useEffect)(() => {
                    var e, n;
                    t && window.rdt && window.rdt("init", f.A.NEXT_PUBLIC_REDDIT_PIXEL_ID, {
                        email: t.email || (null == (e = t.user_metadata) ? void 0 : e.email) || "",
                        phoneNumber: t.phone || (null == (n = t.user_metadata) ? void 0 : n.phone) || "",
                        externalId: t.id
                    })
                }, [t]), (0, r.jsx)(d, {
                    "data-sentry-element": "PageTransition",
                    "data-sentry-component": "ClientRoot",
                    "data-sentry-source-file": "_clientRoot.tsx",
                    children: n
                })
            }
        },
        31475: (e, t, n) => {
            n.d(t, {
                AM: () => c,
                Wv: () => d,
                hl: () => u
            });
            var r = n(95155),
                a = n(12115),
                s = n(505),
                i = n(71408),
                l = n(6410),
                o = n(64269);
            let c = s.bL,
                d = s.l9;
            s.Mz;
            let u = a.forwardRef((e, t) => {
                let {
                    className: n,
                    align: a = "center",
                    sideOffset: c = 4,
                    ...d
                } = e;
                return (0, r.jsx)(s.ZL, {
                    children: (0, r.jsx)(i.N, {
                        children: (0, r.jsx)(s.UC, {
                            ref: t,
                            align: a,
                            sideOffset: c,
                            asChild: !0,
                            ...d,
                            children: (0, r.jsx)(l.P.div, {
                                initial: {
                                    opacity: 0,
                                    scale: .95
                                },
                                animate: {
                                    opacity: 1,
                                    scale: 1
                                },
                                exit: {
                                    opacity: 0,
                                    scale: .95
                                },
                                transition: {
                                    duration: .2,
                                    ease: "easeOut"
                                },
                                className: (0, o.cn)("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none", n),
                                children: d.children
                            })
                        })
                    })
                })
            });
            u.displayName = s.UC.displayName
        },
        34217: (e, t, n) => {
            n.d(t, {
                q: () => r
            });
            let r = {
                classes: {
                    signIn: "sign-in",
                    hotelSearchButton: "hotel-search-button",
                    flightSearchButton: "flight-search-button"
                },
                "data-sentry": {
                    hotelSearchCard: "HotelSearchCard",
                    flightDealCard: "FlightDealCard",
                    earnShoppingCard: "EarnShoppingCard"
                }
            }
        },
        42953: (e, t, n) => {
            n.d(t, {
                A: () => i
            });
            var r = n(49474),
                a = n(20063),
                s = n(12115);
            let i = () => {
                let [e, t] = (0, s.useState)(!1), {
                    isMobile: n
                } = (0, r.l)(), i = (0, a.usePathname)();
                return (0, s.useEffect)(() => {
                    let e = () => {
                        if (n || "/shopping" === i) return;
                        let e = window.scrollY,
                            r = .85 * window.innerHeight,
                            a = .95 * window.innerHeight;
                        e > r && e < a || t(e > .9 * window.innerHeight)
                    };
                    return window.addEventListener("scroll", e), e(), () => window.removeEventListener("scroll", e)
                }, [n, i]), e
            }
        },
        49474: (e, t, n) => {
            n.d(t, {
                WindowSizeProvider: () => l,
                l: () => o
            });
            var r = n(95155),
                a = n(12115);
            let s = (e, t) => {
                    let n, r, a = !1;
                    return function() {
                        for (var s = arguments.length, i = Array(s), l = 0; l < s; l++) i[l] = arguments[l];
                        a ? (clearTimeout(n), n = setTimeout(() => {
                            Date.now() - r >= t && (e.apply(this, i), r = Date.now())
                        }, t - (Date.now() - r))) : (e.apply(this, i), r = Date.now(), a = !0, setTimeout(() => {
                            a = !1
                        }, t))
                    }
                },
                i = (0, a.createContext)(void 0);

            function l(e) {
                let {
                    children: t
                } = e, [n, l] = (0, a.useState)({
                    width: void 0,
                    height: void 0
                }), o = !!(n.width && n.width < 640), c = !!(n.width && n.width < 768), d = (0, a.useCallback)(() => {
                    l({
                        width: window.innerWidth,
                        height: window.innerHeight
                    })
                }, []);
                return (0, a.useEffect)(() => {
                    let e = s(d, 100);
                    return window.addEventListener("resize", e, {
                        passive: !0
                    }), d(), () => window.removeEventListener("resize", e)
                }, [d]), (0, r.jsx)(i.Provider, {
                    value: {
                        windowSize: n,
                        isMobile: o,
                        isMedium: c
                    },
                    "data-sentry-element": "unknown",
                    "data-sentry-component": "WindowSizeProvider",
                    "data-sentry-source-file": "useWindowSize.tsx",
                    children: t
                })
            }

            function o() {
                let e = (0, a.useContext)(i);
                if (void 0 === e) throw Error("useWindowSize must be used within a WindowSizeProvider");
                return e
            }
        },
        56041: (e, t, n) => {
            n.d(t, {
                J2: () => s,
                Pb: () => a,
                W9: () => i
            });
            var r = n(11607);
            let a = 56,
                s = "--banner-height",
                i = r.y ? "var(".concat(s, ", ").concat(a, "px)") : "0"
        },
        56468: (e, t, n) => {
            n.d(t, {
                A: () => a
            });
            var r = n(20063);
            let a = () => ({
                onLandingPage: "/" === (0, r.usePathname)()
            })
        },
        57739: (e, t, n) => {
            n.d(t, {
                default: () => d
            });
            var r = n(95155),
                a = n(56041),
                s = n(38728),
                i = n(12115),
                l = n(25950),
                o = n(80285);
            let c = e => {
                    let {
                        children: t
                    } = e, n = (0, o.b2)(), {
                        user: l
                    } = (0, s.A)(), [c, d] = (0, i.useState)(!1);
                    (0, i.useEffect)(() => {
                        d(!0)
                    }, []);
                    let u = "var(".concat(a.J2, ", ").concat(a.Pb, "px)");
                    return (0, r.jsx)("div", {
                        className: "flex flex-col relative",
                        style: c && l ? {
                            marginTop: n ? u : "0",
                            minHeight: n ? "calc(100dvh - ".concat(u, ")") : "100dvh",
                            transition: "margin-top 0.3s ease-in-out, min-height 0.3s ease-in-out, height 0.3s ease-in-out, top 0.3s ease-in-out"
                        } : {
                            minHeight: "100dvh"
                        },
                        "data-sentry-component": "LayoutWrapperInner",
                        "data-sentry-source-file": "layout-wrapper.tsx",
                        children: t
                    })
                },
                d = e => {
                    let {
                        children: t
                    } = e;
                    return (0, r.jsx)(s.O, {
                        "data-sentry-element": "AuthProvider",
                        "data-sentry-component": "LayoutWrapper",
                        "data-sentry-source-file": "layout-wrapper.tsx",
                        children: (0, r.jsx)(l.jT, {
                            "data-sentry-element": "TabSearchProvider",
                            "data-sentry-source-file": "layout-wrapper.tsx",
                            children: (0, r.jsx)(c, {
                                "data-sentry-element": "LayoutWrapperInner",
                                "data-sentry-source-file": "layout-wrapper.tsx",
                                children: t
                            })
                        })
                    })
                }
        },
        77979: (e, t, n) => {
            n.d(t, {
                cn: () => s
            });
            var r = n(75889),
                a = n(2821);

            function s() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return (0, r.QP)((0, a.$)(t))
            }
        },
        78698: (e, t, n) => {
            n.d(t, {
                H: () => $
            });
            var r = n(95155),
                a = n(12115),
                s = n(30926);
            let i = (0, s.createServerReference)("60b36d046e64691ff85af4263a22eed807627a0de3", s.callServer, void 0, s.findSourceMapURL, "loginWithPhone");
            var l = n(48904),
                o = n(51849),
                c = n(18125),
                d = n(64269),
                u = n(59007),
                h = n(90109),
                m = n(26615),
                x = n(15653),
                f = n(91242),
                p = n(13213);
            x.z.object({
                code: x.z.string(),
                dial_code: x.z.string(),
                name: x.z.string()
            });
            let y = (() => {
                    let e = (0, f.X)().map(e => ({
                            code: e,
                            dial_code: "+".concat((0, p.K)(e)),
                            name: new Intl.DisplayNames(["en"], {
                                type: "region"
                            }).of(e) || e
                        })),
                        t = e.find(e => "US" === e.code),
                        n = e.find(e => "CA" === e.code),
                        r = e.find(e => "GB" === e.code);
                    return [...t ? [t] : [], ...n ? [n] : [], ...r ? [r] : [], ...e.filter(e => "US" !== e.code && "CA" !== e.code && "GB" !== e.code).sort((e, t) => e.name.localeCompare(t.name))]
                })(),
                v = e => {
                    let {
                        value: t,
                        onChange: n,
                        className: s,
                        label: i,
                        labelClassName: l
                    } = e, [o, c] = (0, a.useState)(!1), [x, f] = (0, a.useState)(""), [p, v] = (0, a.useState)(!1), b = (0, a.useRef)(null), g = (0, a.useRef)(null), w = y.find(e => e.dial_code === t) || y.find(e => "US" === e.code) || y[0], j = y.filter(e => e.name.toLowerCase().includes(x.toLowerCase()) || e.dial_code.includes(x) || e.code.toLowerCase().includes(x.toLowerCase())), N = e => {
                        n(e), c(!1), f("")
                    };
                    (0, a.useEffect)(() => {
                        let e = e => {
                            b.current && !b.current.contains(e.target) && (c(!1), v(!1), f(""))
                        };
                        return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e)
                    }, []);
                    let C = !!i && (p || o || !!t);
                    return (0, r.jsxs)("div", {
                        className: (0, d.cn)("relative", s),
                        ref: b,
                        "data-sentry-component": "CountryCodeSelector",
                        "data-sentry-source-file": "CountryCodeSelector.tsx",
                        children: [(0, r.jsxs)("button", {
                            type: "button",
                            onClick: () => {
                                c(!o), v(!o), o || setTimeout(() => {
                                    var e;
                                    null == (e = g.current) || e.focus()
                                }, 10)
                            },
                            className: "flex items-center justify-between min-w-[80px] h-[54px] bg-[#111] rounded-xl px-3 border border-[#4B4B4B6B] focus:outline-none focus:ring-1 focus:border-[#4b4b4bb3] focus:ring-[#4b4b4bb3] text-white text-sm",
                            children: [(0, r.jsx)("div", {
                                className: "flex flex-1 items-center",
                                children: (0, r.jsx)("span", {
                                    className: (0, d.cn)(C && "pt-3"),
                                    children: w.dial_code
                                })
                            }), (0, r.jsx)(u.A, {
                                className: "w-4 h-4 text-white/50 ml-1 flex-shrink-0 mt-3",
                                "data-sentry-element": "ChevronDown",
                                "data-sentry-source-file": "CountryCodeSelector.tsx"
                            })]
                        }), !!i && (0, r.jsx)("label", {
                            className: (0, d.cn)("absolute left-3 transition-all duration-200 pointer-events-none text-white/50 ".concat(C ? "top-2 text-[9px]" : "top-4 text-sm"), l),
                            children: i
                        }), o && (0, r.jsxs)("div", {
                            className: "absolute z-50 top-full left-0 mt-1 w-[240px] max-h-[320px] flex flex-col bg-[#111] border border-[#4B4B4B6B] rounded-xl overflow-hidden shadow-lg",
                            children: [(0, r.jsx)("div", {
                                className: "p-2 border-b border-[#4B4B4B6B]",
                                children: (0, r.jsxs)("div", {
                                    className: "relative",
                                    children: [(0, r.jsx)("input", {
                                        ref: g,
                                        type: "text",
                                        value: x,
                                        onChange: e => f(e.target.value),
                                        placeholder: "Search country",
                                        className: "w-full bg-[#222] rounded-lg px-9 py-2 text-sm text-white border-none focus:outline-none"
                                    }), (0, r.jsx)(h.A, {
                                        className: "absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-white/50"
                                    }), x && (0, r.jsx)("button", {
                                        type: "button",
                                        onClick: () => f(""),
                                        className: "absolute right-2 top-1/2 -translate-y-1/2",
                                        children: (0, r.jsx)(m.A, {
                                            className: "w-4 h-4 text-white/50"
                                        })
                                    })]
                                })
                            }), (0, r.jsx)("div", {
                                className: "overflow-y-auto scrollbar-thin scrollbar-thumb-[#333] scrollbar-track-transparent hover:scrollbar-thumb-[#444]",
                                children: j.length > 0 ? j.map(e => (0, r.jsxs)("button", {
                                    type: "button",
                                    onClick: () => N(e.dial_code),
                                    className: (0, d.cn)("w-full px-4 py-2 text-left hover:bg-[#222] transition-colors flex items-center space-x-2"),
                                    children: [(0, r.jsx)("span", {
                                        className: "text-xs w-8",
                                        children: e.dial_code
                                    }), (0, r.jsx)("span", {
                                        className: "text-sm",
                                        children: e.name
                                    })]
                                }, e.code)) : (0, r.jsx)("div", {
                                    className: "px-4 py-3 text-sm text-white/50 text-center",
                                    children: "No countries found"
                                })
                            })]
                        })]
                    })
                };
            var b = n(81264),
                g = n(52619),
                w = n.n(g);
            let j = x.z.object({
                    phone: x.z.string().min(1, "Phone number is required"),
                    countryCode: x.z.string().min(1, "Country code is required")
                }),
                N = ["+1"],
                C = e => {
                    let {
                        onShowOtp: t,
                        setBetaCode: n,
                        betaCode: s,
                        onClose: u
                    } = e, [h, m] = (0, a.useState)(""), [x, f] = (0, a.useState)("+1"), [p, y] = (0, a.useState)(!1), [g, C] = (0, a.useState)(""), [S, _] = (0, a.useState)(!1), [E, P, k] = (0, a.useActionState)(async () => {
                        try {
                            let e = j.safeParse({
                                phone: h,
                                countryCode: x
                            });
                            if (!e.success) return e.error.errors[0].message;
                            if (!N.includes(x)) return "Sorry, Rove Miles isn't supported in your country yet.";
                            if (p && !s) return "Invite code is required";
                            let n = "".concat(x).concat(h.replace(/\D/g, "")),
                                r = await i(n, s);
                            if (null == r ? void 0 : r.error) return r.error;
                            return (null == r ? void 0 : r.success) && (b.o.success("Verification code sent"), t(n)), null
                        } catch (e) {
                            return console.error("Error in phone form submission:", e), "An unexpected error occurred. Please try again."
                        }
                    }, null), A = e => {
                        let t = e.replace(/(?!^\+)\D/g, "").replace(/\D/g, ""),
                            n = "",
                            r = 0;
                        if (t.length > r) {
                            let e = t.slice(r, r + 3);
                            if (e && (n += "(".concat(e), r += 3), t.length > r) {
                                let e = t.slice(r, r + 3);
                                e && (n += ") ".concat(e), r += 3)
                            }
                            if (t.length > r) {
                                let e = t.slice(r, r + 4);
                                e && (n += "-".concat(e))
                            }
                        }
                        return n
                    }, L = "+1" === x, T = async e => {
                        e.preventDefault();
                        try {
                            _(!0);
                            let e = await fetch("/api/newsletter/register", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify({
                                        email: g,
                                        tags: [x]
                                    })
                                }),
                                r = await e.json();
                            if (!e.ok) {
                                var t, n;
                                let e = (null == (n = r.details) || null == (t = n[0]) ? void 0 : t.message) || r.error || "Email submission failed";
                                b.o.error(e);
                                return
                            }
                            C(""), u(), b.o.success("Email submitted successfully.")
                        } catch (e) {
                            b.o.error("Email submission failed. Please try again.")
                        } finally {
                            _(!1)
                        }
                    };
                    return (0, r.jsxs)("form", {
                        action: P,
                        className: "flex flex-col",
                        "data-sentry-component": "PhoneForm",
                        "data-sentry-source-file": "PhoneForm.tsx",
                        children: [(0, r.jsxs)("div", {
                            className: (0, d.cn)("flex items-start", p || !L ? "mb-2" : "mb-9"),
                            children: [(0, r.jsx)(v, {
                                value: x,
                                onChange: e => {
                                    f(e), y(!1)
                                },
                                className: "mr-2",
                                label: "Country Code",
                                "data-sentry-element": "CountryCodeSelector",
                                "data-sentry-source-file": "PhoneForm.tsx"
                            }), (0, r.jsx)(l.A, {
                                label: "Phone Number",
                                type: "text",
                                name: "phone",
                                value: h,
                                onChange: e => {
                                    y(!1);
                                    let t = e.target.value.replace(/\D/g, "");
                                    "+1" === x ? m(A(t)) : m(t)
                                },
                                className: "flex-1",
                                inputMode: "numeric",
                                autoComplete: "off",
                                autoFocus: !0,
                                disabled: !L,
                                "data-sentry-element": "FloatingLabelInput",
                                "data-sentry-source-file": "PhoneForm.tsx"
                            })]
                        }), !L && (0, r.jsxs)("div", {
                            className: "flex flex-col",
                            children: [(0, r.jsx)("p", {
                                className: "text-xs text-white/50 mb-2",
                                children: "Rove Miles isn't available in your country yet, but we're expanding soon! Enter your email and we'll notify you when we launch in your region."
                            }), (0, r.jsx)(l.A, {
                                label: "Email",
                                name: "email",
                                value: g,
                                onChange: e => C(e.target.value),
                                className: "mb-4"
                            }), (0, r.jsx)(o.A, {
                                isLoading: S,
                                className: "self-center",
                                onClick: T,
                                children: "Submit"
                            })]
                        }), p && (0, r.jsx)(l.A, {
                            label: "Invite Code",
                            name: "betaCode",
                            value: s,
                            onChange: e => n(e.target.value),
                            className: "mb-9"
                        }), E && (0, r.jsx)(c.y1, {
                            className: "mb-2 self-center",
                            children: E
                        }), L && (0, r.jsx)(o.A, {
                            type: "submit",
                            isLoading: k,
                            className: "self-center",
                            children: k ? "Sending code..." : "Continue"
                        }), (0, r.jsxs)("p", {
                            className: "text-xs text-center text-white/30 mt-5 mx-auto",
                            children: ['By clicking "Continue" you agree to the Rove Miles', " ", (0, r.jsx)(w(), {
                                href: "/terms-of-use",
                                className: "underline hover:text-white/50 whitespace-nowrap",
                                target: "_blank",
                                "data-sentry-element": "Link",
                                "data-sentry-source-file": "PhoneForm.tsx",
                                children: "Platform Terms of Use"
                            }), ",", " ", (0, r.jsx)(w(), {
                                href: "/privacy-policy",
                                className: "underline hover:text-white/50 whitespace-nowrap",
                                target: "_blank",
                                "data-sentry-element": "Link",
                                "data-sentry-source-file": "PhoneForm.tsx",
                                children: "Privacy Policy"
                            }), ", and", " ", (0, r.jsx)(w(), {
                                href: "/program-terms",
                                className: "underline hover:text-white/50 whitespace-nowrap",
                                target: "_blank",
                                "data-sentry-element": "Link",
                                "data-sentry-source-file": "PhoneForm.tsx",
                                children: "Rewards Program Terms & Conditions"
                            }), ". Rates may apply to messages, which may be sent by an automated system. Reply STOP to opt out; Reply HELP for help; Message frequency varies; Message and data rates may apply."]
                        })]
                    })
                };
            var S = n(12710);
            let _ = (e, t, n) => e.substring(0, t) + n + e.substring(t + n.length),
                E = "      ",
                P = (0, S.tv)({
                    base: "w-full sm:w-16 h-[64px] sm:h-[72px] bg-transparent text-center text-white border rounded-lg focus:outline-none text-2xl",
                    variants: {
                        variant: {
                            default: "border-white/10 focus:border-white/30",
                            error: "border-[#F7706433] focus:border-[#F7706433]"
                        }
                    }
                }),
                k = e => {
                    let {
                        value: t,
                        onChange: n,
                        disabled: s,
                        variant: i = "default",
                        autoFocus: l = !1
                    } = e, o = (0, a.useRef)([]), c = (e, r) => {
                        if (/^\d*$/.test(r)) {
                            if (6 === r.length) return void n(r);
                            if (n(_(t || E, e, r || " ")), "" !== r && e < 5) {
                                var a;
                                null == (a = o.current[e + 1]) || a.focus()
                            }
                        }
                    }, d = (e, t) => {
                        if ("Backspace" === t.key && "" === h[e] && e > 0) {
                            var n;
                            null == (n = o.current[e - 1]) || n.focus()
                        }
                    }, u = e => {
                        var t;
                        e.preventDefault();
                        let r = e.clipboardData.getData("text").slice(0, 6).split(""),
                            a = E;
                        r.forEach((e, t) => {
                            t < 6 && /^\d$/.test(e) && (a = _(a, t, e))
                        }), n(a), null == (t = o.current[Math.min(r.length, 5)]) || t.focus()
                    }, h = (t || E).split("").map(e => " " === e ? "" : e);
                    return (0, r.jsx)("div", {
                        className: "flex justify-center gap-2 sm:gap-4",
                        "data-sentry-component": "PinInput",
                        "data-sentry-source-file": "PinInput.tsx",
                        children: h.map((e, t) => (0, r.jsx)("input", {
                            ref: e => {
                                o.current[t] = e
                            },
                            type: "text",
                            inputMode: "numeric",
                            maxLength: 6,
                            value: e,
                            onChange: e => c(t, e.target.value),
                            onKeyDown: e => d(t, e),
                            onPaste: u,
                            className: P({
                                variant: i
                            }),
                            disabled: s,
                            autoFocus: l && 0 === t,
                            autoComplete: "one-time-code"
                        }, t))
                    })
                },
                A = (0, s.createServerReference)("406c755f1eed5f99bb69c7d209f9344d80c77d70dc", s.callServer, void 0, s.findSourceMapURL, "verifyOtp");
            var L = n(61464),
                T = n(20063),
                D = n(83693),
                I = n.n(D),
                R = n(92033);
            let B = (0, s.createServerReference)("7fa8ee5a5759985ea0459125b1daca8f4c0f789b6d", s.callServer, void 0, s.findSourceMapURL, "getReferralCodeCookie"),
                z = (0, s.createServerReference)("7fc4a01c68b597bd74b3bb6bf6fd3594618e9e5c56", s.callServer, void 0, s.findSourceMapURL, "deleteReferralCodeCookie");
            var F = n(8155),
                M = n(980),
                O = n(85163);
            let U = {
                SIGN_UP: "SignUp"
            };
            var H = n(99776);
            let W = x.z.object({
                    pin: x.z.string().min(6, "Verification code must be 6 digits").max(6, "Verification code must be 6 digits")
                }),
                G = e => {
                    let {
                        initialData: t,
                        onSignedIn: n,
                        onBack: s,
                        betaCode: l,
                        referralCode: o
                    } = e, [d, u] = (0, a.useState)(""), h = a.useRef(null), [m, x] = (0, a.useState)(0), [f, p] = (0, a.useState)(!1), y = (0, L.T)(), v = (0, T.useRouter)(), {
                        trackMixPanelEvent: g
                    } = (0, M.s)(), w = (0, H.jE)(), [j, N, C] = (0, a.useActionState)(async () => {
                        try {
                            let a = W.safeParse({
                                pin: d
                            });
                            if (!a.success) return a.error.errors[0].message;
                            if (!(null == t ? void 0 : t.phone)) return "Phone number is missing";
                            let s = o;
                            s || (s = await B());
                            let i = await A({
                                phone: t.phone,
                                code: d,
                                referralCode: s
                            });
                            if (null == i ? void 0 : i.error) return i.error;
                            if (null == i ? void 0 : i.success) {
                                if (await w.invalidateQueries({
                                        queryKey: ["auth", "user"]
                                    }), "signup" === i.status) {
                                    var e, r;
                                    s && i.referralCodeUserId && g(O.$.REFERRAL_USED, {
                                        referral_code: s,
                                        referral_user_id: i.referralCodeUserId
                                    }), (0, F.s)(F.b.SIGN_UP_SUCCESS, {
                                        tt_user_id: i.userId,
                                        value: 0,
                                        currency: "USD",
                                        tt_contents: JSON.stringify([{
                                            id: "signup",
                                            type: "registration"
                                        }]),
                                        event_id: "signup_" + Date.now()
                                    }), window.fbq && window.fbq("track", "CompleteRegistration", void 0), window.ttq && window.ttq.track("CompleteRegistration", {
                                        content_type: "registration",
                                        content_id: "signup",
                                        value: .01,
                                        currency: "USD"
                                    }), e = U.SIGN_UP, r = {
                                        value: 0,
                                        currency: "USD"
                                    }, window.rdt && window.rdt("track", e, r)
                                }
                                return i.userId && (g(O.$.USER_LOGGED_IN, {
                                    user_id: i.userId
                                }), i.isUserReturned && null !== i.daysSinceLastVisit && g(O.$.USER_RETURNED, {
                                    user_id: i.userId,
                                    days_since_last_visit: i.daysSinceLastVisit
                                })), await z(), b.o.success("Successfully verified"), n(), y && v.push(y), null
                            }
                            return "Verification failed"
                        } catch (e) {
                            return console.error("Error in OTP verification:", e), "An unexpected error occurred. Please try again."
                        }
                    }, null);
                    (0, a.useEffect)(() => {
                        6 === d.replaceAll(" ", "").length && h.current && h.current.dispatchEvent(new Event("submit", {
                            cancelable: !0,
                            bubbles: !0
                        }))
                    }, [d]), (0, a.useEffect)(() => {
                        let e;
                        return m > 0 ? (p(!0), e = setTimeout(() => {
                            x(m - 1)
                        }, 1e3)) : p(!1), () => {
                            e && clearTimeout(e)
                        }
                    }, [m]);
                    let S = (0, a.useCallback)(async () => {
                            if (null == t ? void 0 : t.phone) try {
                                let e = await i(t.phone, l);
                                (null == e ? void 0 : e.error) ? b.o.error(e.error): (b.o.success("Verification code resent"), x(60))
                            } catch (e) {
                                console.error("Error in OTP resend:", e), b.o.error("Failed to resend code. Please try again.")
                            }
                        }, [null == t ? void 0 : t.phone, l]),
                        _ = (0, a.useMemo)(() => I()(S, 1e3, {
                            leading: !0,
                            trailing: !1
                        }), [S]);
                    return (0, r.jsxs)("form", {
                        ref: h,
                        action: N,
                        className: "flex flex-col relative",
                        "data-sentry-component": "OtpForm",
                        "data-sentry-source-file": "OtpForm.tsx",
                        children: [(0, r.jsx)(k, {
                            value: d,
                            onChange: u,
                            disabled: C,
                            variant: j && !C ? "error" : "default",
                            autoFocus: !0,
                            "data-sentry-element": "PinInput",
                            "data-sentry-source-file": "OtpForm.tsx"
                        }), j && !C && (0, r.jsx)(c.y1, {
                            className: "mb-2 mt-2 self-center",
                            children: j
                        }), C && (0, r.jsx)("div", {
                            className: "absolute inset-0 w-full h-full flex justify-center items-center",
                            children: (0, r.jsx)(R.A, {
                                className: "w-12 h-12 text-white/90 animate-spin"
                            })
                        }), (0, r.jsxs)("p", {
                            className: "text-sm text-white/30 font-normal self-center mt-8",
                            children: ["Wrong phone number?", " ", (0, r.jsx)("span", {
                                className: "text-white/30 underline hover:text-white/50 transition-colors cursor-pointer",
                                onClick: s,
                                children: "Update it here"
                            }), "."]
                        }), (0, r.jsx)("div", {
                            className: "text-center mt-6",
                            children: f ? (0, r.jsxs)("p", {
                                className: "text-white/30 text-sm",
                                children: ["Resend code available in ", (e => {
                                    let t = Math.floor(e / 60),
                                        n = e % 60;
                                    return "".concat(t, ":").concat(n < 10 ? "0" : "").concat(n)
                                })(m)]
                            }) : (0, r.jsx)("p", {
                                className: "underline hover:text-white/50 transition-colors text-white/30 text-sm cursor-pointer",
                                onClick: _,
                                children: "Resend Code"
                            })
                        })]
                    })
                };
            var q = n(16244);
            let V = e => {
                let {
                    isOpen: t,
                    onClose: n,
                    title: a,
                    subtitle: s,
                    children: i
                } = e;
                return (0, r.jsx)(q.lG, {
                    open: t,
                    onOpenChange: n,
                    "data-sentry-element": "Dialog",
                    "data-sentry-component": "AuthDialogContainer",
                    "data-sentry-source-file": "AuthDialogContainer.tsx",
                    children: (0, r.jsxs)(q.Cf, {
                        className: "rounded-lg",
                        closeButton: !1,
                        "data-sentry-element": "DialogContent",
                        "data-sentry-source-file": "AuthDialogContainer.tsx",
                        children: [(0, r.jsx)(q.c7, {
                            "data-sentry-element": "DialogHeader",
                            "data-sentry-source-file": "AuthDialogContainer.tsx",
                            children: (0, r.jsxs)(q.L3, {
                                className: "text-white mb-8 font-normal",
                                "data-sentry-element": "DialogTitle",
                                "data-sentry-source-file": "AuthDialogContainer.tsx",
                                children: [(0, r.jsxs)("div", {
                                    className: "mb-1.5 text-white/80 flex justify-between",
                                    children: [a && (0, r.jsx)("span", {
                                        children: a
                                    }), (0, r.jsx)(q.De, {
                                        "data-sentry-element": "DialogCloseButton",
                                        "data-sentry-source-file": "AuthDialogContainer.tsx"
                                    })]
                                }), s && (0, r.jsx)("p", {
                                    className: "text-sm text-white/40",
                                    children: s
                                })]
                            })
                        }), i]
                    })
                })
            };
            var K = n(24135);
            let $ = e => {
                let {
                    isOpen: t,
                    onClose: n
                } = e, s = (0, T.useSearchParams)(), i = (0, K.rN)(s), [l, o] = (0, a.useState)(null), [c, d] = (0, a.useState)(""), u = (0, H.jE)();
                return (0, a.useEffect)(() => {
                    t ? o({
                        type: "phone",
                        title: "Free travel is one step away",
                        subtitle: "Sign in or register with your phone number. This process takes under 30 seconds."
                    }) : o(null)
                }, [t]), (0, r.jsxs)(V, {
                    isOpen: t,
                    onClose: n,
                    title: null == l ? void 0 : l.title,
                    subtitle: null == l ? void 0 : l.subtitle,
                    "data-sentry-element": "AuthDialogContainer",
                    "data-sentry-component": "AuthDialog",
                    "data-sentry-source-file": "AuthDialog.tsx",
                    children: [(null == l ? void 0 : l.type) === "phone" && (0, r.jsx)(C, {
                        betaCode: c,
                        setBetaCode: d,
                        onShowOtp: e => o({
                            type: "otp",
                            initialData: {
                                phone: e
                            },
                            title: "Verification Code",
                            subtitle: "Enter the 6-digit code sent to your phone."
                        }),
                        onClose: n
                    }), (null == l ? void 0 : l.type) === "otp" && (0, r.jsx)(G, {
                        betaCode: c,
                        referralCode: i || void 0,
                        initialData: l.initialData,
                        onSignedIn: async () => {
                            n(), await u.invalidateQueries({
                                queryKey: ["miles"]
                            })
                        },
                        onBack: () => {
                            o({
                                type: "phone",
                                title: "Free travel is one step away",
                                subtitle: "Sign in or register with your phone number. This process takes under 30 seconds."
                            })
                        }
                    })]
                })
            }
        },
        80285: (e, t, n) => {
            n.d(t, {
                ReferralBanner: () => o,
                b2: () => l
            });
            var r = n(95155),
                a = n(15218);
            n(11607), n(56041);
            var s = n(20063);
            let i = new Set(["/", "/about", "/explore", "/explore/hotels", "/profile", "/shopping", "/transfer-miles"]),
                l = () => {
                    let e = (0, s.usePathname)();
                    return i.has(e)
                },
                o = e => {
                    let {
                        onHeightChange: t
                    } = e;
                    return l() ? (0, r.jsx)(a.lZ, {
                        message: "Give 500 miles, get 500 miles + 10% of the miles they earn—",
                        linkText: "invite a friend ",
                        linkUrl: "/profile?referral",
                        trailingMessage: "to Rove and start earning together. Ends 6/30.",
                        onHeightChange: e => {
                            null == t || t(e)
                        },
                        "data-sentry-element": "Banner",
                        "data-sentry-component": "ReferralBanner",
                        "data-sentry-source-file": "ReferralBanner.tsx"
                    }) : null
                }
        }
    }
]);