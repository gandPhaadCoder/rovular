! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "de22219b-ab38-4243-85e3-a1c2aa31373f", e._sentryDebugIdIdentifier = "sentry-dbid-de22219b-ab38-4243-85e3-a1c2aa31373f")
    } catch (e) {}
}(), (() => {
    "use strict";
    var e = {},
        t = {};

    function r(n) {
        var o = t[n];
        if (void 0 !== o) return o.exports;
        var a = t[n] = {
                id: n,
                loaded: !1,
                exports: {}
            },
            i = !0;
        try {
            e[n].call(a.exports, a, a.exports, r), i = !1
        } finally {
            i && delete t[n]
        }
        return a.loaded = !0, a.exports
    }
    r.m = e, (() => {
        var e = [];
        r.O = (t, n, o, a) => {
            if (n) {
                a = a || 0;
                for (var i = e.length; i > 0 && e[i - 1][2] > a; i--) e[i] = e[i - 1];
                e[i] = [n, o, a];
                return
            }
            for (var d = 1 / 0, i = 0; i < e.length; i++) {
                for (var [n, o, a] = e[i], l = !0, s = 0; s < n.length; s++)(!1 & a || d >= a) && Object.keys(r.O).every(e => r.O[e](n[s])) ? n.splice(s--, 1) : (l = !1, a < d && (d = a));
                if (l) {
                    e.splice(i--, 1);
                    var u = o();
                    void 0 !== u && (t = u)
                }
            }
            return t
        }
    })(), r.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, {
            a: t
        }), t
    }, (() => {
        var e, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__;
        r.t = function(n, o) {
            if (1 & o && (n = this(n)), 8 & o || "object" == typeof n && n && (4 & o && n.__esModule || 16 & o && "function" == typeof n.then)) return n;
            var a = Object.create(null);
            r.r(a);
            var i = {};
            e = e || [null, t({}), t([]), t(t)];
            for (var d = 2 & o && n;
                "object" == typeof d && !~e.indexOf(d); d = t(d)) Object.getOwnPropertyNames(d).forEach(e => i[e] = () => n[e]);
            return i.default = () => n, r.d(a, i), a
        }
    })(), r.d = (e, t) => {
        for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, {
            enumerable: !0,
            get: t[n]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce((t, n) => (r.f[n](e, t), t), [])), r.u = e => 5600 === e ? "static/chunks/05f6971a-6423ea66bbb7a427.js" : 3531 === e ? "static/chunks/3531-87abf34c20123ddb.js" : "static/chunks/" + (({
        12: "profiler",
        9204: "94730671",
        9777: "recorder"
    })[e] || e) + "." + ({
        12: "3894995125fd9087",
        1438: "20f7c7ae42535a23",
        5498: "78f16c318b153d73",
        6793: "9b2c727372e91ff9",
        9204: "bf8540a4bec86598",
        9777: "651f6eb2da4ed371",
        9911: "a4f53982ed13ea33"
    })[e] + ".js", r.miniCssF = e => "static/css/718ee59ff2172a97.css", r.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
        var e = {},
            t = "_N_E:";
        r.l = (n, o, a, i) => {
            if (e[n]) return void e[n].push(o);
            if (void 0 !== a)
                for (var d, l, s = document.getElementsByTagName("script"), u = 0; u < s.length; u++) {
                    var f = s[u];
                    if (f.getAttribute("src") == n || f.getAttribute("data-webpack") == t + a) {
                        d = f;
                        break
                    }
                }
            d || (l = !0, (d = document.createElement("script")).charset = "utf-8", d.timeout = 120, r.nc && d.setAttribute("nonce", r.nc), d.setAttribute("data-webpack", t + a), d.src = r.tu(n)), e[n] = [o];
            var c = (t, r) => {
                    d.onerror = d.onload = null, clearTimeout(p);
                    var o = e[n];
                    if (delete e[n], d.parentNode && d.parentNode.removeChild(d), o && o.forEach(e => e(r)), t) return t(r)
                },
                p = setTimeout(c.bind(null, void 0, {
                    type: "timeout",
                    target: d
                }), 12e4);
            d.onerror = c.bind(null, d.onerror), d.onload = c.bind(null, d.onload), l && document.head.appendChild(d)
        }
    })(), r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e;
        r.tt = () => (void 0 === e && (e = {
            createScriptURL: e => e
        }, "undefined" != typeof trustedTypes && trustedTypes.createPolicy && (e = trustedTypes.createPolicy("nextjs#bundler", e))), e)
    })(), r.tu = e => r.tt().createScriptURL(e), r.p = "/_next/", (() => {
        var e = (e, t, r, n) => {
                var o = document.createElement("link");
                return o.rel = "stylesheet", o.type = "text/css", o.onerror = o.onload = a => {
                    if (o.onerror = o.onload = null, "load" === a.type) r();
                    else {
                        var i = a && ("load" === a.type ? "missing" : a.type),
                            d = a && a.target && a.target.href || t,
                            l = Error("Loading CSS chunk " + e + " failed.\n(" + d + ")");
                        l.code = "CSS_CHUNK_LOAD_FAILED", l.type = i, l.request = d, o.parentNode.removeChild(o), n(l)
                    }
                }, o.href = t, ! function(e) {
                    if ("function" == typeof _N_E_STYLE_LOAD) {
                        let {
                            href: t,
                            onload: r,
                            onerror: n
                        } = e;
                        _N_E_STYLE_LOAD(0 === t.indexOf(window.location.origin) ? new URL(t).pathname : t).then(() => null == r ? void 0 : r.call(e, {
                            type: "load"
                        }), () => null == n ? void 0 : n.call(e, {}))
                    } else document.head.appendChild(e)
                }(o), o
            },
            t = (e, t) => {
                for (var r = document.getElementsByTagName("link"), n = 0; n < r.length; n++) {
                    var o = r[n],
                        a = o.getAttribute("data-href") || o.getAttribute("href");
                    if ("stylesheet" === o.rel && (a === e || a === t)) return o
                }
                for (var i = document.getElementsByTagName("style"), n = 0; n < i.length; n++) {
                    var o = i[n],
                        a = o.getAttribute("data-href");
                    if (a === e || a === t) return o
                }
            },
            n = n => new Promise((o, a) => {
                var i = r.miniCssF(n),
                    d = r.p + i;
                if (t(i, d)) return o();
                e(n, d, o, a)
            }),
            o = {
                8068: 0
            };
        r.f.miniCss = (e, t) => {
            o[e] ? t.push(o[e]) : 0 !== o[e] && ({
                122: 1
            })[e] && t.push(o[e] = n(e).then(() => {
                o[e] = 0
            }, t => {
                throw delete o[e], t
            }))
        }
    })(), (() => {
        var e = {
            8068: 0,
            154: 0,
            2978: 0,
            2294: 0,
            7659: 0,
            397: 0,
            122: 0,
            4896: 0,
            5307: 0
        };
        r.f.j = (t, n) => {
            var o = r.o(e, t) ? e[t] : void 0;
            if (0 !== o)
                if (o) n.push(o[2]);
                else if (/^(122|154|2294|2978|397|4896|5307|7659|8068)$/.test(t)) e[t] = 0;
            else {
                var a = new Promise((r, n) => o = e[t] = [r, n]);
                n.push(o[2] = a);
                var i = r.p + r.u(t),
                    d = Error();
                r.l(i, n => {
                    if (r.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                        var a = n && ("load" === n.type ? "missing" : n.type),
                            i = n && n.target && n.target.src;
                        d.message = "Loading chunk " + t + " failed.\n(" + a + ": " + i + ")", d.name = "ChunkLoadError", d.type = a, d.request = i, o[1](d)
                    }
                }, "chunk-" + t, t)
            }
        }, r.O.j = t => 0 === e[t];
        var t = (t, n) => {
                var o, a, [i, d, l] = n,
                    s = 0;
                if (i.some(t => 0 !== e[t])) {
                    for (o in d) r.o(d, o) && (r.m[o] = d[o]);
                    if (l) var u = l(r)
                }
                for (t && t(n); s < i.length; s++) a = i[s], r.o(e, a) && e[a] && e[a][0](), e[a] = 0;
                return r.O(u)
            },
            n = self.webpackChunk_N_E = self.webpackChunk_N_E || [];
        n.forEach(t.bind(null, 0)), n.push = t.bind(null, n.push.bind(n))
    })(), r.nc = void 0
})();;
(function() {
    if (!/(?:^|;\s)__vercel_toolbar=1(?:;|$)/.test(document.cookie)) return;
    var s = document.createElement('script');
    s.src = 'https://vercel.live/_next-live/feedback/feedback.js';
    s.setAttribute("data-explicit-opt-in", "true");
    s.setAttribute("data-cookie-opt-in", "true");
    s.setAttribute("data-deployment-id", "dpl_DBP9UJ218opYaj91s2jmyHbvbDRi");
    ((document.head || document.documentElement).appendChild(s))
})();