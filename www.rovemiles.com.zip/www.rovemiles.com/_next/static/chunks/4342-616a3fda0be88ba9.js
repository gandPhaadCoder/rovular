! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "bf312cfa-6381-450c-95b0-f2d3f8417df8", e._sentryDebugIdIdentifier = "sentry-dbid-bf312cfa-6381-450c-95b0-f2d3f8417df8")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4342], {
        2954: (e, t, r) => {
            r.d(t, {
                $: () => l
            });
            var s = r(56195),
                i = r(74268),
                n = r(31668),
                u = r(38445),
                a = r(83515),
                h = r(34049),
                l = class extends u.Q {
                    constructor(e, t) {
                        super(), this.options = t, this.#e = e, this.#t = null, this.#r = (0, a.T)(), this.options.experimental_prefetchInRender || this.#r.reject(Error("experimental_prefetchInRender feature flag is not enabled")), this.bindMethods(), this.setOptions(t)
                    }#
                    e;#
                    s = void 0;#
                    i = void 0;#
                    n = void 0;#
                    u;#
                    a;#
                    r;#
                    t;#
                    h;#
                    l;#
                    c;#
                    o;#
                    d;#
                    f;#
                    p = new Set;
                    bindMethods() {
                        this.refetch = this.refetch.bind(this)
                    }
                    onSubscribe() {
                        1 === this.listeners.size && (this.#s.addObserver(this), c(this.#s, this.options) ? this.#y() : this.updateResult(), this.#R())
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.destroy()
                    }
                    shouldFetchOnReconnect() {
                        return o(this.#s, this.options, this.options.refetchOnReconnect)
                    }
                    shouldFetchOnWindowFocus() {
                        return o(this.#s, this.options, this.options.refetchOnWindowFocus)
                    }
                    destroy() {
                        this.listeners = new Set, this.#b(), this.#v(), this.#s.removeObserver(this)
                    }
                    setOptions(e, t) {
                        let r = this.options,
                            s = this.#s;
                        if (this.options = this.#e.defaultQueryOptions(e), void 0 !== this.options.enabled && "boolean" != typeof this.options.enabled && "function" != typeof this.options.enabled && "boolean" != typeof(0, h.Eh)(this.options.enabled, this.#s)) throw Error("Expected enabled to be a boolean or a callback that returns a boolean");
                        this.#m(), this.#s.setOptions(this.options), r._defaulted && !(0, h.f8)(this.options, r) && this.#e.getQueryCache().notify({
                            type: "observerOptionsUpdated",
                            query: this.#s,
                            observer: this
                        });
                        let i = this.hasListeners();
                        i && d(this.#s, s, this.options, r) && this.#y(), this.updateResult(t), i && (this.#s !== s || (0, h.Eh)(this.options.enabled, this.#s) !== (0, h.Eh)(r.enabled, this.#s) || (0, h.d2)(this.options.staleTime, this.#s) !== (0, h.d2)(r.staleTime, this.#s)) && this.#Q();
                        let n = this.#g();
                        i && (this.#s !== s || (0, h.Eh)(this.options.enabled, this.#s) !== (0, h.Eh)(r.enabled, this.#s) || n !== this.#f) && this.#I(n)
                    }
                    getOptimisticResult(e) {
                        var t, r;
                        let s = this.#e.getQueryCache().build(this.#e, e),
                            i = this.createResult(s, e);
                        return t = this, r = i, (0, h.f8)(t.getCurrentResult(), r) || (this.#n = i, this.#a = this.options, this.#u = this.#s.state), i
                    }
                    getCurrentResult() {
                        return this.#n
                    }
                    trackResult(e, t) {
                        let r = {};
                        return Object.keys(e).forEach(s => {
                            Object.defineProperty(r, s, {
                                configurable: !1,
                                enumerable: !0,
                                get: () => (this.trackProp(s), t ? .(s), e[s])
                            })
                        }), r
                    }
                    trackProp(e) {
                        this.#p.add(e)
                    }
                    getCurrentQuery() {
                        return this.#s
                    }
                    refetch({ ...e
                    } = {}) {
                        return this.fetch({ ...e
                        })
                    }
                    fetchOptimistic(e) {
                        let t = this.#e.defaultQueryOptions(e),
                            r = this.#e.getQueryCache().build(this.#e, t);
                        return r.fetch().then(() => this.createResult(r, t))
                    }
                    fetch(e) {
                        return this.#y({ ...e,
                            cancelRefetch: e.cancelRefetch ? ? !0
                        }).then(() => (this.updateResult(), this.#n))
                    }#
                    y(e) {
                        this.#m();
                        let t = this.#s.fetch(this.options, e);
                        return e ? .throwOnError || (t = t.catch(h.lQ)), t
                    }#
                    Q() {
                        this.#b();
                        let e = (0, h.d2)(this.options.staleTime, this.#s);
                        if (h.S$ || this.#n.isStale || !(0, h.gn)(e)) return;
                        let t = (0, h.j3)(this.#n.dataUpdatedAt, e);
                        this.#o = setTimeout(() => {
                            this.#n.isStale || this.updateResult()
                        }, t + 1)
                    }#
                    g() {
                        return ("function" == typeof this.options.refetchInterval ? this.options.refetchInterval(this.#s) : this.options.refetchInterval) ? ? !1
                    }#
                    I(e) {
                        this.#v(), this.#f = e, !h.S$ && !1 !== (0, h.Eh)(this.options.enabled, this.#s) && (0, h.gn)(this.#f) && 0 !== this.#f && (this.#d = setInterval(() => {
                            (this.options.refetchIntervalInBackground || s.m.isFocused()) && this.#y()
                        }, this.#f))
                    }#
                    R() {
                        this.#Q(), this.#I(this.#g())
                    }#
                    b() {
                        this.#o && (clearTimeout(this.#o), this.#o = void 0)
                    }#
                    v() {
                        this.#d && (clearInterval(this.#d), this.#d = void 0)
                    }
                    createResult(e, t) {
                        let r, s = this.#s,
                            i = this.options,
                            u = this.#n,
                            l = this.#u,
                            o = this.#a,
                            p = e !== s ? e.state : this.#i,
                            {
                                state: y
                            } = e,
                            R = { ...y
                            },
                            b = !1;
                        if (t._optimisticResults) {
                            let r = this.hasListeners(),
                                u = !r && c(e, t),
                                a = r && d(e, s, t, i);
                            (u || a) && (R = { ...R,
                                ...(0, n.k)(y.data, e.options)
                            }), "isRestoring" === t._optimisticResults && (R.fetchStatus = "idle")
                        }
                        let {
                            error: v,
                            errorUpdatedAt: m,
                            status: Q
                        } = R;
                        if (t.select && void 0 !== R.data)
                            if (u && R.data === l ? .data && t.select === this.#h) r = this.#l;
                            else try {
                                this.#h = t.select, r = t.select(R.data), r = (0, h.pl)(u ? .data, r, t), this.#l = r, this.#t = null
                            } catch (e) {
                                this.#t = e
                            } else r = R.data;
                        if (void 0 !== t.placeholderData && void 0 === r && "pending" === Q) {
                            let e;
                            if (u ? .isPlaceholderData && t.placeholderData === o ? .placeholderData) e = u.data;
                            else if (e = "function" == typeof t.placeholderData ? t.placeholderData(this.#c ? .state.data, this.#c) : t.placeholderData, t.select && void 0 !== e) try {
                                e = t.select(e), this.#t = null
                            } catch (e) {
                                this.#t = e
                            }
                            void 0 !== e && (Q = "success", r = (0, h.pl)(u ? .data, e, t), b = !0)
                        }
                        this.#t && (v = this.#t, r = this.#l, m = Date.now(), Q = "error");
                        let g = "fetching" === R.fetchStatus,
                            I = "pending" === Q,
                            O = "error" === Q,
                            E = I && g,
                            S = void 0 !== r,
                            C = {
                                status: Q,
                                fetchStatus: R.fetchStatus,
                                isPending: I,
                                isSuccess: "success" === Q,
                                isError: O,
                                isInitialLoading: E,
                                isLoading: E,
                                data: r,
                                dataUpdatedAt: R.dataUpdatedAt,
                                error: v,
                                errorUpdatedAt: m,
                                failureCount: R.fetchFailureCount,
                                failureReason: R.fetchFailureReason,
                                errorUpdateCount: R.errorUpdateCount,
                                isFetched: R.dataUpdateCount > 0 || R.errorUpdateCount > 0,
                                isFetchedAfterMount: R.dataUpdateCount > p.dataUpdateCount || R.errorUpdateCount > p.errorUpdateCount,
                                isFetching: g,
                                isRefetching: g && !I,
                                isLoadingError: O && !S,
                                isPaused: "paused" === R.fetchStatus,
                                isPlaceholderData: b,
                                isRefetchError: O && S,
                                isStale: f(e, t),
                                refetch: this.refetch,
                                promise: this.#r
                            };
                        if (this.options.experimental_prefetchInRender) {
                            let t = e => {
                                    "error" === C.status ? e.reject(C.error) : void 0 !== C.data && e.resolve(C.data)
                                },
                                r = () => {
                                    t(this.#r = C.promise = (0, a.T)())
                                },
                                i = this.#r;
                            switch (i.status) {
                                case "pending":
                                    e.queryHash === s.queryHash && t(i);
                                    break;
                                case "fulfilled":
                                    ("error" === C.status || C.data !== i.value) && r();
                                    break;
                                case "rejected":
                                    ("error" !== C.status || C.error !== i.reason) && r()
                            }
                        }
                        return C
                    }
                    updateResult(e) {
                        let t = this.#n,
                            r = this.createResult(this.#s, this.options);
                        if (this.#u = this.#s.state, this.#a = this.options, void 0 !== this.#u.data && (this.#c = this.#s), (0, h.f8)(r, t)) return;
                        this.#n = r;
                        let s = {};
                        e ? .listeners !== !1 && (() => {
                            if (!t) return !0;
                            let {
                                notifyOnChangeProps: e
                            } = this.options, r = "function" == typeof e ? e() : e;
                            if ("all" === r || !r && !this.#p.size) return !0;
                            let s = new Set(r ? ? this.#p);
                            return this.options.throwOnError && s.add("error"), Object.keys(this.#n).some(e => this.#n[e] !== t[e] && s.has(e))
                        })() && (s.listeners = !0), this.#O({ ...s,
                            ...e
                        })
                    }#
                    m() {
                        let e = this.#e.getQueryCache().build(this.#e, this.options);
                        if (e === this.#s) return;
                        let t = this.#s;
                        this.#s = e, this.#i = e.state, this.hasListeners() && (t ? .removeObserver(this), e.addObserver(this))
                    }
                    onQueryUpdate() {
                        this.updateResult(), this.hasListeners() && this.#R()
                    }#
                    O(e) {
                        i.j.batch(() => {
                            e.listeners && this.listeners.forEach(e => {
                                e(this.#n)
                            }), this.#e.getQueryCache().notify({
                                query: this.#s,
                                type: "observerResultsUpdated"
                            })
                        })
                    }
                };

            function c(e, t) {
                return !1 !== (0, h.Eh)(t.enabled, e) && void 0 === e.state.data && ("error" !== e.state.status || !1 !== t.retryOnMount) || void 0 !== e.state.data && o(e, t, t.refetchOnMount)
            }

            function o(e, t, r) {
                if (!1 !== (0, h.Eh)(t.enabled, e)) {
                    let s = "function" == typeof r ? r(e) : r;
                    return "always" === s || !1 !== s && f(e, t)
                }
                return !1
            }

            function d(e, t, r, s) {
                return (e !== t || !1 === (0, h.Eh)(s.enabled, e)) && (!r.suspense || "error" !== e.state.status) && f(e, r)
            }

            function f(e, t) {
                return !1 !== (0, h.Eh)(t.enabled, e) && e.isStaleByTime((0, h.d2)(t.staleTime, e))
            }
        },
        12211: (e, t, r) => {
            function s(e, t) {
                return "function" == typeof e ? e(...t) : !!e
            }

            function i() {}
            r.d(t, {
                G: () => s,
                l: () => i
            })
        },
        15239: (e, t, r) => {
            r.d(t, {
                default: () => i.a
            });
            var s = r(54652),
                i = r.n(s)
        },
        54652: (e, t, r) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var r in t) Object.defineProperty(e, r, {
                    enumerable: !0,
                    get: t[r]
                })
            }(t, {
                default: function() {
                    return h
                },
                getImageProps: function() {
                    return a
                }
            });
            let s = r(28140),
                i = r(75040),
                n = r(81356),
                u = s._(r(71124));

            function a(e) {
                let {
                    props: t
                } = (0, i.getImgProps)(e, {
                    defaultLoader: u.default,
                    imgConf: {
                        deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
                        imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
                        path: "/_next/image",
                        loader: "default",
                        dangerouslyAllowSVG: !1,
                        unoptimized: !1
                    }
                });
                for (let [e, r] of Object.entries(t)) void 0 === r && delete t[e];
                return {
                    props: t
                }
            }
            let h = n.Image
        },
        78633: (e, t, r) => {
            r.d(t, {
                t: () => m
            });
            var s = r(12115),
                i = r(74268),
                n = r(34049),
                u = r(99776);
            r(95155);
            var a = s.createContext(function() {
                    let e = !1;
                    return {
                        clearReset: () => {
                            e = !1
                        },
                        reset: () => {
                            e = !0
                        },
                        isReset: () => e
                    }
                }()),
                h = () => s.useContext(a),
                l = r(12211),
                c = (e, t) => {
                    (e.suspense || e.throwOnError || e.experimental_prefetchInRender) && !t.isReset() && (e.retryOnMount = !1)
                },
                o = e => {
                    s.useEffect(() => {
                        e.clearReset()
                    }, [e])
                },
                d = e => {
                    let {
                        result: t,
                        errorResetBoundary: r,
                        throwOnError: s,
                        query: i
                    } = e;
                    return t.isError && !r.isReset() && !t.isFetching && i && (0, l.G)(s, [t.error, i])
                },
                f = s.createContext(!1),
                p = () => s.useContext(f);
            f.Provider;
            var y = e => {
                    let t = e.staleTime;
                    e.suspense && (e.staleTime = "function" == typeof t ? (...e) => Math.max(t(...e), 1e3) : Math.max(t ? ? 1e3, 1e3), "number" == typeof e.gcTime && (e.gcTime = Math.max(e.gcTime, 1e3)))
                },
                R = (e, t) => e.isLoading && e.isFetching && !t,
                b = (e, t) => e ? .suspense && t.isPending,
                v = (e, t, r) => t.fetchOptimistic(e).catch(() => {
                    r.clearReset()
                });

            function m(e, t, r) {
                var a, f, m, Q, g;
                let I = (0, u.jE)(r),
                    O = p(),
                    E = h(),
                    S = I.defaultQueryOptions(e);
                null == (f = I.getDefaultOptions().queries) || null == (a = f._experimental_beforeQuery) || a.call(f, S), S._optimisticResults = O ? "isRestoring" : "optimistic", y(S), c(S, E), o(E);
                let C = !I.getQueryCache().get(S.queryHash),
                    [T] = s.useState(() => new t(I, S)),
                    w = T.getOptimisticResult(S),
                    _ = !O && !1 !== e.subscribed;
                if (s.useSyncExternalStore(s.useCallback(e => {
                        let t = _ ? T.subscribe(i.j.batchCalls(e)) : l.l;
                        return T.updateResult(), t
                    }, [T, _]), () => T.getCurrentResult(), () => T.getCurrentResult()), s.useEffect(() => {
                        T.setOptions(S, {
                            listeners: !1
                        })
                    }, [S, T]), b(S, w)) throw v(S, T, E);
                if (d({
                        result: w,
                        errorResetBoundary: E,
                        throwOnError: S.throwOnError,
                        query: I.getQueryCache().get(S.queryHash)
                    })) throw w.error;
                if (null == (Q = I.getDefaultOptions().queries) || null == (m = Q._experimental_afterQuery) || m.call(Q, S, w), S.experimental_prefetchInRender && !n.S$ && R(w, O)) {
                    let e = C ? v(S, T, E) : null == (g = I.getQueryCache().get(S.queryHash)) ? void 0 : g.promise;
                    null == e || e.catch(l.l).finally(() => {
                        T.updateResult()
                    })
                }
                return S.notifyOnChangeProps ? w : T.trackResult(w)
            }
        },
        92033: (e, t, r) => {
            r.d(t, {
                A: () => s
            });
            let s = (0, r(14294).A)("LoaderCircle", [
                ["path", {
                    d: "M21 12a9 9 0 1 1-6.219-8.56",
                    key: "13zald"
                }]
            ])
        }
    }
]);