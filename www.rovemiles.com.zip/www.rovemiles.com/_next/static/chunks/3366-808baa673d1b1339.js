! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "a096078d-4338-49fd-9d11-b0aaeee91179", t._sentryDebugIdIdentifier = "sentry-dbid-a096078d-4338-49fd-9d11-b0aaeee91179")
    } catch (t) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3366], {
        3913: (t, e, a) => {
            a.d(e, {
                R: () => i
            });
            var r = a(53455),
                o = a(15653);
            let s = o.z.object({
                id: o.z.string(),
                name: o.z.string(),
                description: o.z.string().optional(),
                imageUrl: o.z.string().optional(),
                price: o.z.number(),
                currency: o.z.string().optional().default("USD"),
                location: o.z.string().optional(),
                stars: o.z.number().optional().default(0),
                discount: o.z.number().optional(),
                thumbnail: o.z.string().optional(),
                rating: o.z.number().optional().default(0)
            });
            o.z.union([o.z.object({
                deals: o.z.array(s)
            }), o.z.array(s)]);
            let l = async () => {
                let t = await fetch("/api/hotels/deals", {
                    method: "GET"
                });
                if (!t.ok) throw Error("Failed to fetch hotel deals: ".concat(t.status));
                let e = await t.json();
                try {
                    return e.data
                } catch (t) {
                    return console.error("Error parsing hotel deals response:", t), {
                        cpm: [],
                        multiplier: []
                    }
                }
            };

            function i() {
                let t = !(arguments.length > 0) || void 0 === arguments[0] || arguments[0],
                    {
                        data: e,
                        isLoading: a,
                        error: o,
                        ...s
                    } = (0, r.I)({
                        queryKey: ["hotelDeals"],
                        queryFn: l,
                        staleTime: 3e5,
                        gcTime: 36e5,
                        enabled: t
                    });
                return {
                    deals: e,
                    isLoading: a,
                    error: o,
                    ...s
                }
            }
        },
        5835: (t, e, a) => {
            a.d(e, {
                default: () => s
            });
            var r = a(95155),
                o = a(92033);

            function s(t) {
                let {
                    message: e = "Loading...",
                    size: a = 32
                } = t;
                return (0, r.jsxs)("div", {
                    className: "min-h-[50vh] flex flex-col items-center justify-center gap-3 text-sm text-gray-500",
                    "data-sentry-component": "LoadingSpinner",
                    "data-sentry-source-file": "index.tsx",
                    children: [(0, r.jsx)(o.A, {
                        className: "animate-spin text-white",
                        size: a,
                        strokeWidth: 2,
                        "data-sentry-element": "Loader2",
                        "data-sentry-source-file": "index.tsx"
                    }), e && (0, r.jsx)("span", {
                        children: e
                    })]
                })
            }
        },
        6924: (t, e, a) => {
            a.d(e, {
                v: () => n
            });
            var r = a(12115),
                o = a(98674);
            let s = {
                set(t, e) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 7,
                        r = new Date(Date.now() + 864e5 * a).toUTCString();
                    document.cookie = "".concat(encodeURIComponent(t), "=").concat(encodeURIComponent(e), "; expires=").concat(r, "; path=/")
                },
                get(t) {
                    for (let e of document.cookie.split("; ")) {
                        let [a, r] = e.split("=");
                        if (decodeURIComponent(a) === t) return decodeURIComponent(r)
                    }
                    return null
                },
                delete(t) {
                    document.cookie = "".concat(encodeURIComponent(t), "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/")
                }
            };
            var l = a(73788);
            let i = "nearest_airport_info";

            function n() {
                let [t, e] = (0, r.useState)(null), [a, n] = (0, r.useState)(!0);
                return (0, r.useEffect)(() => {
                    (async () => {
                        let t = s.get(i);
                        if (t) try {
                            let a = JSON.parse(t);
                            e(a), n(!1);
                            return
                        } catch (t) {
                            console.error("Failed to parse airport cookie:", t)
                        }
                        try {
                            let {
                                latitude: t,
                                longitude: a
                            } = await o.N.getCurrentLocation(), r = (0, l.V3)(t, a);
                            if (r) {
                                let t = await (0, l.$2)(r.code);
                                t && (s.set(i, JSON.stringify(t), 7), e(t))
                            }
                        } catch (t) {
                            console.error("Failed to resolve nearest airport:", t)
                        } finally {
                            n(!1)
                        }
                    })()
                }, []), {
                    values: t,
                    loading: a
                }
            }
        },
        7417: (t, e, a) => {
            a.d(e, {
                k: () => L
            });
            var r = a(95155),
                o = a(3913),
                s = a(12115);
            let l = t => (0, r.jsxs)("svg", {
                    width: "32",
                    height: "32",
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ...t,
                    "data-sentry-element": "svg",
                    "data-sentry-component": "IconCircleArrowRight",
                    "data-sentry-source-file": "IconCircleArrowRight.tsx",
                    children: [(0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        fill: "black",
                        fillOpacity: "0.13",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowRight.tsx"
                    }), (0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        stroke: "url(#gradient)",
                        strokeWidth: "0.372",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowRight.tsx"
                    }), (0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        stroke: "white",
                        strokeOpacity: "0.2",
                        strokeWidth: "0.372",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowRight.tsx"
                    }), (0, r.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M21.643 16.694L17.502 20.835C17.257 21.079 17.257 21.475 17.502 21.719C17.746 21.963 18.141 21.963 18.385 21.719L23.004 17.1C23.574 16.53 23.574 15.607 23.004 15.038L18.385 10.418C18.141 10.174 17.746 10.174 17.502 10.418C17.257 10.663 17.257 11.058 17.502 11.302L21.643 15.444H9.193C8.848 15.444 8.568 15.724 8.568 16.069C8.568 16.414 8.848 16.694 9.193 16.694H21.643Z",
                        fill: "white",
                        "data-sentry-element": "path",
                        "data-sentry-source-file": "IconCircleArrowRight.tsx"
                    }), (0, r.jsx)("defs", {
                        "data-sentry-element": "defs",
                        "data-sentry-source-file": "IconCircleArrowRight.tsx",
                        children: (0, r.jsxs)("linearGradient", {
                            id: "gradient",
                            x1: "0",
                            y1: "16",
                            x2: "32",
                            y2: "16",
                            gradientUnits: "userSpaceOnUse",
                            "data-sentry-element": "linearGradient",
                            "data-sentry-source-file": "IconCircleArrowRight.tsx",
                            children: [(0, r.jsx)("stop", {
                                stopOpacity: "0",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowRight.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "0.32",
                                stopColor: "#333333",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowRight.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "0.645",
                                stopColor: "#9C9C9C",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowRight.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "1",
                                stopOpacity: "0",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowRight.tsx"
                            })]
                        })
                    })]
                }),
                i = t => (0, r.jsxs)("svg", {
                    width: "32",
                    height: "32",
                    viewBox: "0 0 32 32",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    ...t,
                    "data-sentry-element": "svg",
                    "data-sentry-component": "IconCircleArrowLeft",
                    "data-sentry-source-file": "IconCircleArrowLeft.tsx",
                    children: [(0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        fill: "black",
                        fillOpacity: "0.13",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                    }), (0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        stroke: "url(#gradient)",
                        strokeWidth: "0.372",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                    }), (0, r.jsx)("rect", {
                        x: "0.186",
                        y: "0.186",
                        width: "31.628",
                        height: "31.628",
                        rx: "15.814",
                        stroke: "white",
                        strokeOpacity: "0.2",
                        strokeWidth: "0.372",
                        "data-sentry-element": "rect",
                        "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                    }), (0, r.jsx)("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M10.3569 16.6937L14.4983 20.8352C14.7424 21.0792 14.7424 21.475 14.4983 21.7191C14.2542 21.9631 13.8585 21.9631 13.6144 21.7191L8.99533 17.0999C8.42584 16.5304 8.42584 15.607 8.99533 15.0375L13.6144 10.4184C13.8585 10.1743 14.2542 10.1743 14.4983 10.4184C14.7424 10.6625 14.7424 11.0582 14.4983 11.3023L10.3569 15.4437H22.8064C23.1516 15.4437 23.4314 15.7236 23.4314 16.0687C23.4314 16.4139 23.1516 16.6937 22.8064 16.6937H10.3569Z",
                        fill: "white",
                        "data-sentry-element": "path",
                        "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                    }), (0, r.jsx)("defs", {
                        "data-sentry-element": "defs",
                        "data-sentry-source-file": "IconCircleArrowLeft.tsx",
                        children: (0, r.jsxs)("linearGradient", {
                            id: "gradient",
                            x1: "0",
                            y1: "16",
                            x2: "32",
                            y2: "16",
                            gradientUnits: "userSpaceOnUse",
                            "data-sentry-element": "linearGradient",
                            "data-sentry-source-file": "IconCircleArrowLeft.tsx",
                            children: [(0, r.jsx)("stop", {
                                stopOpacity: "0",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "0.32",
                                stopColor: "#333333",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "0.645",
                                stopColor: "#9C9C9C",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                            }), (0, r.jsx)("stop", {
                                offset: "1",
                                stopOpacity: "0",
                                "data-sentry-element": "stop",
                                "data-sentry-source-file": "IconCircleArrowLeft.tsx"
                            })]
                        })
                    })]
                }),
                n = t => {
                    let {
                        title: e,
                        children: a,
                        cardWidthClass: o = "w-full sm:w-1/2 md:w-1/3 lg:w-1/5"
                    } = t, n = (0, s.useRef)(null), [c, d] = (0, s.useState)(!1), [u, p] = (0, s.useState)(!1), [h, y] = (0, s.useState)(0), m = () => {
                        let t = n.current;
                        t && (d(t.scrollLeft > 0), p(t.scrollLeft + t.clientWidth < t.scrollWidth - 1))
                    }, g = t => {
                        let e = n.current;
                        if (!e) return;
                        let a = e.children;
                        if (!a[t]) return;
                        let r = a[t];
                        e.scrollTo({
                            left: r.offsetLeft,
                            behavior: "smooth"
                        }), y(t)
                    };
                    return (0, s.useEffect)(() => {
                        let t = n.current;
                        if (t) return m(), t.addEventListener("scroll", m), window.addEventListener("resize", m), () => {
                            t.removeEventListener("scroll", m), window.removeEventListener("resize", m)
                        }
                    }, []), (0, s.useEffect)(() => {
                        let t = setTimeout(m, 100);
                        return () => clearTimeout(t)
                    }, [a]), (0, r.jsxs)("section", {
                        className: "w-full",
                        "data-sentry-component": "Carousel",
                        "data-sentry-source-file": "Carousel.tsx",
                        children: [e && (0, r.jsx)("h2", {
                            className: "text-[20px] font-normal text-white tracking-[-0.015em] mb-6",
                            children: e
                        }), (0, r.jsxs)("div", {
                            className: "relative",
                            children: [c && (0, r.jsx)("button", {
                                onClick: () => {
                                    g(Math.max(h - 1, 0))
                                },
                                className: "absolute -left-4 top-1/2 -translate-y-1/2 z-10",
                                children: (0, r.jsx)(i, {})
                            }), u && (0, r.jsx)("button", {
                                onClick: () => {
                                    let t = n.current;
                                    t && g(Math.min(h + 1, t.children.length - 1))
                                },
                                className: "absolute -right-4 top-1/2 -translate-y-1/2 z-10",
                                children: (0, r.jsx)(l, {})
                            }), (0, r.jsx)("div", {
                                ref: n,
                                className: "flex overflow-x-auto overflow-y-hidden gap-4 scroll-smooth snap-x snap-mandatory scrollbar-hide",
                                children: Array.isArray(a) ? a.map((t, e) => (0, r.jsx)("div", {
                                    className: "flex-shrink-0 snap-start ".concat(o),
                                    children: t
                                }, e)) : a
                            })]
                        })]
                    })
                };
            var c = a(97849),
                d = a(26467),
                u = a(50316),
                p = a(72473),
                h = a(15239),
                y = a(10639),
                m = a(20063);
            let g = (t, e) => {
                    let a = new Date,
                        r = new Date(a);
                    r.setDate(a.getDate() + 14);
                    let o = new Date(r);
                    o.setDate(r.getDate() + 1);
                    let s = (0, p.GP)(r, "yyyy-MM-dd"),
                        l = new URLSearchParams({
                            checkin: s,
                            checkout: (0, p.GP)(o, "yyyy-MM-dd"),
                            rooms: encodeURIComponent(JSON.stringify([{
                                adults: 2,
                                children: 0,
                                childrenAges: []
                            }])),
                            guest_nationality: "US",
                            currency: "USD"
                        });
                    e("/search/hotels/".concat(t, "?").concat(l.toString()))
                },
                x = t => {
                    let {
                        hotel: e,
                        city: a,
                        image: o,
                        hotelId: s,
                        dateRange: l = "",
                        miles: i = "0",
                        milesMultiplier: n = "x1"
                    } = t, d = (0, m.useRouter)(), u = "number" == typeof i ? (0, c.HY)(i) : i;
                    return (0, r.jsxs)("div", {
                        onClick: () => g(s, d.push),
                        className: "relative aspect-[4/3] flex-shrink-0 overflow-hidden rounded-[8.44px] border border-[1.055px] border-black/10 cursor-pointer transition-transform hover:scale-[1.02]",
                        "data-sentry-component": "MilesCard",
                        "data-sentry-source-file": "MilesCard.tsx",
                        children: [(0, r.jsx)(h.default, {
                            src: o,
                            alt: "".concat(e, ", ").concat(a),
                            fill: !0,
                            className: "object-cover object-center",
                            sizes: "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 20vw",
                            priority: !0,
                            "data-sentry-element": "Image",
                            "data-sentry-source-file": "MilesCard.tsx"
                        }), (0, r.jsx)("div", {
                            className: "absolute top-0 left-0 w-full h-[100px] bg-gradient-to-b from-black/90 via-black/80 to-transparent z-[5]"
                        }), (0, r.jsxs)("div", {
                            className: "absolute top-4 left-4 text-white z-10",
                            children: [(0, r.jsxs)("div", {
                                className: "font-semibold text-sm leading-tight",
                                children: ["Earn ", u, " miles", " ", (0, r.jsxs)("span", {
                                    className: "text-white/60 text-xs font-normal",
                                    children: ["(", n, ")"]
                                })]
                            }), (0, r.jsx)("span", {
                                className: "text-xs text-white/80 leading-tight",
                                title: e,
                                children: e
                            }), (0, r.jsx)("div", {
                                className: "text-xs",
                                children: l
                            })]
                        }), (0, r.jsx)("div", {
                            className: "absolute bottom-0 left-0 w-full h-[80px] bg-gradient-to-t from-black/70 via-black/50 to-transparent z-[5]"
                        }), (0, r.jsxs)("div", {
                            className: "absolute bottom-[12px] left-1/2 -translate-x-1/2 px-[12px] py-[8px] rounded-md bg-black/60 text-white z-10 flex items-center gap-[6px] max-w-[90%] shadow-lg",
                            children: [(0, r.jsx)(y.A, {
                                className: "w-4 h-4 stroke-white flex-shrink-0",
                                "data-sentry-element": "MapPin",
                                "data-sentry-source-file": "MilesCard.tsx"
                            }), (0, r.jsx)("span", {
                                className: "text-sm font-medium truncate max-w-[200px] block",
                                title: "".concat(e, ", ").concat(a),
                                children: a
                            })]
                        })]
                    })
                },
                f = () => (0, r.jsxs)("div", {
                    className: "relative py-10 px-4 md:px-6 lg:px-8 xl:px-10 2xl:px-12 overflow-hidden",
                    "data-sentry-component": "SkeletonMilesSection",
                    "data-sentry-source-file": "SkeletonMilesSection.tsx",
                    children: [(0, r.jsx)("div", {
                        className: "h-6 w-[250px] bg-gray-800 rounded mb-6 animate-pulse"
                    }), (0, r.jsx)("div", {
                        className: "flex gap-4 overflow-x-auto",
                        children: Array.from({
                            length: 6
                        }).map((t, e) => (0, r.jsxs)("div", {
                            className: "relative aspect-[4/3] w-[256px] flex-shrink-0 overflow-hidden rounded-[8.44px] bg-gray-900 border border-gray-800 animate-pulse",
                            children: [(0, r.jsx)("div", {
                                className: "absolute top-4 left-4 h-4 w-[140px] bg-gray-800 rounded"
                            }), (0, r.jsx)("div", {
                                className: "absolute top-10 left-4 h-3 w-[100px] bg-gray-800 rounded"
                            }), (0, r.jsx)("div", {
                                className: "absolute bottom-4 left-1/2 -translate-x-1/2 h-6 w-[180px] bg-gray-800 rounded"
                            })]
                        }, e))
                    })]
                }),
                v = () => {
                    let {
                        deals: t,
                        isLoading: e
                    } = (0, o.R)(), a = (0, s.useCallback)((t, e) => {
                        if (!t || !e) return 1;
                        try {
                            let a = (0, d.H)(t),
                                r = (0, d.H)(e),
                                o = (0, u.c)(r, a);
                            return o > 0 ? o : 1
                        } catch (t) {
                            return console.error("Error calculating nights:", t), 1
                        }
                    }, []), l = (0, s.useMemo)(() => t && 0 !== t.multiplier.length ? t.multiplier.map(t => {
                        var e, r, o, s, l, i, n, u, h, y, m, g, x;
                        let f = null == (e = t.data) ? void 0 : e.hotel,
                            v = (null == (r = t.data) ? void 0 : r.roomTypes) || [],
                            w = v[0];
                        if (!f || !v.length || !(null == w || null == (s = w.calculations) || null == (o = s.milesEarning) ? void 0 : o.milesEarned)) return null;
                        let b = "";
                        if (t.startDate && t.endDate) try {
                            let e = (0, d.H)(t.startDate),
                                a = (0, d.H)(t.endDate);
                            b = "".concat((0, p.GP)(e, "MMM d"), " - ").concat((0, p.GP)(a, "MMM d"))
                        } catch (t) {
                            console.error("Error formatting display dates:", t)
                        }
                        let j = "";
                        if ("string" == typeof f.address) j = f.address;
                        else if ("object" == typeof f.address) {
                            let t = f.address;
                            t.city && (j = "".concat(t.city).concat(t.country ? ", ".concat(t.country) : ""))
                        } else f.city && (j = "".concat(f.city).concat(f.country ? ", ".concat(f.country) : ""));
                        let C = null == w || null == (i = w.calculations) || null == (l = i.milesEarning) ? void 0 : l.multiplier,
                            k = void 0 !== C ? "number" == typeof C ? "".concat(C, "x") : String(C).startsWith("x") ? String(C) : "".concat(C, "x") : "x1",
                            I = a(t.startDate, t.endDate),
                            S = (null == w || null == (u = w.calculations) || null == (n = u.pricePerNight) ? void 0 : n.amount) || 0,
                            N = (0, c.vv)(S * I),
                            A = (null == w || null == (y = w.calculations) || null == (h = y.sellingPrice) ? void 0 : h.amount) || 0,
                            z = "".concat((0, c.vv)(Math.round(A)), " Total (").concat(I, " night").concat(1 !== I ? "s" : "", ")"),
                            M = (null == (g = w.calculations) || null == (m = g.milesEarning) ? void 0 : m.milesEarned) || 0,
                            R = (0, c.HY)(M),
                            L = "MV" === f.country ? "Maldives" : f.city;
                        return {
                            id: f.id || "hotel-".concat(Math.random().toString(36).slice(2, 11)),
                            title: f.name || "Hotel",
                            thumbnail: f.thumbnail || f.main_photo || "/logo.png",
                            price: N,
                            miles: R,
                            miles_multiplier: k,
                            dates: b,
                            retail_price: z,
                            address: j,
                            rating: f.rating || 0,
                            stars: f.stars || 0,
                            city: L,
                            cpm: (null == w || null == (x = w.calculations) ? void 0 : x.cpm) || 0
                        }
                    }).filter(t => null !== t).sort((t, e) => {
                        let a = t => "number" == typeof t ? t : parseInt(String(t).replace(/,/g, ""), 10) || 0;
                        return a(e.miles) - a(t.miles)
                    }) : [], [t, a]);
                    return e ? (0, r.jsx)(f, {
                        "data-sentry-element": "SkeletonMilesSection",
                        "data-sentry-component": "EarnMiles",
                        "data-sentry-source-file": "EarnMiles.tsx"
                    }) : (0, r.jsx)(n, {
                        title: "Earn miles when you pay in cash",
                        "data-sentry-element": "Carousel",
                        "data-sentry-component": "EarnMiles",
                        "data-sentry-source-file": "EarnMiles.tsx",
                        children: l.map(t => {
                            var e, a;
                            return (0, r.jsx)(x, {
                                hotel: t.title,
                                city: null != (e = t.city) ? e : "",
                                image: null != (a = t.thumbnail) ? a : "",
                                hotelId: t.id,
                                dateRange: t.dates,
                                milesMultiplier: t.miles_multiplier,
                                miles: t.miles
                            }, t.id)
                        })
                    })
                },
                w = t => {
                    let {
                        hotel: e,
                        city: a,
                        image: o,
                        hotelId: s
                    } = t, l = (0, m.useRouter)();
                    return (0, r.jsxs)("div", {
                        onClick: () => g(s, l.push),
                        className: "relative w-full aspect-[3/2] rounded-[12px] overflow-hidden cursor-pointer flex-shrink-0 transition-transform hover:scale-[1.02]",
                        "data-sentry-component": "HotelCard",
                        "data-sentry-source-file": "HotelCard.tsx",
                        children: [(0, r.jsx)(h.default, {
                            src: o,
                            alt: "".concat(e, ", ").concat(a),
                            fill: !0,
                            className: "object-cover object-center",
                            sizes: "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 20vw",
                            priority: !0,
                            "data-sentry-element": "Image",
                            "data-sentry-source-file": "HotelCard.tsx"
                        }), (0, r.jsx)("div", {
                            className: "absolute bottom-0 left-0 w-full h-[60px] bg-gradient-to-b from-transparent via-black/30 to-black/80 z-[5]"
                        }), (0, r.jsxs)("div", {
                            className: "absolute bottom-[12px] left-1/2 -translate-x-1/2 px-[12px] py-[8px] rounded-md backdrop-blur-sm bg-[rgba(24,24,24,0.5)] text-white z-10 flex items-center gap-[6px] max-w-[80%]",
                            children: [(0, r.jsx)(y.A, {
                                className: "w-4 h-4 stroke-white flex-shrink-0",
                                "data-sentry-element": "MapPin",
                                "data-sentry-source-file": "HotelCard.tsx"
                            }), (0, r.jsxs)("span", {
                                className: "text-sm font-medium truncate max-w-[200px] block",
                                title: "".concat(e, ", ").concat(a),
                                children: [e, ", ", a]
                            })]
                        })]
                    })
                },
                b = [{
                    city: "Amsterdam",
                    country: "Netherlands",
                    image: "/destinations/amsterdam.webp"
                }, {
                    city: "Bali (Denpasar)",
                    country: "Indonesia",
                    image: "/destinations/bali.webp"
                }, {
                    city: "Bangkok",
                    country: "Thailand",
                    image: "/destinations/bangkok.webp"
                }, {
                    city: "Barcelona",
                    country: "Spain",
                    image: "/destinations/barcelona.webp"
                }, {
                    city: "Dubai",
                    country: "UAE",
                    image: "/destinations/dubai.webp"
                }, {
                    city: "Las Vegas",
                    country: "USA",
                    image: "/destinations/las_vegas.webp"
                }, {
                    city: "Lisbon",
                    country: "Portugal",
                    image: "/destinations/lisbon.webp"
                }, {
                    city: "London",
                    country: "UK",
                    image: "/destinations/london.webp"
                }, {
                    city: "Los Angeles",
                    country: "USA",
                    image: "/destinations/los_angeles.webp"
                }, {
                    city: "Mexico City",
                    country: "Mexico",
                    image: "/destinations/mexico.webp"
                }, {
                    city: "Miami",
                    country: "USA",
                    image: "/destinations/miami.webp"
                }, {
                    city: "New York",
                    country: "USA",
                    image: "/destinations/new_york.webp"
                }, {
                    city: "Paris",
                    country: "France",
                    image: "/destinations/paris.webp"
                }, {
                    city: "Rio de Janeiro",
                    country: "Brazil",
                    image: "/destinations/rio_de_janeiro.webp"
                }, {
                    city: "Rome",
                    country: "Italy",
                    image: "/destinations/rome.webp"
                }, {
                    city: "Sydney",
                    country: "Australia",
                    image: "/destinations/sydney.webp"
                }, {
                    city: "Tokyo",
                    country: "Japan",
                    image: "/destinations/tokyo.webp"
                }, {
                    city: "Toronto",
                    country: "Canada",
                    image: "/destinations/toronto.webp"
                }, {
                    city: "Vancouver",
                    country: "Canada",
                    image: "/destinations/vancouver.webp"
                }],
                j = ["Wellness", "Adventure", "Beachfront", "Family", "Ski", "City Life", "Luxury"],
                C = [{
                    hotel: "COMO Shambhala Estate",
                    city: "Bali",
                    country: "Indonesia",
                    image: "https://static.cupid.travel/hotels/371100432.jpg",
                    category: "wellness",
                    hotelId: "lp6188c"
                }, {
                    hotel: "Four Seasons Resort Maui at Wailea",
                    city: "Maui",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/275628657.jpg",
                    category: "wellness",
                    hotelId: "lp1d817"
                }, {
                    hotel: "Four Seasons Resort Bora Bora",
                    city: "Bora Bora",
                    country: "French Polynesia",
                    image: "https://static.cupid.travel/hotels/51610543.jpg",
                    category: "wellness",
                    hotelId: "lp4080b"
                }, {
                    hotel: "Kudafushi Resort & Spa",
                    city: "Raa Atoll",
                    country: "Maldives",
                    image: "https://static.cupid.travel/hotels/171571094.jpg",
                    category: "wellness",
                    hotelId: "lp9cd9c"
                }, {
                    hotel: "Mystras Grand Palace Resort & Spa",
                    city: "Sparti",
                    country: "Greece",
                    image: "https://static.cupid.travel/hotels/122948827.jpg",
                    category: "wellness",
                    hotelId: "lp655ab6af"
                }, {
                    hotel: "Kyniska Palace Conference & Spa",
                    city: "Mystras",
                    country: "Greece",
                    image: "https://static.cupid.travel/hotels/195315996.jpg",
                    category: "wellness",
                    hotelId: "lp1f3077"
                }, {
                    hotel: "Nyati Safari Lodge",
                    city: "Hoedspruit",
                    country: "South Africa",
                    image: "https://static.cupid.travel/hotels/122485930.jpg",
                    category: "adventure",
                    hotelId: "lpc35d9"
                }, {
                    hotel: "Discovery Parks - Kangaroo Island",
                    city: "Flinders Chase",
                    country: "Ausralia",
                    image: "https://static.cupid.travel/hotels/497004250.jpg",
                    category: "adventure",
                    hotelId: "lpdec24"
                }, {
                    hotel: "Anantya Serengeti",
                    city: "Serengeti",
                    country: "Tanzania",
                    image: "https://static.cupid.travel/hotels/530616041.jpg",
                    category: "adventure",
                    hotelId: "lp656d929e"
                }, {
                    hotel: "Kapama Southern Camp",
                    city: "Kapama Private Game Reserve",
                    country: "South Africa",
                    image: "https://static.cupid.travel/hotels/567038730.jpg",
                    category: "adventure",
                    hotelId: "lp8cc5d"
                }, {
                    hotel: "Arctic Resort Delight",
                    city: "Rovaniemi",
                    country: "Finland",
                    image: "https://static.cupid.travel/hotels/594977514.jpg",
                    category: "adventure",
                    hotelId: "lpbf4c5"
                }, {
                    hotel: "Lomavekarit Apartments",
                    city: "Rovaniemi",
                    country: "Finland",
                    image: "https://static.cupid.travel/hotels/594291683.jpg",
                    category: "adventure",
                    hotelId: "lpc5130"
                }, {
                    hotel: "Shutters On The Beach",
                    city: "Los Angeles",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/62754570.jpg",
                    category: "beachfront",
                    hotelId: "lp20555"
                }, {
                    hotel: "Four Seasons Hotel at The Surf Club",
                    city: "Miami Beach",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/96473542.jpg",
                    category: "beachfront",
                    hotelId: "lp99e39"
                }, {
                    hotel: "Halekulani",
                    city: "Honolulu",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/251545278.jpg",
                    category: "beachfront",
                    hotelId: "lp2adc7"
                }, {
                    hotel: "Hotel Luxury Patio Azul",
                    city: "Puerto Vallarta",
                    country: "Mexico",
                    image: "https://static.cupid.travel/hotels/373626703.jpg",
                    category: "beachfront",
                    hotelId: "lp65550d2a"
                }, {
                    hotel: "Viceroy Los Cabos",
                    city: "San Jos\xe9 del Cabo",
                    country: "Mexico",
                    image: "https://static.cupid.travel/hotels/169285479.jpg",
                    category: "beachfront",
                    hotelId: "lp820b3"
                }, {
                    hotel: "Santarena Hotel at Las Catalinas",
                    city: "Playa Flamingo",
                    country: "Costa Rica",
                    image: "https://static.cupid.travel/hotels/487987559.jpg",
                    category: "beachfront",
                    hotelId: "lp655bddad"
                }, {
                    hotel: "Pinus Villa 7 bedroom with a private pool",
                    city: "Bandung",
                    country: "Indonesia",
                    image: "https://static.cupid.travel/hotels/568925008.jpg",
                    category: "family",
                    hotelId: "lp87179"
                }, {
                    hotel: "Park Chalet Village",
                    city: "Livigno",
                    country: "Italia",
                    image: "https://static.cupid.travel/hotels/194466399.jpg",
                    category: "family",
                    hotelId: "lp64d7b"
                }, {
                    hotel: "The Resort at Governor's Crossing",
                    city: "Pigeon Forge",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/322366686.jpg",
                    category: "family",
                    hotelId: "lp39e91"
                }, {
                    hotel: "Grand Velas Riviera Nayarit",
                    city: "Nuevo Vallarta",
                    country: "Mexico",
                    image: "https://static.cupid.travel/hotels/217631741.jpg",
                    category: "family",
                    hotelId: "lp35d77"
                }, {
                    hotel: "The Panoramic Getaway",
                    city: "Munnar",
                    country: "India",
                    image: "https://static.cupid.travel/hotels/41407736.jpg",
                    category: "family",
                    hotelId: "lp77166"
                }, {
                    hotel: "Katikies Santorini - The Leading Hotels Of The World",
                    city: "Oia",
                    country: "Greece",
                    image: "https://static.cupid.travel/hotels/437218152.jpg",
                    category: "family",
                    hotelId: "lp2ee53"
                }, {
                    hotel: "The Ritz-Carlton, Doha",
                    city: "Doha",
                    country: "Qatar",
                    image: "https://static.cupid.travel/hotels/ex_413f2ef2_z.jpg",
                    category: "luxury",
                    hotelId: "lp30679"
                }, {
                    hotel: "Park Hyatt Siem Reap",
                    city: " Sivutha Blvd",
                    country: "Cambodia",
                    image: "https://static.cupid.travel/hotels/421816935.jpg",
                    category: "luxury",
                    hotelId: "lp3988b"
                }, {
                    hotel: "Mandarin Oriental Jumeira, Dubai",
                    city: "Dubai",
                    country: "Dubai",
                    image: "https://static.cupid.travel/hotels/416539085.jpg",
                    category: "luxury",
                    hotelId: "lp10249d"
                }, {
                    hotel: "Four Seasons Hotel New York Downtown",
                    city: "New York",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/243380969.jpg",
                    category: "luxury",
                    hotelId: "lp92dad"
                }, {
                    hotel: "The Savoy",
                    city: "London",
                    country: "UK",
                    image: "https://static.cupid.travel/hotels/177109798.jpg",
                    category: "luxury",
                    hotelId: "lp2a32f"
                }, {
                    hotel: "Palace Hotel Tokyo",
                    city: "Tokyo",
                    country: "Japan",
                    image: "https://static.cupid.travel/hotels/ex_790f0d4c_z.jpg",
                    category: "luxury",
                    hotelId: "lp23803"
                }, {
                    hotel: "Widder Hotel",
                    city: "Z\xfcrich",
                    country: "Switzerland",
                    image: "https://static.cupid.travel/hotels/ex_2faacaf1_z.jpg",
                    category: "luxury",
                    hotelId: "lp6635d"
                }, {
                    hotel: "Radisson Blu Hotel Reussen, Andermatt",
                    city: "Andermatt",
                    country: "Switzerland",
                    image: "https://static.cupid.travel/hotels/232849992.jpg",
                    category: "ski",
                    hotelId: "lp1a8781"
                }, {
                    hotel: "Sonus Alpis - Adults Only",
                    city: "Italy",
                    country: "Castelrotto",
                    image: "https://static.cupid.travel/hotels/127495899.jpg",
                    category: "ski",
                    hotelId: "lp65589924"
                }, {
                    hotel: "Andermatt Alpine Apartments",
                    city: "Tires",
                    country: "Italy",
                    image: "https://static.cupid.travel/hotels/273139621.jpg",
                    category: "ski",
                    hotelId: "lp71d6c"
                }, {
                    hotel: "Hotel Interlaken",
                    city: "Interlaken",
                    country: "Switzerland",
                    image: "https://static.cupid.travel/hotels/237084207.jpg",
                    category: "ski",
                    hotelId: "lp655663f7"
                }, {
                    hotel: "Hotel GRACE LA MARGNA ST MORITZ",
                    city: "St. Moritz",
                    country: "Switzerland",
                    image: "https://static.cupid.travel/hotels/515741090.jpg",
                    category: "ski",
                    hotelId: "lp655bb728"
                }, {
                    hotel: "Niseko Konbu Onsen Tsuruga Moku-no-sho",
                    city: "Niseko",
                    country: "Japan",
                    image: "https://static.cupid.travel/hotels/216495703.jpg",
                    category: "ski",
                    hotelId: "lp6a32b"
                }, {
                    hotel: "Pendry Manhattan West",
                    city: "New York",
                    country: "US",
                    image: "https://static.cupid.travel/hotels/331711469.jpg",
                    category: "city life",
                    hotelId: "lp65572a2b"
                }, {
                    hotel: "Roseate House London",
                    city: "London",
                    country: "UK",
                    image: "https://static.cupid.travel/hotels/138764940.jpg",
                    category: "city life",
                    hotelId: "lp27581"
                }, {
                    hotel: "Hotel Bel-Air - Dorchester Collection",
                    city: "Los Angeles",
                    country: "USA",
                    image: "https://static.cupid.travel/hotels/183715157.jpg",
                    category: "city life",
                    hotelId: "lp1b628"
                }, {
                    hotel: "The Standard, Bangkok Mahanakhon",
                    city: "Bangkok",
                    country: "Thailand",
                    image: "https://static.cupid.travel/hotels/339218334.jpg",
                    category: "city life",
                    hotelId: "lp65579880"
                }, {
                    hotel: "Marunouchi Hotel",
                    city: "Tokyo",
                    country: "Japan",
                    image: "https://static.cupid.travel/hotels/268162884.jpg",
                    category: "city life",
                    hotelId: "lpfd1cc"
                }, {
                    hotel: "Gran Estanplaza Berrini",
                    city: "Sao Paolo",
                    country: "Brazil",
                    image: "https://static.cupid.travel/hotels/287688971.jpg",
                    category: "city life",
                    hotelId: "lp3261a"
                }],
                k = t => {
                    let {
                        active: e,
                        onChange: a
                    } = t;
                    return (0, r.jsxs)("div", {
                        className: "w-full pb-4",
                        "data-sentry-component": "HotelCategoryTabs",
                        "data-sentry-source-file": "HotelCategoryTabs.tsx",
                        children: [(0, r.jsx)("h2", {
                            className: "text-[20px] font-normal leading-[145%] tracking-[-0.015em] text-white font-untitled mb-4",
                            children: "What are you looking for?"
                        }), (0, r.jsx)("div", {
                            className: "flex items-center gap-6 overflow-x-auto border-b border-white/10 scrollbar-hide",
                            children: j.map(t => {
                                let o = e === t;
                                return (0, r.jsxs)("button", {
                                    onClick: () => a(t),
                                    className: "relative pb-3 whitespace-nowrap font-untitled text-base transition-colors duration-200 ".concat(o ? "text-white font-medium" : "text-white/60 hover:text-white"),
                                    children: [t, o && (0, r.jsx)("div", {
                                        className: "absolute bottom-0 left-0 right-0 h-[1px]",
                                        style: {
                                            background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                                        }
                                    })]
                                }, t)
                            })
                        })]
                    })
                },
                I = t => {
                    let {
                        children: e
                    } = t;
                    return (0, r.jsx)("div", {
                        className: "w-full",
                        "data-sentry-component": "HotelCategoryWrapper",
                        "data-sentry-source-file": "HotelCategoryWrapper.tsx",
                        children: (0, r.jsx)("div", {
                            className: "rounded-[12px] border border-white/20 bg-[rgba(110,110,110,0.04)] p-6",
                            children: e
                        })
                    })
                };

            function S() {
                let [t, e] = (0, s.useState)("Wellness"), a = C.filter(e => e.category.toLowerCase() === t.toLowerCase());
                return (0, r.jsxs)(I, {
                    "data-sentry-element": "HotelCategoryWrapper",
                    "data-sentry-component": "HotelShowcase",
                    "data-sentry-source-file": "HotelCategories.tsx",
                    children: [(0, r.jsx)(k, {
                        active: t,
                        onChange: e,
                        "data-sentry-element": "HotelCategoryTabs",
                        "data-sentry-source-file": "HotelCategories.tsx"
                    }), (0, r.jsx)(n, {
                        "data-sentry-element": "Carousel",
                        "data-sentry-source-file": "HotelCategories.tsx",
                        children: a.map(t => (0, r.jsx)(w, { ...t
                        }, t.hotel))
                    })]
                })
            }
            var N = a(13141),
                A = a(95125);
            let z = async (t, e) => {
                    try {
                        var a, r;
                        let o = null == (r = (await A.A.get("/api/search/hotel-destinations", {
                            params: {
                                query: t
                            }
                        })).data.data) || null == (a = r[0]) ? void 0 : a.placeId;
                        if (!o) return;
                        let s = new Date;
                        s.setDate(s.getDate() + 14);
                        let l = new Date(s);
                        l.setDate(s.getDate() + 1);
                        let i = (0, p.GP)(s, "yyyy-MM-dd"),
                            n = (0, p.GP)(l, "yyyy-MM-dd"),
                            c = new URLSearchParams({
                                destination: o,
                                checkin: i,
                                checkout: n,
                                rooms: encodeURIComponent(JSON.stringify([{
                                    adults: 2,
                                    children: 0,
                                    childrenAges: []
                                }])),
                                nationality: "US",
                                currency: "USD",
                                coordinates: "",
                                search_name: t,
                                filters: encodeURIComponent(JSON.stringify({
                                    hotelName: "",
                                    facilities: [],
                                    guestRating: 0,
                                    propertyRating: [],
                                    types: [],
                                    sorting: "1",
                                    cancellation: "all"
                                }))
                            });
                        e("/search/hotels?".concat(c.toString()))
                    } catch (t) {
                        console.error("Failed to navigate to hotel search:", t)
                    }
                },
                M = t => {
                    let {
                        city: e,
                        country: a,
                        image: o
                    } = t, s = (0, m.useRouter)();
                    return (0, r.jsxs)("div", {
                        onClick: () => z(e, s.push),
                        className: "relative w-full aspect-[5/4] sm:aspect-[5/5] md:aspect-[5/6] rounded-[12px] overflow-hidden cursor-pointer flex-shrink-0 transition-transform hover:scale-[1.02]",
                        "data-sentry-component": "DestinationCard",
                        "data-sentry-source-file": "DestinationCard.tsx",
                        children: [(0, r.jsx)(h.default, {
                            src: o,
                            alt: "".concat(e, ", ").concat(a),
                            fill: !0,
                            className: "object-cover object-top",
                            sizes: "(max-width: 768px) 100vw, (max-width: 1024px) 50vw, 20vw",
                            priority: !0,
                            "data-sentry-element": "Image",
                            "data-sentry-source-file": "DestinationCard.tsx"
                        }), (0, r.jsxs)("div", {
                            className: "absolute bottom-[12px] left-1/2 -translate-x-1/2 inline-flex items-center justify-center gap-[6px] px-[12px] py-[8px] rounded-md backdrop-blur-sm bg-[rgba(24,24,24,0.5)] text-white z-10",
                            children: [(0, r.jsx)(N.A, {
                                className: "w-4 h-4 stroke-white",
                                "data-sentry-element": "Plane",
                                "data-sentry-source-file": "DestinationCard.tsx"
                            }), (0, r.jsxs)("span", {
                                className: "text-sm font-medium whitespace-nowrap",
                                children: [e, ", ", a]
                            })]
                        }), (0, r.jsx)("div", {
                            className: "absolute bottom-0 left-0 w-full h-[50px] bg-gradient-to-b from-transparent via-black/40 to-black/80 z-[5]"
                        })]
                    })
                },
                R = () => (0, r.jsx)(n, {
                    title: "Explore trending destinations",
                    "data-sentry-element": "Carousel",
                    "data-sentry-component": "TrendingDestinations",
                    "data-sentry-source-file": "TrendingDestinations.tsx",
                    children: b.map(t => (0, r.jsx)(M, { ...t
                    }, t.city))
                }),
                L = () => (0, r.jsxs)("div", {
                    className: "flex flex-col max-w-7xl mx-auto gap-7 p-6",
                    "data-sentry-component": "HotelSection",
                    "data-sentry-source-file": "index.tsx",
                    children: [(0, r.jsx)(R, {
                        "data-sentry-element": "TrendingDestinations",
                        "data-sentry-source-file": "index.tsx"
                    }), (0, r.jsx)(S, {
                        "data-sentry-element": "HotelShowcase",
                        "data-sentry-source-file": "index.tsx"
                    }), (0, r.jsx)(v, {
                        "data-sentry-element": "EarnMiles",
                        "data-sentry-source-file": "index.tsx"
                    })]
                })
        },
        19345: (t, e, a) => {
            a.d(e, {
                K: () => o
            });
            var r = a(95155);
            a(12115);
            let o = t => {
                let {
                    active: e,
                    onClick: a,
                    children: o
                } = t;
                return (0, r.jsxs)("button", {
                    onClick: a,
                    className: "\n      relative px-3 py-1 transition-colors\n      ".concat(e ? "text-white" : "text-white/70 hover:text-white/90", "\n    "),
                    "data-sentry-component": "TabButton",
                    "data-sentry-source-file": "TabButton.tsx",
                    children: [o, e && (0, r.jsx)("div", {
                        className: "absolute bottom-0 left-0 right-0 h-[1px]",
                        style: {
                            background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                        }
                    })]
                })
            }
        },
        21297: (t, e, a) => {
            a.d(e, {
                u: () => d
            });
            var r = a(95155),
                o = a(64269),
                s = a(5673),
                l = a(51515),
                i = a(19345),
                n = a(49474),
                c = a(25950);
            let d = t => {
                let {
                    activeTab: e,
                    isSearchExpanded: a,
                    onExpandChange: d,
                    onSearch: u,
                    initialValues: p,
                    loading: h,
                    onLandingScrolled: y,
                    onSetActiveTab: m
                } = t, {
                    isMobile: g
                } = (0, n.l)(), {
                    activeTab: x
                } = (0, c.F7)();
                return (0, r.jsx)("div", {
                    className: "w-full",
                    "data-sentry-component": "NavbarSearchBar",
                    "data-sentry-source-file": "NavbarSearchBar.tsx",
                    children: g ? (0, r.jsxs)("div", {
                        children: [(0, r.jsx)("div", {
                            className: "flex sm:hidden w-full justify-center items-center",
                            children: (0, r.jsx)(l.A, {
                                from: "explore",
                                onExpandChange: d,
                                onSearch: u,
                                isMinimized: !a,
                                initialValues: p,
                                loading: h,
                                showRegions: !0
                            })
                        }), "flights" === x && (0, r.jsx)("div", {
                            className: "flex items-center justify-between h-14 px-4",
                            children: (0, r.jsx)("div", {
                                className: "flex space-x-1",
                                children: ["Best", "Cheapest"].map(t => (0, r.jsx)(i.K, {
                                    active: e === t,
                                    onClick: () => m(t),
                                    children: t
                                }, t))
                            })
                        })]
                    }) : (0, r.jsx)("div", {
                        className: (0, o.cn)("max-w-7xl mx-auto px-4 w-full h-full hidden sm:flex items-center justify-center", y && "h-auto"),
                        children: (0, r.jsx)(s.A, {
                            variant: "navbar",
                            isMinimized: y,
                            onExpandChange: d,
                            onSearch: u,
                            initialValues: p,
                            loading: h,
                            showRegions: !0
                        })
                    })
                })
            }
        },
        97849: (t, e, a) => {
            a.d(e, {
                HY: () => r,
                vv: () => o
            });
            let r = t => null == t ? "" : t.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","),
                o = t => null == t ? "" : "$".concat(r(t))
        },
        98674: (t, e, a) => {
            a.d(e, {
                N: () => i
            });
            var r = a(15653);
            let o = r.z.object({
                    latitude: r.z.number(),
                    longitude: r.z.number()
                }),
                s = r.z.object({
                    location: r.z.object({
                        lat: r.z.number(),
                        lng: r.z.number(),
                        country: r.z.string(),
                        region: r.z.string(),
                        city: r.z.string(),
                        postalCode: r.z.string().optional(),
                        timezone: r.z.string(),
                        geonameId: r.z.number()
                    }),
                    ip: r.z.string(),
                    as: r.z.object({
                        asn: r.z.number(),
                        name: r.z.string(),
                        route: r.z.string(),
                        domain: r.z.string(),
                        type: r.z.string()
                    }),
                    isp: r.z.string()
                });
            class l {
                async getCurrentLocation() {
                    return this._promise || (this._promise = (async () => {
                        let t = null;
                        try {
                            let e = await fetch("https://api.ipify.org/?format=json");
                            if (e.ok) {
                                let {
                                    ip: a
                                } = await e.json();
                                t = String(a)
                            }
                        } catch (t) {
                            console.error("Failed to fetch IP address", t)
                        }
                        let e = await fetch("/api/location".concat(t ? "?ip=".concat(t) : ""));
                        if (!e.ok) throw Error("Failed to fetch location");
                        let a = await e.json(),
                            r = s.parse(a);
                        return o.parse({
                            latitude: r.location.lat,
                            longitude: r.location.lng
                        })
                    })()), this._promise
                }
                constructor() {
                    this._promise = null
                }
            }
            let i = new l
        }
    }
]);