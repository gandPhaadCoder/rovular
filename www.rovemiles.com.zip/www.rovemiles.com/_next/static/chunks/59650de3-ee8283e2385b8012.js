! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "9a78e77a-1835-413a-9706-7f9209d634dc", t._sentryDebugIdIdentifier = "sentry-dbid-9a78e77a-1835-413a-9706-7f9209d634dc")
    } catch (t) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2150], {
        53380: (t, e, d) => {
            d.d(e, {
                CqI: () => a
            });
            var n = d(56724);

            function a(t) {
                return (0, n.k5)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24",
                        fill: "none",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M8 3 4 7l4 4"
                        },
                        child: []
                    }, {
                        tag: "path",
                        attr: {
                            d: "M4 7h16"
                        },
                        child: []
                    }, {
                        tag: "path",
                        attr: {
                            d: "m16 21 4-4-4-4"
                        },
                        child: []
                    }, {
                        tag: "path",
                        attr: {
                            d: "M20 17H4"
                        },
                        child: []
                    }]
                })(t)
            }
        }
    }
]);