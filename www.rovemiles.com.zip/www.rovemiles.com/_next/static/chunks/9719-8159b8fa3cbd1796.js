! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "1cef6c89-0882-42c4-908c-0021a5c9789d", e._sentryDebugIdIdentifier = "sentry-dbid-1cef6c89-0882-42c4-908c-0021a5c9789d")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9719], {
        505: (e, t, n) => {
            n.d(t, {
                Mz: () => tb,
                UC: () => tC,
                ZL: () => tx,
                bL: () => tw,
                l9: () => tE
            });
            var r, o, a, i = n(12115),
                l = n(92556),
                u = n(94446),
                c = n(3468),
                s = n(47650),
                d = n(95155),
                f = i.forwardRef((e, t) => {
                    let {
                        children: n,
                        ...r
                    } = e, o = i.Children.toArray(n), a = o.find(h);
                    if (a) {
                        let e = a.props.children,
                            n = o.map(t => t !== a ? t : i.Children.count(e) > 1 ? i.Children.only(null) : i.isValidElement(e) ? e.props.children : null);
                        return (0, d.jsx)(p, { ...r,
                            ref: t,
                            children: i.isValidElement(e) ? i.cloneElement(e, void 0, n) : null
                        })
                    }
                    return (0, d.jsx)(p, { ...r,
                        ref: t,
                        children: n
                    })
                });
            f.displayName = "Slot";
            var p = i.forwardRef((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                if (i.isValidElement(n)) {
                    let e = function(e) {
                            let t = Object.getOwnPropertyDescriptor(e.props, "ref") ? .get,
                                n = t && "isReactWarning" in t && t.isReactWarning;
                            return n ? e.ref : (n = (t = Object.getOwnPropertyDescriptor(e, "ref") ? .get) && "isReactWarning" in t && t.isReactWarning) ? e.props.ref : e.props.ref || e.ref
                        }(n),
                        o = function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let o = e[r],
                                    a = t[r];
                                /^on[A-Z]/.test(r) ? o && a ? n[r] = (...e) => {
                                    a(...e), o(...e)
                                } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                    ...a
                                } : "className" === r && (n[r] = [o, a].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(r, n.props);
                    return n.type !== i.Fragment && (o.ref = t ? (0, u.t)(t, e) : e), i.cloneElement(n, o)
                }
                return i.Children.count(n) > 1 ? i.Children.only(null) : null
            });
            p.displayName = "SlotClone";
            var v = ({
                children: e
            }) => (0, d.jsx)(d.Fragment, {
                children: e
            });

            function h(e) {
                return i.isValidElement(e) && e.type === v
            }
            var m = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = i.forwardRef((e, n) => {
                        let {
                            asChild: r,
                            ...o
                        } = e, a = r ? f : t;
                        return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), (0, d.jsx)(a, { ...o,
                            ref: n
                        })
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                g = n(70222),
                y = n(59584),
                w = "dismissableLayer.update",
                b = i.createContext({
                    layers: new Set,
                    layersWithOutsidePointerEventsDisabled: new Set,
                    branches: new Set
                }),
                E = i.forwardRef((e, t) => {
                    var n, r;
                    let {
                        disableOutsidePointerEvents: a = !1,
                        onEscapeKeyDown: c,
                        onPointerDownOutside: s,
                        onFocusOutside: f,
                        onInteractOutside: p,
                        onDismiss: v,
                        ...h
                    } = e, E = i.useContext(b), [P, A] = i.useState(null), R = null != (r = null == P ? void 0 : P.ownerDocument) ? r : null == (n = globalThis) ? void 0 : n.document, [, S] = i.useState({}), j = (0, u.s)(t, e => A(e)), N = Array.from(E.layers), [O] = [...E.layersWithOutsidePointerEventsDisabled].slice(-1), k = N.indexOf(O), L = P ? N.indexOf(P) : -1, D = E.layersWithOutsidePointerEventsDisabled.size > 0, T = L >= k, F = function(e) {
                        var t;
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null == (t = globalThis) ? void 0 : t.document,
                            r = (0, g.c)(e),
                            o = i.useRef(!1),
                            a = i.useRef(() => {});
                        return i.useEffect(() => {
                            let e = e => {
                                    if (e.target && !o.current) {
                                        let t = function() {
                                                C("dismissableLayer.pointerDownOutside", r, o, {
                                                    discrete: !0
                                                })
                                            },
                                            o = {
                                                originalEvent: e
                                            };
                                        "touch" === e.pointerType ? (n.removeEventListener("click", a.current), a.current = t, n.addEventListener("click", a.current, {
                                            once: !0
                                        })) : t()
                                    } else n.removeEventListener("click", a.current);
                                    o.current = !1
                                },
                                t = window.setTimeout(() => {
                                    n.addEventListener("pointerdown", e)
                                }, 0);
                            return () => {
                                window.clearTimeout(t), n.removeEventListener("pointerdown", e), n.removeEventListener("click", a.current)
                            }
                        }, [n, r]), {
                            onPointerDownCapture: () => o.current = !0
                        }
                    }(e => {
                        let t = e.target,
                            n = [...E.branches].some(e => e.contains(t));
                        T && !n && (null == s || s(e), null == p || p(e), e.defaultPrevented || null == v || v())
                    }, R), M = function(e) {
                        var t;
                        let n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null == (t = globalThis) ? void 0 : t.document,
                            r = (0, g.c)(e),
                            o = i.useRef(!1);
                        return i.useEffect(() => {
                            let e = e => {
                                e.target && !o.current && C("dismissableLayer.focusOutside", r, {
                                    originalEvent: e
                                }, {
                                    discrete: !1
                                })
                            };
                            return n.addEventListener("focusin", e), () => n.removeEventListener("focusin", e)
                        }, [n, r]), {
                            onFocusCapture: () => o.current = !0,
                            onBlurCapture: () => o.current = !1
                        }
                    }(e => {
                        let t = e.target;
                        ![...E.branches].some(e => e.contains(t)) && (null == f || f(e), null == p || p(e), e.defaultPrevented || null == v || v())
                    }, R);
                    return (0, y.U)(e => {
                        L === E.layers.size - 1 && (null == c || c(e), !e.defaultPrevented && v && (e.preventDefault(), v()))
                    }, R), i.useEffect(() => {
                        if (P) return a && (0 === E.layersWithOutsidePointerEventsDisabled.size && (o = R.body.style.pointerEvents, R.body.style.pointerEvents = "none"), E.layersWithOutsidePointerEventsDisabled.add(P)), E.layers.add(P), x(), () => {
                            a && 1 === E.layersWithOutsidePointerEventsDisabled.size && (R.body.style.pointerEvents = o)
                        }
                    }, [P, R, a, E]), i.useEffect(() => () => {
                        P && (E.layers.delete(P), E.layersWithOutsidePointerEventsDisabled.delete(P), x())
                    }, [P, E]), i.useEffect(() => {
                        let e = () => S({});
                        return document.addEventListener(w, e), () => document.removeEventListener(w, e)
                    }, []), (0, d.jsx)(m.div, { ...h,
                        ref: j,
                        style: {
                            pointerEvents: D ? T ? "auto" : "none" : void 0,
                            ...e.style
                        },
                        onFocusCapture: (0, l.m)(e.onFocusCapture, M.onFocusCapture),
                        onBlurCapture: (0, l.m)(e.onBlurCapture, M.onBlurCapture),
                        onPointerDownCapture: (0, l.m)(e.onPointerDownCapture, F.onPointerDownCapture)
                    })
                });

            function x() {
                let e = new CustomEvent(w);
                document.dispatchEvent(e)
            }

            function C(e, t, n, r) {
                let {
                    discrete: o
                } = r, a = n.originalEvent.target, i = new CustomEvent(e, {
                    bubbles: !1,
                    cancelable: !0,
                    detail: n
                });
                if (t && a.addEventListener(e, t, {
                        once: !0
                    }), o) a && s.flushSync(() => a.dispatchEvent(i));
                else a.dispatchEvent(i)
            }
            E.displayName = "DismissableLayer", i.forwardRef((e, t) => {
                let n = i.useContext(b),
                    r = i.useRef(null),
                    o = (0, u.s)(t, r);
                return i.useEffect(() => {
                    let e = r.current;
                    if (e) return n.branches.add(e), () => {
                        n.branches.delete(e)
                    }
                }, [n.branches]), (0, d.jsx)(m.div, { ...e,
                    ref: o
                })
            }).displayName = "DismissableLayerBranch";
            var P = 0;

            function A() {
                let e = document.createElement("span");
                return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e
            }
            var R = i.forwardRef((e, t) => {
                let {
                    children: n,
                    ...r
                } = e, o = i.Children.toArray(n), a = o.find(N);
                if (a) {
                    let e = a.props.children,
                        n = o.map(t => t !== a ? t : i.Children.count(e) > 1 ? i.Children.only(null) : i.isValidElement(e) ? e.props.children : null);
                    return (0, d.jsx)(S, { ...r,
                        ref: t,
                        children: i.isValidElement(e) ? i.cloneElement(e, void 0, n) : null
                    })
                }
                return (0, d.jsx)(S, { ...r,
                    ref: t,
                    children: n
                })
            });
            R.displayName = "Slot";
            var S = i.forwardRef((e, t) => {
                let {
                    children: n,
                    ...r
                } = e;
                if (i.isValidElement(n)) {
                    let e = function(e) {
                            let t = Object.getOwnPropertyDescriptor(e.props, "ref") ? .get,
                                n = t && "isReactWarning" in t && t.isReactWarning;
                            return n ? e.ref : (n = (t = Object.getOwnPropertyDescriptor(e, "ref") ? .get) && "isReactWarning" in t && t.isReactWarning) ? e.props.ref : e.props.ref || e.ref
                        }(n),
                        o = function(e, t) {
                            let n = { ...t
                            };
                            for (let r in t) {
                                let o = e[r],
                                    a = t[r];
                                /^on[A-Z]/.test(r) ? o && a ? n[r] = (...e) => {
                                    a(...e), o(...e)
                                } : o && (n[r] = o) : "style" === r ? n[r] = { ...o,
                                    ...a
                                } : "className" === r && (n[r] = [o, a].filter(Boolean).join(" "))
                            }
                            return { ...e,
                                ...n
                            }
                        }(r, n.props);
                    return n.type !== i.Fragment && (o.ref = t ? (0, u.t)(t, e) : e), i.cloneElement(n, o)
                }
                return i.Children.count(n) > 1 ? i.Children.only(null) : null
            });
            S.displayName = "SlotClone";
            var j = ({
                children: e
            }) => (0, d.jsx)(d.Fragment, {
                children: e
            });

            function N(e) {
                return i.isValidElement(e) && e.type === j
            }
            var O = ["a", "button", "div", "form", "h2", "h3", "img", "input", "label", "li", "nav", "ol", "p", "span", "svg", "ul"].reduce((e, t) => {
                    let n = i.forwardRef((e, n) => {
                        let {
                            asChild: r,
                            ...o
                        } = e, a = r ? R : t;
                        return "undefined" != typeof window && (window[Symbol.for("radix-ui")] = !0), (0, d.jsx)(a, { ...o,
                            ref: n
                        })
                    });
                    return n.displayName = `Primitive.${t}`, { ...e,
                        [t]: n
                    }
                }, {}),
                k = "focusScope.autoFocusOnMount",
                L = "focusScope.autoFocusOnUnmount",
                D = {
                    bubbles: !1,
                    cancelable: !0
                },
                T = i.forwardRef((e, t) => {
                    let {
                        loop: n = !1,
                        trapped: r = !1,
                        onMountAutoFocus: o,
                        onUnmountAutoFocus: a,
                        ...l
                    } = e, [c, s] = i.useState(null), f = (0, g.c)(o), p = (0, g.c)(a), v = i.useRef(null), h = (0, u.s)(t, e => s(e)), m = i.useRef({
                        paused: !1,
                        pause() {
                            this.paused = !0
                        },
                        resume() {
                            this.paused = !1
                        }
                    }).current;
                    i.useEffect(() => {
                        if (r) {
                            let e = function(e) {
                                    if (m.paused || !c) return;
                                    let t = e.target;
                                    c.contains(t) ? v.current = t : W(v.current, {
                                        select: !0
                                    })
                                },
                                t = function(e) {
                                    if (m.paused || !c) return;
                                    let t = e.relatedTarget;
                                    null !== t && (c.contains(t) || W(v.current, {
                                        select: !0
                                    }))
                                };
                            document.addEventListener("focusin", e), document.addEventListener("focusout", t);
                            let n = new MutationObserver(function(e) {
                                if (document.activeElement === document.body)
                                    for (let t of e) t.removedNodes.length > 0 && W(c)
                            });
                            return c && n.observe(c, {
                                childList: !0,
                                subtree: !0
                            }), () => {
                                document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), n.disconnect()
                            }
                        }
                    }, [r, c, m.paused]), i.useEffect(() => {
                        if (c) {
                            I.add(m);
                            let e = document.activeElement;
                            if (!c.contains(e)) {
                                let t = new CustomEvent(k, D);
                                c.addEventListener(k, f), c.dispatchEvent(t), t.defaultPrevented || (function(e) {
                                    let {
                                        select: t = !1
                                    } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = document.activeElement;
                                    for (let r of e)
                                        if (W(r, {
                                                select: t
                                            }), document.activeElement !== n) return
                                }(F(c).filter(e => "A" !== e.tagName), {
                                    select: !0
                                }), document.activeElement === e && W(c))
                            }
                            return () => {
                                c.removeEventListener(k, f), setTimeout(() => {
                                    let t = new CustomEvent(L, D);
                                    c.addEventListener(L, p), c.dispatchEvent(t), t.defaultPrevented || W(null != e ? e : document.body, {
                                        select: !0
                                    }), c.removeEventListener(L, p), I.remove(m)
                                }, 0)
                            }
                        }
                    }, [c, f, p, m]);
                    let y = i.useCallback(e => {
                        if (!n && !r || m.paused) return;
                        let t = "Tab" === e.key && !e.altKey && !e.ctrlKey && !e.metaKey,
                            o = document.activeElement;
                        if (t && o) {
                            let t = e.currentTarget,
                                [r, a] = function(e) {
                                    let t = F(e);
                                    return [M(t, e), M(t.reverse(), e)]
                                }(t);
                            r && a ? e.shiftKey || o !== a ? e.shiftKey && o === r && (e.preventDefault(), n && W(a, {
                                select: !0
                            })) : (e.preventDefault(), n && W(r, {
                                select: !0
                            })) : o === t && e.preventDefault()
                        }
                    }, [n, r, m.paused]);
                    return (0, d.jsx)(O.div, {
                        tabIndex: -1,
                        ...l,
                        ref: h,
                        onKeyDown: y
                    })
                });

            function F(e) {
                let t = [],
                    n = document.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, {
                        acceptNode: e => {
                            let t = "INPUT" === e.tagName && "hidden" === e.type;
                            return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP
                        }
                    });
                for (; n.nextNode();) t.push(n.currentNode);
                return t
            }

            function M(e, t) {
                for (let n of e)
                    if (! function(e, t) {
                            let {
                                upTo: n
                            } = t;
                            if ("hidden" === getComputedStyle(e).visibility) return !0;
                            for (; e && (void 0 === n || e !== n);) {
                                if ("none" === getComputedStyle(e).display) return !0;
                                e = e.parentElement
                            }
                            return !1
                        }(n, {
                            upTo: t
                        })) return n
            }

            function W(e) {
                let {
                    select: t = !1
                } = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                if (e && e.focus) {
                    var n;
                    let r = document.activeElement;
                    e.focus({
                        preventScroll: !0
                    }), e !== r && (n = e) instanceof HTMLInputElement && "select" in n && t && e.select()
                }
            }
            T.displayName = "FocusScope";
            var I = function() {
                let e = [];
                return {
                    add(t) {
                        let n = e[0];
                        t !== n && (null == n || n.pause()), (e = B(e, t)).unshift(t)
                    },
                    remove(t) {
                        var n;
                        null == (n = (e = B(e, t))[0]) || n.resume()
                    }
                }
            }();

            function B(e, t) {
                let n = [...e],
                    r = n.indexOf(t);
                return -1 !== r && n.splice(r, 1), n
            }
            var _ = n(68946),
                Y = n(88334),
                X = n(58146),
                z = i.forwardRef((e, t) => {
                    let {
                        children: n,
                        width: r = 10,
                        height: o = 5,
                        ...a
                    } = e;
                    return (0, d.jsx)(m.svg, { ...a,
                        ref: t,
                        width: r,
                        height: o,
                        viewBox: "0 0 30 10",
                        preserveAspectRatio: "none",
                        children: e.asChild ? n : (0, d.jsx)("polygon", {
                            points: "0,0 30,0 15,10"
                        })
                    })
                });
            z.displayName = "Arrow";
            var K = n(4129),
                H = n(84288),
                U = "Popper",
                [V, Z] = (0, c.A)(U),
                [q, $] = V(U),
                G = e => {
                    let {
                        __scopePopper: t,
                        children: n
                    } = e, [r, o] = i.useState(null);
                    return (0, d.jsx)(q, {
                        scope: t,
                        anchor: r,
                        onAnchorChange: o,
                        children: n
                    })
                };
            G.displayName = U;
            var J = "PopperAnchor",
                Q = i.forwardRef((e, t) => {
                    let {
                        __scopePopper: n,
                        virtualRef: r,
                        ...o
                    } = e, a = $(J, n), l = i.useRef(null), c = (0, u.s)(t, l);
                    return i.useEffect(() => {
                        a.onAnchorChange((null == r ? void 0 : r.current) || l.current)
                    }), r ? null : (0, d.jsx)(m.div, { ...o,
                        ref: c
                    })
                });
            Q.displayName = J;
            var ee = "PopperContent",
                [et, en] = V(ee),
                er = i.forwardRef((e, t) => {
                    var n, r, o, a, l, c, s, f;
                    let {
                        __scopePopper: p,
                        side: v = "bottom",
                        sideOffset: h = 0,
                        align: y = "center",
                        alignOffset: w = 0,
                        arrowPadding: b = 0,
                        avoidCollisions: E = !0,
                        collisionBoundary: x = [],
                        collisionPadding: C = 0,
                        sticky: P = "partial",
                        hideWhenDetached: A = !1,
                        updatePositionStrategy: R = "optimized",
                        onPlaced: S,
                        ...j
                    } = e, N = $(ee, p), [O, k] = i.useState(null), L = (0, u.s)(t, e => k(e)), [D, T] = i.useState(null), F = (0, H.X)(D), M = null != (s = null == F ? void 0 : F.width) ? s : 0, W = null != (f = null == F ? void 0 : F.height) ? f : 0, I = "number" == typeof C ? C : {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0,
                        ...C
                    }, B = Array.isArray(x) ? x : [x], _ = B.length > 0, z = {
                        padding: I,
                        boundary: B.filter(el),
                        altBoundary: _
                    }, {
                        refs: U,
                        floatingStyles: V,
                        placement: Z,
                        isPositioned: q,
                        middlewareData: G
                    } = (0, Y.we)({
                        strategy: "fixed",
                        placement: v + ("center" !== y ? "-" + y : ""),
                        whileElementsMounted: function() {
                            for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                            return (0, X.ll)(...t, {
                                animationFrame: "always" === R
                            })
                        },
                        elements: {
                            reference: N.anchor
                        },
                        middleware: [(0, Y.cY)({
                            mainAxis: h + W,
                            alignmentAxis: w
                        }), E && (0, Y.BN)({
                            mainAxis: !0,
                            crossAxis: !1,
                            limiter: "partial" === P ? (0, Y.ER)() : void 0,
                            ...z
                        }), E && (0, Y.UU)({ ...z
                        }), (0, Y.Ej)({ ...z,
                            apply: e => {
                                let {
                                    elements: t,
                                    rects: n,
                                    availableWidth: r,
                                    availableHeight: o
                                } = e, {
                                    width: a,
                                    height: i
                                } = n.reference, l = t.floating.style;
                                l.setProperty("--radix-popper-available-width", "".concat(r, "px")), l.setProperty("--radix-popper-available-height", "".concat(o, "px")), l.setProperty("--radix-popper-anchor-width", "".concat(a, "px")), l.setProperty("--radix-popper-anchor-height", "".concat(i, "px"))
                            }
                        }), D && (0, Y.UE)({
                            element: D,
                            padding: b
                        }), eu({
                            arrowWidth: M,
                            arrowHeight: W
                        }), A && (0, Y.jD)({
                            strategy: "referenceHidden",
                            ...z
                        })]
                    }), [J, Q] = ec(Z), en = (0, g.c)(S);
                    (0, K.N)(() => {
                        q && (null == en || en())
                    }, [q, en]);
                    let er = null == (n = G.arrow) ? void 0 : n.x,
                        eo = null == (r = G.arrow) ? void 0 : r.y,
                        ea = (null == (o = G.arrow) ? void 0 : o.centerOffset) !== 0,
                        [ei, es] = i.useState();
                    return (0, K.N)(() => {
                        O && es(window.getComputedStyle(O).zIndex)
                    }, [O]), (0, d.jsx)("div", {
                        ref: U.setFloating,
                        "data-radix-popper-content-wrapper": "",
                        style: { ...V,
                            transform: q ? V.transform : "translate(0, -200%)",
                            minWidth: "max-content",
                            zIndex: ei,
                            "--radix-popper-transform-origin": [null == (a = G.transformOrigin) ? void 0 : a.x, null == (l = G.transformOrigin) ? void 0 : l.y].join(" "),
                            ...(null == (c = G.hide) ? void 0 : c.referenceHidden) && {
                                visibility: "hidden",
                                pointerEvents: "none"
                            }
                        },
                        dir: e.dir,
                        children: (0, d.jsx)(et, {
                            scope: p,
                            placedSide: J,
                            onArrowChange: T,
                            arrowX: er,
                            arrowY: eo,
                            shouldHideArrow: ea,
                            children: (0, d.jsx)(m.div, {
                                "data-side": J,
                                "data-align": Q,
                                ...j,
                                ref: L,
                                style: { ...j.style,
                                    animation: q ? void 0 : "none"
                                }
                            })
                        })
                    })
                });
            er.displayName = ee;
            var eo = "PopperArrow",
                ea = {
                    top: "bottom",
                    right: "left",
                    bottom: "top",
                    left: "right"
                },
                ei = i.forwardRef(function(e, t) {
                    let {
                        __scopePopper: n,
                        ...r
                    } = e, o = en(eo, n), a = ea[o.placedSide];
                    return (0, d.jsx)("span", {
                        ref: o.onArrowChange,
                        style: {
                            position: "absolute",
                            left: o.arrowX,
                            top: o.arrowY,
                            [a]: 0,
                            transformOrigin: {
                                top: "",
                                right: "0 0",
                                bottom: "center 0",
                                left: "100% 0"
                            }[o.placedSide],
                            transform: {
                                top: "translateY(100%)",
                                right: "translateY(50%) rotate(90deg) translateX(-50%)",
                                bottom: "rotate(180deg)",
                                left: "translateY(50%) rotate(-90deg) translateX(50%)"
                            }[o.placedSide],
                            visibility: o.shouldHideArrow ? "hidden" : void 0
                        },
                        children: (0, d.jsx)(z, { ...r,
                            ref: t,
                            style: { ...r.style,
                                display: "block"
                            }
                        })
                    })
                });

            function el(e) {
                return null !== e
            }
            ei.displayName = eo;
            var eu = e => ({
                name: "transformOrigin",
                options: e,
                fn(t) {
                    var n, r, o, a, i;
                    let {
                        placement: l,
                        rects: u,
                        middlewareData: c
                    } = t, s = (null == (n = c.arrow) ? void 0 : n.centerOffset) !== 0, d = s ? 0 : e.arrowWidth, f = s ? 0 : e.arrowHeight, [p, v] = ec(l), h = {
                        start: "0%",
                        center: "50%",
                        end: "100%"
                    }[v], m = (null != (a = null == (r = c.arrow) ? void 0 : r.x) ? a : 0) + d / 2, g = (null != (i = null == (o = c.arrow) ? void 0 : o.y) ? i : 0) + f / 2, y = "", w = "";
                    return "bottom" === p ? (y = s ? h : "".concat(m, "px"), w = "".concat(-f, "px")) : "top" === p ? (y = s ? h : "".concat(m, "px"), w = "".concat(u.floating.height + f, "px")) : "right" === p ? (y = "".concat(-f, "px"), w = s ? h : "".concat(g, "px")) : "left" === p && (y = "".concat(u.floating.width + f, "px"), w = s ? h : "".concat(g, "px")), {
                        data: {
                            x: y,
                            y: w
                        }
                    }
                }
            });

            function ec(e) {
                let [t, n = "center"] = e.split("-");
                return [t, n]
            }
            var es = i.forwardRef((e, t) => {
                var n, r;
                let {
                    container: o,
                    ...a
                } = e, [l, u] = i.useState(!1);
                (0, K.N)(() => u(!0), []);
                let c = o || l && (null == (r = globalThis) || null == (n = r.document) ? void 0 : n.body);
                return c ? s.createPortal((0, d.jsx)(m.div, { ...a,
                    ref: t
                }), c) : null
            });
            es.displayName = "Portal";
            var ed = n(76842),
                ef = n(23558),
                ep = function(e) {
                    return "undefined" == typeof document ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body
                },
                ev = new WeakMap,
                eh = new WeakMap,
                em = {},
                eg = 0,
                ey = function(e) {
                    return e && (e.host || ey(e.parentNode))
                },
                ew = function(e, t, n, r) {
                    var o = (Array.isArray(e) ? e : [e]).map(function(e) {
                        if (t.contains(e)) return e;
                        var n = ey(e);
                        return n && t.contains(n) ? n : (console.error("aria-hidden", e, "in not contained inside", t, ". Doing nothing"), null)
                    }).filter(function(e) {
                        return !!e
                    });
                    em[n] || (em[n] = new WeakMap);
                    var a = em[n],
                        i = [],
                        l = new Set,
                        u = new Set(o),
                        c = function(e) {
                            !e || l.has(e) || (l.add(e), c(e.parentNode))
                        };
                    o.forEach(c);
                    var s = function(e) {
                        !e || u.has(e) || Array.prototype.forEach.call(e.children, function(e) {
                            if (l.has(e)) s(e);
                            else try {
                                var t = e.getAttribute(r),
                                    o = null !== t && "false" !== t,
                                    u = (ev.get(e) || 0) + 1,
                                    c = (a.get(e) || 0) + 1;
                                ev.set(e, u), a.set(e, c), i.push(e), 1 === u && o && eh.set(e, !0), 1 === c && e.setAttribute(n, "true"), o || e.setAttribute(r, "true")
                            } catch (t) {
                                console.error("aria-hidden: cannot operate on ", e, t)
                            }
                        })
                    };
                    return s(t), l.clear(), eg++,
                        function() {
                            i.forEach(function(e) {
                                var t = ev.get(e) - 1,
                                    o = a.get(e) - 1;
                                ev.set(e, t), a.set(e, o), t || (eh.has(e) || e.removeAttribute(r), eh.delete(e)), o || e.removeAttribute(n)
                            }), --eg || (ev = new WeakMap, ev = new WeakMap, eh = new WeakMap, em = {})
                        }
                },
                eb = function(e, t, n) {
                    void 0 === n && (n = "data-aria-hidden");
                    var r = Array.from(Array.isArray(e) ? e : [e]),
                        o = t || ep(e);
                    return o ? (r.push.apply(r, Array.from(o.querySelectorAll("[aria-live]"))), ew(r, o, n, "aria-hidden")) : function() {
                        return null
                    }
                },
                eE = function() {
                    return (eE = Object.assign || function(e) {
                        for (var t, n = 1, r = arguments.length; n < r; n++)
                            for (var o in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                        return e
                    }).apply(this, arguments)
                };

            function ex(e, t) {
                var n = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (n[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) 0 > t.indexOf(r[o]) && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (n[r[o]] = e[r[o]]);
                return n
            }
            Object.create;
            Object.create;
            var eC = ("function" == typeof SuppressedError && SuppressedError, "right-scroll-bar-position"),
                eP = "width-before-scroll-bar";

            function eA(e, t) {
                return "function" == typeof e ? e(t) : e && (e.current = t), e
            }
            var eR = "undefined" != typeof window ? i.useLayoutEffect : i.useEffect,
                eS = new WeakMap;

            function ej(e) {
                return e
            }
            var eN = function(e) {
                    void 0 === e && (e = {});
                    var t, n, r, o, a = (t = null, void 0 === n && (n = ej), r = [], o = !1, {
                        read: function() {
                            if (o) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
                            return r.length ? r[r.length - 1] : null
                        },
                        useMedium: function(e) {
                            var t = n(e, o);
                            return r.push(t),
                                function() {
                                    r = r.filter(function(e) {
                                        return e !== t
                                    })
                                }
                        },
                        assignSyncMedium: function(e) {
                            for (o = !0; r.length;) {
                                var t = r;
                                r = [], t.forEach(e)
                            }
                            r = {
                                push: function(t) {
                                    return e(t)
                                },
                                filter: function() {
                                    return r
                                }
                            }
                        },
                        assignMedium: function(e) {
                            o = !0;
                            var t = [];
                            if (r.length) {
                                var n = r;
                                r = [], n.forEach(e), t = r
                            }
                            var a = function() {
                                    var n = t;
                                    t = [], n.forEach(e)
                                },
                                i = function() {
                                    return Promise.resolve().then(a)
                                };
                            i(), r = {
                                push: function(e) {
                                    t.push(e), i()
                                },
                                filter: function(e) {
                                    return t = t.filter(e), r
                                }
                            }
                        }
                    });
                    return a.options = eE({
                        async: !0,
                        ssr: !1
                    }, e), a
                }(),
                eO = function() {},
                ek = i.forwardRef(function(e, t) {
                    var n, r, o, a, l = i.useRef(null),
                        u = i.useState({
                            onScrollCapture: eO,
                            onWheelCapture: eO,
                            onTouchMoveCapture: eO
                        }),
                        c = u[0],
                        s = u[1],
                        d = e.forwardProps,
                        f = e.children,
                        p = e.className,
                        v = e.removeScrollBar,
                        h = e.enabled,
                        m = e.shards,
                        g = e.sideCar,
                        y = e.noIsolation,
                        w = e.inert,
                        b = e.allowPinchZoom,
                        E = e.as,
                        x = e.gapMode,
                        C = ex(e, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]),
                        P = (n = [l, t], r = function(e) {
                            return n.forEach(function(t) {
                                return eA(t, e)
                            })
                        }, (o = (0, i.useState)(function() {
                            return {
                                value: null,
                                callback: r,
                                facade: {
                                    get current() {
                                        return o.value
                                    },
                                    set current(value) {
                                        var e = o.value;
                                        e !== value && (o.value = value, o.callback(value, e))
                                    }
                                }
                            }
                        })[0]).callback = r, a = o.facade, eR(function() {
                            var e = eS.get(a);
                            if (e) {
                                var t = new Set(e),
                                    r = new Set(n),
                                    o = a.current;
                                t.forEach(function(e) {
                                    r.has(e) || eA(e, null)
                                }), r.forEach(function(e) {
                                    t.has(e) || eA(e, o)
                                })
                            }
                            eS.set(a, n)
                        }, [n]), a),
                        A = eE(eE({}, C), c);
                    return i.createElement(i.Fragment, null, h && i.createElement(g, {
                        sideCar: eN,
                        removeScrollBar: v,
                        shards: m,
                        noIsolation: y,
                        inert: w,
                        setCallbacks: s,
                        allowPinchZoom: !!b,
                        lockRef: l,
                        gapMode: x
                    }), d ? i.cloneElement(i.Children.only(f), eE(eE({}, A), {
                        ref: P
                    })) : i.createElement(void 0 === E ? "div" : E, eE({}, A, {
                        className: p,
                        ref: P
                    }), f))
                });
            ek.defaultProps = {
                enabled: !0,
                removeScrollBar: !0,
                inert: !1
            }, ek.classNames = {
                fullWidth: eP,
                zeroRight: eC
            };
            var eL = function(e) {
                var t = e.sideCar,
                    n = ex(e, ["sideCar"]);
                if (!t) throw Error("Sidecar: please provide `sideCar` property to import the right car");
                var r = t.read();
                if (!r) throw Error("Sidecar medium not found");
                return i.createElement(r, eE({}, n))
            };
            eL.isSideCarExport = !0;
            var eD = function() {
                    var e = 0,
                        t = null;
                    return {
                        add: function(r) {
                            if (0 == e && (t = function() {
                                    if (!document) return null;
                                    var e = document.createElement("style");
                                    e.type = "text/css";
                                    var t = a || n.nc;
                                    return t && e.setAttribute("nonce", t), e
                                }())) {
                                var o, i;
                                (o = t).styleSheet ? o.styleSheet.cssText = r : o.appendChild(document.createTextNode(r)), i = t, (document.head || document.getElementsByTagName("head")[0]).appendChild(i)
                            }
                            e++
                        },
                        remove: function() {
                            --e || !t || (t.parentNode && t.parentNode.removeChild(t), t = null)
                        }
                    }
                },
                eT = function() {
                    var e = eD();
                    return function(t, n) {
                        i.useEffect(function() {
                            return e.add(t),
                                function() {
                                    e.remove()
                                }
                        }, [t && n])
                    }
                },
                eF = function() {
                    var e = eT();
                    return function(t) {
                        return e(t.styles, t.dynamic), null
                    }
                },
                eM = {
                    left: 0,
                    top: 0,
                    right: 0,
                    gap: 0
                },
                eW = function(e) {
                    return parseInt(e || "", 10) || 0
                },
                eI = function(e) {
                    var t = window.getComputedStyle(document.body),
                        n = t["padding" === e ? "paddingLeft" : "marginLeft"],
                        r = t["padding" === e ? "paddingTop" : "marginTop"],
                        o = t["padding" === e ? "paddingRight" : "marginRight"];
                    return [eW(n), eW(r), eW(o)]
                },
                eB = function(e) {
                    if (void 0 === e && (e = "margin"), "undefined" == typeof window) return eM;
                    var t = eI(e),
                        n = document.documentElement.clientWidth,
                        r = window.innerWidth;
                    return {
                        left: t[0],
                        top: t[1],
                        right: t[2],
                        gap: Math.max(0, r - n + t[2] - t[0])
                    }
                },
                e_ = eF(),
                eY = "data-scroll-locked",
                eX = function(e, t, n, r) {
                    var o = e.left,
                        a = e.top,
                        i = e.right,
                        l = e.gap;
                    return void 0 === n && (n = "margin"), "\n  .".concat("with-scroll-bars-hidden", " {\n   overflow: hidden ").concat(r, ";\n   padding-right: ").concat(l, "px ").concat(r, ";\n  }\n  body[").concat(eY, "] {\n    overflow: hidden ").concat(r, ";\n    overscroll-behavior: contain;\n    ").concat([t && "position: relative ".concat(r, ";"), "margin" === n && "\n    padding-left: ".concat(o, "px;\n    padding-top: ").concat(a, "px;\n    padding-right: ").concat(i, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(l, "px ").concat(r, ";\n    "), "padding" === n && "padding-right: ".concat(l, "px ").concat(r, ";")].filter(Boolean).join(""), "\n  }\n  \n  .").concat(eC, " {\n    right: ").concat(l, "px ").concat(r, ";\n  }\n  \n  .").concat(eP, " {\n    margin-right: ").concat(l, "px ").concat(r, ";\n  }\n  \n  .").concat(eC, " .").concat(eC, " {\n    right: 0 ").concat(r, ";\n  }\n  \n  .").concat(eP, " .").concat(eP, " {\n    margin-right: 0 ").concat(r, ";\n  }\n  \n  body[").concat(eY, "] {\n    ").concat("--removed-body-scroll-bar-size", ": ").concat(l, "px;\n  }\n")
                },
                ez = function() {
                    var e = parseInt(document.body.getAttribute(eY) || "0", 10);
                    return isFinite(e) ? e : 0
                },
                eK = function() {
                    i.useEffect(function() {
                        return document.body.setAttribute(eY, (ez() + 1).toString()),
                            function() {
                                var e = ez() - 1;
                                e <= 0 ? document.body.removeAttribute(eY) : document.body.setAttribute(eY, e.toString())
                            }
                    }, [])
                },
                eH = function(e) {
                    var t = e.noRelative,
                        n = e.noImportant,
                        r = e.gapMode,
                        o = void 0 === r ? "margin" : r;
                    eK();
                    var a = i.useMemo(function() {
                        return eB(o)
                    }, [o]);
                    return i.createElement(e_, {
                        styles: eX(a, !t, o, n ? "" : "!important")
                    })
                },
                eU = !1;
            if ("undefined" != typeof window) try {
                var eV = Object.defineProperty({}, "passive", {
                    get: function() {
                        return eU = !0, !0
                    }
                });
                window.addEventListener("test", eV, eV), window.removeEventListener("test", eV, eV)
            } catch (e) {
                eU = !1
            }
            var eZ = !!eU && {
                    passive: !1
                },
                eq = function(e, t) {
                    if (!(e instanceof Element)) return !1;
                    var n = window.getComputedStyle(e);
                    return "hidden" !== n[t] && (n.overflowY !== n.overflowX || "TEXTAREA" === e.tagName || "visible" !== n[t])
                },
                e$ = function(e, t) {
                    var n = t.ownerDocument,
                        r = t;
                    do {
                        if ("undefined" != typeof ShadowRoot && r instanceof ShadowRoot && (r = r.host), eG(e, r)) {
                            var o = eJ(e, r);
                            if (o[1] > o[2]) return !0
                        }
                        r = r.parentNode
                    } while (r && r !== n.body);
                    return !1
                },
                eG = function(e, t) {
                    return "v" === e ? eq(t, "overflowY") : eq(t, "overflowX")
                },
                eJ = function(e, t) {
                    return "v" === e ? [t.scrollTop, t.scrollHeight, t.clientHeight] : [t.scrollLeft, t.scrollWidth, t.clientWidth]
                },
                eQ = function(e, t, n, r, o) {
                    var a, i = (a = window.getComputedStyle(t).direction, "h" === e && "rtl" === a ? -1 : 1),
                        l = i * r,
                        u = n.target,
                        c = t.contains(u),
                        s = !1,
                        d = l > 0,
                        f = 0,
                        p = 0;
                    do {
                        var v = eJ(e, u),
                            h = v[0],
                            m = v[1] - v[2] - i * h;
                        (h || m) && eG(e, u) && (f += m, p += h), u = u instanceof ShadowRoot ? u.host : u.parentNode
                    } while (!c && u !== document.body || c && (t.contains(u) || t === u));
                    return d && (o && 1 > Math.abs(f) || !o && l > f) ? s = !0 : !d && (o && 1 > Math.abs(p) || !o && -l > p) && (s = !0), s
                },
                e0 = function(e) {
                    return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0]
                },
                e1 = function(e) {
                    return [e.deltaX, e.deltaY]
                },
                e2 = function(e) {
                    return e && "current" in e ? e.current : e
                },
                e9 = 0,
                e5 = [];
            let e4 = (r = function(e) {
                var t = i.useRef([]),
                    n = i.useRef([0, 0]),
                    r = i.useRef(),
                    o = i.useState(e9++)[0],
                    a = i.useState(eF)[0],
                    l = i.useRef(e);
                i.useEffect(function() {
                    l.current = e
                }, [e]), i.useEffect(function() {
                    if (e.inert) {
                        document.body.classList.add("block-interactivity-".concat(o));
                        var t = (function(e, t, n) {
                            if (n || 2 == arguments.length)
                                for (var r, o = 0, a = t.length; o < a; o++) !r && o in t || (r || (r = Array.prototype.slice.call(t, 0, o)), r[o] = t[o]);
                            return e.concat(r || Array.prototype.slice.call(t))
                        })([e.lockRef.current], (e.shards || []).map(e2), !0).filter(Boolean);
                        return t.forEach(function(e) {
                                return e.classList.add("allow-interactivity-".concat(o))
                            }),
                            function() {
                                document.body.classList.remove("block-interactivity-".concat(o)), t.forEach(function(e) {
                                    return e.classList.remove("allow-interactivity-".concat(o))
                                })
                            }
                    }
                }, [e.inert, e.lockRef.current, e.shards]);
                var u = i.useCallback(function(e, t) {
                        if ("touches" in e && 2 === e.touches.length || "wheel" === e.type && e.ctrlKey) return !l.current.allowPinchZoom;
                        var o, a = e0(e),
                            i = n.current,
                            u = "deltaX" in e ? e.deltaX : i[0] - a[0],
                            c = "deltaY" in e ? e.deltaY : i[1] - a[1],
                            s = e.target,
                            d = Math.abs(u) > Math.abs(c) ? "h" : "v";
                        if ("touches" in e && "h" === d && "range" === s.type) return !1;
                        var f = e$(d, s);
                        if (!f) return !0;
                        if (f ? o = d : (o = "v" === d ? "h" : "v", f = e$(d, s)), !f) return !1;
                        if (!r.current && "changedTouches" in e && (u || c) && (r.current = o), !o) return !0;
                        var p = r.current || o;
                        return eQ(p, t, e, "h" === p ? u : c, !0)
                    }, []),
                    c = i.useCallback(function(e) {
                        if (e5.length && e5[e5.length - 1] === a) {
                            var n = "deltaY" in e ? e1(e) : e0(e),
                                r = t.current.filter(function(t) {
                                    var r;
                                    return t.name === e.type && (t.target === e.target || e.target === t.shadowParent) && (r = t.delta, r[0] === n[0] && r[1] === n[1])
                                })[0];
                            if (r && r.should) {
                                e.cancelable && e.preventDefault();
                                return
                            }
                            if (!r) {
                                var o = (l.current.shards || []).map(e2).filter(Boolean).filter(function(t) {
                                    return t.contains(e.target)
                                });
                                (o.length > 0 ? u(e, o[0]) : !l.current.noIsolation) && e.cancelable && e.preventDefault()
                            }
                        }
                    }, []),
                    s = i.useCallback(function(e, n, r, o) {
                        var a = {
                            name: e,
                            delta: n,
                            target: r,
                            should: o,
                            shadowParent: function(e) {
                                for (var t = null; null !== e;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
                                return t
                            }(r)
                        };
                        t.current.push(a), setTimeout(function() {
                            t.current = t.current.filter(function(e) {
                                return e !== a
                            })
                        }, 1)
                    }, []),
                    d = i.useCallback(function(e) {
                        n.current = e0(e), r.current = void 0
                    }, []),
                    f = i.useCallback(function(t) {
                        s(t.type, e1(t), t.target, u(t, e.lockRef.current))
                    }, []),
                    p = i.useCallback(function(t) {
                        s(t.type, e0(t), t.target, u(t, e.lockRef.current))
                    }, []);
                i.useEffect(function() {
                    return e5.push(a), e.setCallbacks({
                            onScrollCapture: f,
                            onWheelCapture: f,
                            onTouchMoveCapture: p
                        }), document.addEventListener("wheel", c, eZ), document.addEventListener("touchmove", c, eZ), document.addEventListener("touchstart", d, eZ),
                        function() {
                            e5 = e5.filter(function(e) {
                                return e !== a
                            }), document.removeEventListener("wheel", c, eZ), document.removeEventListener("touchmove", c, eZ), document.removeEventListener("touchstart", d, eZ)
                        }
                }, []);
                var v = e.removeScrollBar,
                    h = e.inert;
                return i.createElement(i.Fragment, null, h ? i.createElement(a, {
                    styles: "\n  .block-interactivity-".concat(o, " {pointer-events: none;}\n  .allow-interactivity-").concat(o, " {pointer-events: all;}\n")
                }) : null, v ? i.createElement(eH, {
                    gapMode: e.gapMode
                }) : null)
            }, eN.useMedium(r), eL);
            var e8 = i.forwardRef(function(e, t) {
                return i.createElement(ek, eE({}, e, {
                    ref: t,
                    sideCar: e4
                }))
            });
            e8.classNames = ek.classNames;
            var e6 = "Popover",
                [e3, e7] = (0, c.A)(e6, [Z]),
                te = Z(),
                [tt, tn] = e3(e6),
                tr = e => {
                    let {
                        __scopePopover: t,
                        children: n,
                        open: r,
                        defaultOpen: o,
                        onOpenChange: a,
                        modal: l = !1
                    } = e, u = te(t), c = i.useRef(null), [s, f] = i.useState(!1), [p = !1, v] = (0, ef.i)({
                        prop: r,
                        defaultProp: o,
                        onChange: a
                    });
                    return (0, d.jsx)(G, { ...u,
                        children: (0, d.jsx)(tt, {
                            scope: t,
                            contentId: (0, _.B)(),
                            triggerRef: c,
                            open: p,
                            onOpenChange: v,
                            onOpenToggle: i.useCallback(() => v(e => !e), [v]),
                            hasCustomAnchor: s,
                            onCustomAnchorAdd: i.useCallback(() => f(!0), []),
                            onCustomAnchorRemove: i.useCallback(() => f(!1), []),
                            modal: l,
                            children: n
                        })
                    })
                };
            tr.displayName = e6;
            var to = "PopoverAnchor",
                ta = i.forwardRef((e, t) => {
                    let {
                        __scopePopover: n,
                        ...r
                    } = e, o = tn(to, n), a = te(n), {
                        onCustomAnchorAdd: l,
                        onCustomAnchorRemove: u
                    } = o;
                    return i.useEffect(() => (l(), () => u()), [l, u]), (0, d.jsx)(Q, { ...a,
                        ...r,
                        ref: t
                    })
                });
            ta.displayName = to;
            var ti = "PopoverTrigger",
                tl = i.forwardRef((e, t) => {
                    let {
                        __scopePopover: n,
                        ...r
                    } = e, o = tn(ti, n), a = te(n), i = (0, u.s)(t, o.triggerRef), c = (0, d.jsx)(m.button, {
                        type: "button",
                        "aria-haspopup": "dialog",
                        "aria-expanded": o.open,
                        "aria-controls": o.contentId,
                        "data-state": ty(o.open),
                        ...r,
                        ref: i,
                        onClick: (0, l.m)(e.onClick, o.onOpenToggle)
                    });
                    return o.hasCustomAnchor ? c : (0, d.jsx)(Q, {
                        asChild: !0,
                        ...a,
                        children: c
                    })
                });
            tl.displayName = ti;
            var tu = "PopoverPortal",
                [tc, ts] = e3(tu, {
                    forceMount: void 0
                }),
                td = e => {
                    let {
                        __scopePopover: t,
                        forceMount: n,
                        children: r,
                        container: o
                    } = e, a = tn(tu, t);
                    return (0, d.jsx)(tc, {
                        scope: t,
                        forceMount: n,
                        children: (0, d.jsx)(ed.C, {
                            present: n || a.open,
                            children: (0, d.jsx)(es, {
                                asChild: !0,
                                container: o,
                                children: r
                            })
                        })
                    })
                };
            td.displayName = tu;
            var tf = "PopoverContent",
                tp = i.forwardRef((e, t) => {
                    let n = ts(tf, e.__scopePopover),
                        {
                            forceMount: r = n.forceMount,
                            ...o
                        } = e,
                        a = tn(tf, e.__scopePopover);
                    return (0, d.jsx)(ed.C, {
                        present: r || a.open,
                        children: a.modal ? (0, d.jsx)(tv, { ...o,
                            ref: t
                        }) : (0, d.jsx)(th, { ...o,
                            ref: t
                        })
                    })
                });
            tp.displayName = tf;
            var tv = i.forwardRef((e, t) => {
                    let n = tn(tf, e.__scopePopover),
                        r = i.useRef(null),
                        o = (0, u.s)(t, r),
                        a = i.useRef(!1);
                    return i.useEffect(() => {
                        let e = r.current;
                        if (e) return eb(e)
                    }, []), (0, d.jsx)(e8, {
                        as: f,
                        allowPinchZoom: !0,
                        children: (0, d.jsx)(tm, { ...e,
                            ref: o,
                            trapFocus: n.open,
                            disableOutsidePointerEvents: !0,
                            onCloseAutoFocus: (0, l.m)(e.onCloseAutoFocus, e => {
                                var t;
                                e.preventDefault(), a.current || null == (t = n.triggerRef.current) || t.focus()
                            }),
                            onPointerDownOutside: (0, l.m)(e.onPointerDownOutside, e => {
                                let t = e.detail.originalEvent,
                                    n = 0 === t.button && !0 === t.ctrlKey;
                                a.current = 2 === t.button || n
                            }, {
                                checkForDefaultPrevented: !1
                            }),
                            onFocusOutside: (0, l.m)(e.onFocusOutside, e => e.preventDefault(), {
                                checkForDefaultPrevented: !1
                            })
                        })
                    })
                }),
                th = i.forwardRef((e, t) => {
                    let n = tn(tf, e.__scopePopover),
                        r = i.useRef(!1),
                        o = i.useRef(!1);
                    return (0, d.jsx)(tm, { ...e,
                        ref: t,
                        trapFocus: !1,
                        disableOutsidePointerEvents: !1,
                        onCloseAutoFocus: t => {
                            var a, i;
                            null == (a = e.onCloseAutoFocus) || a.call(e, t), t.defaultPrevented || (r.current || null == (i = n.triggerRef.current) || i.focus(), t.preventDefault()), r.current = !1, o.current = !1
                        },
                        onInteractOutside: t => {
                            var a, i;
                            null == (a = e.onInteractOutside) || a.call(e, t), t.defaultPrevented || (r.current = !0, "pointerdown" === t.detail.originalEvent.type && (o.current = !0));
                            let l = t.target;
                            (null == (i = n.triggerRef.current) ? void 0 : i.contains(l)) && t.preventDefault(), "focusin" === t.detail.originalEvent.type && o.current && t.preventDefault()
                        }
                    })
                }),
                tm = i.forwardRef((e, t) => {
                    let {
                        __scopePopover: n,
                        trapFocus: r,
                        onOpenAutoFocus: o,
                        onCloseAutoFocus: a,
                        disableOutsidePointerEvents: l,
                        onEscapeKeyDown: u,
                        onPointerDownOutside: c,
                        onFocusOutside: s,
                        onInteractOutside: f,
                        ...p
                    } = e, v = tn(tf, n), h = te(n);
                    return i.useEffect(() => {
                        var e, t;
                        let n = document.querySelectorAll("[data-radix-focus-guard]");
                        return document.body.insertAdjacentElement("afterbegin", null != (e = n[0]) ? e : A()), document.body.insertAdjacentElement("beforeend", null != (t = n[1]) ? t : A()), P++, () => {
                            1 === P && document.querySelectorAll("[data-radix-focus-guard]").forEach(e => e.remove()), P--
                        }
                    }, []), (0, d.jsx)(T, {
                        asChild: !0,
                        loop: !0,
                        trapped: r,
                        onMountAutoFocus: o,
                        onUnmountAutoFocus: a,
                        children: (0, d.jsx)(E, {
                            asChild: !0,
                            disableOutsidePointerEvents: l,
                            onInteractOutside: f,
                            onEscapeKeyDown: u,
                            onPointerDownOutside: c,
                            onFocusOutside: s,
                            onDismiss: () => v.onOpenChange(!1),
                            children: (0, d.jsx)(er, {
                                "data-state": ty(v.open),
                                role: "dialog",
                                id: v.contentId,
                                ...h,
                                ...p,
                                ref: t,
                                style: { ...p.style,
                                    "--radix-popover-content-transform-origin": "var(--radix-popper-transform-origin)",
                                    "--radix-popover-content-available-width": "var(--radix-popper-available-width)",
                                    "--radix-popover-content-available-height": "var(--radix-popper-available-height)",
                                    "--radix-popover-trigger-width": "var(--radix-popper-anchor-width)",
                                    "--radix-popover-trigger-height": "var(--radix-popper-anchor-height)"
                                }
                            })
                        })
                    })
                }),
                tg = "PopoverClose";

            function ty(e) {
                return e ? "open" : "closed"
            }
            i.forwardRef((e, t) => {
                let {
                    __scopePopover: n,
                    ...r
                } = e, o = tn(tg, n);
                return (0, d.jsx)(m.button, {
                    type: "button",
                    ...r,
                    ref: t,
                    onClick: (0, l.m)(e.onClick, () => o.onOpenChange(!1))
                })
            }).displayName = tg, i.forwardRef((e, t) => {
                let {
                    __scopePopover: n,
                    ...r
                } = e, o = te(n);
                return (0, d.jsx)(ei, { ...o,
                    ...r,
                    ref: t
                })
            }).displayName = "PopoverArrow";
            var tw = tr,
                tb = ta,
                tE = tl,
                tx = td,
                tC = tp
        },
        59007: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(14294).A)("ChevronDown", [
                ["path", {
                    d: "m6 9 6 6 6-6",
                    key: "qrunsl"
                }]
            ])
        },
        90109: (e, t, n) => {
            n.d(t, {
                A: () => r
            });
            let r = (0, n(14294).A)("Search", [
                ["circle", {
                    cx: "11",
                    cy: "11",
                    r: "8",
                    key: "4ej97u"
                }],
                ["path", {
                    d: "m21 21-4.3-4.3",
                    key: "1qie3q"
                }]
            ])
        }
    }
]);