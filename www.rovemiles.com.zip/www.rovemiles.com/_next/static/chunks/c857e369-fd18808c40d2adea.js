! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "3a2910f7-d9c3-493c-be1b-7d0a684222c3", e._sentryDebugIdIdentifier = "sentry-dbid-3a2910f7-d9c3-493c-be1b-7d0a684222c3")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9933], {
        14679: (e, t, r) => {
            r.d(t, {
                A: () => au
            });
            var n, i, o, s = r(81029).hp,
                a = r(95704);
            if ("undefined" == typeof window) {
                var c = {
                    hostname: ""
                };
                n4 = {
                    crypto: {
                        randomUUID: function() {
                            throw Error("unsupported")
                        }
                    },
                    navigator: {
                        userAgent: "",
                        onLine: !0
                    },
                    document: {
                        createElement: function() {
                            return {}
                        },
                        location: c,
                        referrer: ""
                    },
                    screen: {
                        width: 0,
                        height: 0
                    },
                    location: c,
                    addEventListener: function() {},
                    removeEventListener: function() {}
                }
            } else n4 = window;

            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
                return n
            }

            function l(e, t, r, n, i, o, s) {
                try {
                    var a = e[o](s),
                        c = a.value
                } catch (e) {
                    r(e);
                    return
                }
                a.done ? t(c) : Promise.resolve(c).then(n, i)
            }

            function p(e) {
                return function() {
                    var t = this,
                        r = arguments;
                    return new Promise(function(n, i) {
                        var o = e.apply(t, r);

                        function s(e) {
                            l(o, n, i, s, a, "next", e)
                        }

                        function a(e) {
                            l(o, n, i, s, a, "throw", e)
                        }
                        s(void 0)
                    })
                }
            }

            function h(e, t, r) {
                return (h = k() ? Reflect.construct : function(e, t, r) {
                    var n = [null];
                    n.push.apply(n, t);
                    var i = new(Function.bind.apply(e, n));
                    return r && _(i, r.prototype), i
                }).apply(null, arguments)
            }

            function f(e, t, r) {
                return t && function(e, t) {
                    for (var r = 0; r < t.length; r++) {
                        var n = t[r];
                        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
                    }
                }(e.prototype, t), e
            }

            function d() {
                return (d = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function m(e) {
                return (m = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e)
                })(e)
            }

            function g(e, t) {
                if ("function" != typeof t && null !== t) throw TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), t && _(e, t)
            }

            function v(e, t) {
                return null != t && "undefined" != typeof Symbol && t[Symbol.hasInstance] ? !!t[Symbol.hasInstance](e) : e instanceof t
            }

            function y(e, t) {
                if (null == e) return {};
                var r, n, i = {},
                    o = Object.keys(e);
                for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                return i
            }

            function _(e, t) {
                return (_ = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }

            function b(e) {
                return e && "undefined" != typeof Symbol && e.constructor === Symbol ? "symbol" : typeof e
            }

            function w(e) {
                var t = "function" == typeof Map ? new Map : void 0;
                return (w = function(e) {
                    if (null === e || -1 === Function.toString.call(e).indexOf("[native code]")) return e;
                    if ("function" != typeof e) throw TypeError("Super expression must either be null or a function");
                    if (void 0 !== t) {
                        if (t.has(e)) return t.get(e);
                        t.set(e, r)
                    }

                    function r() {
                        return h(e, arguments, m(this).constructor)
                    }
                    return r.prototype = Object.create(e.prototype, {
                        constructor: {
                            value: r,
                            enumerable: !1,
                            writable: !0,
                            configurable: !0
                        }
                    }), _(r, e)
                })(e)
            }

            function k() {
                try {
                    var e = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
                } catch (e) {}
                return (k = function() {
                    return !!e
                })()
            }

            function S(e, t) {
                var r = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (r) return (r = r.call(e)).next.bind(r);
                if (Array.isArray(e) || (r = function(e, t) {
                        if (e) {
                            if ("string" == typeof e) return u(e, void 0);
                            var r = Object.prototype.toString.call(e).slice(8, -1);
                            if ("Object" === r && e.constructor && (r = e.constructor.name), "Map" === r || "Set" === r) return Array.from(r);
                            if ("Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)) return u(e, void 0)
                        }
                    }(e)) || t) {
                    r && (e = r);
                    var n = 0;
                    return function() {
                        return n >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[n++]
                        }
                    }
                }
                throw TypeError("Invalid attempt to iterate non-iterable instance.\\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }

            function C(e, t) {
                var r, n, i, o, s = {
                    label: 0,
                    sent: function() {
                        if (1 & i[0]) throw i[1];
                        return i[1]
                    },
                    trys: [],
                    ops: []
                };
                return o = {
                    next: a(0),
                    throw: a(1),
                    return: a(2)
                }, "function" == typeof Symbol && (o[Symbol.iterator] = function() {
                    return this
                }), o;

                function a(o) {
                    return function(a) {
                        var c = [o, a];
                        if (r) throw TypeError("Generator is already executing.");
                        for (; s;) try {
                            if (r = 1, n && (i = 2 & c[0] ? n.return : c[0] ? n.throw || ((i = n.return) && i.call(n), 0) : n.next) && !(i = i.call(n, c[1])).done) return i;
                            switch (n = 0, i && (c = [2 & c[0], i.value]), c[0]) {
                                case 0:
                                case 1:
                                    i = c;
                                    break;
                                case 4:
                                    return s.label++, {
                                        value: c[1],
                                        done: !1
                                    };
                                case 5:
                                    s.label++, n = c[1], c = [0];
                                    continue;
                                case 7:
                                    c = s.ops.pop(), s.trys.pop();
                                    continue;
                                default:
                                    if (!(i = (i = s.trys).length > 0 && i[i.length - 1]) && (6 === c[0] || 2 === c[0])) {
                                        s = 0;
                                        continue
                                    }
                                    if (3 === c[0] && (!i || c[1] > i[0] && c[1] < i[3])) {
                                        s.label = c[1];
                                        break
                                    }
                                    if (6 === c[0] && s.label < i[1]) {
                                        s.label = i[1], i = c;
                                        break
                                    }
                                    if (i && s.label < i[2]) {
                                        s.label = i[2], s.ops.push(c);
                                        break
                                    }
                                    i[2] && s.ops.pop(), s.trys.pop();
                                    continue
                            }
                            c = t.call(e, s)
                        } catch (e) {
                            c = [6, e], n = 0
                        } finally {
                            r = i = 0
                        }
                        if (5 & c[0]) throw c[1];
                        return {
                            value: c[0] ? c[1] : void 0,
                            done: !0
                        }
                    }
                }
            }

            function I(e) {
                var t = "function" == typeof Symbol && Symbol.iterator,
                    r = t && e[t],
                    n = 0;
                if (r) return r.call(e);
                if (e && "number" == typeof e.length) return {
                    next: function() {
                        return e && n >= e.length && (e = void 0), {
                            value: e && e[n++],
                            done: !e
                        }
                    }
                };
                throw TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.")
            }
            var x = Object.defineProperty,
                O = function(e, t, r) {
                    var n;
                    return n = (void 0 === t ? "undefined" : b(t)) !== "symbol" ? t + "" : t, n in e ? x(e, n, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: r
                    }) : e[n] = r
                },
                E = Object.defineProperty,
                M = function(e, t, r) {
                    var n;
                    return n = (void 0 === t ? "undefined" : b(t)) !== "symbol" ? t + "" : t, n in e ? E(e, n, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: r
                    }) : e[n] = r
                },
                R = function(e) {
                    return e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment", e
                }(R || {}),
                A = {
                    Node: ["childNodes", "parentNode", "parentElement", "textContent"],
                    ShadowRoot: ["host", "styleSheets"],
                    Element: ["shadowRoot", "querySelector", "querySelectorAll"],
                    MutationObserver: []
                },
                T = {
                    Node: ["contains", "getRootNode"],
                    ShadowRoot: ["getSelection"],
                    Element: [],
                    MutationObserver: ["constructor"]
                },
                N = {};

            function P(e) {
                if (N[e]) return N[e];
                var t = globalThis[e],
                    r = t.prototype,
                    n = e in A ? A[e] : void 0,
                    i = !!(n && n.every(function(e) {
                        var t, n;
                        return !!(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
                    })),
                    o = e in T ? T[e] : void 0,
                    s = !!(o && o.every(function(e) {
                        var t;
                        return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
                    }));
                if (i && s && !globalThis.Zone) return N[e] = t.prototype, t.prototype;
                try {
                    var a = document.createElement("iframe");
                    document.body.appendChild(a);
                    var c = a.contentWindow;
                    if (!c) return t.prototype;
                    var u = c[e].prototype;
                    if (document.body.removeChild(a), !u) return r;
                    return N[e] = u
                } catch (e) {
                    return r
                }
            }
            var D = {};

            function L(e, t, r) {
                var n, i = e + "." + String(r);
                if (D[i]) return D[i].call(t);
                var o = null == (n = Object.getOwnPropertyDescriptor(P(e), r)) ? void 0 : n.get;
                return o ? (D[i] = o, o.call(t)) : t[r]
            }
            var F = {},
                U = {
                    childNodes: function(e) {
                        return L("Node", e, "childNodes")
                    },
                    parentNode: function(e) {
                        return L("Node", e, "parentNode")
                    },
                    parentElement: function(e) {
                        return L("Node", e, "parentElement")
                    },
                    textContent: function(e) {
                        return L("Node", e, "textContent")
                    },
                    host: function(e) {
                        return e && "host" in e ? L("ShadowRoot", e, "host") : null
                    },
                    shadowRoot: function(e) {
                        return e && "shadowRoot" in e ? L("Element", e, "shadowRoot") : null
                    }
                };

            function B(e) {
                return e.nodeType === e.ELEMENT_NODE
            }

            function j(e) {
                var t = e && "host" in e && "mode" in e && U.host(e) || null;
                return !!(t && "shadowRoot" in t && U.shadowRoot(t) === e)
            }

            function q(e) {
                return "[object ShadowRoot]" === Object.prototype.toString.call(e)
            }

            function z(e) {
                try {
                    var t, r = e.rules || e.cssRules;
                    if (!r) return null;
                    var n = e.href;
                    return !n && e.ownerNode && e.ownerNode.ownerDocument && (n = e.ownerNode.ownerDocument.location.href), (t = Array.from(r, function(e) {
                        return W(e, n)
                    }).join("")).includes(" background-clip: text;") && !t.includes(" -webkit-background-clip: text;") && (t = t.replace(/\sbackground-clip:\s*text;/g, " -webkit-background-clip: text; background-clip: text;")), t
                } catch (e) {
                    return null
                }
            }

            function W(e, t) {
                if ("styleSheet" in e) {
                    var r;
                    try {
                        r = z(e.styleSheet) || function(e) {
                            var t = e.cssText;
                            if (t.split('"').length < 3) return t;
                            var r = ["@import", "url(" + JSON.stringify(e.href) + ")"];
                            return "" === e.layerName ? r.push("layer") : e.layerName && r.push("layer(" + e.layerName + ")"), e.supportsText && r.push("supports(" + e.supportsText + ")"), e.media.length && r.push(e.media.mediaText), r.join(" ") + ";"
                        }(e)
                    } catch (t) {
                        r = e.cssText
                    }
                    return e.styleSheet.href ? ee(r, e.styleSheet.href) : r
                }
                var n = e.cssText;
                return ("selectorText" in e && e.selectorText.includes(":") && (n = n.replace(/(\[(?:[\w-]+)[^\\])(:(?:[\w-]+)\])/gm, "$1\\$2")), t) ? ee(n, t) : n
            }
            var V = function() {
                function e() {
                    M(this, "idNodeMap", new Map), M(this, "nodeMetaMap", new WeakMap)
                }
                var t = e.prototype;
                return t.getId = function(e) {
                    if (!e) return -1;
                    var t, r = null == (t = this.getMeta(e)) ? void 0 : t.id;
                    return null != r ? r : -1
                }, t.getNode = function(e) {
                    return this.idNodeMap.get(e) || null
                }, t.getIds = function() {
                    return Array.from(this.idNodeMap.keys())
                }, t.getMeta = function(e) {
                    return this.nodeMetaMap.get(e) || null
                }, t.removeNodeFromMap = function(e) {
                    var t = this,
                        r = this.getId(e);
                    this.idNodeMap.delete(r), e.childNodes && e.childNodes.forEach(function(e) {
                        return t.removeNodeFromMap(e)
                    })
                }, t.has = function(e) {
                    return this.idNodeMap.has(e)
                }, t.hasNode = function(e) {
                    return this.nodeMetaMap.has(e)
                }, t.add = function(e, t) {
                    var r = t.id;
                    this.idNodeMap.set(r, e), this.nodeMetaMap.set(e, t)
                }, t.replace = function(e, t) {
                    var r = this.getNode(e);
                    if (r) {
                        var n = this.nodeMetaMap.get(r);
                        n && this.nodeMetaMap.set(t, n)
                    }
                    this.idNodeMap.set(e, t)
                }, t.reset = function() {
                    this.idNodeMap = new Map, this.nodeMetaMap = new WeakMap
                }, e
            }();

            function $(e) {
                var t = e.element,
                    r = e.maskInputOptions,
                    n = e.tagName,
                    i = e.type,
                    o = e.value,
                    s = e.maskInputFn,
                    a = o || "",
                    c = i && G(i);
                return (r[n.toLowerCase()] || c && r[c]) && (a = s ? s(a, t) : "*".repeat(a.length)), a
            }

            function G(e) {
                return e.toLowerCase()
            }
            var Y = "__rrweb_original__";

            function Z(e) {
                var t = e.type;
                return e.hasAttribute("data-rr-is-password") ? "password" : t ? G(t) : null
            }

            function J(e, t) {
                try {
                    r = new URL(e, null != t ? t : window.location.href)
                } catch (e) {
                    return null
                }
                var r, n, i = r.pathname.match(/\.([0-9a-z]+)(?:$)/i);
                return null != (n = null == i ? void 0 : i[1]) ? n : null
            }
            var H = /url\((?:(')([^']*)'|(")(.*?)"|([^)]*))\)/gm,
                X = /^(?:[a-z+]+:)?\/\//i,
                K = /^www\..*/i,
                Q = /^(data:)([^,]*),(.*)/i;

            function ee(e, t) {
                return (e || "").replace(H, function(e, r, n, i, o, s) {
                    var a = n || o || s,
                        c = r || i || "";
                    if (!a) return e;
                    if (X.test(a) || K.test(a) || Q.test(a)) return "url(" + c + a + c + ")";
                    if ("/" === a[0]) return "url(" + c + ((t.indexOf("//") > -1 ? t.split("/").slice(0, 3).join("/") : t.split("/")[0]).split("?")[0] + a) + c + ")";
                    var u = t.split("/"),
                        l = a.split("/");
                    u.pop();
                    for (var p, h, f = S(l); !(h = f()).done;) {
                        var d = h.value;
                        "." !== d && (".." === d ? u.pop() : u.push(d))
                    }
                    return "url(" + c + u.join("/") + c + ")"
                })
            }

            function et(e) {
                return e.replace(/(\/\*[^*]*\*\/)|[\s;]/g, "")
            }
            var er = 1,
                en = RegExp("[^a-z0-9-_:]");

            function ei() {
                return er++
            }
            var eo = /^[^ \t\n\r\u000c]+/,
                es = /^[, \t\n\r\u000c]+/,
                ea = new WeakMap;

            function ec(e, t) {
                return t && "" !== t.trim() ? eu(e, t) : t
            }

            function eu(e, t) {
                var r = ea.get(e);
                if (r || (r = e.createElement("a"), ea.set(e, r)), t) {
                    if (t.startsWith("blob:") || t.startsWith("data:")) return t
                } else t = "";
                return r.setAttribute("href", t), r.href
            }

            function el(e, t, r, n) {
                if (!n) return n;
                if ("src" === r || "href" === r && ("use" !== t || "#" !== n[0]) || "xlink:href" === r && "#" !== n[0]) return ec(e, n);
                if ("background" === r && ("table" === t || "td" === t || "th" === t)) return ec(e, n);
                if ("srcset" === r) return function(e, t) {
                    if ("" === t.trim()) return t;
                    var r = 0;

                    function n(e) {
                        var n, i = e.exec(t.substring(r));
                        return i ? (n = i[0], r += n.length, n) : ""
                    }
                    for (var i = []; n(es), !(r >= t.length);) {
                        var o = n(eo);
                        if ("," === o.slice(-1)) o = ec(e, o.substring(0, o.length - 1)), i.push(o);
                        else {
                            var s = "";
                            o = ec(e, o);
                            for (var a = !1;;) {
                                var c = t.charAt(r);
                                if ("" === c) {
                                    i.push((o + s).trim());
                                    break
                                }
                                if (a) ")" === c && (a = !1);
                                else if ("," === c) {
                                    r += 1, i.push((o + s).trim());
                                    break
                                } else "(" === c && (a = !0);
                                s += c, r += 1
                            }
                        }
                    }
                    return i.join(", ")
                }(e, n);
                if ("style" === r) return ee(n, eu(e));
                else if ("object" === t && "data" === r) return ec(e, n);
                return n
            }

            function ep(e, t, r) {
                return ("video" === e || "audio" === e) && "autoplay" === t
            }

            function eh(e, t, r) {
                if (!e) return !1;
                if (e.nodeType !== e.ELEMENT_NODE) return !!r && eh(U.parentNode(e), t, r);
                for (var n = e.classList.length; n--;) {
                    var i = e.classList[n];
                    if (t.test(i)) return !0
                }
                return !!r && eh(U.parentNode(e), t, r)
            }

            function ef(e, t, r, n) {
                var i;
                if (B(e)) {
                    if (i = e, !U.childNodes(i).length) return !1
                } else {
                    if (null === U.parentElement(e)) return !1;
                    i = U.parentElement(e)
                }
                try {
                    if ("string" == typeof t) {
                        if (n) {
                            if (i.closest("." + t)) return !0
                        } else if (i.classList.contains(t)) return !0
                    } else if (eh(i, t, n)) return !0;
                    if (r) {
                        if (n) {
                            if (i.closest(r)) return !0
                        } else if (i.matches(r)) return !0
                    }
                } catch (e) {}
                return !1
            }

            function ed(e) {
                return null == e ? "" : e.toLowerCase()
            }

            function em(e, t) {
                var r = t.doc,
                    n = t.mirror,
                    i = t.blockClass,
                    o = t.blockSelector,
                    s = t.maskTextClass,
                    a = t.maskTextSelector,
                    c = t.skipChild,
                    u = void 0 !== c && c,
                    l = t.inlineStylesheet,
                    p = void 0 === l || l,
                    h = t.maskInputOptions,
                    f = void 0 === h ? {} : h,
                    d = t.maskTextFn,
                    m = t.maskInputFn,
                    g = t.slimDOMOptions,
                    y = t.dataURLOptions,
                    _ = void 0 === y ? {} : y,
                    b = t.inlineImages,
                    w = void 0 !== b && b,
                    k = t.recordCanvas,
                    C = void 0 !== k && k,
                    I = t.onSerialize,
                    x = t.onIframeLoad,
                    O = t.iframeLoadTimeout,
                    E = void 0 === O ? 5e3 : O,
                    M = t.onStylesheetLoad,
                    A = t.stylesheetLoadTimeout,
                    T = void 0 === A ? 5e3 : A,
                    N = t.keepIframeSrcFn,
                    P = void 0 === N ? function() {
                        return !1
                    } : N,
                    D = t.newlyAddedElement,
                    L = t.cssCaptured,
                    F = t.needsMask,
                    W = t.preserveWhiteSpace,
                    V = void 0 === W || W;
                F || (F = ef(e, s, a, void 0 === F));
                var H = function(e, t) {
                    var r, n, i, o, s, a, c, u, l, p, h, f = t.doc,
                        d = t.mirror,
                        m = t.blockClass,
                        g = t.blockSelector,
                        y = t.needsMask,
                        _ = t.inlineStylesheet,
                        b = t.maskInputOptions,
                        w = t.maskTextFn,
                        k = t.maskInputFn,
                        S = t.dataURLOptions,
                        C = t.inlineImages,
                        I = t.recordCanvas,
                        x = t.keepIframeSrcFn,
                        O = t.newlyAddedElement,
                        E = t.cssCaptured,
                        M = function(e, t) {
                            if (t.hasNode(e)) {
                                var r = t.getId(e);
                                return 1 === r ? void 0 : r
                            }
                        }(f, d);
                    switch (e.nodeType) {
                        case e.DOCUMENT_NODE:
                            if ("CSS1Compat" !== e.compatMode) return {
                                type: R.Document,
                                childNodes: [],
                                compatMode: e.compatMode
                            };
                            return {
                                type: R.Document,
                                childNodes: []
                            };
                        case e.DOCUMENT_TYPE_NODE:
                            return {
                                type: R.DocumentType,
                                name: e.name,
                                publicId: e.publicId,
                                systemId: e.systemId,
                                rootId: M
                            };
                        case e.ELEMENT_NODE:
                            return function(e, t) {
                                for (var r, n = t.doc, i = t.blockClass, o = t.blockSelector, s = t.inlineStylesheet, a = t.maskInputOptions, c = void 0 === a ? {} : a, u = t.maskInputFn, l = t.dataURLOptions, p = void 0 === l ? {} : l, h = t.inlineImages, f = t.recordCanvas, d = t.keepIframeSrcFn, m = t.newlyAddedElement, g = t.rootId, y = function(e, t, r) {
                                        try {
                                            if ("string" == typeof t) {
                                                if (e.classList.contains(t)) return !0
                                            } else
                                                for (var n = e.classList.length; n--;) {
                                                    var i = e.classList[n];
                                                    if (t.test(i)) return !0
                                                }
                                            if (r) return e.matches(r)
                                        } catch (e) {}
                                        return !1
                                    }(e, i, o), _ = function(e) {
                                        if (v(e, HTMLFormElement)) return "form";
                                        var t = G(e.tagName);
                                        return en.test(t) ? "div" : t
                                    }(e), b = {}, w = e.attributes.length, k = 0; k < w; k++) {
                                    var S = e.attributes[k];
                                    ep(_, S.name, S.value) || (b[S.name] = el(n, _, G(S.name), S.value))
                                }
                                if ("link" === _ && s) {
                                    var C = Array.from(n.styleSheets).find(function(t) {
                                            return t.href === e.href
                                        }),
                                        I = null;
                                    C && (I = z(C)), I && (delete b.rel, delete b.href, b._cssText = I)
                                }
                                if ("style" === _ && e.sheet) {
                                    var x = z(e.sheet);
                                    x && (e.childNodes.length > 1 && (x = (function(e, t) {
                                        var r = Array.from(t.childNodes),
                                            n = [];
                                        if (r.length > 1 && e && "string" == typeof e) {
                                            for (var i = et(e), o = 1; o < r.length; o++)
                                                if (r[o].textContent && "string" == typeof r[o].textContent)
                                                    for (var s = et(r[o].textContent), a = 3; a < s.length; a++) {
                                                        var c = s.substring(0, a);
                                                        if (2 === i.split(c).length) {
                                                            for (var u = i.indexOf(c), l = u; l < e.length; l++)
                                                                if (et(e.substring(0, l)).length === u) {
                                                                    n.push(e.substring(0, l)), e = e.substring(l);
                                                                    break
                                                                }
                                                            break
                                                        }
                                                    }
                                        }
                                        return n.push(e), n
                                    })(x, e).join("/* rr_split */")), b._cssText = x)
                                }
                                if ("input" === _ || "textarea" === _ || "select" === _) {
                                    var O = e.value,
                                        E = e.checked;
                                    "radio" !== b.type && "checkbox" !== b.type && "submit" !== b.type && "button" !== b.type && O ? b.value = $({
                                        element: e,
                                        type: Z(e),
                                        tagName: _,
                                        value: O,
                                        maskInputOptions: c,
                                        maskInputFn: u
                                    }) : E && (b.checked = E)
                                }
                                if ("option" === _ && (e.selected && !c.select ? b.selected = !0 : delete b.selected), "dialog" === _ && e.open && (b.rr_open_mode = e.matches("dialog:modal") ? "modal" : "non-modal"), "canvas" === _ && f) {
                                    if ("2d" === e.__context) ! function(e) {
                                        var t = e.getContext("2d");
                                        if (!t) return !0;
                                        for (var r = 0; r < e.width; r += 50)
                                            for (var n = 0; n < e.height; n += 50) {
                                                var i = t.getImageData;
                                                if (new Uint32Array((Y in i ? i[Y] : i).call(t, r, n, Math.min(50, e.width - r), Math.min(50, e.height - n)).data.buffer).some(function(e) {
                                                        return 0 !== e
                                                    })) return !1
                                            }
                                        return !0
                                    }(e) && (b.rr_dataURL = e.toDataURL(p.type, p.quality));
                                    else if (!("__context" in e)) {
                                        var M = e.toDataURL(p.type, p.quality),
                                            A = n.createElement("canvas");
                                        A.width = e.width, A.height = e.height, M !== A.toDataURL(p.type, p.quality) && (b.rr_dataURL = M)
                                    }
                                }
                                if ("img" === _ && h) {
                                    n6 || (n8 = (n6 = n.createElement("canvas")).getContext("2d"));
                                    var T = e.currentSrc || e.getAttribute("src") || "<unknown-src>",
                                        N = e.crossOrigin,
                                        P = function() {
                                            e.removeEventListener("load", P);
                                            try {
                                                n6.width = e.naturalWidth, n6.height = e.naturalHeight, n8.drawImage(e, 0, 0), b.rr_dataURL = n6.toDataURL(p.type, p.quality)
                                            } catch (t) {
                                                if ("anonymous" !== e.crossOrigin) {
                                                    e.crossOrigin = "anonymous", e.complete && 0 !== e.naturalWidth ? P() : e.addEventListener("load", P);
                                                    return
                                                }
                                                console.warn("Cannot inline img src=" + T + "! Error: " + t)
                                            }
                                            "anonymous" === e.crossOrigin && (N ? b.crossOrigin = N : e.removeAttribute("crossorigin"))
                                        };
                                    e.complete && 0 !== e.naturalWidth ? P() : e.addEventListener("load", P)
                                }
                                if ("audio" === _ || "video" === _) {
                                    var D = b;
                                    D.rr_mediaState = e.paused ? "paused" : "played", D.rr_mediaCurrentTime = e.currentTime, D.rr_mediaPlaybackRate = e.playbackRate, D.rr_mediaMuted = e.muted, D.rr_mediaLoop = e.loop, D.rr_mediaVolume = e.volume
                                }
                                if (!(void 0 !== m && m) && (e.scrollLeft && (b.rr_scrollLeft = e.scrollLeft), e.scrollTop && (b.rr_scrollTop = e.scrollTop)), y) {
                                    var L = e.getBoundingClientRect(),
                                        F = L.width,
                                        U = L.height;
                                    b = {
                                        class: b.class,
                                        rr_width: "" + F + "px",
                                        rr_height: "" + U + "px"
                                    }
                                }
                                "iframe" !== _ || d(b.src) || (e.contentDocument || (b.rr_src = b.src), delete b.src);
                                try {
                                    customElements.get(_) && (r = !0)
                                } catch (e) {}
                                return {
                                    type: R.Element,
                                    tagName: _,
                                    attributes: b,
                                    childNodes: [],
                                    isSVG: !!("svg" === e.tagName || e.ownerSVGElement) || void 0,
                                    needBlock: y,
                                    rootId: g,
                                    isCustom: r
                                }
                            }(e, {
                                doc: f,
                                blockClass: m,
                                blockSelector: g,
                                inlineStylesheet: _,
                                maskInputOptions: void 0 === b ? {} : b,
                                maskInputFn: k,
                                dataURLOptions: void 0 === S ? {} : S,
                                inlineImages: C,
                                recordCanvas: I,
                                keepIframeSrcFn: x,
                                newlyAddedElement: void 0 !== O && O,
                                rootId: M
                            });
                        case e.TEXT_NODE:
                            return r = e, i = (n = {
                                doc: f,
                                needsMask: y,
                                maskTextFn: w,
                                rootId: M,
                                cssCaptured: void 0 !== E && E
                            }).needsMask, o = n.maskTextFn, s = n.rootId, a = n.cssCaptured, u = (c = U.parentNode(r)) && c.tagName, l = "", p = "STYLE" === u || void 0, (h = "SCRIPT" === u || void 0) ? l = "SCRIPT_PLACEHOLDER" : !a && (l = U.textContent(r), p && l && (l = ee(l, eu(n.doc)))), !p && !h && l && i && (l = o ? o(l, U.parentElement(r)) : l.replace(/[\S]/g, "*")), {
                                type: R.Text,
                                textContent: l || "",
                                rootId: s
                            };
                        case e.CDATA_SECTION_NODE:
                            return {
                                type: R.CDATA,
                                textContent: "",
                                rootId: M
                            };
                        case e.COMMENT_NODE:
                            return {
                                type: R.Comment,
                                textContent: U.textContent(e) || "",
                                rootId: M
                            };
                        default:
                            return !1
                    }
                }(e, {
                    doc: r,
                    mirror: n,
                    blockClass: i,
                    blockSelector: o,
                    needsMask: F,
                    inlineStylesheet: p,
                    maskInputOptions: f,
                    maskTextFn: d,
                    maskInputFn: m,
                    dataURLOptions: _,
                    inlineImages: w,
                    recordCanvas: C,
                    keepIframeSrcFn: P,
                    newlyAddedElement: void 0 !== D && D,
                    cssCaptured: void 0 !== L && L
                });
                if (!H) return console.warn(e, "not serialized"), null;
                eo = n.hasNode(e) ? n.getId(e) : ! function(e, t) {
                    if (t.comment && e.type === R.Comment) return !0;
                    if (e.type === R.Element) {
                        if (t.script && ("script" === e.tagName || "link" === e.tagName && ("preload" === e.attributes.rel || "modulepreload" === e.attributes.rel) && "script" === e.attributes.as || "link" === e.tagName && "prefetch" === e.attributes.rel && "string" == typeof e.attributes.href && "js" === J(e.attributes.href))) return !0;
                        else if (t.headFavicon && ("link" === e.tagName && "shortcut icon" === e.attributes.rel || "meta" === e.tagName && (ed(e.attributes.name).match(/^msapplication-tile(image|color)$/) || "application-name" === ed(e.attributes.name) || "icon" === ed(e.attributes.rel) || "apple-touch-icon" === ed(e.attributes.rel) || "shortcut icon" === ed(e.attributes.rel)))) return !0;
                        else if ("meta" === e.tagName) {
                            if (t.headMetaDescKeywords && ed(e.attributes.name).match(/^description|keywords$/)) return !0;
                            else if (t.headMetaSocial && (ed(e.attributes.property).match(/^(og|twitter|fb):/) || ed(e.attributes.name).match(/^(og|twitter):/) || "pinterest" === ed(e.attributes.name))) return !0;
                            else if (t.headMetaRobots && ("robots" === ed(e.attributes.name) || "googlebot" === ed(e.attributes.name) || "bingbot" === ed(e.attributes.name))) return !0;
                            else if (t.headMetaHttpEquiv && void 0 !== e.attributes["http-equiv"]) return !0;
                            else if (t.headMetaAuthorship && ("author" === ed(e.attributes.name) || "generator" === ed(e.attributes.name) || "framework" === ed(e.attributes.name) || "publisher" === ed(e.attributes.name) || "progid" === ed(e.attributes.name) || ed(e.attributes.property).match(/^article:/) || ed(e.attributes.property).match(/^product:/))) return !0;
                            else if (t.headMetaVerification && ("google-site-verification" === ed(e.attributes.name) || "yandex-verification" === ed(e.attributes.name) || "csrf-token" === ed(e.attributes.name) || "p:domain_verify" === ed(e.attributes.name) || "verify-v1" === ed(e.attributes.name) || "verification" === ed(e.attributes.name) || "shopify-checkout-api-token" === ed(e.attributes.name))) return !0
                        }
                    }
                    return !1
                }(H, g) && (V || H.type !== R.Text || H.textContent.replace(/^\s+|\s+$/gm, "").length) ? ei() : -2;
                var X = Object.assign(H, {
                    id: eo
                });
                if (n.add(e, X), -2 === eo) return null;
                I && I(e);
                var K = !u;
                if (X.type === R.Element) {
                    K = K && !X.needBlock, delete X.needBlock;
                    var Q = U.shadowRoot(e);
                    Q && q(Q) && (X.isShadowHost = !0)
                }
                if ((X.type === R.Document || X.type === R.Element) && K) {
                    g.headWhitespace && X.type === R.Element && "head" === X.tagName && (V = !1);
                    var er = {
                        doc: r,
                        mirror: n,
                        blockClass: i,
                        blockSelector: o,
                        needsMask: F,
                        maskTextClass: s,
                        maskTextSelector: a,
                        skipChild: u,
                        inlineStylesheet: p,
                        maskInputOptions: f,
                        maskTextFn: d,
                        maskInputFn: m,
                        slimDOMOptions: g,
                        dataURLOptions: _,
                        inlineImages: w,
                        recordCanvas: C,
                        preserveWhiteSpace: V,
                        onSerialize: I,
                        onIframeLoad: x,
                        iframeLoadTimeout: E,
                        onStylesheetLoad: M,
                        stylesheetLoadTimeout: T,
                        keepIframeSrcFn: P,
                        cssCaptured: !1
                    };
                    if (X.type === R.Element && "textarea" === X.tagName && void 0 !== X.attributes.value);
                    else {
                        X.type === R.Element && void 0 !== X.attributes._cssText && "string" == typeof X.attributes._cssText && (er.cssCaptured = !0);
                        for (var eo, es, ea = S(Array.from(U.childNodes(e))); !(es = ea()).done;) {
                            var ec = em(es.value, er);
                            ec && X.childNodes.push(ec)
                        }
                    }
                    var eh = null;
                    if (B(e) && (eh = U.shadowRoot(e)))
                        for (var eg, ev = S(Array.from(U.childNodes(eh))); !(eg = ev()).done;) {
                            var ey = em(eg.value, er);
                            ey && (q(eh) && (ey.isShadow = !0), X.childNodes.push(ey))
                        }
                }
                var e_ = U.parentNode(e);
                return e_ && j(e_) && q(e_) && (X.isShadow = !0), X.type === R.Element && "iframe" === X.tagName && function(e, t, r) {
                    var n, i = e.contentWindow;
                    if (i) {
                        var o = !1;
                        try {
                            n = i.document.readyState
                        } catch (e) {
                            return
                        }
                        if ("complete" !== n) {
                            var s = setTimeout(function() {
                                o || (t(), o = !0)
                            }, r);
                            e.addEventListener("load", function() {
                                clearTimeout(s), o = !0, t()
                            });
                            return
                        }
                        var a = "about:blank";
                        if (i.location.href !== a || e.src === a || "" === e.src) return setTimeout(t, 0), e.addEventListener("load", t);
                        e.addEventListener("load", t)
                    }
                }(e, function() {
                    var t = e.contentDocument;
                    if (t && x) {
                        var r = em(t, {
                            doc: t,
                            mirror: n,
                            blockClass: i,
                            blockSelector: o,
                            needsMask: F,
                            maskTextClass: s,
                            maskTextSelector: a,
                            skipChild: !1,
                            inlineStylesheet: p,
                            maskInputOptions: f,
                            maskTextFn: d,
                            maskInputFn: m,
                            slimDOMOptions: g,
                            dataURLOptions: _,
                            inlineImages: w,
                            recordCanvas: C,
                            preserveWhiteSpace: V,
                            onSerialize: I,
                            onIframeLoad: x,
                            iframeLoadTimeout: E,
                            onStylesheetLoad: M,
                            stylesheetLoadTimeout: T,
                            keepIframeSrcFn: P
                        });
                        r && x(e, r)
                    }
                }, E), X.type === R.Element && "link" === X.tagName && "string" == typeof X.attributes.rel && ("stylesheet" === X.attributes.rel || "preload" === X.attributes.rel && "string" == typeof X.attributes.href && "css" === J(X.attributes.href)) && function(e, t, r) {
                    var n, i = !1;
                    try {
                        n = e.sheet
                    } catch (e) {
                        return
                    }
                    if (!n) {
                        var o = setTimeout(function() {
                            i || (t(), i = !0)
                        }, r);
                        e.addEventListener("load", function() {
                            clearTimeout(o), i = !0, t()
                        })
                    }
                }(e, function() {
                    if (M) {
                        var t = em(e, {
                            doc: r,
                            mirror: n,
                            blockClass: i,
                            blockSelector: o,
                            needsMask: F,
                            maskTextClass: s,
                            maskTextSelector: a,
                            skipChild: !1,
                            inlineStylesheet: p,
                            maskInputOptions: f,
                            maskTextFn: d,
                            maskInputFn: m,
                            slimDOMOptions: g,
                            dataURLOptions: _,
                            inlineImages: w,
                            recordCanvas: C,
                            preserveWhiteSpace: V,
                            onSerialize: I,
                            onIframeLoad: x,
                            iframeLoadTimeout: E,
                            onStylesheetLoad: M,
                            stylesheetLoadTimeout: T,
                            keepIframeSrcFn: P
                        });
                        t && M(e, t)
                    }
                }, T), X
            }
            var eg = {
                    exports: {}
                },
                ev = String,
                ey = function() {
                    return {
                        isColorSupported: !1,
                        reset: ev,
                        bold: ev,
                        dim: ev,
                        italic: ev,
                        underline: ev,
                        inverse: ev,
                        hidden: ev,
                        strikethrough: ev,
                        black: ev,
                        red: ev,
                        green: ev,
                        yellow: ev,
                        blue: ev,
                        magenta: ev,
                        cyan: ev,
                        white: ev,
                        gray: ev,
                        bgBlack: ev,
                        bgRed: ev,
                        bgGreen: ev,
                        bgYellow: ev,
                        bgBlue: ev,
                        bgMagenta: ev,
                        bgCyan: ev,
                        bgWhite: ev
                    }
                };
            eg.exports = ey(), eg.exports.createColors = ey;
            var e_ = eg.exports,
                eb = function(e) {
                    if (e.__esModule) return e;
                    var t = e.default;
                    if ("function" == typeof t) {
                        var r = function e() {
                            return v(this, e) ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments)
                        };
                        r.prototype = t.prototype
                    } else r = {};
                    return Object.defineProperty(r, "__esModule", {
                        value: !0
                    }), Object.keys(e).forEach(function(t) {
                        var n = Object.getOwnPropertyDescriptor(e, t);
                        Object.defineProperty(r, t, n.get ? n : {
                            enumerable: !0,
                            get: function() {
                                return e[t]
                            }
                        })
                    }), r
                }(Object.freeze(Object.defineProperty({
                    __proto__: null,
                    default: {}
                }, Symbol.toStringTag, {
                    value: "Module"
                }))),
                ew = function(e) {
                    function t(r, n, i, o, s, a) {
                        var c;
                        return (c = e.call(this, r) || this).name = "CssSyntaxError", c.reason = r, s && (c.file = s), o && (c.source = o), a && (c.plugin = a), void 0 !== n && void 0 !== i && ("number" == typeof n ? (c.line = n, c.column = i) : (c.line = n.line, c.column = n.column, c.endLine = i.line, c.endColumn = i.column)), c.setMessage(), Error.captureStackTrace && Error.captureStackTrace(c, t), c
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.setMessage = function() {
                        this.message = this.plugin ? this.plugin + ": " : "", this.message += this.file ? this.file : "<css input>", void 0 !== this.line && (this.message += ":" + this.line + ":" + this.column), this.message += ": " + this.reason
                    }, r.showSourceCode = function(e) {
                        var t, r, n = this;
                        if (!this.source) return "";
                        var i = this.source;
                        null == e && (e = e_.isColorSupported), eb && e && (i = eb(i));
                        var o = i.split(/\r?\n/),
                            s = Math.max(this.line - 3, 0),
                            a = Math.min(this.line + 2, o.length),
                            c = String(a).length;
                        if (e) {
                            var u = e_.createColors(!0),
                                l = u.bold,
                                p = u.gray,
                                h = u.red;
                            t = function(e) {
                                return l(h(e))
                            }, r = function(e) {
                                return p(e)
                            }
                        } else t = r = function(e) {
                            return e
                        };
                        return o.slice(s, a).map(function(e, i) {
                            var o = s + 1 + i,
                                a = " " + (" " + o).slice(-c) + " | ";
                            if (o === n.line) {
                                var u = r(a.replace(/\d/g, " ")) + e.slice(0, n.column - 1).replace(/[^\t]/g, " ");
                                return t(">") + r(a) + e + "\n " + u + t("^")
                            }
                            return " " + r(a) + e
                        }).join("\n")
                    }, r.toString = function() {
                        var e = this.showSourceCode();
                        return e && (e = "\n\n" + e + "\n"), this.name + ": " + this.message + e
                    }, t
                }(w(Error));
            ew.default = ew;
            var ek = {};
            ek.isClean = Symbol("isClean"), ek.my = Symbol("my");
            var eS = {
                    after: "\n",
                    beforeClose: "\n",
                    beforeComment: "\n",
                    beforeDecl: "\n",
                    beforeOpen: " ",
                    beforeRule: "\n",
                    colon: ": ",
                    commentLeft: " ",
                    commentRight: " ",
                    emptyBody: "",
                    indent: "    ",
                    semicolon: !1
                },
                eC = function() {
                    function e(e) {
                        this.builder = e
                    }
                    var t = e.prototype;
                    return t.atrule = function(e, t) {
                        var r = "@" + e.name,
                            n = e.params ? this.rawValue(e, "params") : "";
                        if (void 0 !== e.raws.afterName ? r += e.raws.afterName : n && (r += " "), e.nodes) this.block(e, r + n);
                        else {
                            var i = (e.raws.between || "") + (t ? ";" : "");
                            this.builder(r + n + i, e)
                        }
                    }, t.beforeAfter = function(e, t) {
                        for (var r = "decl" === e.type ? this.raw(e, null, "beforeDecl") : "comment" === e.type ? this.raw(e, null, "beforeComment") : "before" === t ? this.raw(e, null, "beforeRule") : this.raw(e, null, "beforeClose"), n = e.parent, i = 0; n && "root" !== n.type;) i += 1, n = n.parent;
                        if (r.includes("\n")) {
                            var o = this.raw(e, null, "indent");
                            if (o.length)
                                for (var s = 0; s < i; s++) r += o
                        }
                        return r
                    }, t.block = function(e, t) {
                        var r, n = this.raw(e, "between", "beforeOpen");
                        this.builder(t + n + "{", e, "start"), e.nodes && e.nodes.length ? (this.body(e), r = this.raw(e, "after")) : r = this.raw(e, "after", "emptyBody"), r && this.builder(r), this.builder("}", e, "end")
                    }, t.body = function(e) {
                        for (var t = e.nodes.length - 1; t > 0 && "comment" === e.nodes[t].type;) t -= 1;
                        for (var r = this.raw(e, "semicolon"), n = 0; n < e.nodes.length; n++) {
                            var i = e.nodes[n],
                                o = this.raw(i, "before");
                            o && this.builder(o), this.stringify(i, t !== n || r)
                        }
                    }, t.comment = function(e) {
                        var t = this.raw(e, "left", "commentLeft"),
                            r = this.raw(e, "right", "commentRight");
                        this.builder("/*" + t + e.text + r + "*/", e)
                    }, t.decl = function(e, t) {
                        var r = this.raw(e, "between", "colon"),
                            n = e.prop + r + this.rawValue(e, "value");
                        e.important && (n += e.raws.important || " !important"), t && (n += ";"), this.builder(n, e)
                    }, t.document = function(e) {
                        this.body(e)
                    }, t.raw = function(e, t, r) {
                        if (r || (r = t), t && void 0 !== (n = e.raws[t])) return n;
                        var n, i = e.parent;
                        if ("before" === r && (!i || "root" === i.type && i.first === e || i && "document" === i.type)) return "";
                        if (!i) return eS[r];
                        var o = e.root();
                        if (o.rawCache || (o.rawCache = {}), void 0 !== o.rawCache[r]) return o.rawCache[r];
                        if ("before" === r || "after" === r) return this.beforeAfter(e, r);
                        var s, a = "raw" + ((s = r)[0].toUpperCase() + s.slice(1));
                        return this[a] ? n = this[a](o, e) : o.walk(function(e) {
                            if (void 0 !== (n = e.raws[t])) return !1
                        }), void 0 === n && (n = eS[r]), o.rawCache[r] = n, n
                    }, t.rawBeforeClose = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && e.nodes.length > 0 && void 0 !== e.raws.after) return (t = e.raws.after).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1
                        }), t && (t = t.replace(/\S/g, "")), t
                    }, t.rawBeforeComment = function(e, t) {
                        var r;
                        return e.walkComments(function(e) {
                            if (void 0 !== e.raws.before) return (r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1
                        }), void 0 === r ? r = this.raw(t, null, "beforeDecl") : r && (r = r.replace(/\S/g, "")), r
                    }, t.rawBeforeDecl = function(e, t) {
                        var r;
                        return e.walkDecls(function(e) {
                            if (void 0 !== e.raws.before) return (r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1
                        }), void 0 === r ? r = this.raw(t, null, "beforeRule") : r && (r = r.replace(/\S/g, "")), r
                    }, t.rawBeforeOpen = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if ("decl" !== e.type && void 0 !== (t = e.raws.between)) return !1
                        }), t
                    }, t.rawBeforeRule = function(e) {
                        var t;
                        return e.walk(function(r) {
                            if (r.nodes && (r.parent !== e || e.first !== r) && void 0 !== r.raws.before) return (t = r.raws.before).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1
                        }), t && (t = t.replace(/\S/g, "")), t
                    }, t.rawColon = function(e) {
                        var t;
                        return e.walkDecls(function(e) {
                            if (void 0 !== e.raws.between) return t = e.raws.between.replace(/[^\s:]/g, ""), !1
                        }), t
                    }, t.rawEmptyBody = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && 0 === e.nodes.length && void 0 !== (t = e.raws.after)) return !1
                        }), t
                    }, t.rawIndent = function(e) {
                        var t;
                        return e.raws.indent ? e.raws.indent : (e.walk(function(r) {
                            var n = r.parent;
                            if (n && n !== e && n.parent && n.parent === e && void 0 !== r.raws.before) {
                                var i = r.raws.before.split("\n");
                                return t = (t = i[i.length - 1]).replace(/\S/g, ""), !1
                            }
                        }), t)
                    }, t.rawSemicolon = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && e.nodes.length && "decl" === e.last.type && void 0 !== (t = e.raws.semicolon)) return !1
                        }), t
                    }, t.rawValue = function(e, t) {
                        var r = e[t],
                            n = e.raws[t];
                        return n && n.value === r ? n.raw : r
                    }, t.root = function(e) {
                        this.body(e), e.raws.after && this.builder(e.raws.after)
                    }, t.rule = function(e) {
                        this.block(e, this.rawValue(e, "selector")), e.raws.ownSemicolon && this.builder(e.raws.ownSemicolon, e, "end")
                    }, t.stringify = function(e, t) {
                        if (!this[e.type]) throw Error("Unknown AST node type " + e.type + ". Maybe you need to change PostCSS stringifier.");
                        this[e.type](e, t)
                    }, e
                }();

            function eI(e, t) {
                new eC(t).stringify(e)
            }
            eC.default = eC, eI.default = eI;
            var ex = ek.isClean,
                eO = ek.my,
                eE = function() {
                    function e(e) {
                        for (var t in void 0 === e && (e = {}), this.raws = {}, this[ex] = !1, this[eO] = !0, e)
                            if ("nodes" === t) {
                                this.nodes = [];
                                for (var r, n = S(e[t]); !(r = n()).done;) {
                                    var i = r.value;
                                    "function" == typeof i.clone ? this.append(i.clone()) : this.append(i)
                                }
                            } else this[t] = e[t]
                    }
                    var t = e.prototype;
                    return t.addToError = function(e) {
                        if (e.postcssNode = this, e.stack && this.source && /\n\s{4}at /.test(e.stack)) {
                            var t = this.source;
                            e.stack = e.stack.replace(/\n\s{4}at /, "$&" + t.input.from + ":" + t.start.line + ":" + t.start.column + "$&")
                        }
                        return e
                    }, t.after = function(e) {
                        return this.parent.insertAfter(this, e), this
                    }, t.assign = function(e) {
                        for (var t in void 0 === e && (e = {}), e) this[t] = e[t];
                        return this
                    }, t.before = function(e) {
                        return this.parent.insertBefore(this, e), this
                    }, t.cleanRaws = function(e) {
                        delete this.raws.before, delete this.raws.after, e || delete this.raws.between
                    }, t.clone = function(e) {
                        void 0 === e && (e = {});
                        var t = function e(t, r) {
                            var n = new t.constructor;
                            for (var i in t)
                                if (Object.prototype.hasOwnProperty.call(t, i) && "proxyCache" !== i) {
                                    var o = t[i],
                                        s = void 0 === o ? "undefined" : b(o);
                                    "parent" === i && "object" === s ? r && (n[i] = r) : "source" === i ? n[i] = o : Array.isArray(o) ? n[i] = o.map(function(t) {
                                        return e(t, n)
                                    }) : ("object" === s && null !== o && (o = e(o)), n[i] = o)
                                }
                            return n
                        }(this);
                        for (var r in e) t[r] = e[r];
                        return t
                    }, t.cloneAfter = function(e) {
                        void 0 === e && (e = {});
                        var t = this.clone(e);
                        return this.parent.insertAfter(this, t), t
                    }, t.cloneBefore = function(e) {
                        void 0 === e && (e = {});
                        var t = this.clone(e);
                        return this.parent.insertBefore(this, t), t
                    }, t.error = function(e, t) {
                        if (void 0 === t && (t = {}), this.source) {
                            var r = this.rangeBy(t),
                                n = r.end,
                                i = r.start;
                            return this.source.input.error(e, {
                                column: i.column,
                                line: i.line
                            }, {
                                column: n.column,
                                line: n.line
                            }, t)
                        }
                        return new ew(e)
                    }, t.getProxyProcessor = function() {
                        return {
                            get: function(e, t) {
                                return "proxyOf" === t ? e : "root" === t ? function() {
                                    return e.root().toProxy()
                                } : e[t]
                            },
                            set: function(e, t, r) {
                                return e[t] === r || (e[t] = r, ("prop" === t || "value" === t || "name" === t || "params" === t || "important" === t || "text" === t) && e.markDirty(), !0)
                            }
                        }
                    }, t.markDirty = function() {
                        if (this[ex]) {
                            this[ex] = !1;
                            for (var e = this; e = e.parent;) e[ex] = !1
                        }
                    }, t.next = function() {
                        if (this.parent) {
                            var e = this.parent.index(this);
                            return this.parent.nodes[e + 1]
                        }
                    }, t.positionBy = function(e, t) {
                        var r = this.source.start;
                        if (e.index) r = this.positionInside(e.index, t);
                        else if (e.word) {
                            var n = (t = this.toString()).indexOf(e.word); - 1 !== n && (r = this.positionInside(n, t))
                        }
                        return r
                    }, t.positionInside = function(e, t) {
                        for (var r = t || this.toString(), n = this.source.start.column, i = this.source.start.line, o = 0; o < e; o++) "\n" === r[o] ? (n = 1, i += 1) : n += 1;
                        return {
                            column: n,
                            line: i
                        }
                    }, t.prev = function() {
                        if (this.parent) {
                            var e = this.parent.index(this);
                            return this.parent.nodes[e - 1]
                        }
                    }, t.rangeBy = function(e) {
                        var t = {
                                column: this.source.start.column,
                                line: this.source.start.line
                            },
                            r = this.source.end ? {
                                column: this.source.end.column + 1,
                                line: this.source.end.line
                            } : {
                                column: t.column + 1,
                                line: t.line
                            };
                        if (e.word) {
                            var n = this.toString(),
                                i = n.indexOf(e.word); - 1 !== i && (t = this.positionInside(i, n), r = this.positionInside(i + e.word.length, n))
                        } else e.start ? t = {
                            column: e.start.column,
                            line: e.start.line
                        } : e.index && (t = this.positionInside(e.index)), e.end ? r = {
                            column: e.end.column,
                            line: e.end.line
                        } : "number" == typeof e.endIndex ? r = this.positionInside(e.endIndex) : e.index && (r = this.positionInside(e.index + 1));
                        return (r.line < t.line || r.line === t.line && r.column <= t.column) && (r = {
                            column: t.column + 1,
                            line: t.line
                        }), {
                            end: r,
                            start: t
                        }
                    }, t.raw = function(e, t) {
                        return new eC().raw(this, e, t)
                    }, t.remove = function() {
                        return this.parent && this.parent.removeChild(this), this.parent = void 0, this
                    }, t.replaceWith = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        if (this.parent) {
                            for (var n, i = this, o = !1, s = S(t); !(n = s()).done;) {
                                var a = n.value;
                                a === this ? o = !0 : o ? (this.parent.insertAfter(i, a), i = a) : this.parent.insertBefore(i, a)
                            }
                            o || this.remove()
                        }
                        return this
                    }, t.root = function() {
                        for (var e = this; e.parent && "document" !== e.parent.type;) e = e.parent;
                        return e
                    }, t.toJSON = function(e, t) {
                        var r = {},
                            n = null == t;
                        t = t || new Map;
                        var i = 0;
                        for (var o in this)
                            if (Object.prototype.hasOwnProperty.call(this, o) && "parent" !== o && "proxyCache" !== o) {
                                var s = this[o];
                                if (Array.isArray(s)) r[o] = s.map(function(e) {
                                    return (void 0 === e ? "undefined" : b(e)) === "object" && e.toJSON ? e.toJSON(null, t) : e
                                });
                                else if ((void 0 === s ? "undefined" : b(s)) === "object" && s.toJSON) r[o] = s.toJSON(null, t);
                                else if ("source" === o) {
                                    var a = t.get(s.input);
                                    null == a && (a = i, t.set(s.input, i), i++), r[o] = {
                                        end: s.end,
                                        inputId: a,
                                        start: s.start
                                    }
                                } else r[o] = s
                            }
                        return n && (r.inputs = [].concat(t.keys()).map(function(e) {
                            return e.toJSON()
                        })), r
                    }, t.toProxy = function() {
                        return this.proxyCache || (this.proxyCache = new Proxy(this, this.getProxyProcessor())), this.proxyCache
                    }, t.toString = function(e) {
                        void 0 === e && (e = eI), e.stringify && (e = e.stringify);
                        var t = "";
                        return e(this, function(e) {
                            t += e
                        }), t
                    }, t.warn = function(e, t, r) {
                        var n = {
                            node: this
                        };
                        for (var i in r) n[i] = r[i];
                        return e.warn(t, n)
                    }, f(e, [{
                        key: "proxyOf",
                        get: function() {
                            return this
                        }
                    }]), e
                }();
            eE.default = eE;
            var eM = function(e) {
                function t(t) {
                    var r;
                    return t && void 0 !== t.value && "string" != typeof t.value && (t = d({}, t, {
                        value: String(t.value)
                    })), (r = e.call(this, t) || this).type = "decl", r
                }
                return g(t, e), f(t, [{
                    key: "variable",
                    get: function() {
                        return this.prop.startsWith("--") || "$" === this.prop[0]
                    }
                }]), t
            }(eE);
            eM.default = eM;
            var eR = eb.SourceMapConsumer,
                eA = eb.SourceMapGenerator,
                eT = eb.existsSync,
                eN = eb.readFileSync,
                eP = eb.dirname,
                eD = eb.join,
                eL = function() {
                    function e(e, t) {
                        if (!1 !== t.map) {
                            this.loadAnnotation(e), this.inline = this.startWith(this.annotation, "data:");
                            var r = t.map ? t.map.prev : void 0,
                                n = this.loadMap(t.from, r);
                            !this.mapFile && t.from && (this.mapFile = t.from), this.mapFile && (this.root = eP(this.mapFile)), n && (this.text = n)
                        }
                    }
                    var t = e.prototype;
                    return t.consumer = function() {
                        return this.consumerCache || (this.consumerCache = new eR(this.text)), this.consumerCache
                    }, t.decodeInline = function(e) {
                        if (/^data:application\/json;charset=utf-?8,/.test(e) || /^data:application\/json,/.test(e)) return decodeURIComponent(e.substr(RegExp.lastMatch.length));
                        if (/^data:application\/json;charset=utf-?8;base64,/.test(e) || /^data:application\/json;base64,/.test(e)) {
                            var t;
                            return t = e.substr(RegExp.lastMatch.length), s ? s.from(t, "base64").toString() : window.atob(t)
                        }
                        throw Error("Unsupported source map encoding " + e.match(/data:application\/json;([^,]+),/)[1])
                    }, t.getAnnotationURL = function(e) {
                        return e.replace(/^\/\*\s*# sourceMappingURL=/, "").trim()
                    }, t.isMap = function(e) {
                        return (void 0 === e ? "undefined" : b(e)) === "object" && ("string" == typeof e.mappings || "string" == typeof e._mappings || Array.isArray(e.sections))
                    }, t.loadAnnotation = function(e) {
                        var t = e.match(/\/\*\s*# sourceMappingURL=/gm);
                        if (t) {
                            var r = e.lastIndexOf(t.pop()),
                                n = e.indexOf("*/", r);
                            r > -1 && n > -1 && (this.annotation = this.getAnnotationURL(e.substring(r, n)))
                        }
                    }, t.loadFile = function(e) {
                        if (this.root = eP(e), eT(e)) return this.mapFile = e, eN(e, "utf-8").toString().trim()
                    }, t.loadMap = function(e, t) {
                        if (!1 === t) return !1;
                        if (t)
                            if ("string" == typeof t) return t;
                            else if ("function" == typeof t) {
                            var r = t(e);
                            if (r) {
                                var n = this.loadFile(r);
                                if (!n) throw Error("Unable to load previous source map: " + r.toString());
                                return n
                            }
                        } else if (v(t, eR)) return eA.fromSourceMap(t).toString();
                        else if (v(t, eA)) return t.toString();
                        else if (this.isMap(t)) return JSON.stringify(t);
                        else throw Error("Unsupported previous source map format: " + t.toString());
                        else if (this.inline) return this.decodeInline(this.annotation);
                        else if (this.annotation) {
                            var i = this.annotation;
                            return e && (i = eD(eP(e), i)), this.loadFile(i)
                        }
                    }, t.startWith = function(e, t) {
                        return !!e && e.substr(0, t.length) === t
                    }, t.withContent = function() {
                        return !!(this.consumer().sourcesContent && this.consumer().sourcesContent.length > 0)
                    }, e
                }();
            eL.default = eL;
            var eF = eb.SourceMapConsumer,
                eU = eb.SourceMapGenerator,
                eB = eb.fileURLToPath,
                ej = eb.pathToFileURL,
                eq = eb.isAbsolute,
                ez = eb.resolve,
                eW = function(e) {
                    void 0 === e && (e = 21);
                    for (var t = "", r = e; r--;) t += "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict" [64 * Math.random() | 0];
                    return t
                },
                eV = Symbol("fromOffsetCache"),
                e$ = !!(eF && eU),
                eG = !!(ez && eq),
                eY = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = {}), null == e || (void 0 === e ? "undefined" : b(e)) === "object" && !e.toString) throw Error("PostCSS received " + e + " instead of CSS string");
                        if (this.css = e.toString(), "\uFEFF" === this.css[0] || "￾" === this.css[0] ? (this.hasBOM = !0, this.css = this.css.slice(1)) : this.hasBOM = !1, t.from && (!eG || /^\w+:\/\//.test(t.from) || eq(t.from) ? this.file = t.from : this.file = ez(t.from)), eG && e$) {
                            var r = new eL(this.css, t);
                            if (r.text) {
                                this.map = r;
                                var n = r.consumer().file;
                                !this.file && n && (this.file = this.mapResolve(n))
                            }
                        }
                        this.file || (this.id = "<input css " + eW(6) + ">"), this.map && (this.map.file = this.from)
                    }
                    var t = e.prototype;
                    return t.error = function(e, t, r, n) {
                        if (void 0 === n && (n = {}), t && (void 0 === t ? "undefined" : b(t)) === "object") {
                            var i, o, s, a = t,
                                c = r;
                            if ("number" == typeof a.offset) {
                                var u = this.fromOffset(a.offset);
                                t = u.line, r = u.col
                            } else t = a.line, r = a.column;
                            if ("number" == typeof c.offset) {
                                var l = this.fromOffset(c.offset);
                                o = l.line, s = l.col
                            } else o = c.line, s = c.column
                        } else if (!r) {
                            var p = this.fromOffset(t);
                            t = p.line, r = p.col
                        }
                        var h = this.origin(t, r, o, s);
                        return (i = h ? new ew(e, void 0 === h.endLine ? h.line : {
                            column: h.column,
                            line: h.line
                        }, void 0 === h.endLine ? h.column : {
                            column: h.endColumn,
                            line: h.endLine
                        }, h.source, h.file, n.plugin) : new ew(e, void 0 === o ? t : {
                            column: r,
                            line: t
                        }, void 0 === o ? r : {
                            column: s,
                            line: o
                        }, this.css, this.file, n.plugin)).input = {
                            column: r,
                            endColumn: s,
                            endLine: o,
                            line: t,
                            source: this.css
                        }, this.file && (ej && (i.input.url = ej(this.file).toString()), i.input.file = this.file), i
                    }, t.fromOffset = function(e) {
                        if (this[eV]) a = this[eV];
                        else {
                            var t = this.css.split("\n");
                            a = Array(t.length);
                            for (var r = 0, n = 0, i = t.length; n < i; n++) a[n] = r, r += t[n].length + 1;
                            this[eV] = a
                        }
                        s = a[a.length - 1];
                        var o = 0;
                        if (e >= s) o = a.length - 1;
                        else
                            for (var s, a, c, u = a.length - 2; o < u;)
                                if (e < a[c = o + (u - o >> 1)]) u = c - 1;
                                else if (e >= a[c + 1]) o = c + 1;
                        else {
                            o = c;
                            break
                        }
                        return {
                            col: e - a[o] + 1,
                            line: o + 1
                        }
                    }, t.mapResolve = function(e) {
                        return /^\w+:\/\//.test(e) ? e : ez(this.map.consumer().sourceRoot || this.map.root || ".", e)
                    }, t.origin = function(e, t, r, n) {
                        if (!this.map) return !1;
                        var i, o, s = this.map.consumer(),
                            a = s.originalPositionFor({
                                column: t,
                                line: e
                            });
                        if (!a.source) return !1;
                        "number" == typeof r && (i = s.originalPositionFor({
                            column: n,
                            line: r
                        })), o = eq(a.source) ? ej(a.source) : new URL(a.source, this.map.consumer().sourceRoot || ej(this.map.mapFile));
                        var c = {
                            column: a.column,
                            endColumn: i && i.column,
                            endLine: i && i.line,
                            line: a.line,
                            url: o.toString()
                        };
                        if ("file:" === o.protocol)
                            if (eB) c.file = eB(o);
                            else throw Error("file: protocol is not available in this PostCSS build");
                        var u = s.sourceContentFor(a.source);
                        return u && (c.source = u), c
                    }, t.toJSON = function() {
                        for (var e = {}, t = 0, r = ["hasBOM", "css", "file", "id"]; t < r.length; t++) {
                            var n = r[t];
                            null != this[n] && (e[n] = this[n])
                        }
                        return this.map && (e.map = d({}, this.map), e.map.consumerCache && (e.map.consumerCache = void 0)), e
                    }, f(e, [{
                        key: "from",
                        get: function() {
                            return this.file || this.id
                        }
                    }]), e
                }();
            eY.default = eY, eb && eb.registerInput && eb.registerInput(eY);
            var eZ = eb.SourceMapConsumer,
                eJ = eb.SourceMapGenerator,
                eH = eb.dirname,
                eX = eb.relative,
                eK = eb.resolve,
                eQ = eb.sep,
                e0 = eb.pathToFileURL,
                e1 = !!(eZ && eJ),
                e2 = !!(eH && eK && eX && eQ),
                e3 = function() {
                    function e(e, t, r, n) {
                        this.stringify = e, this.mapOpts = r.map || {}, this.root = t, this.opts = r, this.css = n, this.originalCSS = n, this.usesFileUrls = !this.mapOpts.from && this.mapOpts.absolute, this.memoizedFileURLs = new Map, this.memoizedPaths = new Map, this.memoizedURLs = new Map
                    }
                    var t = e.prototype;
                    return t.addAnnotation = function() {
                        var e = this.isInline() ? "data:application/json;base64," + this.toBase64(this.map.toString()) : "string" == typeof this.mapOpts.annotation ? this.mapOpts.annotation : "function" == typeof this.mapOpts.annotation ? this.mapOpts.annotation(this.opts.to, this.root) : this.outputFile() + ".map",
                            t = "\n";
                        this.css.includes("\r\n") && (t = "\r\n"), this.css += t + "/*# sourceMappingURL=" + e + " */"
                    }, t.applyPrevMaps = function() {
                        for (var e, t = S(this.previous()); !(e = t()).done;) {
                            var r = e.value,
                                n = this.toUrl(this.path(r.file)),
                                i = r.root || eH(r.file),
                                o = void 0;
                            !1 === this.mapOpts.sourcesContent ? (o = new eZ(r.text)).sourcesContent && (o.sourcesContent = null) : o = r.consumer(), this.map.applySourceMap(o, n, this.toUrl(this.path(i)))
                        }
                    }, t.clearAnnotation = function() {
                        if (!1 !== this.mapOpts.annotation)
                            if (this.root)
                                for (var e, t = this.root.nodes.length - 1; t >= 0; t--) "comment" === (e = this.root.nodes[t]).type && 0 === e.text.indexOf("# sourceMappingURL=") && this.root.removeChild(t);
                            else this.css && (this.css = this.css.replace(/\n*?\/\*#[\S\s]*?\*\/$/gm, ""))
                    }, t.generate = function() {
                        if (this.clearAnnotation(), e2 && e1 && this.isMap()) return this.generateMap();
                        var e = "";
                        return this.stringify(this.root, function(t) {
                            e += t
                        }), [e]
                    }, t.generateMap = function() {
                        if (this.root) this.generateString();
                        else if (1 === this.previous().length) {
                            var e = this.previous()[0].consumer();
                            e.file = this.outputFile(), this.map = eJ.fromSourceMap(e, {
                                ignoreInvalidMapping: !0
                            })
                        } else this.map = new eJ({
                            file: this.outputFile(),
                            ignoreInvalidMapping: !0
                        }), this.map.addMapping({
                            generated: {
                                column: 0,
                                line: 1
                            },
                            original: {
                                column: 0,
                                line: 1
                            },
                            source: this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>"
                        });
                        return (this.isSourcesContent() && this.setSourcesContent(), this.root && this.previous().length > 0 && this.applyPrevMaps(), this.isAnnotation() && this.addAnnotation(), this.isInline()) ? [this.css] : [this.css, this.map]
                    }, t.generateString = function() {
                        var e, t, r = this;
                        this.css = "", this.map = new eJ({
                            file: this.outputFile(),
                            ignoreInvalidMapping: !0
                        });
                        var n = 1,
                            i = 1,
                            o = "<no source>",
                            s = {
                                generated: {
                                    column: 0,
                                    line: 0
                                },
                                original: {
                                    column: 0,
                                    line: 0
                                },
                                source: ""
                            };
                        this.stringify(this.root, function(a, c, u) {
                            if (r.css += a, c && "end" !== u && (s.generated.line = n, s.generated.column = i - 1, c.source && c.source.start ? (s.source = r.sourcePath(c), s.original.line = c.source.start.line, s.original.column = c.source.start.column - 1) : (s.source = o, s.original.line = 1, s.original.column = 0), r.map.addMapping(s)), (e = a.match(/\n/g)) ? (n += e.length, t = a.lastIndexOf("\n"), i = a.length - t) : i += a.length, c && "start" !== u) {
                                var l = c.parent || {
                                    raws: {}
                                };
                                (!("decl" === c.type || "atrule" === c.type && !c.nodes) || c !== l.last || l.raws.semicolon) && (c.source && c.source.end ? (s.source = r.sourcePath(c), s.original.line = c.source.end.line, s.original.column = c.source.end.column - 1, s.generated.line = n, s.generated.column = i - 2) : (s.source = o, s.original.line = 1, s.original.column = 0, s.generated.line = n, s.generated.column = i - 1), r.map.addMapping(s))
                            }
                        })
                    }, t.isAnnotation = function() {
                        return !!this.isInline() || (void 0 !== this.mapOpts.annotation ? this.mapOpts.annotation : !this.previous().length || this.previous().some(function(e) {
                            return e.annotation
                        }))
                    }, t.isInline = function() {
                        if (void 0 !== this.mapOpts.inline) return this.mapOpts.inline;
                        var e = this.mapOpts.annotation;
                        return (void 0 === e || !0 === e) && (!this.previous().length || this.previous().some(function(e) {
                            return e.inline
                        }))
                    }, t.isMap = function() {
                        return void 0 !== this.opts.map ? !!this.opts.map : this.previous().length > 0
                    }, t.isSourcesContent = function() {
                        return void 0 !== this.mapOpts.sourcesContent ? this.mapOpts.sourcesContent : !this.previous().length || this.previous().some(function(e) {
                            return e.withContent()
                        })
                    }, t.outputFile = function() {
                        return this.opts.to ? this.path(this.opts.to) : this.opts.from ? this.path(this.opts.from) : "to.css"
                    }, t.path = function(e) {
                        if (this.mapOpts.absolute || 60 === e.charCodeAt(0) || /^\w+:\/\//.test(e)) return e;
                        var t = this.memoizedPaths.get(e);
                        if (t) return t;
                        var r = this.opts.to ? eH(this.opts.to) : ".";
                        "string" == typeof this.mapOpts.annotation && (r = eH(eK(r, this.mapOpts.annotation)));
                        var n = eX(r, e);
                        return this.memoizedPaths.set(e, n), n
                    }, t.previous = function() {
                        var e = this;
                        if (!this.previousMaps)
                            if (this.previousMaps = [], this.root) this.root.walk(function(t) {
                                if (t.source && t.source.input.map) {
                                    var r = t.source.input.map;
                                    e.previousMaps.includes(r) || e.previousMaps.push(r)
                                }
                            });
                            else {
                                var t = new eY(this.originalCSS, this.opts);
                                t.map && this.previousMaps.push(t.map)
                            }
                        return this.previousMaps
                    }, t.setSourcesContent = function() {
                        var e = this,
                            t = {};
                        if (this.root) this.root.walk(function(r) {
                            if (r.source) {
                                var n = r.source.input.from;
                                if (n && !t[n]) {
                                    t[n] = !0;
                                    var i = e.usesFileUrls ? e.toFileUrl(n) : e.toUrl(e.path(n));
                                    e.map.setSourceContent(i, r.source.input.css)
                                }
                            }
                        });
                        else if (this.css) {
                            var r = this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>";
                            this.map.setSourceContent(r, this.css)
                        }
                    }, t.sourcePath = function(e) {
                        return this.mapOpts.from ? this.toUrl(this.mapOpts.from) : this.usesFileUrls ? this.toFileUrl(e.source.input.from) : this.toUrl(this.path(e.source.input.from))
                    }, t.toBase64 = function(e) {
                        return s ? s.from(e).toString("base64") : window.btoa(unescape(encodeURIComponent(e)))
                    }, t.toFileUrl = function(e) {
                        var t = this.memoizedFileURLs.get(e);
                        if (t) return t;
                        if (e0) {
                            var r = e0(e).toString();
                            return this.memoizedFileURLs.set(e, r), r
                        }
                        throw Error("`map.absolute` option is not available in this PostCSS build")
                    }, t.toUrl = function(e) {
                        var t = this.memoizedURLs.get(e);
                        if (t) return t;
                        "\\" === eQ && (e = e.replace(/\\/g, "/"));
                        var r = encodeURI(e).replace(/[#?]/g, encodeURIComponent);
                        return this.memoizedURLs.set(e, r), r
                    }, e
                }(),
                e9 = function(e) {
                    function t(t) {
                        var r;
                        return (r = e.call(this, t) || this).type = "comment", r
                    }
                    return g(t, e), t
                }(eE);
            e9.default = e9;
            var e4 = ek.isClean,
                e5 = ek.my,
                e6 = function(e) {
                    function t() {
                        return e.apply(this, arguments) || this
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.append = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        for (var n, i = S(t); !(n = i()).done;)
                            for (var o, s = n.value, a = this.normalize(s, this.last), c = S(a); !(o = c()).done;) {
                                var u = o.value;
                                this.proxyOf.nodes.push(u)
                            }
                        return this.markDirty(), this
                    }, r.cleanRaws = function(t) {
                        if (e.prototype.cleanRaws.call(this, t), this.nodes)
                            for (var r, n = S(this.nodes); !(r = n()).done;) r.value.cleanRaws(t)
                    }, r.each = function(e) {
                        if (this.proxyOf.nodes) {
                            for (var t, r, n = this.getIterator(); this.indexes[n] < this.proxyOf.nodes.length && (t = this.indexes[n], !1 !== (r = e(this.proxyOf.nodes[t], t)));) this.indexes[n] += 1;
                            return delete this.indexes[n], r
                        }
                    }, r.every = function(e) {
                        return this.nodes.every(e)
                    }, r.getIterator = function() {
                        this.lastEach || (this.lastEach = 0), this.indexes || (this.indexes = {}), this.lastEach += 1;
                        var e = this.lastEach;
                        return this.indexes[e] = 0, e
                    }, r.getProxyProcessor = function() {
                        return {
                            get: function(e, t) {
                                if ("proxyOf" === t) return e;
                                if (!e[t]) return e[t];
                                if ("each" === t || "string" == typeof t && t.startsWith("walk")) return function() {
                                    for (var r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                                    return e[t].apply(e, [].concat(n.map(function(e) {
                                        return "function" == typeof e ? function(t, r) {
                                            return e(t.toProxy(), r)
                                        } : e
                                    })))
                                };
                                if ("every" === t || "some" === t) return function(r) {
                                    return e[t](function(e) {
                                        for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                        return r.apply(void 0, [].concat([e.toProxy()], n))
                                    })
                                };
                                if ("root" === t) return function() {
                                    return e.root().toProxy()
                                };
                                else if ("nodes" === t) return e.nodes.map(function(e) {
                                    return e.toProxy()
                                });
                                else if ("first" === t || "last" === t) return e[t].toProxy();
                                else return e[t]
                            },
                            set: function(e, t, r) {
                                return e[t] === r || (e[t] = r, ("name" === t || "params" === t || "selector" === t) && e.markDirty(), !0)
                            }
                        }
                    }, r.index = function(e) {
                        return "number" == typeof e ? e : (e.proxyOf && (e = e.proxyOf), this.proxyOf.nodes.indexOf(e))
                    }, r.insertAfter = function(e, t) {
                        var r, n = this.index(e),
                            i = this.normalize(t, this.proxyOf.nodes[n]).reverse();
                        n = this.index(e);
                        for (var o, s = S(i); !(o = s()).done;) {
                            var a = o.value;
                            this.proxyOf.nodes.splice(n + 1, 0, a)
                        }
                        for (var c in this.indexes) n < (r = this.indexes[c]) && (this.indexes[c] = r + i.length);
                        return this.markDirty(), this
                    }, r.insertBefore = function(e, t) {
                        var r, n = this.index(e),
                            i = 0 === n && "prepend",
                            o = this.normalize(t, this.proxyOf.nodes[n], i).reverse();
                        n = this.index(e);
                        for (var s, a = S(o); !(s = a()).done;) {
                            var c = s.value;
                            this.proxyOf.nodes.splice(n, 0, c)
                        }
                        for (var u in this.indexes) n <= (r = this.indexes[u]) && (this.indexes[u] = r + o.length);
                        return this.markDirty(), this
                    }, r.normalize = function(e, r) {
                        var n = this;
                        if ("string" == typeof e) e = function e(t) {
                            return t.map(function(t) {
                                return t.nodes && (t.nodes = e(t.nodes)), delete t.source, t
                            })
                        }(n7(e).nodes);
                        else if (void 0 === e) e = [];
                        else if (Array.isArray(e)) {
                            e = e.slice(0);
                            for (var i, o = S(e); !(i = o()).done;) {
                                var s = i.value;
                                s.parent && s.parent.removeChild(s, "ignore")
                            }
                        } else if ("root" === e.type && "document" !== this.type) {
                            e = e.nodes.slice(0);
                            for (var a, c = S(e); !(a = c()).done;) {
                                var u = a.value;
                                u.parent && u.parent.removeChild(u, "ignore")
                            }
                        } else if (e.type) e = [e];
                        else if (e.prop) {
                            if (void 0 === e.value) throw Error("Value field is missed in node creation");
                            "string" != typeof e.value && (e.value = String(e.value)), e = [new eM(e)]
                        } else if (e.selector) e = [new ie(e)];
                        else if (e.name) e = [new it(e)];
                        else if (e.text) e = [new e9(e)];
                        else throw Error("Unknown node type in node creation");
                        return e.map(function(e) {
                            return e[e5] || t.rebuild(e), (e = e.proxyOf).parent && e.parent.removeChild(e), e[e4] && function e(t) {
                                if (t[e4] = !1, t.proxyOf.nodes)
                                    for (var r, n = S(t.proxyOf.nodes); !(r = n()).done;) e(r.value)
                            }(e), void 0 === e.raws.before && r && void 0 !== r.raws.before && (e.raws.before = r.raws.before.replace(/\S/g, "")), e.parent = n.proxyOf, e
                        })
                    }, r.prepend = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        t = t.reverse();
                        for (var n, i = S(t); !(n = i()).done;) {
                            for (var o, s = n.value, a = this.normalize(s, this.first, "prepend").reverse(), c = S(a); !(o = c()).done;) {
                                var u = o.value;
                                this.proxyOf.nodes.unshift(u)
                            }
                            for (var l in this.indexes) this.indexes[l] = this.indexes[l] + a.length
                        }
                        return this.markDirty(), this
                    }, r.push = function(e) {
                        return e.parent = this, this.proxyOf.nodes.push(e), this
                    }, r.removeAll = function() {
                        for (var e, t = S(this.proxyOf.nodes); !(e = t()).done;) e.value.parent = void 0;
                        return this.proxyOf.nodes = [], this.markDirty(), this
                    }, r.removeChild = function(e) {
                        var t;
                        for (var r in e = this.index(e), this.proxyOf.nodes[e].parent = void 0, this.proxyOf.nodes.splice(e, 1), this.indexes)(t = this.indexes[r]) >= e && (this.indexes[r] = t - 1);
                        return this.markDirty(), this
                    }, r.replaceValues = function(e, t, r) {
                        return r || (r = t, t = {}), this.walkDecls(function(n) {
                            (!t.props || t.props.includes(n.prop)) && (!t.fast || n.value.includes(t.fast)) && (n.value = n.value.replace(e, r))
                        }), this.markDirty(), this
                    }, r.some = function(e) {
                        return this.nodes.some(e)
                    }, r.walk = function(e) {
                        return this.each(function(t, r) {
                            var n;
                            try {
                                n = e(t, r)
                            } catch (e) {
                                throw t.addToError(e)
                            }
                            return !1 !== n && t.walk && (n = t.walk(e)), n
                        })
                    }, r.walkAtRules = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("atrule" === r.type && e.test(r.name)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("atrule" === r.type && r.name === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("atrule" === e.type) return t(e, r)
                        }))
                    }, r.walkComments = function(e) {
                        return this.walk(function(t, r) {
                            if ("comment" === t.type) return e(t, r)
                        })
                    }, r.walkDecls = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("decl" === r.type && e.test(r.prop)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("decl" === r.type && r.prop === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("decl" === e.type) return t(e, r)
                        }))
                    }, r.walkRules = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("rule" === r.type && e.test(r.selector)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("rule" === r.type && r.selector === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("rule" === e.type) return t(e, r)
                        }))
                    }, f(t, [{
                        key: "first",
                        get: function() {
                            if (this.proxyOf.nodes) return this.proxyOf.nodes[0]
                        }
                    }, {
                        key: "last",
                        get: function() {
                            if (this.proxyOf.nodes) return this.proxyOf.nodes[this.proxyOf.nodes.length - 1]
                        }
                    }]), t
                }(eE);
            e6.registerParse = function(e) {
                n7 = e
            }, e6.registerRule = function(e) {
                ie = e
            }, e6.registerAtRule = function(e) {
                it = e
            }, e6.registerRoot = function(e) {
                ir = e
            }, e6.default = e6, e6.rebuild = function(e) {
                "atrule" === e.type ? Object.setPrototypeOf(e, it.prototype) : "rule" === e.type ? Object.setPrototypeOf(e, ie.prototype) : "decl" === e.type ? Object.setPrototypeOf(e, eM.prototype) : "comment" === e.type ? Object.setPrototypeOf(e, e9.prototype) : "root" === e.type && Object.setPrototypeOf(e, ir.prototype), e[e5] = !0, e.nodes && e.nodes.forEach(function(e) {
                    e6.rebuild(e)
                })
            };
            var e8 = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, d({
                        type: "document"
                    }, t)) || this).nodes || (r.nodes = []), r
                }
                return g(t, e), t.prototype.toResult = function(e) {
                    return void 0 === e && (e = {}), new ii(new io, this, e).stringify()
                }, t
            }(e6);
            e8.registerLazyResult = function(e) {
                ii = e
            }, e8.registerProcessor = function(e) {
                io = e
            }, e8.default = e8;
            var e7 = function() {
                function e(e, t) {
                    if (void 0 === t && (t = {}), this.type = "warning", this.text = e, t.node && t.node.source) {
                        var r = t.node.rangeBy(t);
                        this.line = r.start.line, this.column = r.start.column, this.endLine = r.end.line, this.endColumn = r.end.column
                    }
                    for (var n in t) this[n] = t[n]
                }
                return e.prototype.toString = function() {
                    return this.node ? this.node.error(this.text, {
                        index: this.index,
                        plugin: this.plugin,
                        word: this.word
                    }).message : this.plugin ? this.plugin + ": " + this.text : this.text
                }, e
            }();
            e7.default = e7;
            var te = function() {
                function e(e, t, r) {
                    this.processor = e, this.messages = [], this.root = t, this.opts = r, this.css = void 0, this.map = void 0
                }
                var t = e.prototype;
                return t.toString = function() {
                    return this.css
                }, t.warn = function(e, t) {
                    void 0 === t && (t = {}), !t.plugin && this.lastPlugin && this.lastPlugin.postcssPlugin && (t.plugin = this.lastPlugin.postcssPlugin);
                    var r = new e7(e, t);
                    return this.messages.push(r), r
                }, t.warnings = function() {
                    return this.messages.filter(function(e) {
                        return "warning" === e.type
                    })
                }, f(e, [{
                    key: "content",
                    get: function() {
                        return this.css
                    }
                }]), e
            }();
            te.default = te;
            var tt = /[\t\n\f\r "#'()/;[\\\]{}]/g,
                tr = /[\t\n\f\r !"#'():;@[\\\]{}]|\/(?=\*)/g,
                tn = /.[\r\n"'(/\\]/,
                ti = /[\da-f]/i,
                to = function(e) {
                    function t(t) {
                        var r;
                        return (r = e.call(this, t) || this).type = "atrule", r
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.append = function() {
                        for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                        return this.proxyOf.nodes || (this.nodes = []), (t = e.prototype.append).call.apply(t, [].concat([this], n))
                    }, r.prepend = function() {
                        for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                        return this.proxyOf.nodes || (this.nodes = []), (t = e.prototype.prepend).call.apply(t, [].concat([this], n))
                    }, t
                }(e6);
            to.default = to, e6.registerAtRule(to);
            var ts = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, t) || this).type = "root", r.nodes || (r.nodes = []), r
                }
                g(t, e);
                var r = t.prototype;
                return r.normalize = function(t, r, n) {
                    var i = e.prototype.normalize.call(this, t);
                    if (r) {
                        if ("prepend" === n) this.nodes.length > 1 ? r.raws.before = this.nodes[1].raws.before : delete r.raws.before;
                        else if (this.first !== r)
                            for (var o, s = S(i); !(o = s()).done;) o.value.raws.before = r.raws.before
                    }
                    return i
                }, r.removeChild = function(t, r) {
                    var n = this.index(t);
                    return !r && 0 === n && this.nodes.length > 1 && (this.nodes[1].raws.before = this.nodes[n].raws.before), e.prototype.removeChild.call(this, t)
                }, r.toResult = function(e) {
                    return void 0 === e && (e = {}), new is(new ia, this, e).stringify()
                }, t
            }(e6);
            ts.registerLazyResult = function(e) {
                is = e
            }, ts.registerProcessor = function(e) {
                ia = e
            }, ts.default = ts, e6.registerRoot(ts);
            var ta = {
                comma: function(e) {
                    return ta.split(e, [","], !0)
                },
                space: function(e) {
                    return ta.split(e, [" ", "\n", "	"])
                },
                split: function(e, t, r) {
                    for (var n, i = [], o = "", s = !1, a = 0, c = !1, u = "", l = !1, p = S(e); !(n = p()).done;) {
                        var h = n.value;
                        l ? l = !1 : "\\" === h ? l = !0 : c ? h === u && (c = !1) : '"' === h || "'" === h ? (c = !0, u = h) : "(" === h ? a += 1 : ")" === h ? a > 0 && (a -= 1) : 0 === a && t.includes(h) && (s = !0), s ? ("" !== o && i.push(o.trim()), o = "", s = !1) : o += h
                    }
                    return (r || "" !== o) && i.push(o.trim()), i
                }
            };
            ta.default = ta;
            var tc = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, t) || this).type = "rule", r.nodes || (r.nodes = []), r
                }
                return g(t, e), f(t, [{
                    key: "selectors",
                    get: function() {
                        return ta.comma(this.selector)
                    },
                    set: function(e) {
                        var t = this.selector ? this.selector.match(/,\s*/) : null,
                            r = t ? t[0] : "," + this.raw("between", "beforeOpen");
                        this.selector = e.join(r)
                    }
                }]), t
            }(e6);
            tc.default = tc, e6.registerRule(tc);
            var tu = function(e, t) {
                    void 0 === t && (t = {});
                    var r, n, i, o, s, a, c, u, l, p, h = e.css.valueOf(),
                        f = t.ignoreErrors,
                        d = h.length,
                        m = 0,
                        g = [],
                        v = [];

                    function y(t) {
                        throw e.error("Unclosed " + t, m)
                    }
                    return {
                        back: function(e) {
                            v.push(e)
                        },
                        endOfFile: function() {
                            return 0 === v.length && m >= d
                        },
                        nextToken: function(e) {
                            if (v.length) return v.pop();
                            if (!(m >= d)) {
                                var t = !!e && e.ignoreUnclosed;
                                switch (r = h.charCodeAt(m)) {
                                    case 10:
                                    case 32:
                                    case 9:
                                    case 13:
                                    case 12:
                                        n = m;
                                        do n += 1, r = h.charCodeAt(n); while (32 === r || 10 === r || 9 === r || 13 === r || 12 === r);
                                        p = ["space", h.slice(m, n)], m = n - 1;
                                        break;
                                    case 91:
                                    case 93:
                                    case 123:
                                    case 125:
                                    case 58:
                                    case 59:
                                    case 41:
                                        var _ = String.fromCharCode(r);
                                        p = [_, _, m];
                                        break;
                                    case 40:
                                        if (u = g.length ? g.pop()[1] : "", l = h.charCodeAt(m + 1), "url" === u && 39 !== l && 34 !== l && 32 !== l && 10 !== l && 9 !== l && 12 !== l && 13 !== l) {
                                            n = m;
                                            do {
                                                if (a = !1, -1 === (n = h.indexOf(")", n + 1)))
                                                    if (f || t) {
                                                        n = m;
                                                        break
                                                    } else y("bracket");
                                                for (c = n; 92 === h.charCodeAt(c - 1);) c -= 1, a = !a
                                            } while (a);
                                            p = ["brackets", h.slice(m, n + 1), m, n], m = n
                                        } else n = h.indexOf(")", m + 1), o = h.slice(m, n + 1), -1 === n || tn.test(o) ? p = ["(", "(", m] : (p = ["brackets", o, m, n], m = n);
                                        break;
                                    case 39:
                                    case 34:
                                        i = 39 === r ? "'" : '"', n = m;
                                        do {
                                            if (a = !1, -1 === (n = h.indexOf(i, n + 1)))
                                                if (f || t) {
                                                    n = m + 1;
                                                    break
                                                } else y("string");
                                            for (c = n; 92 === h.charCodeAt(c - 1);) c -= 1, a = !a
                                        } while (a);
                                        p = ["string", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    case 64:
                                        tt.lastIndex = m + 1, tt.test(h), n = 0 === tt.lastIndex ? h.length - 1 : tt.lastIndex - 2, p = ["at-word", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    case 92:
                                        for (n = m, s = !0; 92 === h.charCodeAt(n + 1);) n += 1, s = !s;
                                        if (r = h.charCodeAt(n + 1), s && 47 !== r && 32 !== r && 10 !== r && 9 !== r && 13 !== r && 12 !== r && (n += 1, ti.test(h.charAt(n)))) {
                                            for (; ti.test(h.charAt(n + 1));) n += 1;
                                            32 === h.charCodeAt(n + 1) && (n += 1)
                                        }
                                        p = ["word", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    default:
                                        47 === r && 42 === h.charCodeAt(m + 1) ? (0 === (n = h.indexOf("*/", m + 2) + 1) && (f || t ? n = h.length : y("comment")), p = ["comment", h.slice(m, n + 1), m, n]) : (tr.lastIndex = m + 1, tr.test(h), n = 0 === tr.lastIndex ? h.length - 1 : tr.lastIndex - 2, p = ["word", h.slice(m, n + 1), m, n], g.push(p)), m = n
                                }
                                return m++, p
                            }
                        },
                        position: function() {
                            return m
                        }
                    }
                },
                tl = {
                    empty: !0,
                    space: !0
                },
                tp = function() {
                    function e(e) {
                        this.input = e, this.root = new ts, this.current = this.root, this.spaces = "", this.semicolon = !1, this.createTokenizer(), this.root.source = {
                            input: e,
                            start: {
                                column: 1,
                                line: 1,
                                offset: 0
                            }
                        }
                    }
                    var t = e.prototype;
                    return t.atrule = function(e) {
                        var t, r, n, i = new to;
                        i.name = e[1].slice(1), "" === i.name && this.unnamedAtrule(i, e), this.init(i, e[2]);
                        for (var o = !1, s = !1, a = [], c = []; !this.tokenizer.endOfFile();) {
                            if ("(" === (t = (e = this.tokenizer.nextToken())[0]) || "[" === t ? c.push("(" === t ? ")" : "]") : "{" === t && c.length > 0 ? c.push("}") : t === c[c.length - 1] && c.pop(), 0 === c.length)
                                if (";" === t) {
                                    i.source.end = this.getPosition(e[2]), i.source.end.offset++, this.semicolon = !0;
                                    break
                                } else if ("{" === t) {
                                s = !0;
                                break
                            } else if ("}" === t) {
                                if (a.length > 0) {
                                    for (n = a.length - 1, r = a[n]; r && "space" === r[0];) r = a[--n];
                                    r && (i.source.end = this.getPosition(r[3] || r[2]), i.source.end.offset++)
                                }
                                this.end(e);
                                break
                            } else a.push(e);
                            else a.push(e);
                            if (this.tokenizer.endOfFile()) {
                                o = !0;
                                break
                            }
                        }
                        i.raws.between = this.spacesAndCommentsFromEnd(a), a.length ? (i.raws.afterName = this.spacesAndCommentsFromStart(a), this.raw(i, "params", a), o && (e = a[a.length - 1], i.source.end = this.getPosition(e[3] || e[2]), i.source.end.offset++, this.spaces = i.raws.between, i.raws.between = "")) : (i.raws.afterName = "", i.params = ""), s && (i.nodes = [], this.current = i)
                    }, t.checkMissedSemicolon = function(e) {
                        var t, r = this.colon(e);
                        if (!1 !== r) {
                            for (var n = 0, i = r - 1; i >= 0 && ("space" === (t = e[i])[0] || 2 !== (n += 1)); i--);
                            throw this.input.error("Missed semicolon", "word" === t[0] ? t[3] + 1 : t[2])
                        }
                    }, t.colon = function(e) {
                        for (var t, r, n, i = 0, o = S(e.entries()); !(n = o()).done;) {
                            var s = n.value,
                                a = s[0],
                                c = s[1];
                            if ("(" === (t = c[0]) && (i += 1), ")" === t && (i -= 1), 0 === i && ":" === t)
                                if (r)
                                    if ("word" === r[0] && "progid" === r[1]) continue;
                                    else return a;
                            else this.doubleColon(c);
                            r = c
                        }
                        return !1
                    }, t.comment = function(e) {
                        var t = new e9;
                        this.init(t, e[2]), t.source.end = this.getPosition(e[3] || e[2]), t.source.end.offset++;
                        var r = e[1].slice(2, -2);
                        if (/^\s*$/.test(r)) t.text = "", t.raws.left = r, t.raws.right = "";
                        else {
                            var n = r.match(/^(\s*)([^]*\S)(\s*)$/);
                            t.text = n[2], t.raws.left = n[1], t.raws.right = n[3]
                        }
                    }, t.createTokenizer = function() {
                        this.tokenizer = tu(this.input)
                    }, t.decl = function(e, t) {
                        var r, n, i = new eM;
                        this.init(i, e[0][2]);
                        var o = e[e.length - 1];
                        for (";" === o[0] && (this.semicolon = !0, e.pop()), i.source.end = this.getPosition(o[3] || o[2] || function(e) {
                                for (var t = e.length - 1; t >= 0; t--) {
                                    var r = e[t],
                                        n = r[3] || r[2];
                                    if (n) return n
                                }
                            }(e)), i.source.end.offset++;
                            "word" !== e[0][0];) 1 === e.length && this.unknownWord(e), i.raws.before += e.shift()[1];
                        for (i.source.start = this.getPosition(e[0][2]), i.prop = ""; e.length;) {
                            var s = e[0][0];
                            if (":" === s || "space" === s || "comment" === s) break;
                            i.prop += e.shift()[1]
                        }
                        for (i.raws.between = ""; e.length;) {
                            if (":" === (r = e.shift())[0]) {
                                i.raws.between += r[1];
                                break
                            }
                            "word" === r[0] && /\w/.test(r[1]) && this.unknownWord([r]), i.raws.between += r[1]
                        }("_" === i.prop[0] || "*" === i.prop[0]) && (i.raws.before += i.prop[0], i.prop = i.prop.slice(1));
                        for (var a = []; e.length && ("space" === (n = e[0][0]) || "comment" === n);) a.push(e.shift());
                        this.precheckMissedSemicolon(e);
                        for (var c = e.length - 1; c >= 0; c--) {
                            if ("!important" === (r = e[c])[1].toLowerCase()) {
                                i.important = !0;
                                var u = this.stringFrom(e, c);
                                " !important" !== (u = this.spacesFromEnd(e) + u) && (i.raws.important = u);
                                break
                            }
                            if ("important" === r[1].toLowerCase()) {
                                for (var l = e.slice(0), p = "", h = c; h > 0; h--) {
                                    var f = l[h][0];
                                    if (0 === p.trim().indexOf("!") && "space" !== f) break;
                                    p = l.pop()[1] + p
                                }
                                0 === p.trim().indexOf("!") && (i.important = !0, i.raws.important = p, e = l)
                            }
                            if ("space" !== r[0] && "comment" !== r[0]) break
                        }
                        e.some(function(e) {
                            return "space" !== e[0] && "comment" !== e[0]
                        }) && (i.raws.between += a.map(function(e) {
                            return e[1]
                        }).join(""), a = []), this.raw(i, "value", a.concat(e), t), i.value.includes(":") && !t && this.checkMissedSemicolon(e)
                    }, t.doubleColon = function(e) {
                        throw this.input.error("Double colon", {
                            offset: e[2]
                        }, {
                            offset: e[2] + e[1].length
                        })
                    }, t.emptyRule = function(e) {
                        var t = new tc;
                        this.init(t, e[2]), t.selector = "", t.raws.between = "", this.current = t
                    }, t.end = function(e) {
                        this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.semicolon = !1, this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.spaces = "", this.current.parent ? (this.current.source.end = this.getPosition(e[2]), this.current.source.end.offset++, this.current = this.current.parent) : this.unexpectedClose(e)
                    }, t.endFile = function() {
                        this.current.parent && this.unclosedBlock(), this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.root.source.end = this.getPosition(this.tokenizer.position())
                    }, t.freeSemicolon = function(e) {
                        if (this.spaces += e[1], this.current.nodes) {
                            var t = this.current.nodes[this.current.nodes.length - 1];
                            t && "rule" === t.type && !t.raws.ownSemicolon && (t.raws.ownSemicolon = this.spaces, this.spaces = "")
                        }
                    }, t.getPosition = function(e) {
                        var t = this.input.fromOffset(e);
                        return {
                            column: t.col,
                            line: t.line,
                            offset: e
                        }
                    }, t.init = function(e, t) {
                        this.current.push(e), e.source = {
                            input: this.input,
                            start: this.getPosition(t)
                        }, e.raws.before = this.spaces, this.spaces = "", "comment" !== e.type && (this.semicolon = !1)
                    }, t.other = function(e) {
                        for (var t = !1, r = null, n = !1, i = null, o = [], s = e[1].startsWith("--"), a = [], c = e; c;) {
                            if (r = c[0], a.push(c), "(" === r || "[" === r) i || (i = c), o.push("(" === r ? ")" : "]");
                            else if (s && n && "{" === r) i || (i = c), o.push("}");
                            else if (0 === o.length)
                                if (";" === r)
                                    if (n) return void this.decl(a, s);
                                    else break;
                            else if ("{" === r) return void this.rule(a);
                            else if ("}" === r) {
                                this.tokenizer.back(a.pop()), t = !0;
                                break
                            } else ":" === r && (n = !0);
                            else r === o[o.length - 1] && (o.pop(), 0 === o.length && (i = null));
                            c = this.tokenizer.nextToken()
                        }
                        if (this.tokenizer.endOfFile() && (t = !0), o.length > 0 && this.unclosedBracket(i), t && n) {
                            if (!s)
                                for (; a.length && ("space" === (c = a[a.length - 1][0]) || "comment" === c);) this.tokenizer.back(a.pop());
                            this.decl(a, s)
                        } else this.unknownWord(a)
                    }, t.parse = function() {
                        for (var e; !this.tokenizer.endOfFile();) switch ((e = this.tokenizer.nextToken())[0]) {
                            case "space":
                                this.spaces += e[1];
                                break;
                            case ";":
                                this.freeSemicolon(e);
                                break;
                            case "}":
                                this.end(e);
                                break;
                            case "comment":
                                this.comment(e);
                                break;
                            case "at-word":
                                this.atrule(e);
                                break;
                            case "{":
                                this.emptyRule(e);
                                break;
                            default:
                                this.other(e)
                        }
                        this.endFile()
                    }, t.precheckMissedSemicolon = function() {}, t.raw = function(e, t, r, n) {
                        for (var i, o, s, a, c = r.length, u = "", l = !0, p = 0; p < c; p += 1) "space" !== (o = (i = r[p])[0]) || p !== c - 1 || n ? "comment" === o ? (a = r[p - 1] ? r[p - 1][0] : "empty", s = r[p + 1] ? r[p + 1][0] : "empty", tl[a] || tl[s] || "," === u.slice(-1) ? l = !1 : u += i[1]) : u += i[1] : l = !1;
                        if (!l) {
                            var h = r.reduce(function(e, t) {
                                return e + t[1]
                            }, "");
                            e.raws[t] = {
                                raw: h,
                                value: u
                            }
                        }
                        e[t] = u
                    }, t.rule = function(e) {
                        e.pop();
                        var t = new tc;
                        this.init(t, e[0][2]), t.raws.between = this.spacesAndCommentsFromEnd(e), this.raw(t, "selector", e), this.current = t
                    }, t.spacesAndCommentsFromEnd = function(e) {
                        for (var t, r = ""; e.length && ("space" === (t = e[e.length - 1][0]) || "comment" === t);) r = e.pop()[1] + r;
                        return r
                    }, t.spacesAndCommentsFromStart = function(e) {
                        for (var t, r = ""; e.length && ("space" === (t = e[0][0]) || "comment" === t);) r += e.shift()[1];
                        return r
                    }, t.spacesFromEnd = function(e) {
                        for (var t = ""; e.length && "space" === e[e.length - 1][0];) t = e.pop()[1] + t;
                        return t
                    }, t.stringFrom = function(e, t) {
                        for (var r = "", n = t; n < e.length; n++) r += e[n][1];
                        return e.splice(t, e.length - t), r
                    }, t.unclosedBlock = function() {
                        var e = this.current.source.start;
                        throw this.input.error("Unclosed block", e.line, e.column)
                    }, t.unclosedBracket = function(e) {
                        throw this.input.error("Unclosed bracket", {
                            offset: e[2]
                        }, {
                            offset: e[2] + 1
                        })
                    }, t.unexpectedClose = function(e) {
                        throw this.input.error("Unexpected }", {
                            offset: e[2]
                        }, {
                            offset: e[2] + 1
                        })
                    }, t.unknownWord = function(e) {
                        throw this.input.error("Unknown word", {
                            offset: e[0][2]
                        }, {
                            offset: e[0][2] + e[0][1].length
                        })
                    }, t.unnamedAtrule = function(e, t) {
                        throw this.input.error("At-rule without name", {
                            offset: t[2]
                        }, {
                            offset: t[2] + t[1].length
                        })
                    }, e
                }();

            function th(e, t) {
                var r = new tp(new eY(e, t));
                try {
                    r.parse()
                } catch (e) {
                    throw e
                }
                return r.root
            }
            th.default = th, e6.registerParse(th);
            var tf = ek.isClean,
                td = ek.my,
                tm = {
                    atrule: "AtRule",
                    comment: "Comment",
                    decl: "Declaration",
                    document: "Document",
                    root: "Root",
                    rule: "Rule"
                },
                tg = {
                    AtRule: !0,
                    AtRuleExit: !0,
                    Comment: !0,
                    CommentExit: !0,
                    Declaration: !0,
                    DeclarationExit: !0,
                    Document: !0,
                    DocumentExit: !0,
                    Once: !0,
                    OnceExit: !0,
                    postcssPlugin: !0,
                    prepare: !0,
                    Root: !0,
                    RootExit: !0,
                    Rule: !0,
                    RuleExit: !0
                },
                tv = {
                    Once: !0,
                    postcssPlugin: !0,
                    prepare: !0
                };

            function ty(e) {
                return (void 0 === e ? "undefined" : b(e)) === "object" && "function" == typeof e.then
            }

            function t_(e) {
                var t = !1,
                    r = tm[e.type];
                return ("decl" === e.type ? t = e.prop.toLowerCase() : "atrule" === e.type && (t = e.name.toLowerCase()), t && e.append) ? [r, r + "-" + t, 0, r + "Exit", r + "Exit-" + t] : t ? [r, r + "-" + t, r + "Exit", r + "Exit-" + t] : e.append ? [r, 0, r + "Exit"] : [r, r + "Exit"]
            }

            function tb(e) {
                var t;
                return {
                    eventIndex: 0,
                    events: "document" === e.type ? ["Document", 0, "DocumentExit"] : "root" === e.type ? ["Root", 0, "RootExit"] : t_(e),
                    iterator: 0,
                    node: e,
                    visitorIndex: 0,
                    visitors: []
                }
            }

            function tw(e) {
                return e[tf] = !1, e.nodes && e.nodes.forEach(function(e) {
                    return tw(e)
                }), e
            }
            var tk = {},
                tS = function() {
                    function e(t, r, n) {
                        var i, o = this;
                        if (this.stringified = !1, this.processed = !1, (void 0 === r ? "undefined" : b(r)) === "object" && null !== r && ("root" === r.type || "document" === r.type)) i = tw(r);
                        else if (v(r, e) || v(r, te)) i = tw(r.root), r.map && (void 0 === n.map && (n.map = {}), n.map.inline || (n.map.inline = !1), n.map.prev = r.map);
                        else {
                            var s = th;
                            n.syntax && (s = n.syntax.parse), n.parser && (s = n.parser), s.parse && (s = s.parse);
                            try {
                                i = s(r, n)
                            } catch (e) {
                                this.processed = !0, this.error = e
                            }
                            i && !i[td] && e6.rebuild(i)
                        }
                        this.result = new te(t, i, n), this.helpers = d({}, tk, {
                            postcss: tk,
                            result: this.result
                        }), this.plugins = this.processor.plugins.map(function(e) {
                            return (void 0 === e ? "undefined" : b(e)) === "object" && e.prepare ? d({}, e, e.prepare(o.result)) : e
                        })
                    }
                    var t = e.prototype;
                    return t.async = function() {
                        return this.error ? Promise.reject(this.error) : this.processed ? Promise.resolve(this.result) : (this.processing || (this.processing = this.runAsync()), this.processing)
                    }, t.catch = function(e) {
                        return this.async().catch(e)
                    }, t.finally = function(e) {
                        return this.async().then(e, e)
                    }, t.getAsyncError = function() {
                        throw Error("Use process(css).then(cb) to work with async plugins")
                    }, t.handleError = function(e, t) {
                        var r = this.result.lastPlugin;
                        try {
                            t && t.addToError(e), this.error = e, "CssSyntaxError" !== e.name || e.plugin ? r.postcssVersion : (e.plugin = r.postcssPlugin, e.setMessage())
                        } catch (e) {
                            console && console.error && console.error(e)
                        }
                        return e
                    }, t.prepareVisitors = function() {
                        var e = this;
                        this.listeners = {};
                        for (var t, r = function(t, r, n) {
                                e.listeners[r] || (e.listeners[r] = []), e.listeners[r].push([t, n])
                            }, n = S(this.plugins); !(t = n()).done;) {
                            var i = t.value;
                            if ((void 0 === i ? "undefined" : b(i)) === "object")
                                for (var o in i) {
                                    if (!tg[o] && /^[A-Z]/.test(o)) throw Error("Unknown event " + o + " in " + i.postcssPlugin + ". Try to update PostCSS (" + this.processor.version + " now).");
                                    if (!tv[o])
                                        if ("object" === b(i[o]))
                                            for (var s in i[o]) r(i, "*" === s ? o : o + "-" + s.toLowerCase(), i[o][s]);
                                        else "function" == typeof i[o] && r(i, o, i[o])
                                }
                        }
                        this.hasListener = Object.keys(this.listeners).length > 0
                    }, t.runAsync = function() {
                        var e = this;
                        return p(function() {
                            var t, r, n, i, o, s, a, c, u, l, p, h;
                            return C(this, function(f) {
                                switch (f.label) {
                                    case 0:
                                        e.plugin = 0, t = 0, f.label = 1;
                                    case 1:
                                        if (!(t < e.plugins.length)) return [3, 6];
                                        if (r = e.plugins[t], !ty(n = e.runOnRoot(r))) return [3, 5];
                                        f.label = 2;
                                    case 2:
                                        return f.trys.push([2, 4, , 5]), [4, n];
                                    case 3:
                                        return f.sent(), [3, 5];
                                    case 4:
                                        throw i = f.sent(), e.handleError(i);
                                    case 5:
                                        return t++, [3, 1];
                                    case 6:
                                        if (e.prepareVisitors(), !e.hasListener) return [3, 18];
                                        o = e.result.root, f.label = 7;
                                    case 7:
                                        if (o[tf]) return [3, 14];
                                        o[tf] = !0, s = [tb(o)], f.label = 8;
                                    case 8:
                                        if (!(s.length > 0)) return [3, 13];
                                        if (!ty(a = e.visitTick(s))) return [3, 12];
                                        f.label = 9;
                                    case 9:
                                        return f.trys.push([9, 11, , 12]), [4, a];
                                    case 10:
                                        return f.sent(), [3, 12];
                                    case 11:
                                        throw c = f.sent(), u = s[s.length - 1].node, e.handleError(c, u);
                                    case 12:
                                        return [3, 8];
                                    case 13:
                                        return [3, 7];
                                    case 14:
                                        if (!e.listeners.OnceExit) return [3, 18];
                                        l = function() {
                                            var t, r, n, i;
                                            return C(this, function(s) {
                                                switch (s.label) {
                                                    case 0:
                                                        r = (t = h.value)[0], n = t[1], e.result.lastPlugin = r, s.label = 1;
                                                    case 1:
                                                        if (s.trys.push([1, 6, , 7]), "document" !== o.type) return [3, 3];
                                                        return [4, Promise.all(o.nodes.map(function(t) {
                                                            return n(t, e.helpers)
                                                        }))];
                                                    case 2:
                                                        return s.sent(), [3, 5];
                                                    case 3:
                                                        return [4, n(o, e.helpers)];
                                                    case 4:
                                                        s.sent(), s.label = 5;
                                                    case 5:
                                                        return [3, 7];
                                                    case 6:
                                                        throw i = s.sent(), e.handleError(i);
                                                    case 7:
                                                        return [2]
                                                }
                                            })
                                        }, p = S(e.listeners.OnceExit), f.label = 15;
                                    case 15:
                                        if ((h = p()).done) return [3, 18];
                                        return [5, I(l())];
                                    case 16:
                                        f.sent(), f.label = 17;
                                    case 17:
                                        return [3, 15];
                                    case 18:
                                        return e.processed = !0, [2, e.stringify()]
                                }
                            })
                        })()
                    }, t.runOnRoot = function(e) {
                        var t = this;
                        this.result.lastPlugin = e;
                        try {
                            if ((void 0 === e ? "undefined" : b(e)) === "object" && e.Once) {
                                if ("document" === this.result.root.type) {
                                    var r = this.result.root.nodes.map(function(r) {
                                        return e.Once(r, t.helpers)
                                    });
                                    if (ty(r[0])) return Promise.all(r);
                                    return r
                                }
                                return e.Once(this.result.root, this.helpers)
                            }
                            if ("function" == typeof e) return e(this.result.root, this.result)
                        } catch (e) {
                            throw this.handleError(e)
                        }
                    }, t.stringify = function() {
                        if (this.error) throw this.error;
                        if (this.stringified) return this.result;
                        this.stringified = !0, this.sync();
                        var e = this.result.opts,
                            t = eI;
                        e.syntax && (t = e.syntax.stringify), e.stringifier && (t = e.stringifier), t.stringify && (t = t.stringify);
                        var r = new e3(t, this.result.root, this.result.opts).generate();
                        return this.result.css = r[0], this.result.map = r[1], this.result
                    }, t.sync = function() {
                        if (this.error) throw this.error;
                        if (this.processed) return this.result;
                        if (this.processed = !0, this.processing) throw this.getAsyncError();
                        for (var e, t = S(this.plugins); !(e = t()).done;) {
                            var r = e.value;
                            if (ty(this.runOnRoot(r))) throw this.getAsyncError()
                        }
                        if (this.prepareVisitors(), this.hasListener) {
                            for (var n = this.result.root; !n[tf];) n[tf] = !0, this.walkSync(n);
                            if (this.listeners.OnceExit)
                                if ("document" === n.type)
                                    for (var i, o = S(n.nodes); !(i = o()).done;) {
                                        var s = i.value;
                                        this.visitSync(this.listeners.OnceExit, s)
                                    } else this.visitSync(this.listeners.OnceExit, n)
                        }
                        return this.result
                    }, t.then = function(e, t) {
                        return this.async().then(e, t)
                    }, t.toString = function() {
                        return this.css
                    }, t.visitSync = function(e, t) {
                        for (var r, n = S(e); !(r = n()).done;) {
                            var i = r.value,
                                o = i[0],
                                s = i[1];
                            this.result.lastPlugin = o;
                            var a = void 0;
                            try {
                                a = s(t, this.helpers)
                            } catch (e) {
                                throw this.handleError(e, t.proxyOf)
                            }
                            if ("root" !== t.type && "document" !== t.type && !t.parent) return !0;
                            if (ty(a)) throw this.getAsyncError()
                        }
                    }, t.visitTick = function(e) {
                        var t = e[e.length - 1],
                            r = t.node,
                            n = t.visitors;
                        if ("root" !== r.type && "document" !== r.type && !r.parent) return void e.pop();
                        if (n.length > 0 && t.visitorIndex < n.length) {
                            var i = n[t.visitorIndex],
                                o = i[0],
                                s = i[1];
                            t.visitorIndex += 1, t.visitorIndex === n.length && (t.visitors = [], t.visitorIndex = 0), this.result.lastPlugin = o;
                            try {
                                return s(r.toProxy(), this.helpers)
                            } catch (e) {
                                throw this.handleError(e, r)
                            }
                        }
                        if (0 !== t.iterator) {
                            for (var a, c = t.iterator; a = r.nodes[r.indexes[c]];)
                                if (r.indexes[c] += 1, !a[tf]) {
                                    a[tf] = !0, e.push(tb(a));
                                    return
                                }
                            t.iterator = 0, delete r.indexes[c]
                        }
                        for (var u = t.events; t.eventIndex < u.length;) {
                            var l = u[t.eventIndex];
                            if (t.eventIndex += 1, 0 === l) {
                                r.nodes && r.nodes.length && (r[tf] = !0, t.iterator = r.getIterator());
                                return
                            }
                            if (this.listeners[l]) {
                                t.visitors = this.listeners[l];
                                return
                            }
                        }
                        e.pop()
                    }, t.walkSync = function(e) {
                        var t = this;
                        e[tf] = !0;
                        for (var r, n = t_(e), i = S(n); !(r = i()).done;) {
                            var o = r.value;
                            if (0 === o) e.nodes && e.each(function(e) {
                                e[tf] || t.walkSync(e)
                            });
                            else {
                                var s = this.listeners[o];
                                if (s && this.visitSync(s, e.toProxy())) return
                            }
                        }
                    }, t.warnings = function() {
                        return this.sync().warnings()
                    }, f(e, [{
                        key: "content",
                        get: function() {
                            return this.stringify().content
                        }
                    }, {
                        key: "css",
                        get: function() {
                            return this.stringify().css
                        }
                    }, {
                        key: "map",
                        get: function() {
                            return this.stringify().map
                        }
                    }, {
                        key: "messages",
                        get: function() {
                            return this.sync().messages
                        }
                    }, {
                        key: "opts",
                        get: function() {
                            return this.result.opts
                        }
                    }, {
                        key: "processor",
                        get: function() {
                            return this.result.processor
                        }
                    }, {
                        key: "root",
                        get: function() {
                            return this.sync().root
                        }
                    }, {
                        key: Symbol.toStringTag,
                        get: function() {
                            return "LazyResult"
                        }
                    }]), e
                }();
            tS.registerPostcss = function(e) {
                tk = e
            }, tS.default = tS, ts.registerLazyResult(tS), e8.registerLazyResult(tS);
            var tC = function() {
                function e(e, t, r) {
                    t = t.toString(), this.stringified = !1, this._processor = e, this._css = t, this._opts = r, this._map = void 0, this.result = new te(this._processor, n, this._opts), this.result.css = t;
                    var n, i = this;
                    Object.defineProperty(this.result, "root", {
                        get: function() {
                            return i.root
                        }
                    });
                    var o = new e3(eI, n, this._opts, t);
                    if (o.isMap()) {
                        var s = o.generate(),
                            a = s[0],
                            c = s[1];
                        a && (this.result.css = a), c && (this.result.map = c)
                    } else o.clearAnnotation(), this.result.css = o.css
                }
                var t = e.prototype;
                return t.async = function() {
                    return this.error ? Promise.reject(this.error) : Promise.resolve(this.result)
                }, t.catch = function(e) {
                    return this.async().catch(e)
                }, t.finally = function(e) {
                    return this.async().then(e, e)
                }, t.sync = function() {
                    if (this.error) throw this.error;
                    return this.result
                }, t.then = function(e, t) {
                    return this.async().then(e, t)
                }, t.toString = function() {
                    return this._css
                }, t.warnings = function() {
                    return []
                }, f(e, [{
                    key: "content",
                    get: function() {
                        return this.result.css
                    }
                }, {
                    key: "css",
                    get: function() {
                        return this.result.css
                    }
                }, {
                    key: "map",
                    get: function() {
                        return this.result.map
                    }
                }, {
                    key: "messages",
                    get: function() {
                        return []
                    }
                }, {
                    key: "opts",
                    get: function() {
                        return this.result.opts
                    }
                }, {
                    key: "processor",
                    get: function() {
                        return this.result.processor
                    }
                }, {
                    key: "root",
                    get: function() {
                        var e;
                        if (this._root) return this._root;
                        try {
                            e = th(this._css, this._opts)
                        } catch (e) {
                            this.error = e
                        }
                        if (!this.error) return this._root = e, e;
                        throw this.error
                    }
                }, {
                    key: Symbol.toStringTag,
                    get: function() {
                        return "NoWorkResult"
                    }
                }]), e
            }();
            tC.default = tC;
            var tI = function() {
                function e(e) {
                    void 0 === e && (e = []), this.version = "8.4.38", this.plugins = this.normalize(e)
                }
                var t = e.prototype;
                return t.normalize = function(e) {
                    for (var t, r = [], n = S(e); !(t = n()).done;) {
                        var i = t.value;
                        if (!0 === i.postcss ? i = i() : i.postcss && (i = i.postcss), (void 0 === i ? "undefined" : b(i)) === "object" && Array.isArray(i.plugins)) r = r.concat(i.plugins);
                        else if ((void 0 === i ? "undefined" : b(i)) === "object" && i.postcssPlugin) r.push(i);
                        else if ("function" == typeof i) r.push(i);
                        else if ((void 0 === i ? "undefined" : b(i)) === "object" && (i.parse || i.stringify));
                        else throw Error(i + " is not a PostCSS plugin")
                    }
                    return r
                }, t.process = function(e, t) {
                    return (void 0 === t && (t = {}), this.plugins.length || t.parser || t.stringifier || t.syntax) ? new tS(this, e, t) : new tC(this, e, t)
                }, t.use = function(e) {
                    return this.plugins = this.plugins.concat(this.normalize([e])), this
                }, e
            }();

            function tx(e, t) {
                if (Array.isArray(e)) return e.map(function(e) {
                    return tx(e)
                });
                var r = e.inputs,
                    n = y(e, ["inputs"]);
                if (r) {
                    t = [];
                    for (var i, o = S(r); !(i = o()).done;) {
                        var s = i.value,
                            a = d({}, s, {
                                __proto__: eY.prototype
                            });
                        a.map && (a.map = d({}, a.map, {
                            __proto__: eL.prototype
                        })), t.push(a)
                    }
                }
                if (n.nodes && (n.nodes = e.nodes.map(function(e) {
                        return tx(e, t)
                    })), n.source) {
                    var c = n.source,
                        u = c.inputId;
                    n.source = y(c, ["inputId"]), null != u && (n.source.input = t[u])
                }
                if ("root" === n.type) return new ts(n);
                if ("decl" === n.type) return new eM(n);
                if ("rule" === n.type) return new tc(n);
                if ("comment" === n.type) return new e9(n);
                if ("atrule" === n.type) return new to(n);
                else throw Error("Unknown node type: " + e.type)
            }

            function tO() {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return 1 === t.length && Array.isArray(t[0]) && (t = t[0]), new tI(t)
            }
            tI.default = tI, ts.registerProcessor(tI), e8.registerProcessor(tI), tx.default = tx, tO.plugin = function(e, t) {
                var r, n = !1;

                function i() {
                    for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                    console && console.warn && !n && (n = !0, console.warn(e + ": postcss.plugin was deprecated. Migration guide:\nhttps://evilmartians.com/chronicles/postcss-8-plugin-migration"), a.env.LANG && a.env.LANG.startsWith("cn") && console.warn(e + ": 里面 postcss.plugin 被弃用. 迁移指南:\nhttps://www.w3ctech.com/topic/2226"));
                    var s = t.apply(void 0, [].concat(i));
                    return s.postcssPlugin = e, s.postcssVersion = new tI().version, s
                }
                return Object.defineProperty(i, "postcss", {
                    get: function() {
                        return r || (r = i()), r
                    }
                }), i.process = function(e, t, r) {
                    return tO([i(r)]).process(e, t)
                }, i
            }, tO.stringify = eI, tO.parse = th, tO.fromJSON = tx, tO.list = ta, tO.comment = function(e) {
                return new e9(e)
            }, tO.atRule = function(e) {
                return new to(e)
            }, tO.decl = function(e) {
                return new eM(e)
            }, tO.rule = function(e) {
                return new tc(e)
            }, tO.root = function(e) {
                return new ts(e)
            }, tO.document = function(e) {
                return new e8(e)
            }, tO.CssSyntaxError = ew, tO.Declaration = eM, tO.Container = e6, tO.Processor = tI, tO.Document = e8, tO.Comment = e9, tO.Warning = e7, tO.AtRule = to, tO.Result = te, tO.Input = eY, tO.Rule = tc, tO.Root = ts, tO.Node = eE, tS.registerPostcss(tO), tO.default = tO;
            var tE = function(e) {
                return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
            }(tO);
            tE.stringify, tE.fromJSON, tE.plugin, tE.parse, tE.list, tE.document, tE.comment, tE.atRule, tE.rule, tE.decl, tE.root, tE.CssSyntaxError, tE.Declaration, tE.Container, tE.Processor, tE.Document, tE.Comment, tE.Warning, tE.AtRule, tE.Result, tE.Input, tE.Rule, tE.Root, tE.Node;
            var tM = Object.defineProperty,
                tR = function(e, t, r) {
                    var n;
                    return n = (void 0 === t ? "undefined" : b(t)) !== "symbol" ? t + "" : t, n in e ? tM(e, n, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: r
                    }) : e[n] = r
                },
                tA = {
                    exports: {}
                },
                tT = String,
                tN = function() {
                    return {
                        isColorSupported: !1,
                        reset: tT,
                        bold: tT,
                        dim: tT,
                        italic: tT,
                        underline: tT,
                        inverse: tT,
                        hidden: tT,
                        strikethrough: tT,
                        black: tT,
                        red: tT,
                        green: tT,
                        yellow: tT,
                        blue: tT,
                        magenta: tT,
                        cyan: tT,
                        white: tT,
                        gray: tT,
                        bgBlack: tT,
                        bgRed: tT,
                        bgGreen: tT,
                        bgYellow: tT,
                        bgBlue: tT,
                        bgMagenta: tT,
                        bgCyan: tT,
                        bgWhite: tT
                    }
                };
            tA.exports = tN(), tA.exports.createColors = tN;
            var tP = tA.exports,
                tD = function(e) {
                    if (e.__esModule) return e;
                    var t = e.default;
                    if ("function" == typeof t) {
                        var r = function e() {
                            return v(this, e) ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments)
                        };
                        r.prototype = t.prototype
                    } else r = {};
                    return Object.defineProperty(r, "__esModule", {
                        value: !0
                    }), Object.keys(e).forEach(function(t) {
                        var n = Object.getOwnPropertyDescriptor(e, t);
                        Object.defineProperty(r, t, n.get ? n : {
                            enumerable: !0,
                            get: function() {
                                return e[t]
                            }
                        })
                    }), r
                }(Object.freeze(Object.defineProperty({
                    __proto__: null,
                    default: {}
                }, Symbol.toStringTag, {
                    value: "Module"
                }))),
                tL = function(e) {
                    function t(r, n, i, o, s, a) {
                        var c;
                        return (c = e.call(this, r) || this).name = "CssSyntaxError", c.reason = r, s && (c.file = s), o && (c.source = o), a && (c.plugin = a), void 0 !== n && void 0 !== i && ("number" == typeof n ? (c.line = n, c.column = i) : (c.line = n.line, c.column = n.column, c.endLine = i.line, c.endColumn = i.column)), c.setMessage(), Error.captureStackTrace && Error.captureStackTrace(c, t), c
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.setMessage = function() {
                        this.message = this.plugin ? this.plugin + ": " : "", this.message += this.file ? this.file : "<css input>", void 0 !== this.line && (this.message += ":" + this.line + ":" + this.column), this.message += ": " + this.reason
                    }, r.showSourceCode = function(e) {
                        var t, r, n = this;
                        if (!this.source) return "";
                        var i = this.source;
                        null == e && (e = tP.isColorSupported), tD && e && (i = tD(i));
                        var o = i.split(/\r?\n/),
                            s = Math.max(this.line - 3, 0),
                            a = Math.min(this.line + 2, o.length),
                            c = String(a).length;
                        if (e) {
                            var u = tP.createColors(!0),
                                l = u.bold,
                                p = u.gray,
                                h = u.red;
                            t = function(e) {
                                return l(h(e))
                            }, r = function(e) {
                                return p(e)
                            }
                        } else t = r = function(e) {
                            return e
                        };
                        return o.slice(s, a).map(function(e, i) {
                            var o = s + 1 + i,
                                a = " " + (" " + o).slice(-c) + " | ";
                            if (o === n.line) {
                                var u = r(a.replace(/\d/g, " ")) + e.slice(0, n.column - 1).replace(/[^\t]/g, " ");
                                return t(">") + r(a) + e + "\n " + u + t("^")
                            }
                            return " " + r(a) + e
                        }).join("\n")
                    }, r.toString = function() {
                        var e = this.showSourceCode();
                        return e && (e = "\n\n" + e + "\n"), this.name + ": " + this.message + e
                    }, t
                }(w(Error));
            tL.default = tL;
            var tF = {};
            tF.isClean = Symbol("isClean"), tF.my = Symbol("my");
            var tU = {
                    after: "\n",
                    beforeClose: "\n",
                    beforeComment: "\n",
                    beforeDecl: "\n",
                    beforeOpen: " ",
                    beforeRule: "\n",
                    colon: ": ",
                    commentLeft: " ",
                    commentRight: " ",
                    emptyBody: "",
                    indent: "    ",
                    semicolon: !1
                },
                tB = function() {
                    function e(e) {
                        this.builder = e
                    }
                    var t = e.prototype;
                    return t.atrule = function(e, t) {
                        var r = "@" + e.name,
                            n = e.params ? this.rawValue(e, "params") : "";
                        if (void 0 !== e.raws.afterName ? r += e.raws.afterName : n && (r += " "), e.nodes) this.block(e, r + n);
                        else {
                            var i = (e.raws.between || "") + (t ? ";" : "");
                            this.builder(r + n + i, e)
                        }
                    }, t.beforeAfter = function(e, t) {
                        for (var r = "decl" === e.type ? this.raw(e, null, "beforeDecl") : "comment" === e.type ? this.raw(e, null, "beforeComment") : "before" === t ? this.raw(e, null, "beforeRule") : this.raw(e, null, "beforeClose"), n = e.parent, i = 0; n && "root" !== n.type;) i += 1, n = n.parent;
                        if (r.includes("\n")) {
                            var o = this.raw(e, null, "indent");
                            if (o.length)
                                for (var s = 0; s < i; s++) r += o
                        }
                        return r
                    }, t.block = function(e, t) {
                        var r, n = this.raw(e, "between", "beforeOpen");
                        this.builder(t + n + "{", e, "start"), e.nodes && e.nodes.length ? (this.body(e), r = this.raw(e, "after")) : r = this.raw(e, "after", "emptyBody"), r && this.builder(r), this.builder("}", e, "end")
                    }, t.body = function(e) {
                        for (var t = e.nodes.length - 1; t > 0 && "comment" === e.nodes[t].type;) t -= 1;
                        for (var r = this.raw(e, "semicolon"), n = 0; n < e.nodes.length; n++) {
                            var i = e.nodes[n],
                                o = this.raw(i, "before");
                            o && this.builder(o), this.stringify(i, t !== n || r)
                        }
                    }, t.comment = function(e) {
                        var t = this.raw(e, "left", "commentLeft"),
                            r = this.raw(e, "right", "commentRight");
                        this.builder("/*" + t + e.text + r + "*/", e)
                    }, t.decl = function(e, t) {
                        var r = this.raw(e, "between", "colon"),
                            n = e.prop + r + this.rawValue(e, "value");
                        e.important && (n += e.raws.important || " !important"), t && (n += ";"), this.builder(n, e)
                    }, t.document = function(e) {
                        this.body(e)
                    }, t.raw = function(e, t, r) {
                        if (r || (r = t), t && void 0 !== (n = e.raws[t])) return n;
                        var n, i = e.parent;
                        if ("before" === r && (!i || "root" === i.type && i.first === e || i && "document" === i.type)) return "";
                        if (!i) return tU[r];
                        var o = e.root();
                        if (o.rawCache || (o.rawCache = {}), void 0 !== o.rawCache[r]) return o.rawCache[r];
                        if ("before" === r || "after" === r) return this.beforeAfter(e, r);
                        var s, a = "raw" + ((s = r)[0].toUpperCase() + s.slice(1));
                        return this[a] ? n = this[a](o, e) : o.walk(function(e) {
                            if (void 0 !== (n = e.raws[t])) return !1
                        }), void 0 === n && (n = tU[r]), o.rawCache[r] = n, n
                    }, t.rawBeforeClose = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && e.nodes.length > 0 && void 0 !== e.raws.after) return (t = e.raws.after).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1
                        }), t && (t = t.replace(/\S/g, "")), t
                    }, t.rawBeforeComment = function(e, t) {
                        var r;
                        return e.walkComments(function(e) {
                            if (void 0 !== e.raws.before) return (r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1
                        }), void 0 === r ? r = this.raw(t, null, "beforeDecl") : r && (r = r.replace(/\S/g, "")), r
                    }, t.rawBeforeDecl = function(e, t) {
                        var r;
                        return e.walkDecls(function(e) {
                            if (void 0 !== e.raws.before) return (r = e.raws.before).includes("\n") && (r = r.replace(/[^\n]+$/, "")), !1
                        }), void 0 === r ? r = this.raw(t, null, "beforeRule") : r && (r = r.replace(/\S/g, "")), r
                    }, t.rawBeforeOpen = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if ("decl" !== e.type && void 0 !== (t = e.raws.between)) return !1
                        }), t
                    }, t.rawBeforeRule = function(e) {
                        var t;
                        return e.walk(function(r) {
                            if (r.nodes && (r.parent !== e || e.first !== r) && void 0 !== r.raws.before) return (t = r.raws.before).includes("\n") && (t = t.replace(/[^\n]+$/, "")), !1
                        }), t && (t = t.replace(/\S/g, "")), t
                    }, t.rawColon = function(e) {
                        var t;
                        return e.walkDecls(function(e) {
                            if (void 0 !== e.raws.between) return t = e.raws.between.replace(/[^\s:]/g, ""), !1
                        }), t
                    }, t.rawEmptyBody = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && 0 === e.nodes.length && void 0 !== (t = e.raws.after)) return !1
                        }), t
                    }, t.rawIndent = function(e) {
                        var t;
                        return e.raws.indent ? e.raws.indent : (e.walk(function(r) {
                            var n = r.parent;
                            if (n && n !== e && n.parent && n.parent === e && void 0 !== r.raws.before) {
                                var i = r.raws.before.split("\n");
                                return t = (t = i[i.length - 1]).replace(/\S/g, ""), !1
                            }
                        }), t)
                    }, t.rawSemicolon = function(e) {
                        var t;
                        return e.walk(function(e) {
                            if (e.nodes && e.nodes.length && "decl" === e.last.type && void 0 !== (t = e.raws.semicolon)) return !1
                        }), t
                    }, t.rawValue = function(e, t) {
                        var r = e[t],
                            n = e.raws[t];
                        return n && n.value === r ? n.raw : r
                    }, t.root = function(e) {
                        this.body(e), e.raws.after && this.builder(e.raws.after)
                    }, t.rule = function(e) {
                        this.block(e, this.rawValue(e, "selector")), e.raws.ownSemicolon && this.builder(e.raws.ownSemicolon, e, "end")
                    }, t.stringify = function(e, t) {
                        if (!this[e.type]) throw Error("Unknown AST node type " + e.type + ". Maybe you need to change PostCSS stringifier.");
                        this[e.type](e, t)
                    }, e
                }();

            function tj(e, t) {
                new tB(t).stringify(e)
            }
            tB.default = tB, tj.default = tj;
            var tq = tF.isClean,
                tz = tF.my,
                tW = function() {
                    function e(e) {
                        for (var t in void 0 === e && (e = {}), this.raws = {}, this[tq] = !1, this[tz] = !0, e)
                            if ("nodes" === t) {
                                this.nodes = [];
                                for (var r, n = S(e[t]); !(r = n()).done;) {
                                    var i = r.value;
                                    "function" == typeof i.clone ? this.append(i.clone()) : this.append(i)
                                }
                            } else this[t] = e[t]
                    }
                    var t = e.prototype;
                    return t.addToError = function(e) {
                        if (e.postcssNode = this, e.stack && this.source && /\n\s{4}at /.test(e.stack)) {
                            var t = this.source;
                            e.stack = e.stack.replace(/\n\s{4}at /, "$&" + t.input.from + ":" + t.start.line + ":" + t.start.column + "$&")
                        }
                        return e
                    }, t.after = function(e) {
                        return this.parent.insertAfter(this, e), this
                    }, t.assign = function(e) {
                        for (var t in void 0 === e && (e = {}), e) this[t] = e[t];
                        return this
                    }, t.before = function(e) {
                        return this.parent.insertBefore(this, e), this
                    }, t.cleanRaws = function(e) {
                        delete this.raws.before, delete this.raws.after, e || delete this.raws.between
                    }, t.clone = function(e) {
                        void 0 === e && (e = {});
                        var t = function e(t, r) {
                            var n = new t.constructor;
                            for (var i in t)
                                if (Object.prototype.hasOwnProperty.call(t, i) && "proxyCache" !== i) {
                                    var o = t[i],
                                        s = void 0 === o ? "undefined" : b(o);
                                    "parent" === i && "object" === s ? r && (n[i] = r) : "source" === i ? n[i] = o : Array.isArray(o) ? n[i] = o.map(function(t) {
                                        return e(t, n)
                                    }) : ("object" === s && null !== o && (o = e(o)), n[i] = o)
                                }
                            return n
                        }(this);
                        for (var r in e) t[r] = e[r];
                        return t
                    }, t.cloneAfter = function(e) {
                        void 0 === e && (e = {});
                        var t = this.clone(e);
                        return this.parent.insertAfter(this, t), t
                    }, t.cloneBefore = function(e) {
                        void 0 === e && (e = {});
                        var t = this.clone(e);
                        return this.parent.insertBefore(this, t), t
                    }, t.error = function(e, t) {
                        if (void 0 === t && (t = {}), this.source) {
                            var r = this.rangeBy(t),
                                n = r.end,
                                i = r.start;
                            return this.source.input.error(e, {
                                column: i.column,
                                line: i.line
                            }, {
                                column: n.column,
                                line: n.line
                            }, t)
                        }
                        return new tL(e)
                    }, t.getProxyProcessor = function() {
                        return {
                            get: function(e, t) {
                                return "proxyOf" === t ? e : "root" === t ? function() {
                                    return e.root().toProxy()
                                } : e[t]
                            },
                            set: function(e, t, r) {
                                return e[t] === r || (e[t] = r, ("prop" === t || "value" === t || "name" === t || "params" === t || "important" === t || "text" === t) && e.markDirty(), !0)
                            }
                        }
                    }, t.markDirty = function() {
                        if (this[tq]) {
                            this[tq] = !1;
                            for (var e = this; e = e.parent;) e[tq] = !1
                        }
                    }, t.next = function() {
                        if (this.parent) {
                            var e = this.parent.index(this);
                            return this.parent.nodes[e + 1]
                        }
                    }, t.positionBy = function(e, t) {
                        var r = this.source.start;
                        if (e.index) r = this.positionInside(e.index, t);
                        else if (e.word) {
                            var n = (t = this.toString()).indexOf(e.word); - 1 !== n && (r = this.positionInside(n, t))
                        }
                        return r
                    }, t.positionInside = function(e, t) {
                        for (var r = t || this.toString(), n = this.source.start.column, i = this.source.start.line, o = 0; o < e; o++) "\n" === r[o] ? (n = 1, i += 1) : n += 1;
                        return {
                            column: n,
                            line: i
                        }
                    }, t.prev = function() {
                        if (this.parent) {
                            var e = this.parent.index(this);
                            return this.parent.nodes[e - 1]
                        }
                    }, t.rangeBy = function(e) {
                        var t = {
                                column: this.source.start.column,
                                line: this.source.start.line
                            },
                            r = this.source.end ? {
                                column: this.source.end.column + 1,
                                line: this.source.end.line
                            } : {
                                column: t.column + 1,
                                line: t.line
                            };
                        if (e.word) {
                            var n = this.toString(),
                                i = n.indexOf(e.word); - 1 !== i && (t = this.positionInside(i, n), r = this.positionInside(i + e.word.length, n))
                        } else e.start ? t = {
                            column: e.start.column,
                            line: e.start.line
                        } : e.index && (t = this.positionInside(e.index)), e.end ? r = {
                            column: e.end.column,
                            line: e.end.line
                        } : "number" == typeof e.endIndex ? r = this.positionInside(e.endIndex) : e.index && (r = this.positionInside(e.index + 1));
                        return (r.line < t.line || r.line === t.line && r.column <= t.column) && (r = {
                            column: t.column + 1,
                            line: t.line
                        }), {
                            end: r,
                            start: t
                        }
                    }, t.raw = function(e, t) {
                        return new tB().raw(this, e, t)
                    }, t.remove = function() {
                        return this.parent && this.parent.removeChild(this), this.parent = void 0, this
                    }, t.replaceWith = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        if (this.parent) {
                            for (var n, i = this, o = !1, s = S(t); !(n = s()).done;) {
                                var a = n.value;
                                a === this ? o = !0 : o ? (this.parent.insertAfter(i, a), i = a) : this.parent.insertBefore(i, a)
                            }
                            o || this.remove()
                        }
                        return this
                    }, t.root = function() {
                        for (var e = this; e.parent && "document" !== e.parent.type;) e = e.parent;
                        return e
                    }, t.toJSON = function(e, t) {
                        var r = {},
                            n = null == t;
                        t = t || new Map;
                        var i = 0;
                        for (var o in this)
                            if (Object.prototype.hasOwnProperty.call(this, o) && "parent" !== o && "proxyCache" !== o) {
                                var s = this[o];
                                if (Array.isArray(s)) r[o] = s.map(function(e) {
                                    return (void 0 === e ? "undefined" : b(e)) === "object" && e.toJSON ? e.toJSON(null, t) : e
                                });
                                else if ((void 0 === s ? "undefined" : b(s)) === "object" && s.toJSON) r[o] = s.toJSON(null, t);
                                else if ("source" === o) {
                                    var a = t.get(s.input);
                                    null == a && (a = i, t.set(s.input, i), i++), r[o] = {
                                        end: s.end,
                                        inputId: a,
                                        start: s.start
                                    }
                                } else r[o] = s
                            }
                        return n && (r.inputs = [].concat(t.keys()).map(function(e) {
                            return e.toJSON()
                        })), r
                    }, t.toProxy = function() {
                        return this.proxyCache || (this.proxyCache = new Proxy(this, this.getProxyProcessor())), this.proxyCache
                    }, t.toString = function(e) {
                        void 0 === e && (e = tj), e.stringify && (e = e.stringify);
                        var t = "";
                        return e(this, function(e) {
                            t += e
                        }), t
                    }, t.warn = function(e, t, r) {
                        var n = {
                            node: this
                        };
                        for (var i in r) n[i] = r[i];
                        return e.warn(t, n)
                    }, f(e, [{
                        key: "proxyOf",
                        get: function() {
                            return this
                        }
                    }]), e
                }();
            tW.default = tW;
            var tV = function(e) {
                function t(t) {
                    var r;
                    return t && void 0 !== t.value && "string" != typeof t.value && (t = d({}, t, {
                        value: String(t.value)
                    })), (r = e.call(this, t) || this).type = "decl", r
                }
                return g(t, e), f(t, [{
                    key: "variable",
                    get: function() {
                        return this.prop.startsWith("--") || "$" === this.prop[0]
                    }
                }]), t
            }(tW);
            tV.default = tV;
            var t$ = tD.SourceMapConsumer,
                tG = tD.SourceMapGenerator,
                tY = tD.existsSync,
                tZ = tD.readFileSync,
                tJ = tD.dirname,
                tH = tD.join,
                tX = function() {
                    function e(e, t) {
                        if (!1 !== t.map) {
                            this.loadAnnotation(e), this.inline = this.startWith(this.annotation, "data:");
                            var r = t.map ? t.map.prev : void 0,
                                n = this.loadMap(t.from, r);
                            !this.mapFile && t.from && (this.mapFile = t.from), this.mapFile && (this.root = tJ(this.mapFile)), n && (this.text = n)
                        }
                    }
                    var t = e.prototype;
                    return t.consumer = function() {
                        return this.consumerCache || (this.consumerCache = new t$(this.text)), this.consumerCache
                    }, t.decodeInline = function(e) {
                        if (/^data:application\/json;charset=utf-?8,/.test(e) || /^data:application\/json,/.test(e)) return decodeURIComponent(e.substr(RegExp.lastMatch.length));
                        if (/^data:application\/json;charset=utf-?8;base64,/.test(e) || /^data:application\/json;base64,/.test(e)) {
                            var t;
                            return t = e.substr(RegExp.lastMatch.length), s ? s.from(t, "base64").toString() : window.atob(t)
                        }
                        throw Error("Unsupported source map encoding " + e.match(/data:application\/json;([^,]+),/)[1])
                    }, t.getAnnotationURL = function(e) {
                        return e.replace(/^\/\*\s*# sourceMappingURL=/, "").trim()
                    }, t.isMap = function(e) {
                        return (void 0 === e ? "undefined" : b(e)) === "object" && ("string" == typeof e.mappings || "string" == typeof e._mappings || Array.isArray(e.sections))
                    }, t.loadAnnotation = function(e) {
                        var t = e.match(/\/\*\s*# sourceMappingURL=/gm);
                        if (t) {
                            var r = e.lastIndexOf(t.pop()),
                                n = e.indexOf("*/", r);
                            r > -1 && n > -1 && (this.annotation = this.getAnnotationURL(e.substring(r, n)))
                        }
                    }, t.loadFile = function(e) {
                        if (this.root = tJ(e), tY(e)) return this.mapFile = e, tZ(e, "utf-8").toString().trim()
                    }, t.loadMap = function(e, t) {
                        if (!1 === t) return !1;
                        if (t)
                            if ("string" == typeof t) return t;
                            else if ("function" == typeof t) {
                            var r = t(e);
                            if (r) {
                                var n = this.loadFile(r);
                                if (!n) throw Error("Unable to load previous source map: " + r.toString());
                                return n
                            }
                        } else if (v(t, t$)) return tG.fromSourceMap(t).toString();
                        else if (v(t, tG)) return t.toString();
                        else if (this.isMap(t)) return JSON.stringify(t);
                        else throw Error("Unsupported previous source map format: " + t.toString());
                        else if (this.inline) return this.decodeInline(this.annotation);
                        else if (this.annotation) {
                            var i = this.annotation;
                            return e && (i = tH(tJ(e), i)), this.loadFile(i)
                        }
                    }, t.startWith = function(e, t) {
                        return !!e && e.substr(0, t.length) === t
                    }, t.withContent = function() {
                        return !!(this.consumer().sourcesContent && this.consumer().sourcesContent.length > 0)
                    }, e
                }();
            tX.default = tX;
            var tK = tD.SourceMapConsumer,
                tQ = tD.SourceMapGenerator,
                t0 = tD.fileURLToPath,
                t1 = tD.pathToFileURL,
                t2 = tD.isAbsolute,
                t3 = tD.resolve,
                t9 = function(e) {
                    void 0 === e && (e = 21);
                    for (var t = "", r = e; r--;) t += "useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict" [64 * Math.random() | 0];
                    return t
                },
                t4 = Symbol("fromOffsetCache"),
                t5 = !!(tK && tQ),
                t6 = !!(t3 && t2),
                t8 = function() {
                    function e(e, t) {
                        if (void 0 === t && (t = {}), null == e || (void 0 === e ? "undefined" : b(e)) === "object" && !e.toString) throw Error("PostCSS received " + e + " instead of CSS string");
                        if (this.css = e.toString(), "\uFEFF" === this.css[0] || "￾" === this.css[0] ? (this.hasBOM = !0, this.css = this.css.slice(1)) : this.hasBOM = !1, t.from && (!t6 || /^\w+:\/\//.test(t.from) || t2(t.from) ? this.file = t.from : this.file = t3(t.from)), t6 && t5) {
                            var r = new tX(this.css, t);
                            if (r.text) {
                                this.map = r;
                                var n = r.consumer().file;
                                !this.file && n && (this.file = this.mapResolve(n))
                            }
                        }
                        this.file || (this.id = "<input css " + t9(6) + ">"), this.map && (this.map.file = this.from)
                    }
                    var t = e.prototype;
                    return t.error = function(e, t, r, n) {
                        if (void 0 === n && (n = {}), t && (void 0 === t ? "undefined" : b(t)) === "object") {
                            var i, o, s, a = t,
                                c = r;
                            if ("number" == typeof a.offset) {
                                var u = this.fromOffset(a.offset);
                                t = u.line, r = u.col
                            } else t = a.line, r = a.column;
                            if ("number" == typeof c.offset) {
                                var l = this.fromOffset(c.offset);
                                o = l.line, s = l.col
                            } else o = c.line, s = c.column
                        } else if (!r) {
                            var p = this.fromOffset(t);
                            t = p.line, r = p.col
                        }
                        var h = this.origin(t, r, o, s);
                        return (i = h ? new tL(e, void 0 === h.endLine ? h.line : {
                            column: h.column,
                            line: h.line
                        }, void 0 === h.endLine ? h.column : {
                            column: h.endColumn,
                            line: h.endLine
                        }, h.source, h.file, n.plugin) : new tL(e, void 0 === o ? t : {
                            column: r,
                            line: t
                        }, void 0 === o ? r : {
                            column: s,
                            line: o
                        }, this.css, this.file, n.plugin)).input = {
                            column: r,
                            endColumn: s,
                            endLine: o,
                            line: t,
                            source: this.css
                        }, this.file && (t1 && (i.input.url = t1(this.file).toString()), i.input.file = this.file), i
                    }, t.fromOffset = function(e) {
                        if (this[t4]) a = this[t4];
                        else {
                            var t = this.css.split("\n");
                            a = Array(t.length);
                            for (var r = 0, n = 0, i = t.length; n < i; n++) a[n] = r, r += t[n].length + 1;
                            this[t4] = a
                        }
                        s = a[a.length - 1];
                        var o = 0;
                        if (e >= s) o = a.length - 1;
                        else
                            for (var s, a, c, u = a.length - 2; o < u;)
                                if (e < a[c = o + (u - o >> 1)]) u = c - 1;
                                else if (e >= a[c + 1]) o = c + 1;
                        else {
                            o = c;
                            break
                        }
                        return {
                            col: e - a[o] + 1,
                            line: o + 1
                        }
                    }, t.mapResolve = function(e) {
                        return /^\w+:\/\//.test(e) ? e : t3(this.map.consumer().sourceRoot || this.map.root || ".", e)
                    }, t.origin = function(e, t, r, n) {
                        if (!this.map) return !1;
                        var i, o, s = this.map.consumer(),
                            a = s.originalPositionFor({
                                column: t,
                                line: e
                            });
                        if (!a.source) return !1;
                        "number" == typeof r && (i = s.originalPositionFor({
                            column: n,
                            line: r
                        })), o = t2(a.source) ? t1(a.source) : new URL(a.source, this.map.consumer().sourceRoot || t1(this.map.mapFile));
                        var c = {
                            column: a.column,
                            endColumn: i && i.column,
                            endLine: i && i.line,
                            line: a.line,
                            url: o.toString()
                        };
                        if ("file:" === o.protocol)
                            if (t0) c.file = t0(o);
                            else throw Error("file: protocol is not available in this PostCSS build");
                        var u = s.sourceContentFor(a.source);
                        return u && (c.source = u), c
                    }, t.toJSON = function() {
                        for (var e = {}, t = 0, r = ["hasBOM", "css", "file", "id"]; t < r.length; t++) {
                            var n = r[t];
                            null != this[n] && (e[n] = this[n])
                        }
                        return this.map && (e.map = d({}, this.map), e.map.consumerCache && (e.map.consumerCache = void 0)), e
                    }, f(e, [{
                        key: "from",
                        get: function() {
                            return this.file || this.id
                        }
                    }]), e
                }();
            t8.default = t8, tD && tD.registerInput && tD.registerInput(t8);
            var t7 = tD.SourceMapConsumer,
                re = tD.SourceMapGenerator,
                rt = tD.dirname,
                rr = tD.relative,
                rn = tD.resolve,
                ri = tD.sep,
                ro = tD.pathToFileURL,
                rs = !!(t7 && re),
                ra = !!(rt && rn && rr && ri),
                rc = function() {
                    function e(e, t, r, n) {
                        this.stringify = e, this.mapOpts = r.map || {}, this.root = t, this.opts = r, this.css = n, this.originalCSS = n, this.usesFileUrls = !this.mapOpts.from && this.mapOpts.absolute, this.memoizedFileURLs = new Map, this.memoizedPaths = new Map, this.memoizedURLs = new Map
                    }
                    var t = e.prototype;
                    return t.addAnnotation = function() {
                        var e = this.isInline() ? "data:application/json;base64," + this.toBase64(this.map.toString()) : "string" == typeof this.mapOpts.annotation ? this.mapOpts.annotation : "function" == typeof this.mapOpts.annotation ? this.mapOpts.annotation(this.opts.to, this.root) : this.outputFile() + ".map",
                            t = "\n";
                        this.css.includes("\r\n") && (t = "\r\n"), this.css += t + "/*# sourceMappingURL=" + e + " */"
                    }, t.applyPrevMaps = function() {
                        for (var e, t = S(this.previous()); !(e = t()).done;) {
                            var r = e.value,
                                n = this.toUrl(this.path(r.file)),
                                i = r.root || rt(r.file),
                                o = void 0;
                            !1 === this.mapOpts.sourcesContent ? (o = new t7(r.text)).sourcesContent && (o.sourcesContent = null) : o = r.consumer(), this.map.applySourceMap(o, n, this.toUrl(this.path(i)))
                        }
                    }, t.clearAnnotation = function() {
                        if (!1 !== this.mapOpts.annotation)
                            if (this.root)
                                for (var e, t = this.root.nodes.length - 1; t >= 0; t--) "comment" === (e = this.root.nodes[t]).type && 0 === e.text.indexOf("# sourceMappingURL=") && this.root.removeChild(t);
                            else this.css && (this.css = this.css.replace(/\n*?\/\*#[\S\s]*?\*\/$/gm, ""))
                    }, t.generate = function() {
                        if (this.clearAnnotation(), ra && rs && this.isMap()) return this.generateMap();
                        var e = "";
                        return this.stringify(this.root, function(t) {
                            e += t
                        }), [e]
                    }, t.generateMap = function() {
                        if (this.root) this.generateString();
                        else if (1 === this.previous().length) {
                            var e = this.previous()[0].consumer();
                            e.file = this.outputFile(), this.map = re.fromSourceMap(e, {
                                ignoreInvalidMapping: !0
                            })
                        } else this.map = new re({
                            file: this.outputFile(),
                            ignoreInvalidMapping: !0
                        }), this.map.addMapping({
                            generated: {
                                column: 0,
                                line: 1
                            },
                            original: {
                                column: 0,
                                line: 1
                            },
                            source: this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>"
                        });
                        return (this.isSourcesContent() && this.setSourcesContent(), this.root && this.previous().length > 0 && this.applyPrevMaps(), this.isAnnotation() && this.addAnnotation(), this.isInline()) ? [this.css] : [this.css, this.map]
                    }, t.generateString = function() {
                        var e, t, r = this;
                        this.css = "", this.map = new re({
                            file: this.outputFile(),
                            ignoreInvalidMapping: !0
                        });
                        var n = 1,
                            i = 1,
                            o = "<no source>",
                            s = {
                                generated: {
                                    column: 0,
                                    line: 0
                                },
                                original: {
                                    column: 0,
                                    line: 0
                                },
                                source: ""
                            };
                        this.stringify(this.root, function(a, c, u) {
                            if (r.css += a, c && "end" !== u && (s.generated.line = n, s.generated.column = i - 1, c.source && c.source.start ? (s.source = r.sourcePath(c), s.original.line = c.source.start.line, s.original.column = c.source.start.column - 1) : (s.source = o, s.original.line = 1, s.original.column = 0), r.map.addMapping(s)), (e = a.match(/\n/g)) ? (n += e.length, t = a.lastIndexOf("\n"), i = a.length - t) : i += a.length, c && "start" !== u) {
                                var l = c.parent || {
                                    raws: {}
                                };
                                (!("decl" === c.type || "atrule" === c.type && !c.nodes) || c !== l.last || l.raws.semicolon) && (c.source && c.source.end ? (s.source = r.sourcePath(c), s.original.line = c.source.end.line, s.original.column = c.source.end.column - 1, s.generated.line = n, s.generated.column = i - 2) : (s.source = o, s.original.line = 1, s.original.column = 0, s.generated.line = n, s.generated.column = i - 1), r.map.addMapping(s))
                            }
                        })
                    }, t.isAnnotation = function() {
                        return !!this.isInline() || (void 0 !== this.mapOpts.annotation ? this.mapOpts.annotation : !this.previous().length || this.previous().some(function(e) {
                            return e.annotation
                        }))
                    }, t.isInline = function() {
                        if (void 0 !== this.mapOpts.inline) return this.mapOpts.inline;
                        var e = this.mapOpts.annotation;
                        return (void 0 === e || !0 === e) && (!this.previous().length || this.previous().some(function(e) {
                            return e.inline
                        }))
                    }, t.isMap = function() {
                        return void 0 !== this.opts.map ? !!this.opts.map : this.previous().length > 0
                    }, t.isSourcesContent = function() {
                        return void 0 !== this.mapOpts.sourcesContent ? this.mapOpts.sourcesContent : !this.previous().length || this.previous().some(function(e) {
                            return e.withContent()
                        })
                    }, t.outputFile = function() {
                        return this.opts.to ? this.path(this.opts.to) : this.opts.from ? this.path(this.opts.from) : "to.css"
                    }, t.path = function(e) {
                        if (this.mapOpts.absolute || 60 === e.charCodeAt(0) || /^\w+:\/\//.test(e)) return e;
                        var t = this.memoizedPaths.get(e);
                        if (t) return t;
                        var r = this.opts.to ? rt(this.opts.to) : ".";
                        "string" == typeof this.mapOpts.annotation && (r = rt(rn(r, this.mapOpts.annotation)));
                        var n = rr(r, e);
                        return this.memoizedPaths.set(e, n), n
                    }, t.previous = function() {
                        var e = this;
                        if (!this.previousMaps)
                            if (this.previousMaps = [], this.root) this.root.walk(function(t) {
                                if (t.source && t.source.input.map) {
                                    var r = t.source.input.map;
                                    e.previousMaps.includes(r) || e.previousMaps.push(r)
                                }
                            });
                            else {
                                var t = new t8(this.originalCSS, this.opts);
                                t.map && this.previousMaps.push(t.map)
                            }
                        return this.previousMaps
                    }, t.setSourcesContent = function() {
                        var e = this,
                            t = {};
                        if (this.root) this.root.walk(function(r) {
                            if (r.source) {
                                var n = r.source.input.from;
                                if (n && !t[n]) {
                                    t[n] = !0;
                                    var i = e.usesFileUrls ? e.toFileUrl(n) : e.toUrl(e.path(n));
                                    e.map.setSourceContent(i, r.source.input.css)
                                }
                            }
                        });
                        else if (this.css) {
                            var r = this.opts.from ? this.toUrl(this.path(this.opts.from)) : "<no source>";
                            this.map.setSourceContent(r, this.css)
                        }
                    }, t.sourcePath = function(e) {
                        return this.mapOpts.from ? this.toUrl(this.mapOpts.from) : this.usesFileUrls ? this.toFileUrl(e.source.input.from) : this.toUrl(this.path(e.source.input.from))
                    }, t.toBase64 = function(e) {
                        return s ? s.from(e).toString("base64") : window.btoa(unescape(encodeURIComponent(e)))
                    }, t.toFileUrl = function(e) {
                        var t = this.memoizedFileURLs.get(e);
                        if (t) return t;
                        if (ro) {
                            var r = ro(e).toString();
                            return this.memoizedFileURLs.set(e, r), r
                        }
                        throw Error("`map.absolute` option is not available in this PostCSS build")
                    }, t.toUrl = function(e) {
                        var t = this.memoizedURLs.get(e);
                        if (t) return t;
                        "\\" === ri && (e = e.replace(/\\/g, "/"));
                        var r = encodeURI(e).replace(/[#?]/g, encodeURIComponent);
                        return this.memoizedURLs.set(e, r), r
                    }, e
                }(),
                ru = function(e) {
                    function t(t) {
                        var r;
                        return (r = e.call(this, t) || this).type = "comment", r
                    }
                    return g(t, e), t
                }(tW);
            ru.default = ru;
            var rl = tF.isClean,
                rp = tF.my,
                rh = function(e) {
                    function t() {
                        return e.apply(this, arguments) || this
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.append = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        for (var n, i = S(t); !(n = i()).done;)
                            for (var o, s = n.value, a = this.normalize(s, this.last), c = S(a); !(o = c()).done;) {
                                var u = o.value;
                                this.proxyOf.nodes.push(u)
                            }
                        return this.markDirty(), this
                    }, r.cleanRaws = function(t) {
                        if (e.prototype.cleanRaws.call(this, t), this.nodes)
                            for (var r, n = S(this.nodes); !(r = n()).done;) r.value.cleanRaws(t)
                    }, r.each = function(e) {
                        if (this.proxyOf.nodes) {
                            for (var t, r, n = this.getIterator(); this.indexes[n] < this.proxyOf.nodes.length && (t = this.indexes[n], !1 !== (r = e(this.proxyOf.nodes[t], t)));) this.indexes[n] += 1;
                            return delete this.indexes[n], r
                        }
                    }, r.every = function(e) {
                        return this.nodes.every(e)
                    }, r.getIterator = function() {
                        this.lastEach || (this.lastEach = 0), this.indexes || (this.indexes = {}), this.lastEach += 1;
                        var e = this.lastEach;
                        return this.indexes[e] = 0, e
                    }, r.getProxyProcessor = function() {
                        return {
                            get: function(e, t) {
                                if ("proxyOf" === t) return e;
                                if (!e[t]) return e[t];
                                if ("each" === t || "string" == typeof t && t.startsWith("walk")) return function() {
                                    for (var r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                                    return e[t].apply(e, [].concat(n.map(function(e) {
                                        return "function" == typeof e ? function(t, r) {
                                            return e(t.toProxy(), r)
                                        } : e
                                    })))
                                };
                                if ("every" === t || "some" === t) return function(r) {
                                    return e[t](function(e) {
                                        for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
                                        return r.apply(void 0, [].concat([e.toProxy()], n))
                                    })
                                };
                                if ("root" === t) return function() {
                                    return e.root().toProxy()
                                };
                                else if ("nodes" === t) return e.nodes.map(function(e) {
                                    return e.toProxy()
                                });
                                else if ("first" === t || "last" === t) return e[t].toProxy();
                                else return e[t]
                            },
                            set: function(e, t, r) {
                                return e[t] === r || (e[t] = r, ("name" === t || "params" === t || "selector" === t) && e.markDirty(), !0)
                            }
                        }
                    }, r.index = function(e) {
                        return "number" == typeof e ? e : (e.proxyOf && (e = e.proxyOf), this.proxyOf.nodes.indexOf(e))
                    }, r.insertAfter = function(e, t) {
                        var r, n = this.index(e),
                            i = this.normalize(t, this.proxyOf.nodes[n]).reverse();
                        n = this.index(e);
                        for (var o, s = S(i); !(o = s()).done;) {
                            var a = o.value;
                            this.proxyOf.nodes.splice(n + 1, 0, a)
                        }
                        for (var c in this.indexes) n < (r = this.indexes[c]) && (this.indexes[c] = r + i.length);
                        return this.markDirty(), this
                    }, r.insertBefore = function(e, t) {
                        var r, n = this.index(e),
                            i = 0 === n && "prepend",
                            o = this.normalize(t, this.proxyOf.nodes[n], i).reverse();
                        n = this.index(e);
                        for (var s, a = S(o); !(s = a()).done;) {
                            var c = s.value;
                            this.proxyOf.nodes.splice(n, 0, c)
                        }
                        for (var u in this.indexes) n <= (r = this.indexes[u]) && (this.indexes[u] = r + o.length);
                        return this.markDirty(), this
                    }, r.normalize = function(e, r) {
                        var n = this;
                        if ("string" == typeof e) e = function e(t) {
                            return t.map(function(t) {
                                return t.nodes && (t.nodes = e(t.nodes)), delete t.source, t
                            })
                        }(ic(e).nodes);
                        else if (void 0 === e) e = [];
                        else if (Array.isArray(e)) {
                            e = e.slice(0);
                            for (var i, o = S(e); !(i = o()).done;) {
                                var s = i.value;
                                s.parent && s.parent.removeChild(s, "ignore")
                            }
                        } else if ("root" === e.type && "document" !== this.type) {
                            e = e.nodes.slice(0);
                            for (var a, c = S(e); !(a = c()).done;) {
                                var u = a.value;
                                u.parent && u.parent.removeChild(u, "ignore")
                            }
                        } else if (e.type) e = [e];
                        else if (e.prop) {
                            if (void 0 === e.value) throw Error("Value field is missed in node creation");
                            "string" != typeof e.value && (e.value = String(e.value)), e = [new tV(e)]
                        } else if (e.selector) e = [new iu(e)];
                        else if (e.name) e = [new il(e)];
                        else if (e.text) e = [new ru(e)];
                        else throw Error("Unknown node type in node creation");
                        return e.map(function(e) {
                            return e[rp] || t.rebuild(e), (e = e.proxyOf).parent && e.parent.removeChild(e), e[rl] && function e(t) {
                                if (t[rl] = !1, t.proxyOf.nodes)
                                    for (var r, n = S(t.proxyOf.nodes); !(r = n()).done;) e(r.value)
                            }(e), void 0 === e.raws.before && r && void 0 !== r.raws.before && (e.raws.before = r.raws.before.replace(/\S/g, "")), e.parent = n.proxyOf, e
                        })
                    }, r.prepend = function() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        t = t.reverse();
                        for (var n, i = S(t); !(n = i()).done;) {
                            for (var o, s = n.value, a = this.normalize(s, this.first, "prepend").reverse(), c = S(a); !(o = c()).done;) {
                                var u = o.value;
                                this.proxyOf.nodes.unshift(u)
                            }
                            for (var l in this.indexes) this.indexes[l] = this.indexes[l] + a.length
                        }
                        return this.markDirty(), this
                    }, r.push = function(e) {
                        return e.parent = this, this.proxyOf.nodes.push(e), this
                    }, r.removeAll = function() {
                        for (var e, t = S(this.proxyOf.nodes); !(e = t()).done;) e.value.parent = void 0;
                        return this.proxyOf.nodes = [], this.markDirty(), this
                    }, r.removeChild = function(e) {
                        var t;
                        for (var r in e = this.index(e), this.proxyOf.nodes[e].parent = void 0, this.proxyOf.nodes.splice(e, 1), this.indexes)(t = this.indexes[r]) >= e && (this.indexes[r] = t - 1);
                        return this.markDirty(), this
                    }, r.replaceValues = function(e, t, r) {
                        return r || (r = t, t = {}), this.walkDecls(function(n) {
                            (!t.props || t.props.includes(n.prop)) && (!t.fast || n.value.includes(t.fast)) && (n.value = n.value.replace(e, r))
                        }), this.markDirty(), this
                    }, r.some = function(e) {
                        return this.nodes.some(e)
                    }, r.walk = function(e) {
                        return this.each(function(t, r) {
                            var n;
                            try {
                                n = e(t, r)
                            } catch (e) {
                                throw t.addToError(e)
                            }
                            return !1 !== n && t.walk && (n = t.walk(e)), n
                        })
                    }, r.walkAtRules = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("atrule" === r.type && e.test(r.name)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("atrule" === r.type && r.name === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("atrule" === e.type) return t(e, r)
                        }))
                    }, r.walkComments = function(e) {
                        return this.walk(function(t, r) {
                            if ("comment" === t.type) return e(t, r)
                        })
                    }, r.walkDecls = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("decl" === r.type && e.test(r.prop)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("decl" === r.type && r.prop === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("decl" === e.type) return t(e, r)
                        }))
                    }, r.walkRules = function(e, t) {
                        return t ? v(e, RegExp) ? this.walk(function(r, n) {
                            if ("rule" === r.type && e.test(r.selector)) return t(r, n)
                        }) : this.walk(function(r, n) {
                            if ("rule" === r.type && r.selector === e) return t(r, n)
                        }) : (t = e, this.walk(function(e, r) {
                            if ("rule" === e.type) return t(e, r)
                        }))
                    }, f(t, [{
                        key: "first",
                        get: function() {
                            if (this.proxyOf.nodes) return this.proxyOf.nodes[0]
                        }
                    }, {
                        key: "last",
                        get: function() {
                            if (this.proxyOf.nodes) return this.proxyOf.nodes[this.proxyOf.nodes.length - 1]
                        }
                    }]), t
                }(tW);
            rh.registerParse = function(e) {
                ic = e
            }, rh.registerRule = function(e) {
                iu = e
            }, rh.registerAtRule = function(e) {
                il = e
            }, rh.registerRoot = function(e) {
                ip = e
            }, rh.default = rh, rh.rebuild = function(e) {
                "atrule" === e.type ? Object.setPrototypeOf(e, il.prototype) : "rule" === e.type ? Object.setPrototypeOf(e, iu.prototype) : "decl" === e.type ? Object.setPrototypeOf(e, tV.prototype) : "comment" === e.type ? Object.setPrototypeOf(e, ru.prototype) : "root" === e.type && Object.setPrototypeOf(e, ip.prototype), e[rp] = !0, e.nodes && e.nodes.forEach(function(e) {
                    rh.rebuild(e)
                })
            };
            var rf = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, d({
                        type: "document"
                    }, t)) || this).nodes || (r.nodes = []), r
                }
                return g(t, e), t.prototype.toResult = function(e) {
                    return void 0 === e && (e = {}), new ih(new id, this, e).stringify()
                }, t
            }(rh);
            rf.registerLazyResult = function(e) {
                ih = e
            }, rf.registerProcessor = function(e) {
                id = e
            }, rf.default = rf;
            var rd = function() {
                function e(e, t) {
                    if (void 0 === t && (t = {}), this.type = "warning", this.text = e, t.node && t.node.source) {
                        var r = t.node.rangeBy(t);
                        this.line = r.start.line, this.column = r.start.column, this.endLine = r.end.line, this.endColumn = r.end.column
                    }
                    for (var n in t) this[n] = t[n]
                }
                return e.prototype.toString = function() {
                    return this.node ? this.node.error(this.text, {
                        index: this.index,
                        plugin: this.plugin,
                        word: this.word
                    }).message : this.plugin ? this.plugin + ": " + this.text : this.text
                }, e
            }();
            rd.default = rd;
            var rm = function() {
                function e(e, t, r) {
                    this.processor = e, this.messages = [], this.root = t, this.opts = r, this.css = void 0, this.map = void 0
                }
                var t = e.prototype;
                return t.toString = function() {
                    return this.css
                }, t.warn = function(e, t) {
                    void 0 === t && (t = {}), !t.plugin && this.lastPlugin && this.lastPlugin.postcssPlugin && (t.plugin = this.lastPlugin.postcssPlugin);
                    var r = new rd(e, t);
                    return this.messages.push(r), r
                }, t.warnings = function() {
                    return this.messages.filter(function(e) {
                        return "warning" === e.type
                    })
                }, f(e, [{
                    key: "content",
                    get: function() {
                        return this.css
                    }
                }]), e
            }();
            rm.default = rm;
            var rg = /[\t\n\f\r "#'()/;[\\\]{}]/g,
                rv = /[\t\n\f\r !"#'():;@[\\\]{}]|\/(?=\*)/g,
                ry = /.[\r\n"'(/\\]/,
                r_ = /[\da-f]/i,
                rb = function(e) {
                    function t(t) {
                        var r;
                        return (r = e.call(this, t) || this).type = "atrule", r
                    }
                    g(t, e);
                    var r = t.prototype;
                    return r.append = function() {
                        for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                        return this.proxyOf.nodes || (this.nodes = []), (t = e.prototype.append).call.apply(t, [].concat([this], n))
                    }, r.prepend = function() {
                        for (var t, r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
                        return this.proxyOf.nodes || (this.nodes = []), (t = e.prototype.prepend).call.apply(t, [].concat([this], n))
                    }, t
                }(rh);
            rb.default = rb, rh.registerAtRule(rb);
            var rw = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, t) || this).type = "root", r.nodes || (r.nodes = []), r
                }
                g(t, e);
                var r = t.prototype;
                return r.normalize = function(t, r, n) {
                    var i = e.prototype.normalize.call(this, t);
                    if (r) {
                        if ("prepend" === n) this.nodes.length > 1 ? r.raws.before = this.nodes[1].raws.before : delete r.raws.before;
                        else if (this.first !== r)
                            for (var o, s = S(i); !(o = s()).done;) o.value.raws.before = r.raws.before
                    }
                    return i
                }, r.removeChild = function(t, r) {
                    var n = this.index(t);
                    return !r && 0 === n && this.nodes.length > 1 && (this.nodes[1].raws.before = this.nodes[n].raws.before), e.prototype.removeChild.call(this, t)
                }, r.toResult = function(e) {
                    return void 0 === e && (e = {}), new im(new ig, this, e).stringify()
                }, t
            }(rh);
            rw.registerLazyResult = function(e) {
                im = e
            }, rw.registerProcessor = function(e) {
                ig = e
            }, rw.default = rw, rh.registerRoot(rw);
            var rk = {
                comma: function(e) {
                    return rk.split(e, [","], !0)
                },
                space: function(e) {
                    return rk.split(e, [" ", "\n", "	"])
                },
                split: function(e, t, r) {
                    for (var n, i = [], o = "", s = !1, a = 0, c = !1, u = "", l = !1, p = S(e); !(n = p()).done;) {
                        var h = n.value;
                        l ? l = !1 : "\\" === h ? l = !0 : c ? h === u && (c = !1) : '"' === h || "'" === h ? (c = !0, u = h) : "(" === h ? a += 1 : ")" === h ? a > 0 && (a -= 1) : 0 === a && t.includes(h) && (s = !0), s ? ("" !== o && i.push(o.trim()), o = "", s = !1) : o += h
                    }
                    return (r || "" !== o) && i.push(o.trim()), i
                }
            };
            rk.default = rk;
            var rS = function(e) {
                function t(t) {
                    var r;
                    return (r = e.call(this, t) || this).type = "rule", r.nodes || (r.nodes = []), r
                }
                return g(t, e), f(t, [{
                    key: "selectors",
                    get: function() {
                        return rk.comma(this.selector)
                    },
                    set: function(e) {
                        var t = this.selector ? this.selector.match(/,\s*/) : null,
                            r = t ? t[0] : "," + this.raw("between", "beforeOpen");
                        this.selector = e.join(r)
                    }
                }]), t
            }(rh);
            rS.default = rS, rh.registerRule(rS);
            var rC = function(e, t) {
                    void 0 === t && (t = {});
                    var r, n, i, o, s, a, c, u, l, p, h = e.css.valueOf(),
                        f = t.ignoreErrors,
                        d = h.length,
                        m = 0,
                        g = [],
                        v = [];

                    function y(t) {
                        throw e.error("Unclosed " + t, m)
                    }
                    return {
                        back: function(e) {
                            v.push(e)
                        },
                        endOfFile: function() {
                            return 0 === v.length && m >= d
                        },
                        nextToken: function(e) {
                            if (v.length) return v.pop();
                            if (!(m >= d)) {
                                var t = !!e && e.ignoreUnclosed;
                                switch (r = h.charCodeAt(m)) {
                                    case 10:
                                    case 32:
                                    case 9:
                                    case 13:
                                    case 12:
                                        n = m;
                                        do n += 1, r = h.charCodeAt(n); while (32 === r || 10 === r || 9 === r || 13 === r || 12 === r);
                                        p = ["space", h.slice(m, n)], m = n - 1;
                                        break;
                                    case 91:
                                    case 93:
                                    case 123:
                                    case 125:
                                    case 58:
                                    case 59:
                                    case 41:
                                        var _ = String.fromCharCode(r);
                                        p = [_, _, m];
                                        break;
                                    case 40:
                                        if (u = g.length ? g.pop()[1] : "", l = h.charCodeAt(m + 1), "url" === u && 39 !== l && 34 !== l && 32 !== l && 10 !== l && 9 !== l && 12 !== l && 13 !== l) {
                                            n = m;
                                            do {
                                                if (a = !1, -1 === (n = h.indexOf(")", n + 1)))
                                                    if (f || t) {
                                                        n = m;
                                                        break
                                                    } else y("bracket");
                                                for (c = n; 92 === h.charCodeAt(c - 1);) c -= 1, a = !a
                                            } while (a);
                                            p = ["brackets", h.slice(m, n + 1), m, n], m = n
                                        } else n = h.indexOf(")", m + 1), o = h.slice(m, n + 1), -1 === n || ry.test(o) ? p = ["(", "(", m] : (p = ["brackets", o, m, n], m = n);
                                        break;
                                    case 39:
                                    case 34:
                                        i = 39 === r ? "'" : '"', n = m;
                                        do {
                                            if (a = !1, -1 === (n = h.indexOf(i, n + 1)))
                                                if (f || t) {
                                                    n = m + 1;
                                                    break
                                                } else y("string");
                                            for (c = n; 92 === h.charCodeAt(c - 1);) c -= 1, a = !a
                                        } while (a);
                                        p = ["string", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    case 64:
                                        rg.lastIndex = m + 1, rg.test(h), n = 0 === rg.lastIndex ? h.length - 1 : rg.lastIndex - 2, p = ["at-word", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    case 92:
                                        for (n = m, s = !0; 92 === h.charCodeAt(n + 1);) n += 1, s = !s;
                                        if (r = h.charCodeAt(n + 1), s && 47 !== r && 32 !== r && 10 !== r && 9 !== r && 13 !== r && 12 !== r && (n += 1, r_.test(h.charAt(n)))) {
                                            for (; r_.test(h.charAt(n + 1));) n += 1;
                                            32 === h.charCodeAt(n + 1) && (n += 1)
                                        }
                                        p = ["word", h.slice(m, n + 1), m, n], m = n;
                                        break;
                                    default:
                                        47 === r && 42 === h.charCodeAt(m + 1) ? (0 === (n = h.indexOf("*/", m + 2) + 1) && (f || t ? n = h.length : y("comment")), p = ["comment", h.slice(m, n + 1), m, n]) : (rv.lastIndex = m + 1, rv.test(h), n = 0 === rv.lastIndex ? h.length - 1 : rv.lastIndex - 2, p = ["word", h.slice(m, n + 1), m, n], g.push(p)), m = n
                                }
                                return m++, p
                            }
                        },
                        position: function() {
                            return m
                        }
                    }
                },
                rI = {
                    empty: !0,
                    space: !0
                },
                rx = function() {
                    function e(e) {
                        this.input = e, this.root = new rw, this.current = this.root, this.spaces = "", this.semicolon = !1, this.createTokenizer(), this.root.source = {
                            input: e,
                            start: {
                                column: 1,
                                line: 1,
                                offset: 0
                            }
                        }
                    }
                    var t = e.prototype;
                    return t.atrule = function(e) {
                        var t, r, n, i = new rb;
                        i.name = e[1].slice(1), "" === i.name && this.unnamedAtrule(i, e), this.init(i, e[2]);
                        for (var o = !1, s = !1, a = [], c = []; !this.tokenizer.endOfFile();) {
                            if ("(" === (t = (e = this.tokenizer.nextToken())[0]) || "[" === t ? c.push("(" === t ? ")" : "]") : "{" === t && c.length > 0 ? c.push("}") : t === c[c.length - 1] && c.pop(), 0 === c.length)
                                if (";" === t) {
                                    i.source.end = this.getPosition(e[2]), i.source.end.offset++, this.semicolon = !0;
                                    break
                                } else if ("{" === t) {
                                s = !0;
                                break
                            } else if ("}" === t) {
                                if (a.length > 0) {
                                    for (n = a.length - 1, r = a[n]; r && "space" === r[0];) r = a[--n];
                                    r && (i.source.end = this.getPosition(r[3] || r[2]), i.source.end.offset++)
                                }
                                this.end(e);
                                break
                            } else a.push(e);
                            else a.push(e);
                            if (this.tokenizer.endOfFile()) {
                                o = !0;
                                break
                            }
                        }
                        i.raws.between = this.spacesAndCommentsFromEnd(a), a.length ? (i.raws.afterName = this.spacesAndCommentsFromStart(a), this.raw(i, "params", a), o && (e = a[a.length - 1], i.source.end = this.getPosition(e[3] || e[2]), i.source.end.offset++, this.spaces = i.raws.between, i.raws.between = "")) : (i.raws.afterName = "", i.params = ""), s && (i.nodes = [], this.current = i)
                    }, t.checkMissedSemicolon = function(e) {
                        var t, r = this.colon(e);
                        if (!1 !== r) {
                            for (var n = 0, i = r - 1; i >= 0 && ("space" === (t = e[i])[0] || 2 !== (n += 1)); i--);
                            throw this.input.error("Missed semicolon", "word" === t[0] ? t[3] + 1 : t[2])
                        }
                    }, t.colon = function(e) {
                        for (var t, r, n, i = 0, o = S(e.entries()); !(n = o()).done;) {
                            var s = n.value,
                                a = s[0],
                                c = s[1];
                            if ("(" === (t = c[0]) && (i += 1), ")" === t && (i -= 1), 0 === i && ":" === t)
                                if (r)
                                    if ("word" === r[0] && "progid" === r[1]) continue;
                                    else return a;
                            else this.doubleColon(c);
                            r = c
                        }
                        return !1
                    }, t.comment = function(e) {
                        var t = new ru;
                        this.init(t, e[2]), t.source.end = this.getPosition(e[3] || e[2]), t.source.end.offset++;
                        var r = e[1].slice(2, -2);
                        if (/^\s*$/.test(r)) t.text = "", t.raws.left = r, t.raws.right = "";
                        else {
                            var n = r.match(/^(\s*)([^]*\S)(\s*)$/);
                            t.text = n[2], t.raws.left = n[1], t.raws.right = n[3]
                        }
                    }, t.createTokenizer = function() {
                        this.tokenizer = rC(this.input)
                    }, t.decl = function(e, t) {
                        var r, n, i = new tV;
                        this.init(i, e[0][2]);
                        var o = e[e.length - 1];
                        for (";" === o[0] && (this.semicolon = !0, e.pop()), i.source.end = this.getPosition(o[3] || o[2] || function(e) {
                                for (var t = e.length - 1; t >= 0; t--) {
                                    var r = e[t],
                                        n = r[3] || r[2];
                                    if (n) return n
                                }
                            }(e)), i.source.end.offset++;
                            "word" !== e[0][0];) 1 === e.length && this.unknownWord(e), i.raws.before += e.shift()[1];
                        for (i.source.start = this.getPosition(e[0][2]), i.prop = ""; e.length;) {
                            var s = e[0][0];
                            if (":" === s || "space" === s || "comment" === s) break;
                            i.prop += e.shift()[1]
                        }
                        for (i.raws.between = ""; e.length;) {
                            if (":" === (r = e.shift())[0]) {
                                i.raws.between += r[1];
                                break
                            }
                            "word" === r[0] && /\w/.test(r[1]) && this.unknownWord([r]), i.raws.between += r[1]
                        }("_" === i.prop[0] || "*" === i.prop[0]) && (i.raws.before += i.prop[0], i.prop = i.prop.slice(1));
                        for (var a = []; e.length && ("space" === (n = e[0][0]) || "comment" === n);) a.push(e.shift());
                        this.precheckMissedSemicolon(e);
                        for (var c = e.length - 1; c >= 0; c--) {
                            if ("!important" === (r = e[c])[1].toLowerCase()) {
                                i.important = !0;
                                var u = this.stringFrom(e, c);
                                " !important" !== (u = this.spacesFromEnd(e) + u) && (i.raws.important = u);
                                break
                            }
                            if ("important" === r[1].toLowerCase()) {
                                for (var l = e.slice(0), p = "", h = c; h > 0; h--) {
                                    var f = l[h][0];
                                    if (0 === p.trim().indexOf("!") && "space" !== f) break;
                                    p = l.pop()[1] + p
                                }
                                0 === p.trim().indexOf("!") && (i.important = !0, i.raws.important = p, e = l)
                            }
                            if ("space" !== r[0] && "comment" !== r[0]) break
                        }
                        e.some(function(e) {
                            return "space" !== e[0] && "comment" !== e[0]
                        }) && (i.raws.between += a.map(function(e) {
                            return e[1]
                        }).join(""), a = []), this.raw(i, "value", a.concat(e), t), i.value.includes(":") && !t && this.checkMissedSemicolon(e)
                    }, t.doubleColon = function(e) {
                        throw this.input.error("Double colon", {
                            offset: e[2]
                        }, {
                            offset: e[2] + e[1].length
                        })
                    }, t.emptyRule = function(e) {
                        var t = new rS;
                        this.init(t, e[2]), t.selector = "", t.raws.between = "", this.current = t
                    }, t.end = function(e) {
                        this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.semicolon = !1, this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.spaces = "", this.current.parent ? (this.current.source.end = this.getPosition(e[2]), this.current.source.end.offset++, this.current = this.current.parent) : this.unexpectedClose(e)
                    }, t.endFile = function() {
                        this.current.parent && this.unclosedBlock(), this.current.nodes && this.current.nodes.length && (this.current.raws.semicolon = this.semicolon), this.current.raws.after = (this.current.raws.after || "") + this.spaces, this.root.source.end = this.getPosition(this.tokenizer.position())
                    }, t.freeSemicolon = function(e) {
                        if (this.spaces += e[1], this.current.nodes) {
                            var t = this.current.nodes[this.current.nodes.length - 1];
                            t && "rule" === t.type && !t.raws.ownSemicolon && (t.raws.ownSemicolon = this.spaces, this.spaces = "")
                        }
                    }, t.getPosition = function(e) {
                        var t = this.input.fromOffset(e);
                        return {
                            column: t.col,
                            line: t.line,
                            offset: e
                        }
                    }, t.init = function(e, t) {
                        this.current.push(e), e.source = {
                            input: this.input,
                            start: this.getPosition(t)
                        }, e.raws.before = this.spaces, this.spaces = "", "comment" !== e.type && (this.semicolon = !1)
                    }, t.other = function(e) {
                        for (var t = !1, r = null, n = !1, i = null, o = [], s = e[1].startsWith("--"), a = [], c = e; c;) {
                            if (r = c[0], a.push(c), "(" === r || "[" === r) i || (i = c), o.push("(" === r ? ")" : "]");
                            else if (s && n && "{" === r) i || (i = c), o.push("}");
                            else if (0 === o.length)
                                if (";" === r)
                                    if (n) return void this.decl(a, s);
                                    else break;
                            else if ("{" === r) return void this.rule(a);
                            else if ("}" === r) {
                                this.tokenizer.back(a.pop()), t = !0;
                                break
                            } else ":" === r && (n = !0);
                            else r === o[o.length - 1] && (o.pop(), 0 === o.length && (i = null));
                            c = this.tokenizer.nextToken()
                        }
                        if (this.tokenizer.endOfFile() && (t = !0), o.length > 0 && this.unclosedBracket(i), t && n) {
                            if (!s)
                                for (; a.length && ("space" === (c = a[a.length - 1][0]) || "comment" === c);) this.tokenizer.back(a.pop());
                            this.decl(a, s)
                        } else this.unknownWord(a)
                    }, t.parse = function() {
                        for (var e; !this.tokenizer.endOfFile();) switch ((e = this.tokenizer.nextToken())[0]) {
                            case "space":
                                this.spaces += e[1];
                                break;
                            case ";":
                                this.freeSemicolon(e);
                                break;
                            case "}":
                                this.end(e);
                                break;
                            case "comment":
                                this.comment(e);
                                break;
                            case "at-word":
                                this.atrule(e);
                                break;
                            case "{":
                                this.emptyRule(e);
                                break;
                            default:
                                this.other(e)
                        }
                        this.endFile()
                    }, t.precheckMissedSemicolon = function() {}, t.raw = function(e, t, r, n) {
                        for (var i, o, s, a, c = r.length, u = "", l = !0, p = 0; p < c; p += 1) "space" !== (o = (i = r[p])[0]) || p !== c - 1 || n ? "comment" === o ? (a = r[p - 1] ? r[p - 1][0] : "empty", s = r[p + 1] ? r[p + 1][0] : "empty", rI[a] || rI[s] || "," === u.slice(-1) ? l = !1 : u += i[1]) : u += i[1] : l = !1;
                        if (!l) {
                            var h = r.reduce(function(e, t) {
                                return e + t[1]
                            }, "");
                            e.raws[t] = {
                                raw: h,
                                value: u
                            }
                        }
                        e[t] = u
                    }, t.rule = function(e) {
                        e.pop();
                        var t = new rS;
                        this.init(t, e[0][2]), t.raws.between = this.spacesAndCommentsFromEnd(e), this.raw(t, "selector", e), this.current = t
                    }, t.spacesAndCommentsFromEnd = function(e) {
                        for (var t, r = ""; e.length && ("space" === (t = e[e.length - 1][0]) || "comment" === t);) r = e.pop()[1] + r;
                        return r
                    }, t.spacesAndCommentsFromStart = function(e) {
                        for (var t, r = ""; e.length && ("space" === (t = e[0][0]) || "comment" === t);) r += e.shift()[1];
                        return r
                    }, t.spacesFromEnd = function(e) {
                        for (var t = ""; e.length && "space" === e[e.length - 1][0];) t = e.pop()[1] + t;
                        return t
                    }, t.stringFrom = function(e, t) {
                        for (var r = "", n = t; n < e.length; n++) r += e[n][1];
                        return e.splice(t, e.length - t), r
                    }, t.unclosedBlock = function() {
                        var e = this.current.source.start;
                        throw this.input.error("Unclosed block", e.line, e.column)
                    }, t.unclosedBracket = function(e) {
                        throw this.input.error("Unclosed bracket", {
                            offset: e[2]
                        }, {
                            offset: e[2] + 1
                        })
                    }, t.unexpectedClose = function(e) {
                        throw this.input.error("Unexpected }", {
                            offset: e[2]
                        }, {
                            offset: e[2] + 1
                        })
                    }, t.unknownWord = function(e) {
                        throw this.input.error("Unknown word", {
                            offset: e[0][2]
                        }, {
                            offset: e[0][2] + e[0][1].length
                        })
                    }, t.unnamedAtrule = function(e, t) {
                        throw this.input.error("At-rule without name", {
                            offset: t[2]
                        }, {
                            offset: t[2] + t[1].length
                        })
                    }, e
                }();

            function rO(e, t) {
                var r = new rx(new t8(e, t));
                try {
                    r.parse()
                } catch (e) {
                    throw e
                }
                return r.root
            }
            rO.default = rO, rh.registerParse(rO);
            var rE = tF.isClean,
                rM = tF.my,
                rR = {
                    atrule: "AtRule",
                    comment: "Comment",
                    decl: "Declaration",
                    document: "Document",
                    root: "Root",
                    rule: "Rule"
                },
                rA = {
                    AtRule: !0,
                    AtRuleExit: !0,
                    Comment: !0,
                    CommentExit: !0,
                    Declaration: !0,
                    DeclarationExit: !0,
                    Document: !0,
                    DocumentExit: !0,
                    Once: !0,
                    OnceExit: !0,
                    postcssPlugin: !0,
                    prepare: !0,
                    Root: !0,
                    RootExit: !0,
                    Rule: !0,
                    RuleExit: !0
                },
                rT = {
                    Once: !0,
                    postcssPlugin: !0,
                    prepare: !0
                };

            function rN(e) {
                return (void 0 === e ? "undefined" : b(e)) === "object" && "function" == typeof e.then
            }

            function rP(e) {
                var t = !1,
                    r = rR[e.type];
                return ("decl" === e.type ? t = e.prop.toLowerCase() : "atrule" === e.type && (t = e.name.toLowerCase()), t && e.append) ? [r, r + "-" + t, 0, r + "Exit", r + "Exit-" + t] : t ? [r, r + "-" + t, r + "Exit", r + "Exit-" + t] : e.append ? [r, 0, r + "Exit"] : [r, r + "Exit"]
            }

            function rD(e) {
                var t;
                return {
                    eventIndex: 0,
                    events: "document" === e.type ? ["Document", 0, "DocumentExit"] : "root" === e.type ? ["Root", 0, "RootExit"] : rP(e),
                    iterator: 0,
                    node: e,
                    visitorIndex: 0,
                    visitors: []
                }
            }

            function rL(e) {
                return e[rE] = !1, e.nodes && e.nodes.forEach(function(e) {
                    return rL(e)
                }), e
            }
            var rF = {},
                rU = function() {
                    function e(t, r, n) {
                        var i, o = this;
                        if (this.stringified = !1, this.processed = !1, (void 0 === r ? "undefined" : b(r)) === "object" && null !== r && ("root" === r.type || "document" === r.type)) i = rL(r);
                        else if (v(r, e) || v(r, rm)) i = rL(r.root), r.map && (void 0 === n.map && (n.map = {}), n.map.inline || (n.map.inline = !1), n.map.prev = r.map);
                        else {
                            var s = rO;
                            n.syntax && (s = n.syntax.parse), n.parser && (s = n.parser), s.parse && (s = s.parse);
                            try {
                                i = s(r, n)
                            } catch (e) {
                                this.processed = !0, this.error = e
                            }
                            i && !i[rM] && rh.rebuild(i)
                        }
                        this.result = new rm(t, i, n), this.helpers = d({}, rF, {
                            postcss: rF,
                            result: this.result
                        }), this.plugins = this.processor.plugins.map(function(e) {
                            return (void 0 === e ? "undefined" : b(e)) === "object" && e.prepare ? d({}, e, e.prepare(o.result)) : e
                        })
                    }
                    var t = e.prototype;
                    return t.async = function() {
                        return this.error ? Promise.reject(this.error) : this.processed ? Promise.resolve(this.result) : (this.processing || (this.processing = this.runAsync()), this.processing)
                    }, t.catch = function(e) {
                        return this.async().catch(e)
                    }, t.finally = function(e) {
                        return this.async().then(e, e)
                    }, t.getAsyncError = function() {
                        throw Error("Use process(css).then(cb) to work with async plugins")
                    }, t.handleError = function(e, t) {
                        var r = this.result.lastPlugin;
                        try {
                            t && t.addToError(e), this.error = e, "CssSyntaxError" !== e.name || e.plugin ? r.postcssVersion : (e.plugin = r.postcssPlugin, e.setMessage())
                        } catch (e) {
                            console && console.error && console.error(e)
                        }
                        return e
                    }, t.prepareVisitors = function() {
                        var e = this;
                        this.listeners = {};
                        for (var t, r = function(t, r, n) {
                                e.listeners[r] || (e.listeners[r] = []), e.listeners[r].push([t, n])
                            }, n = S(this.plugins); !(t = n()).done;) {
                            var i = t.value;
                            if ((void 0 === i ? "undefined" : b(i)) === "object")
                                for (var o in i) {
                                    if (!rA[o] && /^[A-Z]/.test(o)) throw Error("Unknown event " + o + " in " + i.postcssPlugin + ". Try to update PostCSS (" + this.processor.version + " now).");
                                    if (!rT[o])
                                        if ("object" === b(i[o]))
                                            for (var s in i[o]) r(i, "*" === s ? o : o + "-" + s.toLowerCase(), i[o][s]);
                                        else "function" == typeof i[o] && r(i, o, i[o])
                                }
                        }
                        this.hasListener = Object.keys(this.listeners).length > 0
                    }, t.runAsync = function() {
                        var e = this;
                        return p(function() {
                            var t, r, n, i, o, s, a, c, u, l, p, h;
                            return C(this, function(f) {
                                switch (f.label) {
                                    case 0:
                                        e.plugin = 0, t = 0, f.label = 1;
                                    case 1:
                                        if (!(t < e.plugins.length)) return [3, 6];
                                        if (r = e.plugins[t], !rN(n = e.runOnRoot(r))) return [3, 5];
                                        f.label = 2;
                                    case 2:
                                        return f.trys.push([2, 4, , 5]), [4, n];
                                    case 3:
                                        return f.sent(), [3, 5];
                                    case 4:
                                        throw i = f.sent(), e.handleError(i);
                                    case 5:
                                        return t++, [3, 1];
                                    case 6:
                                        if (e.prepareVisitors(), !e.hasListener) return [3, 18];
                                        o = e.result.root, f.label = 7;
                                    case 7:
                                        if (o[rE]) return [3, 14];
                                        o[rE] = !0, s = [rD(o)], f.label = 8;
                                    case 8:
                                        if (!(s.length > 0)) return [3, 13];
                                        if (!rN(a = e.visitTick(s))) return [3, 12];
                                        f.label = 9;
                                    case 9:
                                        return f.trys.push([9, 11, , 12]), [4, a];
                                    case 10:
                                        return f.sent(), [3, 12];
                                    case 11:
                                        throw c = f.sent(), u = s[s.length - 1].node, e.handleError(c, u);
                                    case 12:
                                        return [3, 8];
                                    case 13:
                                        return [3, 7];
                                    case 14:
                                        if (!e.listeners.OnceExit) return [3, 18];
                                        l = function() {
                                            var t, r, n, i;
                                            return C(this, function(s) {
                                                switch (s.label) {
                                                    case 0:
                                                        r = (t = h.value)[0], n = t[1], e.result.lastPlugin = r, s.label = 1;
                                                    case 1:
                                                        if (s.trys.push([1, 6, , 7]), "document" !== o.type) return [3, 3];
                                                        return [4, Promise.all(o.nodes.map(function(t) {
                                                            return n(t, e.helpers)
                                                        }))];
                                                    case 2:
                                                        return s.sent(), [3, 5];
                                                    case 3:
                                                        return [4, n(o, e.helpers)];
                                                    case 4:
                                                        s.sent(), s.label = 5;
                                                    case 5:
                                                        return [3, 7];
                                                    case 6:
                                                        throw i = s.sent(), e.handleError(i);
                                                    case 7:
                                                        return [2]
                                                }
                                            })
                                        }, p = S(e.listeners.OnceExit), f.label = 15;
                                    case 15:
                                        if ((h = p()).done) return [3, 18];
                                        return [5, I(l())];
                                    case 16:
                                        f.sent(), f.label = 17;
                                    case 17:
                                        return [3, 15];
                                    case 18:
                                        return e.processed = !0, [2, e.stringify()]
                                }
                            })
                        })()
                    }, t.runOnRoot = function(e) {
                        var t = this;
                        this.result.lastPlugin = e;
                        try {
                            if ((void 0 === e ? "undefined" : b(e)) === "object" && e.Once) {
                                if ("document" === this.result.root.type) {
                                    var r = this.result.root.nodes.map(function(r) {
                                        return e.Once(r, t.helpers)
                                    });
                                    if (rN(r[0])) return Promise.all(r);
                                    return r
                                }
                                return e.Once(this.result.root, this.helpers)
                            }
                            if ("function" == typeof e) return e(this.result.root, this.result)
                        } catch (e) {
                            throw this.handleError(e)
                        }
                    }, t.stringify = function() {
                        if (this.error) throw this.error;
                        if (this.stringified) return this.result;
                        this.stringified = !0, this.sync();
                        var e = this.result.opts,
                            t = tj;
                        e.syntax && (t = e.syntax.stringify), e.stringifier && (t = e.stringifier), t.stringify && (t = t.stringify);
                        var r = new rc(t, this.result.root, this.result.opts).generate();
                        return this.result.css = r[0], this.result.map = r[1], this.result
                    }, t.sync = function() {
                        if (this.error) throw this.error;
                        if (this.processed) return this.result;
                        if (this.processed = !0, this.processing) throw this.getAsyncError();
                        for (var e, t = S(this.plugins); !(e = t()).done;) {
                            var r = e.value;
                            if (rN(this.runOnRoot(r))) throw this.getAsyncError()
                        }
                        if (this.prepareVisitors(), this.hasListener) {
                            for (var n = this.result.root; !n[rE];) n[rE] = !0, this.walkSync(n);
                            if (this.listeners.OnceExit)
                                if ("document" === n.type)
                                    for (var i, o = S(n.nodes); !(i = o()).done;) {
                                        var s = i.value;
                                        this.visitSync(this.listeners.OnceExit, s)
                                    } else this.visitSync(this.listeners.OnceExit, n)
                        }
                        return this.result
                    }, t.then = function(e, t) {
                        return this.async().then(e, t)
                    }, t.toString = function() {
                        return this.css
                    }, t.visitSync = function(e, t) {
                        for (var r, n = S(e); !(r = n()).done;) {
                            var i = r.value,
                                o = i[0],
                                s = i[1];
                            this.result.lastPlugin = o;
                            var a = void 0;
                            try {
                                a = s(t, this.helpers)
                            } catch (e) {
                                throw this.handleError(e, t.proxyOf)
                            }
                            if ("root" !== t.type && "document" !== t.type && !t.parent) return !0;
                            if (rN(a)) throw this.getAsyncError()
                        }
                    }, t.visitTick = function(e) {
                        var t = e[e.length - 1],
                            r = t.node,
                            n = t.visitors;
                        if ("root" !== r.type && "document" !== r.type && !r.parent) return void e.pop();
                        if (n.length > 0 && t.visitorIndex < n.length) {
                            var i = n[t.visitorIndex],
                                o = i[0],
                                s = i[1];
                            t.visitorIndex += 1, t.visitorIndex === n.length && (t.visitors = [], t.visitorIndex = 0), this.result.lastPlugin = o;
                            try {
                                return s(r.toProxy(), this.helpers)
                            } catch (e) {
                                throw this.handleError(e, r)
                            }
                        }
                        if (0 !== t.iterator) {
                            for (var a, c = t.iterator; a = r.nodes[r.indexes[c]];)
                                if (r.indexes[c] += 1, !a[rE]) {
                                    a[rE] = !0, e.push(rD(a));
                                    return
                                }
                            t.iterator = 0, delete r.indexes[c]
                        }
                        for (var u = t.events; t.eventIndex < u.length;) {
                            var l = u[t.eventIndex];
                            if (t.eventIndex += 1, 0 === l) {
                                r.nodes && r.nodes.length && (r[rE] = !0, t.iterator = r.getIterator());
                                return
                            }
                            if (this.listeners[l]) {
                                t.visitors = this.listeners[l];
                                return
                            }
                        }
                        e.pop()
                    }, t.walkSync = function(e) {
                        var t = this;
                        e[rE] = !0;
                        for (var r, n = rP(e), i = S(n); !(r = i()).done;) {
                            var o = r.value;
                            if (0 === o) e.nodes && e.each(function(e) {
                                e[rE] || t.walkSync(e)
                            });
                            else {
                                var s = this.listeners[o];
                                if (s && this.visitSync(s, e.toProxy())) return
                            }
                        }
                    }, t.warnings = function() {
                        return this.sync().warnings()
                    }, f(e, [{
                        key: "content",
                        get: function() {
                            return this.stringify().content
                        }
                    }, {
                        key: "css",
                        get: function() {
                            return this.stringify().css
                        }
                    }, {
                        key: "map",
                        get: function() {
                            return this.stringify().map
                        }
                    }, {
                        key: "messages",
                        get: function() {
                            return this.sync().messages
                        }
                    }, {
                        key: "opts",
                        get: function() {
                            return this.result.opts
                        }
                    }, {
                        key: "processor",
                        get: function() {
                            return this.result.processor
                        }
                    }, {
                        key: "root",
                        get: function() {
                            return this.sync().root
                        }
                    }, {
                        key: Symbol.toStringTag,
                        get: function() {
                            return "LazyResult"
                        }
                    }]), e
                }();
            rU.registerPostcss = function(e) {
                rF = e
            }, rU.default = rU, rw.registerLazyResult(rU), rf.registerLazyResult(rU);
            var rB = function() {
                function e(e, t, r) {
                    t = t.toString(), this.stringified = !1, this._processor = e, this._css = t, this._opts = r, this._map = void 0, this.result = new rm(this._processor, n, this._opts), this.result.css = t;
                    var n, i = this;
                    Object.defineProperty(this.result, "root", {
                        get: function() {
                            return i.root
                        }
                    });
                    var o = new rc(tj, n, this._opts, t);
                    if (o.isMap()) {
                        var s = o.generate(),
                            a = s[0],
                            c = s[1];
                        a && (this.result.css = a), c && (this.result.map = c)
                    } else o.clearAnnotation(), this.result.css = o.css
                }
                var t = e.prototype;
                return t.async = function() {
                    return this.error ? Promise.reject(this.error) : Promise.resolve(this.result)
                }, t.catch = function(e) {
                    return this.async().catch(e)
                }, t.finally = function(e) {
                    return this.async().then(e, e)
                }, t.sync = function() {
                    if (this.error) throw this.error;
                    return this.result
                }, t.then = function(e, t) {
                    return this.async().then(e, t)
                }, t.toString = function() {
                    return this._css
                }, t.warnings = function() {
                    return []
                }, f(e, [{
                    key: "content",
                    get: function() {
                        return this.result.css
                    }
                }, {
                    key: "css",
                    get: function() {
                        return this.result.css
                    }
                }, {
                    key: "map",
                    get: function() {
                        return this.result.map
                    }
                }, {
                    key: "messages",
                    get: function() {
                        return []
                    }
                }, {
                    key: "opts",
                    get: function() {
                        return this.result.opts
                    }
                }, {
                    key: "processor",
                    get: function() {
                        return this.result.processor
                    }
                }, {
                    key: "root",
                    get: function() {
                        var e;
                        if (this._root) return this._root;
                        try {
                            e = rO(this._css, this._opts)
                        } catch (e) {
                            this.error = e
                        }
                        if (!this.error) return this._root = e, e;
                        throw this.error
                    }
                }, {
                    key: Symbol.toStringTag,
                    get: function() {
                        return "NoWorkResult"
                    }
                }]), e
            }();
            rB.default = rB;
            var rj = function() {
                function e(e) {
                    void 0 === e && (e = []), this.version = "8.4.38", this.plugins = this.normalize(e)
                }
                var t = e.prototype;
                return t.normalize = function(e) {
                    for (var t, r = [], n = S(e); !(t = n()).done;) {
                        var i = t.value;
                        if (!0 === i.postcss ? i = i() : i.postcss && (i = i.postcss), (void 0 === i ? "undefined" : b(i)) === "object" && Array.isArray(i.plugins)) r = r.concat(i.plugins);
                        else if ((void 0 === i ? "undefined" : b(i)) === "object" && i.postcssPlugin) r.push(i);
                        else if ("function" == typeof i) r.push(i);
                        else if ((void 0 === i ? "undefined" : b(i)) === "object" && (i.parse || i.stringify));
                        else throw Error(i + " is not a PostCSS plugin")
                    }
                    return r
                }, t.process = function(e, t) {
                    return (void 0 === t && (t = {}), this.plugins.length || t.parser || t.stringifier || t.syntax) ? new rU(this, e, t) : new rB(this, e, t)
                }, t.use = function(e) {
                    return this.plugins = this.plugins.concat(this.normalize([e])), this
                }, e
            }();

            function rq(e, t) {
                if (Array.isArray(e)) return e.map(function(e) {
                    return rq(e)
                });
                var r = e.inputs,
                    n = y(e, ["inputs"]);
                if (r) {
                    t = [];
                    for (var i, o = S(r); !(i = o()).done;) {
                        var s = i.value,
                            a = d({}, s, {
                                __proto__: t8.prototype
                            });
                        a.map && (a.map = d({}, a.map, {
                            __proto__: tX.prototype
                        })), t.push(a)
                    }
                }
                if (n.nodes && (n.nodes = e.nodes.map(function(e) {
                        return rq(e, t)
                    })), n.source) {
                    var c = n.source,
                        u = c.inputId;
                    n.source = y(c, ["inputId"]), null != u && (n.source.input = t[u])
                }
                if ("root" === n.type) return new rw(n);
                if ("decl" === n.type) return new tV(n);
                if ("rule" === n.type) return new rS(n);
                if ("comment" === n.type) return new ru(n);
                if ("atrule" === n.type) return new rb(n);
                else throw Error("Unknown node type: " + e.type)
            }

            function rz() {
                for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                return 1 === t.length && Array.isArray(t[0]) && (t = t[0]), new rj(t)
            }
            rj.default = rj, rw.registerProcessor(rj), rf.registerProcessor(rj), rq.default = rq, rz.plugin = function(e, t) {
                var r, n = !1;

                function i() {
                    for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                    console && console.warn && !n && (n = !0, console.warn(e + ": postcss.plugin was deprecated. Migration guide:\nhttps://evilmartians.com/chronicles/postcss-8-plugin-migration"), a.env.LANG && a.env.LANG.startsWith("cn") && console.warn(e + ": 里面 postcss.plugin 被弃用. 迁移指南:\nhttps://www.w3ctech.com/topic/2226"));
                    var s = t.apply(void 0, [].concat(i));
                    return s.postcssPlugin = e, s.postcssVersion = new rj().version, s
                }
                return Object.defineProperty(i, "postcss", {
                    get: function() {
                        return r || (r = i()), r
                    }
                }), i.process = function(e, t, r) {
                    return rz([i(r)]).process(e, t)
                }, i
            }, rz.stringify = tj, rz.parse = rO, rz.fromJSON = rq, rz.list = rk, rz.comment = function(e) {
                return new ru(e)
            }, rz.atRule = function(e) {
                return new rb(e)
            }, rz.decl = function(e) {
                return new tV(e)
            }, rz.rule = function(e) {
                return new rS(e)
            }, rz.root = function(e) {
                return new rw(e)
            }, rz.document = function(e) {
                return new rf(e)
            }, rz.CssSyntaxError = tL, rz.Declaration = tV, rz.Container = rh, rz.Processor = rj, rz.Document = rf, rz.Comment = ru, rz.Warning = rd, rz.AtRule = rb, rz.Result = rm, rz.Input = t8, rz.Rule = rS, rz.Root = rw, rz.Node = tW, rU.registerPostcss(rz), rz.default = rz;
            var rW = function(e) {
                return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
            }(rz);
            rW.stringify, rW.fromJSON, rW.plugin, rW.parse, rW.list, rW.document, rW.comment, rW.atRule, rW.rule, rW.decl, rW.root, rW.CssSyntaxError, rW.Declaration, rW.Container, rW.Processor, rW.Document, rW.Comment, rW.Warning, rW.AtRule, rW.Result, rW.Input, rW.Rule, rW.Root, rW.Node;
            var rV = function() {
                    function e() {
                        for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                        tR(this, "parentElement", null), tR(this, "parentNode", null), tR(this, "ownerDocument"), tR(this, "firstChild", null), tR(this, "lastChild", null), tR(this, "previousSibling", null), tR(this, "nextSibling", null), tR(this, "ELEMENT_NODE", 1), tR(this, "TEXT_NODE", 3), tR(this, "nodeType"), tR(this, "nodeName"), tR(this, "RRNodeType")
                    }
                    var t = e.prototype;
                    return t.contains = function(t) {
                        if (!v(t, e) || t.ownerDocument !== this.ownerDocument) return !1;
                        if (t === this) return !0;
                        for (; t.parentNode;) {
                            if (t.parentNode === this) return !0;
                            t = t.parentNode
                        }
                        return !1
                    }, t.appendChild = function(e) {
                        throw Error("RRDomException: Failed to execute 'appendChild' on 'RRNode': This RRNode type does not support this method.")
                    }, t.insertBefore = function(e, t) {
                        throw Error("RRDomException: Failed to execute 'insertBefore' on 'RRNode': This RRNode type does not support this method.")
                    }, t.removeChild = function(e) {
                        throw Error("RRDomException: Failed to execute 'removeChild' on 'RRNode': This RRNode type does not support this method.")
                    }, t.toString = function() {
                        return "RRNode"
                    }, f(e, [{
                        key: "childNodes",
                        get: function() {
                            for (var e = [], t = this.firstChild; t;) e.push(t), t = t.nextSibling;
                            return e
                        }
                    }]), e
                }(),
                r$ = {
                    Node: ["childNodes", "parentNode", "parentElement", "textContent"],
                    ShadowRoot: ["host", "styleSheets"],
                    Element: ["shadowRoot", "querySelector", "querySelectorAll"],
                    MutationObserver: []
                },
                rG = {
                    Node: ["contains", "getRootNode"],
                    ShadowRoot: ["getSelection"],
                    Element: [],
                    MutationObserver: ["constructor"]
                },
                rY = {};

            function rZ(e) {
                if (rY[e]) return rY[e];
                var t = globalThis[e],
                    r = t.prototype,
                    n = e in r$ ? r$[e] : void 0,
                    i = !!(n && n.every(function(e) {
                        var t, n;
                        return !!(null == (n = null == (t = Object.getOwnPropertyDescriptor(r, e)) ? void 0 : t.get) ? void 0 : n.toString().includes("[native code]"))
                    })),
                    o = e in rG ? rG[e] : void 0,
                    s = !!(o && o.every(function(e) {
                        var t;
                        return "function" == typeof r[e] && (null == (t = r[e]) ? void 0 : t.toString().includes("[native code]"))
                    }));
                if (i && s && !globalThis.Zone) return rY[e] = t.prototype, t.prototype;
                try {
                    var a = document.createElement("iframe");
                    document.body.appendChild(a);
                    var c = a.contentWindow;
                    if (!c) return t.prototype;
                    var u = c[e].prototype;
                    if (document.body.removeChild(a), !u) return r;
                    return rY[e] = u
                } catch (e) {
                    return r
                }
            }
            var rJ = {};

            function rH(e, t, r) {
                var n, i = e + "." + String(r);
                if (rJ[i]) return rJ[i].call(t);
                var o = null == (n = Object.getOwnPropertyDescriptor(rZ(e), r)) ? void 0 : n.get;
                return o ? (rJ[i] = o, o.call(t)) : t[r]
            }
            var rX = {};

            function rK(e, t, r) {
                var n = e + "." + String(r);
                if (rX[n]) return rX[n].bind(t);
                var i = rZ(e)[r];
                return "function" != typeof i ? t[r] : (rX[n] = i, i.bind(t))
            }
            var rQ = {
                childNodes: function(e) {
                    return rH("Node", e, "childNodes")
                },
                parentNode: function(e) {
                    return rH("Node", e, "parentNode")
                },
                parentElement: function(e) {
                    return rH("Node", e, "parentElement")
                },
                textContent: function(e) {
                    return rH("Node", e, "textContent")
                },
                contains: function(e, t) {
                    return rK("Node", e, "contains")(t)
                },
                getRootNode: function(e) {
                    return rK("Node", e, "getRootNode")()
                },
                host: function(e) {
                    return e && "host" in e ? rH("ShadowRoot", e, "host") : null
                },
                shadowRoot: function(e) {
                    return e && "shadowRoot" in e ? rH("Element", e, "shadowRoot") : null
                }
            };

            function r0(e, t, r) {
                void 0 === r && (r = document);
                var n = {
                    capture: !0,
                    passive: !0
                };
                return r.addEventListener(e, t, n),
                    function() {
                        return r.removeEventListener(e, t, n)
                    }
            }
            var r1 = "Please stop import mirror directly. Instead of that,\r\nnow you can use replayer.getMirror() to access the mirror instance of a replayer,\r\nor you can use record.mirror to access the mirror instance during recording.",
                r2 = {
                    map: {},
                    getId: function() {
                        return console.error(r1), -1
                    },
                    getNode: function() {
                        return console.error(r1), null
                    },
                    removeNodeFromMap: function() {
                        console.error(r1)
                    },
                    has: function() {
                        return console.error(r1), !1
                    },
                    reset: function() {
                        console.error(r1)
                    }
                };

            function r3(e, t, r) {
                void 0 === r && (r = {});
                var n = null,
                    i = 0;
                return function() {
                    for (var o = arguments.length, s = Array(o), a = 0; a < o; a++) s[a] = arguments[a];
                    var c = Date.now();
                    i || !1 !== r.leading || (i = c);
                    var u = t - (c - i),
                        l = this;
                    u <= 0 || u > t ? (n && (clearTimeout(n), n = null), i = c, e.apply(l, s)) : n || !1 === r.trailing || (n = setTimeout(function() {
                        i = !1 === r.leading ? 0 : Date.now(), n = null, e.apply(l, s)
                    }, u))
                }
            }

            function r9(e, t, r, n, i) {
                void 0 === i && (i = window);
                var o = i.Object.getOwnPropertyDescriptor(e, t);
                return i.Object.defineProperty(e, t, n ? r : {
                        set: function(e) {
                            var t = this;
                            setTimeout(function() {
                                r.set.call(t, e)
                            }, 0), o && o.set && o.set.call(this, e)
                        }
                    }),
                    function() {
                        return r9(e, t, o || {}, !0)
                    }
            }

            function r4(e, t, r) {
                try {
                    if (!(t in e)) return function() {};
                    var n = e[t],
                        i = r(n);
                    return "function" == typeof i && (i.prototype = i.prototype || {}, Object.defineProperties(i, {
                            __rrweb_original__: {
                                enumerable: !1,
                                value: n
                            }
                        })), e[t] = i,
                        function() {
                            e[t] = n
                        }
                } catch (e) {
                    return function() {}
                }
            }
            "undefined" != typeof window && window.Proxy && window.Reflect && (r2 = new Proxy(r2, {
                get: function(e, t, r) {
                    return "map" === t && console.error(r1), Reflect.get(e, t, r)
                }
            }));
            var r5 = Date.now;

            function r6(e) {
                var t, r, n, i, o = e.document;
                return {
                    left: o.scrollingElement ? o.scrollingElement.scrollLeft : void 0 !== e.pageXOffset ? e.pageXOffset : o.documentElement.scrollLeft || (null == o ? void 0 : o.body) && (null == (t = rQ.parentElement(o.body)) ? void 0 : t.scrollLeft) || (null == (r = null == o ? void 0 : o.body) ? void 0 : r.scrollLeft) || 0,
                    top: o.scrollingElement ? o.scrollingElement.scrollTop : void 0 !== e.pageYOffset ? e.pageYOffset : (null == o ? void 0 : o.documentElement.scrollTop) || (null == o ? void 0 : o.body) && (null == (n = rQ.parentElement(o.body)) ? void 0 : n.scrollTop) || (null == (i = null == o ? void 0 : o.body) ? void 0 : i.scrollTop) || 0
                }
            }

            function r8() {
                return window.innerHeight || document.documentElement && document.documentElement.clientHeight || document.body && document.body.clientHeight
            }

            function r7() {
                return window.innerWidth || document.documentElement && document.documentElement.clientWidth || document.body && document.body.clientWidth
            }

            function ne(e) {
                return e ? e.nodeType === e.ELEMENT_NODE ? e : rQ.parentElement(e) : null
            }

            function nt(e, t, r, n) {
                if (!e) return !1;
                var i = ne(e);
                if (!i) return !1;
                try {
                    if ("string" == typeof t) {
                        if (i.classList.contains(t) || n && null !== i.closest("." + t)) return !0
                    } else if (eh(i, t, n)) return !0
                } catch (e) {}
                return !!(r && (i.matches(r) || n && null !== i.closest(r))) || !1
            }

            function nr(e, t, r) {
                return "TITLE" === e.tagName && !!r.headTitleMutations || -2 === t.getId(e)
            }

            function nn(e) {
                return !!e.changedTouches
            }

            function ni(e, t) {
                return !!("IFRAME" === e.nodeName && t.getMeta(e))
            }

            function no(e, t) {
                return !!("LINK" === e.nodeName && e.nodeType === e.ELEMENT_NODE && e.getAttribute && "stylesheet" === e.getAttribute("rel") && t.getMeta(e))
            }

            function ns(e) {
                return !!e && (v(e, rV) && "shadowRoot" in e ? !!e.shadowRoot : !!rQ.shadowRoot(e))
            }
            /[1-9][0-9]{12}/.test(Date.now().toString()) || (r5 = function() {
                return new Date().getTime()
            });
            var na = function() {
                function e() {
                    O(this, "id", 1), O(this, "styleIDMap", new WeakMap), O(this, "idStyleMap", new Map)
                }
                var t = e.prototype;
                return t.getId = function(e) {
                    var t;
                    return null != (t = this.styleIDMap.get(e)) ? t : -1
                }, t.has = function(e) {
                    return this.styleIDMap.has(e)
                }, t.add = function(e, t) {
                    var r;
                    return this.has(e) ? this.getId(e) : (r = void 0 === t ? this.id++ : t, this.styleIDMap.set(e, r), this.idStyleMap.set(r, e), r)
                }, t.getStyle = function(e) {
                    return this.idStyleMap.get(e) || null
                }, t.reset = function() {
                    this.styleIDMap = new WeakMap, this.idStyleMap = new Map, this.id = 1
                }, t.generateId = function() {
                    return this.id++
                }, e
            }();

            function nc(e) {
                var t, r = null;
                return "getRootNode" in e && (null == (t = rQ.getRootNode(e)) ? void 0 : t.nodeType) === Node.DOCUMENT_FRAGMENT_NODE && rQ.host(rQ.getRootNode(e)) && (r = rQ.host(rQ.getRootNode(e))), r
            }

            function nu(e) {
                var t = e.ownerDocument;
                return !!t && (rQ.contains(t, e) || function(e) {
                    var t = e.ownerDocument;
                    if (!t) return !1;
                    var r = function(e) {
                        for (var t, r = e; t = nc(r);) r = t;
                        return r
                    }(e);
                    return rQ.contains(t, r)
                }(e))
            }
            var nl = function(e) {
                    return e[e.DomContentLoaded = 0] = "DomContentLoaded", e[e.Load = 1] = "Load", e[e.FullSnapshot = 2] = "FullSnapshot", e[e.IncrementalSnapshot = 3] = "IncrementalSnapshot", e[e.Meta = 4] = "Meta", e[e.Custom = 5] = "Custom", e[e.Plugin = 6] = "Plugin", e
                }(nl || {}),
                np = function(e) {
                    return e[e.Mutation = 0] = "Mutation", e[e.MouseMove = 1] = "MouseMove", e[e.MouseInteraction = 2] = "MouseInteraction", e[e.Scroll = 3] = "Scroll", e[e.ViewportResize = 4] = "ViewportResize", e[e.Input = 5] = "Input", e[e.TouchMove = 6] = "TouchMove", e[e.MediaInteraction = 7] = "MediaInteraction", e[e.StyleSheetRule = 8] = "StyleSheetRule", e[e.CanvasMutation = 9] = "CanvasMutation", e[e.Font = 10] = "Font", e[e.Log = 11] = "Log", e[e.Drag = 12] = "Drag", e[e.StyleDeclaration = 13] = "StyleDeclaration", e[e.Selection = 14] = "Selection", e[e.AdoptedStyleSheet = 15] = "AdoptedStyleSheet", e[e.CustomElement = 16] = "CustomElement", e
                }(np || {}),
                nh = function(e) {
                    return e[e.MouseUp = 0] = "MouseUp", e[e.MouseDown = 1] = "MouseDown", e[e.Click = 2] = "Click", e[e.ContextMenu = 3] = "ContextMenu", e[e.DblClick = 4] = "DblClick", e[e.Focus = 5] = "Focus", e[e.Blur = 6] = "Blur", e[e.TouchStart = 7] = "TouchStart", e[e.TouchMove_Departed = 8] = "TouchMove_Departed", e[e.TouchEnd = 9] = "TouchEnd", e[e.TouchCancel = 10] = "TouchCancel", e
                }(nh || {}),
                nf = function(e) {
                    return e[e.Mouse = 0] = "Mouse", e[e.Pen = 1] = "Pen", e[e.Touch = 2] = "Touch", e
                }(nf || {}),
                nd = function(e) {
                    return e[e["2D"] = 0] = "2D", e[e.WebGL = 1] = "WebGL", e[e.WebGL2 = 2] = "WebGL2", e
                }(nd || {}),
                nm = function(e) {
                    return e[e.Play = 0] = "Play", e[e.Pause = 1] = "Pause", e[e.Seeked = 2] = "Seeked", e[e.VolumeChange = 3] = "VolumeChange", e[e.RateChange = 4] = "RateChange", e
                }(nm || {}),
                ng = function(e) {
                    return e[e.Document = 0] = "Document", e[e.DocumentType = 1] = "DocumentType", e[e.Element = 2] = "Element", e[e.Text = 3] = "Text", e[e.CDATA = 4] = "CDATA", e[e.Comment = 5] = "Comment", e
                }(ng || {}),
                nv = function() {
                    function e() {
                        O(this, "length", 0), O(this, "head", null), O(this, "tail", null)
                    }
                    var t = e.prototype;
                    return t.get = function(e) {
                        if (e >= this.length) throw Error("Position outside of list range");
                        for (var t = this.head, r = 0; r < e; r++) t = (null == t ? void 0 : t.next) || null;
                        return t
                    }, t.addNode = function(e) {
                        var t = {
                            value: e,
                            previous: null,
                            next: null
                        };
                        if (e.__ln = t, e.previousSibling && "__ln" in e.previousSibling) {
                            var r = e.previousSibling.__ln.next;
                            t.next = r, t.previous = e.previousSibling.__ln, e.previousSibling.__ln.next = t, r && (r.previous = t)
                        } else if (e.nextSibling && "__ln" in e.nextSibling && e.nextSibling.__ln.previous) {
                            var n = e.nextSibling.__ln.previous;
                            t.previous = n, t.next = e.nextSibling.__ln, e.nextSibling.__ln.previous = t, n && (n.next = t)
                        } else this.head && (this.head.previous = t), t.next = this.head, this.head = t;
                        null === t.next && (this.tail = t), this.length++
                    }, t.removeNode = function(e) {
                        var t = e.__ln;
                        this.head && (t.previous ? (t.previous.next = t.next, t.next ? t.next.previous = t.previous : this.tail = t.previous) : (this.head = t.next, this.head ? this.head.previous = null : this.tail = null), e.__ln && delete e.__ln, this.length--)
                    }, e
                }(),
                ny = function(e, t) {
                    return e + "@" + t
                },
                n_ = function() {
                    function e() {
                        var e = this;
                        O(this, "frozen", !1), O(this, "locked", !1), O(this, "texts", []), O(this, "attributes", []), O(this, "attributeMap", new WeakMap), O(this, "removes", []), O(this, "mapRemoves", []), O(this, "movedMap", {}), O(this, "addedSet", new Set), O(this, "movedSet", new Set), O(this, "droppedSet", new Set), O(this, "removesSubTreeCache", new Set), O(this, "mutationCb"), O(this, "blockClass"), O(this, "blockSelector"), O(this, "maskTextClass"), O(this, "maskTextSelector"), O(this, "inlineStylesheet"), O(this, "maskInputOptions"), O(this, "maskTextFn"), O(this, "maskInputFn"), O(this, "keepIframeSrcFn"), O(this, "recordCanvas"), O(this, "inlineImages"), O(this, "slimDOMOptions"), O(this, "dataURLOptions"), O(this, "doc"), O(this, "mirror"), O(this, "iframeManager"), O(this, "stylesheetManager"), O(this, "shadowDomManager"), O(this, "canvasManager"), O(this, "processedNodeManager"), O(this, "unattachedDoc"), O(this, "processMutations", function(t) {
                            t.forEach(e.processMutation), e.emit()
                        }), O(this, "emit", function() {
                            if (!e.frozen && !e.locked) {
                                for (var t = [], r = new Set, n = new nv, i = function(t) {
                                        for (var r = t, n = -2; - 2 === n;) n = (r = r && r.nextSibling) && e.mirror.getId(r);
                                        return n
                                    }, o = function(o) {
                                        var s = rQ.parentNode(o);
                                        if (s && nu(o)) {
                                            var a = !1;
                                            if (o.nodeType === Node.TEXT_NODE) {
                                                var c = s.tagName;
                                                if ("TEXTAREA" === c) return;
                                                "STYLE" === c && e.addedSet.has(s) && (a = !0)
                                            }
                                            var u = j(s) ? e.mirror.getId(nc(o)) : e.mirror.getId(s),
                                                l = i(o);
                                            if (-1 === u || -1 === l) return n.addNode(o);
                                            var p = em(o, {
                                                doc: e.doc,
                                                mirror: e.mirror,
                                                blockClass: e.blockClass,
                                                blockSelector: e.blockSelector,
                                                maskTextClass: e.maskTextClass,
                                                maskTextSelector: e.maskTextSelector,
                                                skipChild: !0,
                                                newlyAddedElement: !0,
                                                inlineStylesheet: e.inlineStylesheet,
                                                maskInputOptions: e.maskInputOptions,
                                                maskTextFn: e.maskTextFn,
                                                maskInputFn: e.maskInputFn,
                                                slimDOMOptions: e.slimDOMOptions,
                                                dataURLOptions: e.dataURLOptions,
                                                recordCanvas: e.recordCanvas,
                                                inlineImages: e.inlineImages,
                                                onSerialize: function(t) {
                                                    ni(t, e.mirror) && e.iframeManager.addIframe(t), no(t, e.mirror) && e.stylesheetManager.trackLinkElement(t), ns(o) && e.shadowDomManager.addShadowRoot(rQ.shadowRoot(o), e.doc)
                                                },
                                                onIframeLoad: function(t, r) {
                                                    e.iframeManager.attachIframe(t, r), e.shadowDomManager.observeAttachShadow(t)
                                                },
                                                onStylesheetLoad: function(t, r) {
                                                    e.stylesheetManager.attachLinkElement(t, r)
                                                },
                                                cssCaptured: a
                                            });
                                            p && (t.push({
                                                parentId: u,
                                                nextId: l,
                                                node: p
                                            }), r.add(p.id))
                                        }
                                    }; e.mapRemoves.length;) e.mirror.removeNodeFromMap(e.mapRemoves.shift());
                                for (var s, a = S(e.movedSet); !(s = a()).done;) {
                                    var c = s.value;
                                    (!nw(e.removesSubTreeCache, c, e.mirror) || e.movedSet.has(rQ.parentNode(c))) && o(c)
                                }
                                for (var u, l = S(e.addedSet); !(u = l()).done;) {
                                    var p = u.value;
                                    nk(e.droppedSet, p) || nw(e.removesSubTreeCache, p, e.mirror) ? nk(e.movedSet, p) ? o(p) : e.droppedSet.add(p) : o(p)
                                }
                                for (var h = null; n.length;) {
                                    var f = null;
                                    if (h) {
                                        var d = e.mirror.getId(rQ.parentNode(h.value)),
                                            m = i(h.value); - 1 !== d && -1 !== m && (f = h)
                                    }
                                    if (!f)
                                        for (var g = n.tail; g;) {
                                            var v = g;
                                            if (g = g.previous, v) {
                                                var y = e.mirror.getId(rQ.parentNode(v.value));
                                                if (-1 === i(v.value)) continue;
                                                if (-1 !== y) {
                                                    f = v;
                                                    break
                                                }
                                                var _ = v.value,
                                                    b = rQ.parentNode(_);
                                                if (b && b.nodeType === Node.DOCUMENT_FRAGMENT_NODE) {
                                                    var w = rQ.host(b);
                                                    if (-1 !== e.mirror.getId(w)) {
                                                        f = v;
                                                        break
                                                    }
                                                }
                                            }
                                        }
                                    if (!f) {
                                        for (; n.head;) n.removeNode(n.head.value);
                                        break
                                    }
                                    h = f.previous, n.removeNode(f.value), o(f.value)
                                }
                                var k = {
                                    texts: e.texts.map(function(t) {
                                        var r = t.node,
                                            n = rQ.parentNode(r);
                                        return n && "TEXTAREA" === n.tagName && e.genTextAreaValueMutation(n), {
                                            id: e.mirror.getId(r),
                                            value: t.value
                                        }
                                    }).filter(function(e) {
                                        return !r.has(e.id)
                                    }).filter(function(t) {
                                        return e.mirror.has(t.id)
                                    }),
                                    attributes: e.attributes.map(function(t) {
                                        var r = t.attributes;
                                        if ("string" == typeof r.style) {
                                            var n = JSON.stringify(t.styleDiff),
                                                i = JSON.stringify(t._unchangedStyles);
                                            n.length < r.style.length && (n + i).split("var(").length === r.style.split("var(").length && (r.style = t.styleDiff)
                                        }
                                        return {
                                            id: e.mirror.getId(t.node),
                                            attributes: r
                                        }
                                    }).filter(function(e) {
                                        return !r.has(e.id)
                                    }).filter(function(t) {
                                        return e.mirror.has(t.id)
                                    }),
                                    removes: e.removes,
                                    adds: t
                                };
                                (k.texts.length || k.attributes.length || k.removes.length || k.adds.length) && (e.texts = [], e.attributes = [], e.attributeMap = new WeakMap, e.removes = [], e.addedSet = new Set, e.movedSet = new Set, e.droppedSet = new Set, e.removesSubTreeCache = new Set, e.movedMap = {}, e.mutationCb(k))
                            }
                        }), O(this, "genTextAreaValueMutation", function(t) {
                            var r = e.attributeMap.get(t);
                            r || (r = {
                                node: t,
                                attributes: {},
                                styleDiff: {},
                                _unchangedStyles: {}
                            }, e.attributes.push(r), e.attributeMap.set(t, r)), r.attributes.value = Array.from(rQ.childNodes(t), function(e) {
                                return rQ.textContent(e) || ""
                            }).join("")
                        }), O(this, "processMutation", function(t) {
                            if (!nr(t.target, e.mirror, e.slimDOMOptions)) switch (t.type) {
                                case "characterData":
                                    var r = rQ.textContent(t.target);
                                    nt(t.target, e.blockClass, e.blockSelector, !1) || r === t.oldValue || e.texts.push({
                                        value: ef(t.target, e.maskTextClass, e.maskTextSelector, !0) && r ? e.maskTextFn ? e.maskTextFn(r, ne(t.target)) : r.replace(/[\S]/g, "*") : r,
                                        node: t.target
                                    });
                                    break;
                                case "attributes":
                                    var n = t.target,
                                        i = t.attributeName,
                                        o = t.target.getAttribute(i);
                                    if ("value" === i) {
                                        var s = Z(n);
                                        o = $({
                                            element: n,
                                            maskInputOptions: e.maskInputOptions,
                                            tagName: n.tagName,
                                            type: s,
                                            value: o,
                                            maskInputFn: e.maskInputFn
                                        })
                                    }
                                    if (nt(t.target, e.blockClass, e.blockSelector, !1) || o === t.oldValue) return;
                                    var a = e.attributeMap.get(t.target);
                                    if ("IFRAME" === n.tagName && "src" === i && !e.keepIframeSrcFn(o))
                                        if (n.contentDocument) return;
                                        else i = "rr_src";
                                    if (a || (a = {
                                            node: t.target,
                                            attributes: {},
                                            styleDiff: {},
                                            _unchangedStyles: {}
                                        }, e.attributes.push(a), e.attributeMap.set(t.target, a)), "type" === i && "INPUT" === n.tagName && "password" === (t.oldValue || "").toLowerCase() && n.setAttribute("data-rr-is-password", "true"), !ep(n.tagName, i))
                                        if (a.attributes[i] = el(e.doc, G(n.tagName), G(i), o), "style" === i) {
                                            if (!e.unattachedDoc) try {
                                                e.unattachedDoc = document.implementation.createHTMLDocument()
                                            } catch (t) {
                                                e.unattachedDoc = e.doc
                                            }
                                            var c = e.unattachedDoc.createElement("span");
                                            t.oldValue && c.setAttribute("style", t.oldValue);
                                            for (var u, l = S(Array.from(n.style)); !(u = l()).done;) {
                                                var p = u.value,
                                                    h = n.style.getPropertyValue(p),
                                                    f = n.style.getPropertyPriority(p);
                                                h !== c.style.getPropertyValue(p) || f !== c.style.getPropertyPriority(p) ? "" === f ? a.styleDiff[p] = h : a.styleDiff[p] = [h, f] : a._unchangedStyles[p] = [h, f]
                                            }
                                            for (var d, m = S(Array.from(c.style)); !(d = m()).done;) {
                                                var g = d.value;
                                                "" === n.style.getPropertyValue(g) && (a.styleDiff[g] = !1)
                                            }
                                        } else "open" === i && "DIALOG" === n.tagName && (n.matches("dialog:modal") ? a.attributes.rr_open_mode = "modal" : a.attributes.rr_open_mode = "non-modal");
                                    break;
                                case "childList":
                                    if (nt(t.target, e.blockClass, e.blockSelector, !0)) return;
                                    if ("TEXTAREA" === t.target.tagName) return void e.genTextAreaValueMutation(t.target);
                                    t.addedNodes.forEach(function(r) {
                                        return e.genAdds(r, t.target)
                                    }), t.removedNodes.forEach(function(r) {
                                        var n = e.mirror.getId(r),
                                            i = j(t.target) ? e.mirror.getId(rQ.host(t.target)) : e.mirror.getId(t.target);
                                        nt(t.target, e.blockClass, e.blockSelector, !1) || nr(r, e.mirror, e.slimDOMOptions) || -1 === e.mirror.getId(r) || (e.addedSet.has(r) ? (nb(e.addedSet, r), e.droppedSet.add(r)) : e.addedSet.has(t.target) && -1 === n || function e(t, r) {
                                            if (j(t)) return !1;
                                            var n = r.getId(t);
                                            if (!r.has(n)) return !0;
                                            var i = rQ.parentNode(t);
                                            return (!i || i.nodeType !== t.DOCUMENT_NODE) && (!i || e(i, r))
                                        }(t.target, e.mirror) || (e.movedSet.has(r) && e.movedMap[ny(n, i)] ? nb(e.movedSet, r) : (e.removes.push({
                                            parentId: i,
                                            id: n,
                                            isShadow: !!(j(t.target) && q(t.target)) || void 0
                                        }), function(e, t) {
                                            for (var r = [e]; r.length;) {
                                                var n = r.pop();
                                                t.has(n) || (t.add(n), rQ.childNodes(n).forEach(function(e) {
                                                    return r.push(e)
                                                }))
                                            }
                                        }(r, e.removesSubTreeCache))), e.mapRemoves.push(r))
                                    })
                            }
                        }), O(this, "genAdds", function(t, r) {
                            if (!e.processedNodeManager.inOtherBuffer(t, e) && !(e.addedSet.has(t) || e.movedSet.has(t))) {
                                if (e.mirror.hasNode(t)) {
                                    if (nr(t, e.mirror, e.slimDOMOptions)) return;
                                    e.movedSet.add(t);
                                    var n = null;
                                    r && e.mirror.hasNode(r) && (n = e.mirror.getId(r)), n && -1 !== n && (e.movedMap[ny(e.mirror.getId(t), n)] = !0)
                                } else e.addedSet.add(t), e.droppedSet.delete(t);
                                !nt(t, e.blockClass, e.blockSelector, !1) && (rQ.childNodes(t).forEach(function(t) {
                                    return e.genAdds(t)
                                }), ns(t) && rQ.childNodes(rQ.shadowRoot(t)).forEach(function(r) {
                                    e.processedNodeManager.add(r, e), e.genAdds(r, t)
                                }))
                            }
                        })
                    }
                    var t = e.prototype;
                    return t.init = function(e) {
                        var t = this;
                        ["mutationCb", "blockClass", "blockSelector", "maskTextClass", "maskTextSelector", "inlineStylesheet", "maskInputOptions", "maskTextFn", "maskInputFn", "keepIframeSrcFn", "recordCanvas", "inlineImages", "slimDOMOptions", "dataURLOptions", "doc", "mirror", "iframeManager", "stylesheetManager", "shadowDomManager", "canvasManager", "processedNodeManager"].forEach(function(r) {
                            t[r] = e[r]
                        })
                    }, t.freeze = function() {
                        this.frozen = !0, this.canvasManager.freeze()
                    }, t.unfreeze = function() {
                        this.frozen = !1, this.canvasManager.unfreeze(), this.emit()
                    }, t.isFrozen = function() {
                        return this.frozen
                    }, t.lock = function() {
                        this.locked = !0, this.canvasManager.lock()
                    }, t.unlock = function() {
                        this.locked = !1, this.canvasManager.unlock(), this.emit()
                    }, t.reset = function() {
                        this.shadowDomManager.reset(), this.canvasManager.reset()
                    }, e
                }();

            function nb(e, t) {
                e.delete(t), rQ.childNodes(t).forEach(function(t) {
                    return nb(e, t)
                })
            }

            function nw(e, t, r) {
                var n, i, o, s;
                return 0 !== e.size && (n = e, i = t, !!(s = rQ.parentNode(i)) && n.has(s))
            }

            function nk(e, t) {
                return 0 !== e.size && function e(t, r) {
                    var n = rQ.parentNode(r);
                    return !!n && (!!t.has(n) || e(t, n))
                }(e, t)
            }
            var nS = function(e) {
                    return iv ? function() {
                        for (var t = arguments.length, r = Array(t), n = 0; n < t; n++) r[n] = arguments[n];
                        try {
                            return e.apply(void 0, [].concat(r))
                        } catch (e) {
                            if (iv && !0 === iv(e)) return;
                            throw e
                        }
                    } : e
                },
                nC = [];

            function nI(e) {
                try {
                    if ("composedPath" in e) {
                        var t = e.composedPath();
                        if (t.length) return t[0]
                    } else if ("path" in e && e.path.length) return e.path[0]
                } catch (e) {}
                return e && e.target
            }

            function nx(e, t) {
                var r = new n_;
                nC.push(r), r.init(e);
                var n = new(rZ("MutationObserver")).constructor(nS(r.processMutations.bind(r)));
                return n.observe(t, {
                    attributes: !0,
                    attributeOldValue: !0,
                    characterData: !0,
                    characterDataOldValue: !0,
                    childList: !0,
                    subtree: !0
                }), n
            }

            function nO(e) {
                var t = e.scrollCb,
                    r = e.doc,
                    n = e.mirror,
                    i = e.blockClass,
                    o = e.blockSelector,
                    s = e.sampling;
                return r0("scroll", nS(r3(nS(function(e) {
                    var s = nI(e);
                    if (!(!s || nt(s, i, o, !0))) {
                        var a = n.getId(s);
                        if (s === r && r.defaultView) {
                            var c = r6(r.defaultView);
                            t({
                                id: a,
                                x: c.left,
                                y: c.top
                            })
                        } else t({
                            id: a,
                            x: s.scrollLeft,
                            y: s.scrollTop
                        })
                    }
                }), s.scroll || 100)), r)
            }
            var nE = ["INPUT", "TEXTAREA", "SELECT"],
                nM = new WeakMap;

            function nR(e) {
                var t = [];
                if (nP("CSSGroupingRule") && v(e.parentRule, CSSGroupingRule) || nP("CSSMediaRule") && v(e.parentRule, CSSMediaRule) || nP("CSSSupportsRule") && v(e.parentRule, CSSSupportsRule) || nP("CSSConditionRule") && v(e.parentRule, CSSConditionRule)) {
                    var r = Array.from(e.parentRule.cssRules).indexOf(e);
                    t.unshift(r)
                } else if (e.parentStyleSheet) {
                    var n = Array.from(e.parentStyleSheet.cssRules).indexOf(e);
                    t.unshift(n)
                }
                return t
            }

            function nA(e, t, r) {
                var n, i;
                return e ? (e.ownerNode ? n = t.getId(e.ownerNode) : i = r.getId(e), {
                    styleId: i,
                    id: n
                }) : {}
            }

            function nT(e, t) {
                var r, n, i, o = e.mirror,
                    s = e.stylesheetManager,
                    a = null;
                a = "#document" === t.nodeName ? o.getId(t) : o.getId(rQ.host(t));
                var c = "#document" === t.nodeName ? null == (r = t.defaultView) ? void 0 : r.Document : null == (i = null == (n = t.ownerDocument) ? void 0 : n.defaultView) ? void 0 : i.ShadowRoot,
                    u = (null == c ? void 0 : c.prototype) ? Object.getOwnPropertyDescriptor(null == c ? void 0 : c.prototype, "adoptedStyleSheets") : void 0;
                return null !== a && -1 !== a && c && u ? (Object.defineProperty(t, "adoptedStyleSheets", {
                    configurable: u.configurable,
                    enumerable: u.enumerable,
                    get: function() {
                        var e;
                        return null == (e = u.get) ? void 0 : e.call(this)
                    },
                    set: function(e) {
                        var t, r = null == (t = u.set) ? void 0 : t.call(this, e);
                        if (null !== a && -1 !== a) try {
                            s.adoptStyleSheets(e, a)
                        } catch (e) {}
                        return r
                    }
                }), nS(function() {
                    Object.defineProperty(t, "adoptedStyleSheets", {
                        configurable: u.configurable,
                        enumerable: u.enumerable,
                        get: u.get,
                        set: u.set
                    })
                })) : function() {}
            }

            function nN(e, t) {
                void 0 === t && (t = {});
                var r = e.doc.defaultView;
                if (!r) return function() {};
                f = t, m = e.mutationCb, g = e.mousemoveCb, y = e.mouseInteractionCb, _ = e.scrollCb, b = e.viewportResizeCb, w = e.inputCb, k = e.mediaInteractionCb, C = e.styleSheetRuleCb, I = e.styleDeclarationCb, x = e.canvasMutationCb, O = e.fontCb, E = e.selectionCb, M = e.customElementCb, e.mutationCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.mutation && f.mutation.apply(f, [].concat(t)), m.apply(void 0, [].concat(t))
                }, e.mousemoveCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.mousemove && f.mousemove.apply(f, [].concat(t)), g.apply(void 0, [].concat(t))
                }, e.mouseInteractionCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.mouseInteraction && f.mouseInteraction.apply(f, [].concat(t)), y.apply(void 0, [].concat(t))
                }, e.scrollCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.scroll && f.scroll.apply(f, [].concat(t)), _.apply(void 0, [].concat(t))
                }, e.viewportResizeCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.viewportResize && f.viewportResize.apply(f, [].concat(t)), b.apply(void 0, [].concat(t))
                }, e.inputCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.input && f.input.apply(f, [].concat(t)), w.apply(void 0, [].concat(t))
                }, e.mediaInteractionCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.mediaInteaction && f.mediaInteaction.apply(f, [].concat(t)), k.apply(void 0, [].concat(t))
                }, e.styleSheetRuleCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.styleSheetRule && f.styleSheetRule.apply(f, [].concat(t)), C.apply(void 0, [].concat(t))
                }, e.styleDeclarationCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.styleDeclaration && f.styleDeclaration.apply(f, [].concat(t)), I.apply(void 0, [].concat(t))
                }, e.canvasMutationCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.canvasMutation && f.canvasMutation.apply(f, [].concat(t)), x.apply(void 0, [].concat(t))
                }, e.fontCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.font && f.font.apply(f, [].concat(t)), O.apply(void 0, [].concat(t))
                }, e.selectionCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.selection && f.selection.apply(f, [].concat(t)), E.apply(void 0, [].concat(t))
                }, e.customElementCb = function() {
                    for (var e = arguments.length, t = Array(e), r = 0; r < e; r++) t[r] = arguments[r];
                    f.customElement && f.customElement.apply(f, [].concat(t)), M.apply(void 0, [].concat(t))
                }, e.recordDOM && (eu = nx(e, e.doc));
                var n = function(e) {
                        var t, r = e.mousemoveCb,
                            n = e.sampling,
                            i = e.doc,
                            o = e.mirror;
                        if (!1 === n.mousemove) return function() {};
                        var s = "number" == typeof n.mousemove ? n.mousemove : 50,
                            a = "number" == typeof n.mousemoveCallback ? n.mousemoveCallback : 500,
                            c = [],
                            u = r3(nS(function(e) {
                                var n = Date.now() - t;
                                r(c.map(function(e) {
                                    return e.timeOffset -= n, e
                                }), e), c = [], t = null
                            }), a),
                            l = nS(r3(nS(function(e) {
                                var r = nI(e),
                                    n = nn(e) ? e.changedTouches[0] : e,
                                    i = n.clientX,
                                    s = n.clientY;
                                t || (t = r5()), c.push({
                                    x: i,
                                    y: s,
                                    id: o.getId(r),
                                    timeOffset: r5() - t
                                }), u("undefined" != typeof DragEvent && v(e, DragEvent) ? np.Drag : v(e, MouseEvent) ? np.MouseMove : np.TouchMove)
                            }), s, {
                                trailing: !1
                            })),
                            p = [r0("mousemove", l, i), r0("touchmove", l, i), r0("drag", l, i)];
                        return nS(function() {
                            p.forEach(function(e) {
                                return e()
                            })
                        })
                    }(e),
                    i = function(e) {
                        var t = e.mouseInteractionCb,
                            r = e.doc,
                            n = e.mirror,
                            i = e.blockClass,
                            o = e.blockSelector,
                            s = e.sampling;
                        if (!1 === s.mouseInteraction) return function() {};
                        var a = !0 === s.mouseInteraction || void 0 === s.mouseInteraction ? {} : s.mouseInteraction,
                            c = [],
                            u = null;
                        return Object.keys(nh).filter(function(e) {
                            return Number.isNaN(Number(e)) && !e.endsWith("_Departed") && !1 !== a[e]
                        }).forEach(function(e) {
                            var s = G(e),
                                a = function(r) {
                                    var s = nI(r);
                                    if (!nt(s, i, o, !0)) {
                                        var a = null,
                                            c = e;
                                        if ("pointerType" in r) {
                                            switch (r.pointerType) {
                                                case "mouse":
                                                    a = nf.Mouse;
                                                    break;
                                                case "touch":
                                                    a = nf.Touch;
                                                    break;
                                                case "pen":
                                                    a = nf.Pen
                                            }
                                            a === nf.Touch ? nh[e] === nh.MouseDown ? c = "TouchStart" : nh[e] === nh.MouseUp && (c = "TouchEnd") : nf.Pen
                                        } else nn(r) && (a = nf.Touch);
                                        null !== a ? (u = a, (c.startsWith("Touch") && a === nf.Touch || c.startsWith("Mouse") && a === nf.Mouse) && (a = null)) : nh[e] === nh.Click && (a = u, u = null);
                                        var l = nn(r) ? r.changedTouches[0] : r;
                                        if (l) {
                                            var p = n.getId(s),
                                                h = l.clientX,
                                                f = l.clientY;
                                            nS(t)(d({
                                                type: nh[c],
                                                id: p,
                                                x: h,
                                                y: f
                                            }, null !== a && {
                                                pointerType: a
                                            }))
                                        }
                                    }
                                };
                            if (window.PointerEvent) switch (nh[e]) {
                                case nh.MouseDown:
                                case nh.MouseUp:
                                    s = s.replace("mouse", "pointer");
                                    break;
                                case nh.TouchStart:
                                case nh.TouchEnd:
                                    return
                            }
                            c.push(r0(s, a, r))
                        }), nS(function() {
                            c.forEach(function(e) {
                                return e()
                            })
                        })
                    }(e),
                    o = nO(e),
                    s = (R = {
                        win: r
                    }, A = e.viewportResizeCb, T = R.win, N = -1, P = -1, r0("resize", nS(r3(nS(function() {
                        var e = r8(),
                            t = r7();
                        (N !== e || P !== t) && (A({
                            width: Number(t),
                            height: Number(e)
                        }), N = e, P = t)
                    }), 200)), T)),
                    a = function(e) {
                        var t = e.inputCb,
                            r = e.doc,
                            n = e.mirror,
                            i = e.blockClass,
                            o = e.blockSelector,
                            s = e.ignoreClass,
                            a = e.ignoreSelector,
                            c = e.maskInputOptions,
                            u = e.maskInputFn,
                            l = e.sampling,
                            p = e.userTriggeredOnInput;

                        function h(e) {
                            var t = nI(e),
                                n = e.isTrusted,
                                l = t && t.tagName;
                            if ((t && "OPTION" === l && (t = rQ.parentElement(t)), !(!t || !l || 0 > nE.indexOf(l) || nt(t, i, o, !0))) && !(t.classList.contains(s) || a && t.matches(a))) {
                                var h = t.value,
                                    d = !1,
                                    m = Z(t) || "";
                                "radio" === m || "checkbox" === m ? d = t.checked : (c[l.toLowerCase()] || c[m]) && (h = $({
                                    element: t,
                                    maskInputOptions: c,
                                    tagName: l,
                                    type: m,
                                    value: h,
                                    maskInputFn: u
                                })), f(t, p ? {
                                    text: h,
                                    isChecked: d,
                                    userTriggered: n
                                } : {
                                    text: h,
                                    isChecked: d
                                });
                                var g = t.name;
                                "radio" === m && g && d && r.querySelectorAll('input[type="radio"][name="' + g + '"]').forEach(function(e) {
                                    if (e !== t) {
                                        var r = e.value;
                                        f(e, p ? {
                                            text: r,
                                            isChecked: !d,
                                            userTriggered: !1
                                        } : {
                                            text: r,
                                            isChecked: !d
                                        })
                                    }
                                })
                            }
                        }

                        function f(e, r) {
                            var i = nM.get(e);
                            if (!i || i.text !== r.text || i.isChecked !== r.isChecked) {
                                nM.set(e, r);
                                var o = n.getId(e);
                                nS(t)(d({}, r, {
                                    id: o
                                }))
                            }
                        }
                        var m = ("last" === l.input ? ["change"] : ["input", "change"]).map(function(e) {
                                return r0(e, nS(h), r)
                            }),
                            g = r.defaultView;
                        if (!g) return function() {
                            m.forEach(function(e) {
                                return e()
                            })
                        };
                        var v = g.Object.getOwnPropertyDescriptor(g.HTMLInputElement.prototype, "value"),
                            y = [
                                [g.HTMLInputElement.prototype, "value"],
                                [g.HTMLInputElement.prototype, "checked"],
                                [g.HTMLSelectElement.prototype, "value"],
                                [g.HTMLTextAreaElement.prototype, "value"],
                                [g.HTMLSelectElement.prototype, "selectedIndex"],
                                [g.HTMLOptionElement.prototype, "selected"]
                            ];
                        return v && v.set && m.push.apply(m, [].concat(y.map(function(e) {
                            return r9(e[0], e[1], {
                                set: function() {
                                    nS(h)({
                                        target: this,
                                        isTrusted: !1
                                    })
                                }
                            }, !1, g)
                        }))), nS(function() {
                            m.forEach(function(e) {
                                return e()
                            })
                        })
                    }(e),
                    c = (D = e.mediaInteractionCb, L = e.blockClass, F = e.blockSelector, U = e.mirror, B = e.sampling, j = e.doc, z = [r0("play", (q = nS(function(e) {
                        return r3(nS(function(t) {
                            var r = nI(t);
                            if (!(!r || nt(r, L, F, !0))) {
                                var n = r.currentTime,
                                    i = r.volume,
                                    o = r.muted,
                                    s = r.playbackRate,
                                    a = r.loop;
                                D({
                                    type: e,
                                    id: U.getId(r),
                                    currentTime: n,
                                    volume: i,
                                    muted: o,
                                    playbackRate: s,
                                    loop: a
                                })
                            }
                        }), B.media || 500)
                    }))(nm.Play), j), r0("pause", q(nm.Pause), j), r0("seeked", q(nm.Seeked), j), r0("volumechange", q(nm.VolumeChange), j), r0("ratechange", q(nm.RateChange), j)], nS(function() {
                        z.forEach(function(e) {
                            return e()
                        })
                    })),
                    u = function() {},
                    l = function() {},
                    p = function() {},
                    h = function() {};
                e.recordDOM && (u = function(e, t) {
                    var r, n, i = e.styleSheetRuleCb,
                        o = e.mirror,
                        s = e.stylesheetManager,
                        a = t.win;
                    if (!a.CSSStyleSheet || !a.CSSStyleSheet.prototype) return function() {};
                    var c = a.CSSStyleSheet.prototype.insertRule;
                    a.CSSStyleSheet.prototype.insertRule = new Proxy(c, {
                        apply: nS(function(e, t, r) {
                            var n = r[0],
                                a = r[1],
                                c = nA(t, o, s.styleMirror),
                                u = c.id,
                                l = c.styleId;
                            return (u && -1 !== u || l && -1 !== l) && i({
                                id: u,
                                styleId: l,
                                adds: [{
                                    rule: n,
                                    index: a
                                }]
                            }), e.apply(t, r)
                        })
                    }), a.CSSStyleSheet.prototype.addRule = function(e, t, r) {
                        return void 0 === r && (r = this.cssRules.length), a.CSSStyleSheet.prototype.insertRule.apply(this, [e + " { " + t + " }", r])
                    };
                    var u = a.CSSStyleSheet.prototype.deleteRule;
                    a.CSSStyleSheet.prototype.deleteRule = new Proxy(u, {
                        apply: nS(function(e, t, r) {
                            var n = r[0],
                                a = nA(t, o, s.styleMirror),
                                c = a.id,
                                u = a.styleId;
                            return (c && -1 !== c || u && -1 !== u) && i({
                                id: c,
                                styleId: u,
                                removes: [{
                                    index: n
                                }]
                            }), e.apply(t, r)
                        })
                    }), a.CSSStyleSheet.prototype.removeRule = function(e) {
                        return a.CSSStyleSheet.prototype.deleteRule.apply(this, [e])
                    }, a.CSSStyleSheet.prototype.replace && (r = a.CSSStyleSheet.prototype.replace, a.CSSStyleSheet.prototype.replace = new Proxy(r, {
                        apply: nS(function(e, t, r) {
                            var n = r[0],
                                a = nA(t, o, s.styleMirror),
                                c = a.id,
                                u = a.styleId;
                            return (c && -1 !== c || u && -1 !== u) && i({
                                id: c,
                                styleId: u,
                                replace: n
                            }), e.apply(t, r)
                        })
                    })), a.CSSStyleSheet.prototype.replaceSync && (n = a.CSSStyleSheet.prototype.replaceSync, a.CSSStyleSheet.prototype.replaceSync = new Proxy(n, {
                        apply: nS(function(e, t, r) {
                            var n = r[0],
                                a = nA(t, o, s.styleMirror),
                                c = a.id,
                                u = a.styleId;
                            return (c && -1 !== c || u && -1 !== u) && i({
                                id: c,
                                styleId: u,
                                replaceSync: n
                            }), e.apply(t, r)
                        })
                    }));
                    var l = {};
                    nD("CSSGroupingRule") ? l.CSSGroupingRule = a.CSSGroupingRule : (nD("CSSMediaRule") && (l.CSSMediaRule = a.CSSMediaRule), nD("CSSConditionRule") && (l.CSSConditionRule = a.CSSConditionRule), nD("CSSSupportsRule") && (l.CSSSupportsRule = a.CSSSupportsRule));
                    var p = {};
                    return Object.entries(l).forEach(function(e) {
                        var t = e[0],
                            r = e[1];
                        p[t] = {
                            insertRule: r.prototype.insertRule,
                            deleteRule: r.prototype.deleteRule
                        }, r.prototype.insertRule = new Proxy(p[t].insertRule, {
                            apply: nS(function(e, t, r) {
                                var n = r[0],
                                    a = r[1],
                                    c = nA(t.parentStyleSheet, o, s.styleMirror),
                                    u = c.id,
                                    l = c.styleId;
                                return (u && -1 !== u || l && -1 !== l) && i({
                                    id: u,
                                    styleId: l,
                                    adds: [{
                                        rule: n,
                                        index: [].concat(nR(t), [a || 0])
                                    }]
                                }), e.apply(t, r)
                            })
                        }), r.prototype.deleteRule = new Proxy(p[t].deleteRule, {
                            apply: nS(function(e, t, r) {
                                var n = r[0],
                                    a = nA(t.parentStyleSheet, o, s.styleMirror),
                                    c = a.id,
                                    u = a.styleId;
                                return (c && -1 !== c || u && -1 !== u) && i({
                                    id: c,
                                    styleId: u,
                                    removes: [{
                                        index: [].concat(nR(t), [n])
                                    }]
                                }), e.apply(t, r)
                            })
                        })
                    }), nS(function() {
                        a.CSSStyleSheet.prototype.insertRule = c, a.CSSStyleSheet.prototype.deleteRule = u, r && (a.CSSStyleSheet.prototype.replace = r), n && (a.CSSStyleSheet.prototype.replaceSync = n), Object.entries(l).forEach(function(e) {
                            var t = e[0],
                                r = e[1];
                            r.prototype.insertRule = p[t].insertRule, r.prototype.deleteRule = p[t].deleteRule
                        })
                    })
                }(e, {
                    win: r
                }), l = nT(e, e.doc), W = e.styleDeclarationCb, V = e.mirror, Y = e.ignoreCSSAttributes, J = e.stylesheetManager, X = (H = ({
                    win: r
                }).win).CSSStyleDeclaration.prototype.setProperty, H.CSSStyleDeclaration.prototype.setProperty = new Proxy(X, {
                    apply: nS(function(e, t, r) {
                        var n, i = r[0],
                            o = r[1],
                            s = r[2];
                        if (Y.has(i)) return X.apply(t, [i, o, s]);
                        var a = nA(null == (n = t.parentRule) ? void 0 : n.parentStyleSheet, V, J.styleMirror),
                            c = a.id,
                            u = a.styleId;
                        return (c && -1 !== c || u && -1 !== u) && W({
                            id: c,
                            styleId: u,
                            set: {
                                property: i,
                                value: o,
                                priority: s
                            },
                            index: nR(t.parentRule)
                        }), e.apply(t, r)
                    })
                }), K = H.CSSStyleDeclaration.prototype.removeProperty, H.CSSStyleDeclaration.prototype.removeProperty = new Proxy(K, {
                    apply: nS(function(e, t, r) {
                        var n, i = r[0];
                        if (Y.has(i)) return K.apply(t, [i]);
                        var o = nA(null == (n = t.parentRule) ? void 0 : n.parentStyleSheet, V, J.styleMirror),
                            s = o.id,
                            a = o.styleId;
                        return (s && -1 !== s || a && -1 !== a) && W({
                            id: s,
                            styleId: a,
                            remove: {
                                property: i
                            },
                            index: nR(t.parentRule)
                        }), e.apply(t, r)
                    })
                }), p = nS(function() {
                    H.CSSStyleDeclaration.prototype.setProperty = X, H.CSSStyleDeclaration.prototype.removeProperty = K
                }), e.collectFonts && (h = function(e) {
                    var t = e.fontCb,
                        r = e.doc,
                        n = r.defaultView;
                    if (!n) return function() {};
                    var i = [],
                        o = new WeakMap,
                        s = n.FontFace;
                    n.FontFace = function(e, t, r) {
                        var n = new s(e, t, r);
                        return o.set(n, {
                            family: e,
                            buffer: "string" != typeof t,
                            descriptors: r,
                            fontSource: "string" == typeof t ? t : JSON.stringify(Array.from(new Uint8Array(t)))
                        }), n
                    };
                    var a = r4(r.fonts, "add", function(e) {
                        return function(r) {
                            return setTimeout(nS(function() {
                                var e = o.get(r);
                                e && (t(e), o.delete(r))
                            }), 0), e.apply(this, [r])
                        }
                    });
                    return i.push(function() {
                        n.FontFace = s
                    }), i.push(a), nS(function() {
                        i.forEach(function(e) {
                            return e()
                        })
                    })
                }(e)));
                for (var f, m, g, y, _, b, w, k, C, I, x, O, E, M, R, A, T, N, P, D, L, F, U, B, j, q, z, W, V, Y, J, H, X, K, Q, ee, et, er, en, ei, eo, es, ea, ec, eu, el, ep = (Q = e.doc, ee = e.mirror, et = e.blockClass, er = e.blockSelector, en = e.selectionCb, ei = !0, (eo = nS(function() {
                        var e = Q.getSelection();
                        if (e && (!ei || null == e || !e.isCollapsed)) {
                            ei = e.isCollapsed || !1;
                            for (var t = [], r = e.rangeCount || 0, n = 0; n < r; n++) {
                                var i = e.getRangeAt(n),
                                    o = i.startContainer,
                                    s = i.startOffset,
                                    a = i.endContainer,
                                    c = i.endOffset;
                                nt(o, et, er, !0) || nt(a, et, er, !0) || t.push({
                                    start: ee.getId(o),
                                    startOffset: s,
                                    end: ee.getId(a),
                                    endOffset: c
                                })
                            }
                            en({
                                ranges: t
                            })
                        }
                    }))(), r0("selectionchange", eo)), eh = (es = e.doc, ea = e.customElementCb, (ec = es.defaultView) && ec.customElements ? r4(ec.customElements, "define", function(e) {
                        return function(t, r, n) {
                            try {
                                ea({
                                    define: {
                                        name: t
                                    }
                                })
                            } catch (e) {
                                console.warn("Custom element callback failed for " + t)
                            }
                            return e.apply(this, [t, r, n])
                        }
                    }) : function() {}), ef = [], ed = S(e.plugins); !(el = ed()).done;) {
                    var em = el.value;
                    ef.push(em.observer(em.callback, r, em.options))
                }
                return nS(function() {
                    nC.forEach(function(e) {
                        return e.reset()
                    }), null == eu || eu.disconnect(), n(), i(), o(), s(), a(), c(), u(), l(), p(), h(), ep(), eh(), ef.forEach(function(e) {
                        return e()
                    })
                })
            }

            function nP(e) {
                return void 0 !== window[e]
            }

            function nD(e) {
                return !!(void 0 !== window[e] && window[e].prototype && "insertRule" in window[e].prototype && "deleteRule" in window[e].prototype)
            }
            for (var nL = function() {
                    function e(e) {
                        O(this, "iframeIdToRemoteIdMap", new WeakMap), O(this, "iframeRemoteIdToIdMap", new WeakMap), this.generateIdFn = e
                    }
                    var t = e.prototype;
                    return t.getId = function(e, t, r, n) {
                        var i = r || this.getIdToRemoteIdMap(e),
                            o = n || this.getRemoteIdToIdMap(e),
                            s = i.get(t);
                        return s || (s = this.generateIdFn(), i.set(t, s), o.set(s, t)), s
                    }, t.getIds = function(e, t) {
                        var r = this,
                            n = this.getIdToRemoteIdMap(e),
                            i = this.getRemoteIdToIdMap(e);
                        return t.map(function(t) {
                            return r.getId(e, t, n, i)
                        })
                    }, t.getRemoteId = function(e, t, r) {
                        var n = r || this.getRemoteIdToIdMap(e);
                        if ("number" != typeof t) return t;
                        var i = n.get(t);
                        return i || -1
                    }, t.getRemoteIds = function(e, t) {
                        var r = this,
                            n = this.getRemoteIdToIdMap(e);
                        return t.map(function(t) {
                            return r.getRemoteId(e, t, n)
                        })
                    }, t.reset = function(e) {
                        if (!e) {
                            this.iframeIdToRemoteIdMap = new WeakMap, this.iframeRemoteIdToIdMap = new WeakMap;
                            return
                        }
                        this.iframeIdToRemoteIdMap.delete(e), this.iframeRemoteIdToIdMap.delete(e)
                    }, t.getIdToRemoteIdMap = function(e) {
                        var t = this.iframeIdToRemoteIdMap.get(e);
                        return t || (t = new Map, this.iframeIdToRemoteIdMap.set(e, t)), t
                    }, t.getRemoteIdToIdMap = function(e) {
                        var t = this.iframeRemoteIdToIdMap.get(e);
                        return t || (t = new Map, this.iframeRemoteIdToIdMap.set(e, t)), t
                    }, e
                }(), nF = function() {
                    function e(e) {
                        O(this, "iframes", new WeakMap), O(this, "crossOriginIframeMap", new WeakMap), O(this, "crossOriginIframeMirror", new nL(ei)), O(this, "crossOriginIframeStyleMirror"), O(this, "crossOriginIframeRootIdMap", new WeakMap), O(this, "mirror"), O(this, "mutationCb"), O(this, "wrappedEmit"), O(this, "loadListener"), O(this, "stylesheetManager"), O(this, "recordCrossOriginIframes"), this.mutationCb = e.mutationCb, this.wrappedEmit = e.wrappedEmit, this.stylesheetManager = e.stylesheetManager, this.recordCrossOriginIframes = e.recordCrossOriginIframes, this.crossOriginIframeStyleMirror = new nL(this.stylesheetManager.styleMirror.generateId.bind(this.stylesheetManager.styleMirror)), this.mirror = e.mirror, this.recordCrossOriginIframes && window.addEventListener("message", this.handleMessage.bind(this))
                    }
                    var t = e.prototype;
                    return t.addIframe = function(e) {
                        this.iframes.set(e, !0), e.contentWindow && this.crossOriginIframeMap.set(e.contentWindow, e)
                    }, t.addLoadListener = function(e) {
                        this.loadListener = e
                    }, t.attachIframe = function(e, t) {
                        var r, n;
                        this.mutationCb({
                            adds: [{
                                parentId: this.mirror.getId(e),
                                nextId: null,
                                node: t
                            }],
                            removes: [],
                            texts: [],
                            attributes: [],
                            isAttachIframe: !0
                        }), this.recordCrossOriginIframes && (null == (r = e.contentWindow) || r.addEventListener("message", this.handleMessage.bind(this))), null == (n = this.loadListener) || n.call(this, e), e.contentDocument && e.contentDocument.adoptedStyleSheets && e.contentDocument.adoptedStyleSheets.length > 0 && this.stylesheetManager.adoptStyleSheets(e.contentDocument.adoptedStyleSheets, this.mirror.getId(e.contentDocument))
                    }, t.handleMessage = function(e) {
                        if ("rrweb" === e.data.type && e.origin === e.data.origin && e.source) {
                            var t = this.crossOriginIframeMap.get(e.source);
                            if (t) {
                                var r = this.transformCrossOriginEvent(t, e.data.event);
                                r && this.wrappedEmit(r, e.data.isCheckout)
                            }
                        }
                    }, t.transformCrossOriginEvent = function(e, t) {
                        var r, n = this;
                        switch (t.type) {
                            case nl.FullSnapshot:
                                this.crossOriginIframeMirror.reset(e), this.crossOriginIframeStyleMirror.reset(e), this.replaceIdOnNode(t.data.node, e);
                                var i = t.data.node.id;
                                return this.crossOriginIframeRootIdMap.set(e, i), this.patchRootIdOnNode(t.data.node, i), {
                                    timestamp: t.timestamp,
                                    type: nl.IncrementalSnapshot,
                                    data: {
                                        source: np.Mutation,
                                        adds: [{
                                            parentId: this.mirror.getId(e),
                                            nextId: null,
                                            node: t.data.node
                                        }],
                                        removes: [],
                                        texts: [],
                                        attributes: [],
                                        isAttachIframe: !0
                                    }
                                };
                            case nl.Meta:
                            case nl.Load:
                            case nl.DomContentLoaded:
                                break;
                            case nl.Plugin:
                                return t;
                            case nl.Custom:
                                return this.replaceIds(t.data.payload, e, ["id", "parentId", "previousId", "nextId"]), t;
                            case nl.IncrementalSnapshot:
                                switch (t.data.source) {
                                    case np.Mutation:
                                        return t.data.adds.forEach(function(t) {
                                            n.replaceIds(t, e, ["parentId", "nextId", "previousId"]), n.replaceIdOnNode(t.node, e);
                                            var r = n.crossOriginIframeRootIdMap.get(e);
                                            r && n.patchRootIdOnNode(t.node, r)
                                        }), t.data.removes.forEach(function(t) {
                                            n.replaceIds(t, e, ["parentId", "id"])
                                        }), t.data.attributes.forEach(function(t) {
                                            n.replaceIds(t, e, ["id"])
                                        }), t.data.texts.forEach(function(t) {
                                            n.replaceIds(t, e, ["id"])
                                        }), t;
                                    case np.Drag:
                                    case np.TouchMove:
                                    case np.MouseMove:
                                        return t.data.positions.forEach(function(t) {
                                            n.replaceIds(t, e, ["id"])
                                        }), t;
                                    case np.ViewportResize:
                                        return !1;
                                    case np.MediaInteraction:
                                    case np.MouseInteraction:
                                    case np.Scroll:
                                    case np.CanvasMutation:
                                    case np.Input:
                                        return this.replaceIds(t.data, e, ["id"]), t;
                                    case np.StyleSheetRule:
                                    case np.StyleDeclaration:
                                        return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleId"]), t;
                                    case np.Font:
                                        return t;
                                    case np.Selection:
                                        return t.data.ranges.forEach(function(t) {
                                            n.replaceIds(t, e, ["start", "end"])
                                        }), t;
                                    case np.AdoptedStyleSheet:
                                        return this.replaceIds(t.data, e, ["id"]), this.replaceStyleIds(t.data, e, ["styleIds"]), null == (r = t.data.styles) || r.forEach(function(t) {
                                            n.replaceStyleIds(t, e, ["styleId"])
                                        }), t
                                }
                        }
                        return !1
                    }, t.replace = function(e, t, r, n) {
                        for (var i, o = S(n); !(i = o()).done;) {
                            var s = i.value;
                            (Array.isArray(t[s]) || "number" == typeof t[s]) && (Array.isArray(t[s]) ? t[s] = e.getIds(r, t[s]) : t[s] = e.getId(r, t[s]))
                        }
                        return t
                    }, t.replaceIds = function(e, t, r) {
                        return this.replace(this.crossOriginIframeMirror, e, t, r)
                    }, t.replaceStyleIds = function(e, t, r) {
                        return this.replace(this.crossOriginIframeStyleMirror, e, t, r)
                    }, t.replaceIdOnNode = function(e, t) {
                        var r = this;
                        this.replaceIds(e, t, ["id", "rootId"]), "childNodes" in e && e.childNodes.forEach(function(e) {
                            r.replaceIdOnNode(e, t)
                        })
                    }, t.patchRootIdOnNode = function(e, t) {
                        var r = this;
                        e.type === ng.Document || e.rootId || (e.rootId = t), "childNodes" in e && e.childNodes.forEach(function(e) {
                            r.patchRootIdOnNode(e, t)
                        })
                    }, e
                }(), nU = function() {
                    function e(e) {
                        O(this, "shadowDoms", new WeakSet), O(this, "mutationCb"), O(this, "scrollCb"), O(this, "bypassOptions"), O(this, "mirror"), O(this, "restoreHandlers", []), this.mutationCb = e.mutationCb, this.scrollCb = e.scrollCb, this.bypassOptions = e.bypassOptions, this.mirror = e.mirror, this.init()
                    }
                    var t = e.prototype;
                    return t.init = function() {
                        this.reset(), this.patchAttachShadow(Element, document)
                    }, t.addShadowRoot = function(e, t) {
                        var r = this;
                        if (q(e) && !this.shadowDoms.has(e)) {
                            this.shadowDoms.add(e);
                            var n = nx(d({}, this.bypassOptions, {
                                doc: t,
                                mutationCb: this.mutationCb,
                                mirror: this.mirror,
                                shadowDomManager: this
                            }), e);
                            this.restoreHandlers.push(function() {
                                return n.disconnect()
                            }), this.restoreHandlers.push(nO(d({}, this.bypassOptions, {
                                scrollCb: this.scrollCb,
                                doc: e,
                                mirror: this.mirror
                            }))), setTimeout(function() {
                                e.adoptedStyleSheets && e.adoptedStyleSheets.length > 0 && r.bypassOptions.stylesheetManager.adoptStyleSheets(e.adoptedStyleSheets, r.mirror.getId(rQ.host(e))), r.restoreHandlers.push(nT({
                                    mirror: r.mirror,
                                    stylesheetManager: r.bypassOptions.stylesheetManager
                                }, e))
                            }, 0)
                        }
                    }, t.observeAttachShadow = function(e) {
                        e.contentWindow && e.contentDocument && this.patchAttachShadow(e.contentWindow.Element, e.contentDocument)
                    }, t.patchAttachShadow = function(e, t) {
                        var r = this;
                        this.restoreHandlers.push(r4(e.prototype, "attachShadow", function(e) {
                            return function(n) {
                                var i = e.call(this, n),
                                    o = rQ.shadowRoot(this);
                                return o && nu(this) && r.addShadowRoot(o, t), i
                            }
                        }))
                    }, t.reset = function() {
                        this.restoreHandlers.forEach(function(e) {
                            try {
                                e()
                            } catch (e) {}
                        }), this.restoreHandlers = [], this.shadowDoms = new WeakSet
                    }, e
                }(), nB = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", nj = "undefined" == typeof Uint8Array ? [] : new Uint8Array(256), nq = 0; nq < nB.length; nq++) nj[nB.charCodeAt(nq)] = nq;
            var nz = function(e) {
                    var t, r = new Uint8Array(e),
                        n = r.length,
                        i = "";
                    for (t = 0; t < n; t += 3) i += nB[r[t] >> 2], i += nB[(3 & r[t]) << 4 | r[t + 1] >> 4], i += nB[(15 & r[t + 1]) << 2 | r[t + 2] >> 6], i += nB[63 & r[t + 2]];
                    return n % 3 == 2 ? i = i.substring(0, i.length - 1) + "=" : n % 3 == 1 && (i = i.substring(0, i.length - 2) + "=="), i
                },
                nW = new Map,
                nV = function(e, t, r) {
                    if (e && (nG(e, t) || (void 0 === e ? "undefined" : b(e)) === "object")) {
                        var n, i = e.constructor.name,
                            o = ((n = nW.get(r)) || (n = new Map, nW.set(r, n)), n.has(i) || n.set(i, []), n.get(i)),
                            s = o.indexOf(e);
                        return -1 === s && (s = o.length, o.push(e)), s
                    }
                },
                n$ = function(e, t, r) {
                    return e.map(function(e) {
                        return function e(t, r, n) {
                            if (v(t, Array)) return t.map(function(t) {
                                return e(t, r, n)
                            });
                            if (null === t);
                            else if (v(t, Float32Array) || v(t, Float64Array) || v(t, Int32Array) || v(t, Uint32Array) || v(t, Uint8Array) || v(t, Uint16Array) || v(t, Int16Array) || v(t, Int8Array) || v(t, Uint8ClampedArray)) return {
                                rr_type: t.constructor.name,
                                args: [Object.values(t)]
                            };
                            else if (v(t, ArrayBuffer)) return {
                                rr_type: t.constructor.name,
                                base64: nz(t)
                            };
                            else if (v(t, DataView)) return {
                                rr_type: t.constructor.name,
                                args: [e(t.buffer, r, n), t.byteOffset, t.byteLength]
                            };
                            else if (v(t, HTMLImageElement)) return {
                                rr_type: t.constructor.name,
                                src: t.src
                            };
                            else if (v(t, HTMLCanvasElement)) return {
                                rr_type: "HTMLImageElement",
                                src: t.toDataURL()
                            };
                            else if (v(t, ImageData)) return {
                                rr_type: t.constructor.name,
                                args: [e(t.data, r, n), t.width, t.height]
                            };
                            else if (nG(t, r) || (void 0 === t ? "undefined" : b(t)) === "object") return {
                                rr_type: t.constructor.name,
                                index: nV(t, r, n)
                            };
                            return t
                        }(e, t, r)
                    })
                },
                nG = function(e, t) {
                    return !!["WebGLActiveInfo", "WebGLBuffer", "WebGLFramebuffer", "WebGLProgram", "WebGLRenderbuffer", "WebGLShader", "WebGLShaderPrecisionFormat", "WebGLTexture", "WebGLUniformLocation", "WebGLVertexArrayObject", "WebGLVertexArrayObjectOES"].filter(function(e) {
                        return "function" == typeof t[e]
                    }).find(function(r) {
                        return v(e, t[r])
                    })
                };

            function nY(e, t, r, n) {
                var i = [];
                try {
                    var o = r4(e.HTMLCanvasElement.prototype, "getContext", function(e) {
                        return function(i) {
                            for (var o = arguments.length, s = Array(o > 1 ? o - 1 : 0), a = 1; a < o; a++) s[a - 1] = arguments[a];
                            if (!nt(this, t, r, !0)) {
                                var c = "experimental-webgl" === i ? "webgl" : i;
                                if ("__context" in this || (this.__context = c), n && ["webgl", "webgl2"].includes(c))
                                    if (s[0] && "object" === b(s[0])) {
                                        var u = s[0];
                                        u.preserveDrawingBuffer || (u.preserveDrawingBuffer = !0)
                                    } else s.splice(0, 1, {
                                        preserveDrawingBuffer: !0
                                    })
                            }
                            return e.apply(this, [].concat([i], s))
                        }
                    });
                    i.push(o)
                } catch (e) {
                    console.error("failed to patch HTMLCanvasElement.prototype.getContext")
                }
                return function() {
                    i.forEach(function(e) {
                        return e()
                    })
                }
            }

            function nZ(e, t, r, n, i, o) {
                for (var s, a = [], c = Object.getOwnPropertyNames(e), u = S(c); !(s = u()).done;) ! function() {
                    var c = s.value;
                    if (!["isContextLost", "canvas", "drawingBufferWidth", "drawingBufferHeight"].includes(c)) try {
                        if ("function" != typeof e[c]) return "continue";
                        var u = r4(e, c, function(e) {
                            return function() {
                                for (var s = arguments.length, a = Array(s), u = 0; u < s; u++) a[u] = arguments[u];
                                var l = e.apply(this, a);
                                if (nV(l, o, this), "tagName" in this.canvas && !nt(this.canvas, n, i, !0)) {
                                    var p = n$(a, o, this);
                                    r(this.canvas, {
                                        type: t,
                                        property: c,
                                        args: p
                                    })
                                }
                                return l
                            }
                        });
                        a.push(u)
                    } catch (n) {
                        a.push(r9(e, c, {
                            set: function(e) {
                                r(this.canvas, {
                                    type: t,
                                    property: c,
                                    args: [e],
                                    setter: !0
                                })
                            }
                        }))
                    }
                }();
                return a
            }
            var nJ = "KGZ1bmN0aW9uKCkgewogICJ1c2Ugc3RyaWN0IjsKICB2YXIgY2hhcnMgPSAiQUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5ejAxMjM0NTY3ODkrLyI7CiAgdmFyIGxvb2t1cCA9IHR5cGVvZiBVaW50OEFycmF5ID09PSAidW5kZWZpbmVkIiA/IFtdIDogbmV3IFVpbnQ4QXJyYXkoMjU2KTsKICBmb3IgKHZhciBpID0gMDsgaSA8IGNoYXJzLmxlbmd0aDsgaSsrKSB7CiAgICBsb29rdXBbY2hhcnMuY2hhckNvZGVBdChpKV0gPSBpOwogIH0KICB2YXIgZW5jb2RlID0gZnVuY3Rpb24oYXJyYXlidWZmZXIpIHsKICAgIHZhciBieXRlcyA9IG5ldyBVaW50OEFycmF5KGFycmF5YnVmZmVyKSwgaTIsIGxlbiA9IGJ5dGVzLmxlbmd0aCwgYmFzZTY0ID0gIiI7CiAgICBmb3IgKGkyID0gMDsgaTIgPCBsZW47IGkyICs9IDMpIHsKICAgICAgYmFzZTY0ICs9IGNoYXJzW2J5dGVzW2kyXSA+PiAyXTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMl0gJiAzKSA8PCA0IHwgYnl0ZXNbaTIgKyAxXSA+PiA0XTsKICAgICAgYmFzZTY0ICs9IGNoYXJzWyhieXRlc1tpMiArIDFdICYgMTUpIDw8IDIgfCBieXRlc1tpMiArIDJdID4+IDZdOwogICAgICBiYXNlNjQgKz0gY2hhcnNbYnl0ZXNbaTIgKyAyXSAmIDYzXTsKICAgIH0KICAgIGlmIChsZW4gJSAzID09PSAyKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDEpICsgIj0iOwogICAgfSBlbHNlIGlmIChsZW4gJSAzID09PSAxKSB7CiAgICAgIGJhc2U2NCA9IGJhc2U2NC5zdWJzdHJpbmcoMCwgYmFzZTY0Lmxlbmd0aCAtIDIpICsgIj09IjsKICAgIH0KICAgIHJldHVybiBiYXNlNjQ7CiAgfTsKICBjb25zdCBsYXN0QmxvYk1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7CiAgY29uc3QgdHJhbnNwYXJlbnRCbG9iTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTsKICBhc3luYyBmdW5jdGlvbiBnZXRUcmFuc3BhcmVudEJsb2JGb3Iod2lkdGgsIGhlaWdodCwgZGF0YVVSTE9wdGlvbnMpIHsKICAgIGNvbnN0IGlkID0gYCR7d2lkdGh9LSR7aGVpZ2h0fWA7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBpZiAodHJhbnNwYXJlbnRCbG9iTWFwLmhhcyhpZCkpIHJldHVybiB0cmFuc3BhcmVudEJsb2JNYXAuZ2V0KGlkKTsKICAgICAgY29uc3Qgb2Zmc2NyZWVuID0gbmV3IE9mZnNjcmVlbkNhbnZhcyh3aWR0aCwgaGVpZ2h0KTsKICAgICAgb2Zmc2NyZWVuLmdldENvbnRleHQoIjJkIik7CiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCBvZmZzY3JlZW4uY29udmVydFRvQmxvYihkYXRhVVJMT3B0aW9ucyk7CiAgICAgIGNvbnN0IGFycmF5QnVmZmVyID0gYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpOwogICAgICBjb25zdCBiYXNlNjQgPSBlbmNvZGUoYXJyYXlCdWZmZXIpOwogICAgICB0cmFuc3BhcmVudEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICByZXR1cm4gYmFzZTY0OwogICAgfSBlbHNlIHsKICAgICAgcmV0dXJuICIiOwogICAgfQogIH0KICBjb25zdCB3b3JrZXIgPSBzZWxmOwogIHdvcmtlci5vbm1lc3NhZ2UgPSBhc3luYyBmdW5jdGlvbihlKSB7CiAgICBpZiAoIk9mZnNjcmVlbkNhbnZhcyIgaW4gZ2xvYmFsVGhpcykgewogICAgICBjb25zdCB7IGlkLCBiaXRtYXAsIHdpZHRoLCBoZWlnaHQsIGRhdGFVUkxPcHRpb25zIH0gPSBlLmRhdGE7CiAgICAgIGNvbnN0IHRyYW5zcGFyZW50QmFzZTY0ID0gZ2V0VHJhbnNwYXJlbnRCbG9iRm9yKAogICAgICAgIHdpZHRoLAogICAgICAgIGhlaWdodCwKICAgICAgICBkYXRhVVJMT3B0aW9ucwogICAgICApOwogICAgICBjb25zdCBvZmZzY3JlZW4gPSBuZXcgT2Zmc2NyZWVuQ2FudmFzKHdpZHRoLCBoZWlnaHQpOwogICAgICBjb25zdCBjdHggPSBvZmZzY3JlZW4uZ2V0Q29udGV4dCgiMmQiKTsKICAgICAgY3R4LmRyYXdJbWFnZShiaXRtYXAsIDAsIDApOwogICAgICBiaXRtYXAuY2xvc2UoKTsKICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IG9mZnNjcmVlbi5jb252ZXJ0VG9CbG9iKGRhdGFVUkxPcHRpb25zKTsKICAgICAgY29uc3QgdHlwZSA9IGJsb2IudHlwZTsKICAgICAgY29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCBibG9iLmFycmF5QnVmZmVyKCk7CiAgICAgIGNvbnN0IGJhc2U2NCA9IGVuY29kZShhcnJheUJ1ZmZlcik7CiAgICAgIGlmICghbGFzdEJsb2JNYXAuaGFzKGlkKSAmJiBhd2FpdCB0cmFuc3BhcmVudEJhc2U2NCA9PT0gYmFzZTY0KSB7CiAgICAgICAgbGFzdEJsb2JNYXAuc2V0KGlkLCBiYXNlNjQpOwogICAgICAgIHJldHVybiB3b3JrZXIucG9zdE1lc3NhZ2UoeyBpZCB9KTsKICAgICAgfQogICAgICBpZiAobGFzdEJsb2JNYXAuZ2V0KGlkKSA9PT0gYmFzZTY0KSByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQgfSk7CiAgICAgIHdvcmtlci5wb3N0TWVzc2FnZSh7CiAgICAgICAgaWQsCiAgICAgICAgdHlwZSwKICAgICAgICBiYXNlNjQsCiAgICAgICAgd2lkdGgsCiAgICAgICAgaGVpZ2h0CiAgICAgIH0pOwogICAgICBsYXN0QmxvYk1hcC5zZXQoaWQsIGJhc2U2NCk7CiAgICB9IGVsc2UgewogICAgICByZXR1cm4gd29ya2VyLnBvc3RNZXNzYWdlKHsgaWQ6IGUuZGF0YS5pZCB9KTsKICAgIH0KICB9Owp9KSgpOwovLyMgc291cmNlTWFwcGluZ1VSTD1pbWFnZS1iaXRtYXAtZGF0YS11cmwtd29ya2VyLUlKcEM3Z19iLmpzLm1hcAo=",
                nH = "undefined" != typeof window && window.Blob && new Blob([Uint8Array.from(atob(nJ), function(e) {
                    return e.charCodeAt(0)
                })], {
                    type: "text/javascript;charset=utf-8"
                });

            function nX(e) {
                var t;
                try {
                    if (!(t = nH && (window.URL || window.webkitURL).createObjectURL(nH))) throw "";
                    var r = new Worker(t, {
                        name: null == e ? void 0 : e.name
                    });
                    return r.addEventListener("error", function() {
                        (window.URL || window.webkitURL).revokeObjectURL(t)
                    }), r
                } catch (t) {
                    return new Worker("data:text/javascript;base64," + nJ, {
                        name: null == e ? void 0 : e.name
                    })
                } finally {
                    t && (window.URL || window.webkitURL).revokeObjectURL(t)
                }
            }
            var nK = function() {
                    function e(e) {
                        var t = this;
                        O(this, "pendingCanvasMutations", new Map), O(this, "rafStamps", {
                            latestId: 0,
                            invokeId: null
                        }), O(this, "mirror"), O(this, "mutationCb"), O(this, "resetObservers"), O(this, "frozen", !1), O(this, "locked", !1), O(this, "processMutation", function(e, r) {
                            (t.rafStamps.invokeId && t.rafStamps.latestId !== t.rafStamps.invokeId || !t.rafStamps.invokeId) && (t.rafStamps.invokeId = t.rafStamps.latestId), t.pendingCanvasMutations.has(e) || t.pendingCanvasMutations.set(e, []), t.pendingCanvasMutations.get(e).push(r)
                        });
                        var r = e.sampling,
                            n = void 0 === r ? "all" : r,
                            i = e.win,
                            o = e.blockClass,
                            s = e.blockSelector,
                            a = e.recordCanvas,
                            c = e.dataURLOptions;
                        this.mutationCb = e.mutationCb, this.mirror = e.mirror, a && "all" === n && this.initCanvasMutationObserver(i, o, s), a && "number" == typeof n && this.initCanvasFPSObserver(n, i, o, s, {
                            dataURLOptions: c
                        })
                    }
                    var t = e.prototype;
                    return t.reset = function() {
                        this.pendingCanvasMutations.clear(), this.resetObservers && this.resetObservers()
                    }, t.freeze = function() {
                        this.frozen = !0
                    }, t.unfreeze = function() {
                        this.frozen = !1
                    }, t.lock = function() {
                        this.locked = !0
                    }, t.unlock = function() {
                        this.locked = !1
                    }, t.initCanvasFPSObserver = function(e, t, r, n, i) {
                        var o, s = this,
                            a = nY(t, r, n, !0),
                            c = new Map,
                            u = new nX;
                        u.onmessage = function(e) {
                            var t = e.data.id;
                            if (c.set(t, !1), "base64" in e.data) {
                                var r = e.data,
                                    n = r.base64,
                                    i = r.type,
                                    o = r.width,
                                    a = r.height;
                                s.mutationCb({
                                    id: t,
                                    type: nd["2D"],
                                    commands: [{
                                        property: "clearRect",
                                        args: [0, 0, o, a]
                                    }, {
                                        property: "drawImage",
                                        args: [{
                                            rr_type: "ImageBitmap",
                                            args: [{
                                                rr_type: "Blob",
                                                data: [{
                                                    rr_type: "ArrayBuffer",
                                                    base64: n
                                                }],
                                                type: i
                                            }]
                                        }, 0, 0]
                                    }]
                                })
                            }
                        };
                        var l = 1e3 / e,
                            h = 0,
                            f = function() {
                                var e = [];
                                return t.document.querySelectorAll("canvas").forEach(function(t) {
                                    nt(t, r, n, !0) || e.push(t)
                                }), e
                            },
                            d = function(e) {
                                if (h && e - h < l) {
                                    o = requestAnimationFrame(d);
                                    return
                                }
                                h = e, f().forEach(p(function(e) {
                                    var t, r, n, o;
                                    return C(this, function(a) {
                                        switch (a.label) {
                                            case 0:
                                                if (r = s.mirror.getId(e), c.get(r) || 0 === e.width || 0 === e.height) return [2];
                                                return c.set(r, !0), ["webgl", "webgl2"].includes(e.__context) && (null == (t = null == (n = e.getContext(e.__context)) ? void 0 : n.getContextAttributes()) ? void 0 : t.preserveDrawingBuffer) === !1 && n.clear(n.COLOR_BUFFER_BIT), [4, createImageBitmap(e)];
                                            case 1:
                                                return o = a.sent(), u.postMessage({
                                                    id: r,
                                                    bitmap: o,
                                                    width: e.width,
                                                    height: e.height,
                                                    dataURLOptions: i.dataURLOptions
                                                }, [o]), [2]
                                        }
                                    })
                                })), o = requestAnimationFrame(d)
                            };
                        o = requestAnimationFrame(d), this.resetObservers = function() {
                            a(), cancelAnimationFrame(o)
                        }
                    }, t.initCanvasMutationObserver = function(e, t, r) {
                        this.startRAFTimestamping(), this.startPendingCanvasMutationFlusher();
                        var n, i, o = nY(e, t, r, !1),
                            s = function(e, t, r, n) {
                                for (var i, o = [], s = Object.getOwnPropertyNames(t.CanvasRenderingContext2D.prototype), a = S(s); !(i = a()).done;) ! function() {
                                    var s = i.value;
                                    try {
                                        if ("function" != typeof t.CanvasRenderingContext2D.prototype[s]) return "continue";
                                        var a = r4(t.CanvasRenderingContext2D.prototype, s, function(i) {
                                            return function() {
                                                for (var o = this, a = arguments.length, c = Array(a), u = 0; u < a; u++) c[u] = arguments[u];
                                                return nt(this.canvas, r, n, !0) || setTimeout(function() {
                                                    var r = n$(c, t, o);
                                                    e(o.canvas, {
                                                        type: nd["2D"],
                                                        property: s,
                                                        args: r
                                                    })
                                                }, 0), i.apply(this, c)
                                            }
                                        });
                                        o.push(a)
                                    } catch (r) {
                                        var c = r9(t.CanvasRenderingContext2D.prototype, s, {
                                            set: function(t) {
                                                e(this.canvas, {
                                                    type: nd["2D"],
                                                    property: s,
                                                    args: [t],
                                                    setter: !0
                                                })
                                            }
                                        });
                                        o.push(c)
                                    }
                                }();
                                return function() {
                                    o.forEach(function(e) {
                                        return e()
                                    })
                                }
                            }(this.processMutation.bind(this), e, t, r),
                            a = (n = this.processMutation.bind(this), (i = []).push.apply(i, [].concat(nZ(e.WebGLRenderingContext.prototype, nd.WebGL, n, t, r, e))), void 0 !== e.WebGL2RenderingContext && i.push.apply(i, [].concat(nZ(e.WebGL2RenderingContext.prototype, nd.WebGL2, n, t, r, e))), function() {
                                i.forEach(function(e) {
                                    return e()
                                })
                            });
                        this.resetObservers = function() {
                            o(), s(), a()
                        }
                    }, t.startPendingCanvasMutationFlusher = function() {
                        var e = this;
                        requestAnimationFrame(function() {
                            return e.flushPendingCanvasMutations()
                        })
                    }, t.startRAFTimestamping = function() {
                        var e = this,
                            t = function(r) {
                                e.rafStamps.latestId = r, requestAnimationFrame(t)
                            };
                        requestAnimationFrame(t)
                    }, t.flushPendingCanvasMutations = function() {
                        var e = this;
                        this.pendingCanvasMutations.forEach(function(t, r) {
                            var n = e.mirror.getId(r);
                            e.flushPendingCanvasMutationFor(r, n)
                        }), requestAnimationFrame(function() {
                            return e.flushPendingCanvasMutations()
                        })
                    }, t.flushPendingCanvasMutationFor = function(e, t) {
                        if (!this.frozen && !this.locked) {
                            var r = this.pendingCanvasMutations.get(e);
                            if (r && -1 !== t) {
                                var n = r.map(function(e) {
                                        return e.type, y(e, ["type"])
                                    }),
                                    i = r[0].type;
                                this.mutationCb({
                                    id: t,
                                    type: i,
                                    commands: n
                                }), this.pendingCanvasMutations.delete(e)
                            }
                        }
                    }, e
                }(),
                nQ = function() {
                    function e(e) {
                        O(this, "trackedLinkElements", new WeakSet), O(this, "mutationCb"), O(this, "adoptedStyleSheetCb"), O(this, "styleMirror", new na), this.mutationCb = e.mutationCb, this.adoptedStyleSheetCb = e.adoptedStyleSheetCb
                    }
                    var t = e.prototype;
                    return t.attachLinkElement = function(e, t) {
                        "_cssText" in t.attributes && this.mutationCb({
                            adds: [],
                            removes: [],
                            texts: [],
                            attributes: [{
                                id: t.id,
                                attributes: t.attributes
                            }]
                        }), this.trackLinkElement(e)
                    }, t.trackLinkElement = function(e) {
                        this.trackedLinkElements.has(e) || (this.trackedLinkElements.add(e), this.trackStylesheetInLinkElement(e))
                    }, t.adoptStyleSheets = function(e, t) {
                        if (0 !== e.length) {
                            for (var r, n, i = {
                                    id: t,
                                    styleIds: []
                                }, o = [], s = S(e); !(n = s()).done;) r = this,
                                function() {
                                    var e = n.value,
                                        t = void 0;
                                    r.styleMirror.has(e) ? t = r.styleMirror.getId(e) : (t = r.styleMirror.add(e), o.push({
                                        styleId: t,
                                        rules: Array.from(e.rules || CSSRule, function(t, r) {
                                            return {
                                                rule: W(t, e.href),
                                                index: r
                                            }
                                        })
                                    })), i.styleIds.push(t)
                                }();
                            o.length > 0 && (i.styles = o), this.adoptedStyleSheetCb(i)
                        }
                    }, t.reset = function() {
                        this.styleMirror.reset(), this.trackedLinkElements = new WeakSet
                    }, t.trackStylesheetInLinkElement = function(e) {}, e
                }(),
                n0 = function() {
                    function e() {
                        O(this, "nodeMap", new WeakMap), O(this, "active", !1)
                    }
                    var t = e.prototype;
                    return t.inOtherBuffer = function(e, t) {
                        var r = this.nodeMap.get(e);
                        return r && Array.from(r).some(function(e) {
                            return e !== t
                        })
                    }, t.add = function(e, t) {
                        var r = this;
                        this.active || (this.active = !0, requestAnimationFrame(function() {
                            r.nodeMap = new WeakMap, r.active = !1
                        })), this.nodeMap.set(e, (this.nodeMap.get(e) || new Set).add(t))
                    }, t.destroy = function() {}, e
                }(),
                n1 = !1;
            try {
                if (2 !== Array.from([1], function(e) {
                        return 2 * e
                    })[0]) {
                    var n2 = document.createElement("iframe");
                    document.body.appendChild(n2), Array.from = (null == (n5 = n2.contentWindow) ? void 0 : n5.Array.from) || Array.from, document.body.removeChild(n2)
                }
            } catch (e) {
                console.debug("Unable to override Array.from", e)
            }
            var n3 = new V;

            function n9(e) {
                void 0 === e && (e = {});
                var t = e.emit,
                    r = e.checkoutEveryNms,
                    n = e.checkoutEveryNth,
                    i = e.blockClass,
                    o = void 0 === i ? "rr-block" : i,
                    s = e.blockSelector,
                    a = void 0 === s ? null : s,
                    c = e.ignoreClass,
                    u = void 0 === c ? "rr-ignore" : c,
                    l = e.ignoreSelector,
                    p = void 0 === l ? null : l,
                    h = e.maskTextClass,
                    f = void 0 === h ? "rr-mask" : h,
                    m = e.maskTextSelector,
                    g = void 0 === m ? null : m,
                    v = e.inlineStylesheet,
                    y = void 0 === v || v,
                    _ = e.maskAllInputs,
                    b = e.maskInputOptions,
                    w = e.slimDOMOptions,
                    k = e.maskInputFn,
                    C = e.maskTextFn,
                    I = e.hooks,
                    x = e.packFn,
                    O = e.sampling,
                    E = void 0 === O ? {} : O,
                    M = e.dataURLOptions,
                    R = void 0 === M ? {} : M,
                    A = e.mousemoveWait,
                    T = e.recordDOM,
                    N = void 0 === T || T,
                    P = e.recordCanvas,
                    D = void 0 !== P && P,
                    L = e.recordCrossOriginIframes,
                    F = void 0 !== L && L,
                    U = e.recordAfter,
                    B = void 0 === U ? "DOMContentLoaded" === e.recordAfter ? e.recordAfter : "load" : U,
                    j = e.userTriggeredOnInput,
                    q = void 0 !== j && j,
                    z = e.collectFonts,
                    W = void 0 !== z && z,
                    $ = e.inlineImages,
                    G = void 0 !== $ && $,
                    Y = e.plugins,
                    Z = e.keepIframeSrcFn,
                    J = void 0 === Z ? function() {
                        return !1
                    } : Z,
                    H = e.ignoreCSSAttributes,
                    X = void 0 === H ? new Set([]) : H;
                iv = e.errorHandler;
                var K = !F || window.parent === window,
                    Q = !1;
                if (!K) try {
                    window.parent.document && (Q = !1)
                } catch (e) {
                    Q = !0
                }
                if (K && !t) throw Error("emit function is required");
                if (!K && !Q) return function() {};
                void 0 !== A && void 0 === E.mousemove && (E.mousemove = A), n3.reset();
                var ee = !0 === _ ? {
                        color: !0,
                        date: !0,
                        "datetime-local": !0,
                        email: !0,
                        month: !0,
                        number: !0,
                        range: !0,
                        search: !0,
                        tel: !0,
                        text: !0,
                        time: !0,
                        url: !0,
                        week: !0,
                        textarea: !0,
                        select: !0,
                        password: !0
                    } : void 0 !== b ? b : {
                        password: !0
                    },
                    et = !0 === w || "all" === w ? {
                        script: !0,
                        comment: !0,
                        headFavicon: !0,
                        headWhitespace: !0,
                        headMetaSocial: !0,
                        headMetaRobots: !0,
                        headMetaHttpEquiv: !0,
                        headMetaVerification: !0,
                        headMetaAuthorship: "all" === w,
                        headMetaDescKeywords: "all" === w,
                        headTitleMutations: "all" === w
                    } : w || {};
                void 0 === ei && (ei = window), "NodeList" in ei && !ei.NodeList.prototype.forEach && (ei.NodeList.prototype.forEach = Array.prototype.forEach), "DOMTokenList" in ei && !ei.DOMTokenList.prototype.forEach && (ei.DOMTokenList.prototype.forEach = Array.prototype.forEach);
                var er = 0,
                    en = function(e) {
                        for (var t, r = S(Y || []); !(t = r()).done;) {
                            var n = t.value;
                            n.eventProcessor && (e = n.eventProcessor(e))
                        }
                        return x && !Q && (e = x(e)), e
                    };
                iy = function(e, i) {
                    var o;
                    if (e.timestamp = r5(), (null == (o = nC[0]) ? void 0 : o.isFrozen()) && e.type !== nl.FullSnapshot && (e.type !== nl.IncrementalSnapshot || e.data.source !== np.Mutation) && nC.forEach(function(e) {
                            return e.unfreeze()
                        }), K) null == t || t(en(e), i);
                    else if (Q) {
                        var s = {
                            type: "rrweb",
                            event: en(e),
                            origin: window.location.origin,
                            isCheckout: i
                        };
                        window.parent.postMessage(s, "*")
                    }
                    if (e.type === nl.FullSnapshot) eo = e, er = 0;
                    else if (e.type === nl.IncrementalSnapshot) {
                        if (e.data.source === np.Mutation && e.data.isAttachIframe) return;
                        er++;
                        var a = n && er >= n,
                            c = r && e.timestamp - eo.timestamp > r;
                        (a || c) && i_(!0)
                    }
                };
                for (var ei, eo, es, ea = function(e) {
                        iy({
                            type: nl.IncrementalSnapshot,
                            data: d({
                                source: np.Mutation
                            }, e)
                        })
                    }, ec = function(e) {
                        return iy({
                            type: nl.IncrementalSnapshot,
                            data: d({
                                source: np.Scroll
                            }, e)
                        })
                    }, eu = function(e) {
                        return iy({
                            type: nl.IncrementalSnapshot,
                            data: d({
                                source: np.CanvasMutation
                            }, e)
                        })
                    }, el = new nQ({
                        mutationCb: ea,
                        adoptedStyleSheetCb: function(e) {
                            return iy({
                                type: nl.IncrementalSnapshot,
                                data: d({
                                    source: np.AdoptedStyleSheet
                                }, e)
                            })
                        }
                    }), ep = new nF({
                        mirror: n3,
                        mutationCb: ea,
                        stylesheetManager: el,
                        recordCrossOriginIframes: F,
                        wrappedEmit: iy
                    }), eh = S(Y || []); !(es = eh()).done;) {
                    var ef = es.value;
                    ef.getMirror && ef.getMirror({
                        nodeMirror: n3,
                        crossOriginIframeMirror: ep.crossOriginIframeMirror,
                        crossOriginIframeStyleMirror: ep.crossOriginIframeStyleMirror
                    })
                }
                var ed = new n0;
                ib = new nK({
                    recordCanvas: D,
                    mutationCb: eu,
                    win: window,
                    blockClass: o,
                    blockSelector: a,
                    mirror: n3,
                    sampling: E.canvas,
                    dataURLOptions: R
                });
                var eg = new nU({
                    mutationCb: ea,
                    scrollCb: ec,
                    bypassOptions: {
                        blockClass: o,
                        blockSelector: a,
                        maskTextClass: f,
                        maskTextSelector: g,
                        inlineStylesheet: y,
                        maskInputOptions: ee,
                        dataURLOptions: R,
                        maskTextFn: C,
                        maskInputFn: k,
                        recordCanvas: D,
                        inlineImages: G,
                        sampling: E,
                        slimDOMOptions: et,
                        iframeManager: ep,
                        stylesheetManager: el,
                        canvasManager: ib,
                        keepIframeSrcFn: J,
                        processedNodeManager: ed
                    },
                    mirror: n3
                });
                i_ = function(e) {
                    if (void 0 === e && (e = !1), N) {
                        iy({
                            type: nl.Meta,
                            data: {
                                href: window.location.href,
                                width: r7(),
                                height: r8()
                            }
                        }, e), el.reset(), eg.init(), nC.forEach(function(e) {
                            return e.lock()
                        });
                        var t, r, n, i, s, c, u, l, p, h, d, m, v, _, b, w, S, I, x, O, E, M, A, T, P = (t = document, i = void 0 === (n = (r = {
                            mirror: n3,
                            blockClass: o,
                            blockSelector: a,
                            maskTextClass: f,
                            maskTextSelector: g,
                            inlineStylesheet: y,
                            maskAllInputs: ee,
                            maskTextFn: C,
                            maskInputFn: k,
                            slimDOM: et,
                            dataURLOptions: R,
                            recordCanvas: D,
                            inlineImages: G,
                            onSerialize: function(e) {
                                ni(e, n3) && ep.addIframe(e), no(e, n3) && el.trackLinkElement(e), ns(e) && eg.addShadowRoot(rQ.shadowRoot(e), document)
                            },
                            onIframeLoad: function(e, t) {
                                ep.attachIframe(e, t), eg.observeAttachShadow(e)
                            },
                            onStylesheetLoad: function(e, t) {
                                el.attachLinkElement(e, t)
                            },
                            keepIframeSrcFn: J
                        }).mirror) ? new V : n, s = r.blockClass, c = r.blockSelector, u = r.maskTextClass, l = r.maskTextSelector, p = r.inlineStylesheet, h = r.inlineImages, d = r.recordCanvas, v = void 0 !== (m = r.maskAllInputs) && m, _ = r.maskTextFn, b = r.maskInputFn, S = void 0 !== (w = r.slimDOM) && w, I = r.dataURLOptions, x = r.preserveWhiteSpace, O = r.onSerialize, E = r.onIframeLoad, M = r.iframeLoadTimeout, A = r.onStylesheetLoad, em(t, {
                            doc: t,
                            mirror: i,
                            blockClass: void 0 === s ? "rr-block" : s,
                            blockSelector: void 0 === c ? null : c,
                            maskTextClass: void 0 === u ? "rr-mask" : u,
                            maskTextSelector: void 0 === l ? null : l,
                            skipChild: !1,
                            inlineStylesheet: void 0 === p || p,
                            maskInputOptions: !0 === v ? {
                                color: !0,
                                date: !0,
                                "datetime-local": !0,
                                email: !0,
                                month: !0,
                                number: !0,
                                range: !0,
                                search: !0,
                                tel: !0,
                                text: !0,
                                time: !0,
                                url: !0,
                                week: !0,
                                textarea: !0,
                                select: !0,
                                password: !0
                            } : !1 === v ? {
                                password: !0
                            } : v,
                            maskTextFn: _,
                            maskInputFn: b,
                            slimDOMOptions: !0 === S || "all" === S ? {
                                script: !0,
                                comment: !0,
                                headFavicon: !0,
                                headWhitespace: !0,
                                headMetaDescKeywords: "all" === S,
                                headMetaSocial: !0,
                                headMetaRobots: !0,
                                headMetaHttpEquiv: !0,
                                headMetaAuthorship: !0,
                                headMetaVerification: !0
                            } : !1 === S ? {} : S,
                            dataURLOptions: I,
                            inlineImages: void 0 !== h && h,
                            recordCanvas: void 0 !== d && d,
                            preserveWhiteSpace: x,
                            onSerialize: O,
                            onIframeLoad: E,
                            iframeLoadTimeout: M,
                            onStylesheetLoad: A,
                            stylesheetLoadTimeout: r.stylesheetLoadTimeout,
                            keepIframeSrcFn: void 0 === (T = r.keepIframeSrcFn) ? function() {
                                return !1
                            } : T,
                            newlyAddedElement: !1
                        }));
                        if (!P) return console.warn("Failed to snapshot the document");
                        iy({
                            type: nl.FullSnapshot,
                            data: {
                                node: P,
                                initialOffset: r6(window)
                            }
                        }, e), nC.forEach(function(e) {
                            return e.unlock()
                        }), document.adoptedStyleSheets && document.adoptedStyleSheets.length > 0 && el.adoptStyleSheets(document.adoptedStyleSheets, n3.getId(document))
                    }
                };
                try {
                    var ev = [],
                        ey = function(e) {
                            var t;
                            return nS(nN)({
                                mutationCb: ea,
                                mousemoveCb: function(e, t) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: {
                                            source: t,
                                            positions: e
                                        }
                                    })
                                },
                                mouseInteractionCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.MouseInteraction
                                        }, e)
                                    })
                                },
                                scrollCb: ec,
                                viewportResizeCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.ViewportResize
                                        }, e)
                                    })
                                },
                                inputCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.Input
                                        }, e)
                                    })
                                },
                                mediaInteractionCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.MediaInteraction
                                        }, e)
                                    })
                                },
                                styleSheetRuleCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.StyleSheetRule
                                        }, e)
                                    })
                                },
                                styleDeclarationCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.StyleDeclaration
                                        }, e)
                                    })
                                },
                                canvasMutationCb: eu,
                                fontCb: function(e) {
                                    return iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.Font
                                        }, e)
                                    })
                                },
                                selectionCb: function(e) {
                                    iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.Selection
                                        }, e)
                                    })
                                },
                                customElementCb: function(e) {
                                    iy({
                                        type: nl.IncrementalSnapshot,
                                        data: d({
                                            source: np.CustomElement
                                        }, e)
                                    })
                                },
                                blockClass: o,
                                ignoreClass: u,
                                ignoreSelector: p,
                                maskTextClass: f,
                                maskTextSelector: g,
                                maskInputOptions: ee,
                                inlineStylesheet: y,
                                sampling: E,
                                recordDOM: N,
                                recordCanvas: D,
                                inlineImages: G,
                                userTriggeredOnInput: q,
                                collectFonts: W,
                                doc: e,
                                maskInputFn: k,
                                maskTextFn: C,
                                keepIframeSrcFn: J,
                                blockSelector: a,
                                slimDOMOptions: et,
                                dataURLOptions: R,
                                mirror: n3,
                                iframeManager: ep,
                                stylesheetManager: el,
                                shadowDomManager: eg,
                                processedNodeManager: ed,
                                canvasManager: ib,
                                ignoreCSSAttributes: X,
                                plugins: (null == (t = null == Y ? void 0 : Y.filter(function(e) {
                                    return e.observer
                                })) ? void 0 : t.map(function(e) {
                                    return {
                                        observer: e.observer,
                                        options: e.options,
                                        callback: function(t) {
                                            return iy({
                                                type: nl.Plugin,
                                                data: {
                                                    plugin: e.name,
                                                    payload: t
                                                }
                                            })
                                        }
                                    }
                                })) || []
                            }, I)
                        };
                    ep.addLoadListener(function(e) {
                        try {
                            ev.push(ey(e.contentDocument))
                        } catch (e) {
                            console.warn(e)
                        }
                    });
                    var e_ = function() {
                        i_(), ev.push(ey(document)), n1 = !0
                    };
                    return "interactive" === document.readyState || "complete" === document.readyState ? e_() : (ev.push(r0("DOMContentLoaded", function() {
                            iy({
                                type: nl.DomContentLoaded,
                                data: {}
                            }), "DOMContentLoaded" === B && e_()
                        })), ev.push(r0("load", function() {
                            iy({
                                type: nl.Load,
                                data: {}
                            }), "load" === B && e_()
                        }, window))),
                        function() {
                            ev.forEach(function(e) {
                                return e()
                            }), ed.destroy(), n1 = !1, iv = void 0
                        }
                } catch (e) {
                    console.warn(e)
                }
            }
            n9.addCustomEvent = function(e, t) {
                    if (!n1) throw Error("please add custom event after start recording");
                    iy({
                        type: nl.Custom,
                        data: {
                            tag: e,
                            payload: t
                        }
                    })
                }, n9.freezePage = function() {
                    nC.forEach(function(e) {
                        return e.freeze()
                    })
                }, n9.takeFullSnapshot = function(e) {
                    if (!n1) throw Error("please take full snapshot after start recording");
                    i_(e)
                }, n9.mirror = n3,
                function(e) {
                    e[e.NotStarted = 0] = "NotStarted", e[e.Running = 1] = "Running", e[e.Stopped = 2] = "Stopped"
                }(iw || (iw = {})), n9.addCustomEvent, n9.freezePage, n9.takeFullSnapshot;
            var n4, n5, n6, n8, n7, ie, it, ir, ii, io, is, ia, ic, iu, il, ip, ih, id, im, ig, iv, iy, i_, ib, iw, ik, iS, iC, iI = n4.setImmediate,
                ix = Object.prototype.toString,
                iO = void 0 !== iI ? function(e) {
                    return iI(e)
                } : setTimeout;
            try {
                Object.defineProperty({}, "x", {}), ik = function(e, t, r, n) {
                    return Object.defineProperty(e, t, {
                        value: r,
                        writable: !0,
                        configurable: !1 !== n
                    })
                }
            } catch (e) {
                ik = function(e, t, r) {
                    return e[t] = r, e
                }
            }

            function iE(e, t) {
                iC.add(e, t), iS || (iS = iO(iC.drain))
            }

            function iM(e) {
                var t, r = typeof e;
                return null !== e && ("object" === r || "function" === r) && (t = e.then), "function" == typeof t && t
            }

            function iR() {
                for (var e = 0; e < this.chain.length; e++) ! function(e, t, r) {
                    var n, i;
                    try {
                        !1 === t ? r.reject(e.msg) : (n = !0 === t ? e.msg : t.call(void 0, e.msg)) === r.promise ? r.reject(TypeError("Promise-chain cycle")) : (i = iM(n)) ? i.call(n, r.resolve, r.reject) : r.resolve(n)
                    } catch (e) {
                        r.reject(e)
                    }
                }(this, 1 === this.state ? this.chain[e].success : this.chain[e].failure, this.chain[e]);
                this.chain.length = 0
            }

            function iA(e) {
                var t, r = this;
                if (!r.triggered) {
                    r.triggered = !0, r.def && (r = r.def);
                    try {
                        (t = iM(e)) ? iE(function() {
                            var n = new iP(r);
                            try {
                                t.call(e, function() {
                                    iA.apply(n, arguments)
                                }, function() {
                                    iT.apply(n, arguments)
                                })
                            } catch (e) {
                                iT.call(n, e)
                            }
                        }): (r.msg = e, r.state = 1, r.chain.length > 0 && iE(iR, r))
                    } catch (e) {
                        iT.call(new iP(r), e)
                    }
                }
            }

            function iT(e) {
                var t = this;
                !t.triggered && (t.triggered = !0, t.def && (t = t.def), t.msg = e, t.state = 2, t.chain.length > 0 && iE(iR, t))
            }

            function iN(e, t, r, n) {
                for (var i = 0; i < t.length; i++) ! function(i) {
                    e.resolve(t[i]).then(function(e) {
                        r(i, e)
                    }, n)
                }(i)
            }

            function iP(e) {
                this.def = e, this.triggered = !1
            }

            function iD(e) {
                this.promise = e, this.state = 0, this.triggered = !1, this.chain = [], this.msg = void 0
            }

            function iL(e) {
                if ("function" != typeof e) throw TypeError("Not a function");
                if (0 !== this.__NPO__) throw TypeError("Not a promise");
                this.__NPO__ = 1;
                var t = new iD(this);
                this.then = function(e, r) {
                    var n = {
                        success: "function" != typeof e || e,
                        failure: "function" == typeof r && r
                    };
                    return n.promise = new this.constructor(function(e, t) {
                        if ("function" != typeof e || "function" != typeof t) throw TypeError("Not a function");
                        n.resolve = e, n.reject = t
                    }), t.chain.push(n), 0 !== t.state && iE(iR, t), n.promise
                }, this.catch = function(e) {
                    return this.then(void 0, e)
                };
                try {
                    e.call(void 0, function(e) {
                        iA.call(t, e)
                    }, function(e) {
                        iT.call(t, e)
                    })
                } catch (e) {
                    iT.call(t, e)
                }
            }
            iC = function() {
                var e, t, r;

                function n(e, t) {
                    this.fn = e, this.self = t, this.next = void 0
                }
                return {
                    add: function(i, o) {
                        r = new n(i, o), t ? t.next = r : e = r, t = r, r = void 0
                    },
                    drain: function() {
                        var r = e;
                        for (e = t = iS = void 0; r;) r.fn.call(r.self), r = r.next
                    }
                }
            }();
            var iF = ik({}, "constructor", iL, !1);
            iL.prototype = iF, ik(iF, "__NPO__", 0, !1), ik(iL, "resolve", function(e) {
                return e && "object" == typeof e && 1 === e.__NPO__ ? e : new this(function(t, r) {
                    if ("function" != typeof t || "function" != typeof r) throw TypeError("Not a function");
                    t(e)
                })
            }), ik(iL, "reject", function(e) {
                return new this(function(t, r) {
                    if ("function" != typeof t || "function" != typeof r) throw TypeError("Not a function");
                    r(e)
                })
            }), ik(iL, "all", function(e) {
                var t = this;
                return "[object Array]" !== ix.call(e) ? t.reject(TypeError("Not an array")) : 0 === e.length ? t.resolve([]) : new t(function(r, n) {
                    if ("function" != typeof r || "function" != typeof n) throw TypeError("Not a function");
                    var i = e.length,
                        o = Array(i),
                        s = 0;
                    iN(t, e, function(e, t) {
                        o[e] = t, ++s === i && r(o)
                    }, n)
                })
            }), ik(iL, "race", function(e) {
                var t = this;
                return "[object Array]" !== ix.call(e) ? t.reject(TypeError("Not an array")) : new t(function(r, n) {
                    if ("function" != typeof r || "function" != typeof n) throw TypeError("Not a function");
                    iN(t, e, function(e, t) {
                        r(t)
                    }, n)
                })
            }), n = "undefined" != typeof Promise && -1 !== Promise.toString().indexOf("[native code]") ? Promise : iL;
            var iU = {
                    DEBUG: !1,
                    LIB_VERSION: "2.63.0"
                },
                iB = Array.prototype,
                ij = Function.prototype,
                iq = Object.prototype,
                iz = iB.slice,
                iW = iq.toString,
                iV = iq.hasOwnProperty,
                i$ = n4.console,
                iG = n4.navigator,
                iY = n4.document,
                iZ = n4.opera,
                iJ = n4.screen,
                iH = iG.userAgent,
                iX = ij.bind,
                iK = iB.forEach,
                iQ = iB.indexOf,
                i0 = iB.map,
                i1 = Array.isArray,
                i2 = {},
                i3 = {
                    trim: function(e) {
                        return e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "")
                    }
                },
                i9 = {
                    log: function() {
                        if (iU.DEBUG && !i3.isUndefined(i$) && i$) try {
                            i$.log.apply(i$, arguments)
                        } catch (e) {
                            i3.each(arguments, function(e) {
                                i$.log(e)
                            })
                        }
                    },
                    warn: function() {
                        if (iU.DEBUG && !i3.isUndefined(i$) && i$) {
                            var e = ["Mixpanel warning:"].concat(i3.toArray(arguments));
                            try {
                                i$.warn.apply(i$, e)
                            } catch (t) {
                                i3.each(e, function(e) {
                                    i$.warn(e)
                                })
                            }
                        }
                    },
                    error: function() {
                        if (iU.DEBUG && !i3.isUndefined(i$) && i$) {
                            var e = ["Mixpanel error:"].concat(i3.toArray(arguments));
                            try {
                                i$.error.apply(i$, e)
                            } catch (t) {
                                i3.each(e, function(e) {
                                    i$.error(e)
                                })
                            }
                        }
                    },
                    critical: function() {
                        if (!i3.isUndefined(i$) && i$) {
                            var e = ["Mixpanel error:"].concat(i3.toArray(arguments));
                            try {
                                i$.error.apply(i$, e)
                            } catch (t) {
                                i3.each(e, function(e) {
                                    i$.error(e)
                                })
                            }
                        }
                    }
                },
                i4 = function(e, t) {
                    return function() {
                        return arguments[0] = "[" + t + "] " + arguments[0], e.apply(i9, arguments)
                    }
                },
                i5 = function(e) {
                    return {
                        log: i4(i9.log, e),
                        error: i4(i9.error, e),
                        critical: i4(i9.critical, e)
                    }
                },
                i6 = function(e) {
                    return function() {
                        try {
                            return e.apply(this, arguments)
                        } catch (e) {
                            i9.critical("Implementation error. Please turn on debug and contact support@mixpanel.com."), iU.DEBUG && i9.critical(e)
                        }
                    }
                };
            i3.bind = function(e, t) {
                var r, n;
                if (iX && e.bind === iX) return iX.apply(e, iz.call(arguments, 1));
                if (!i3.isFunction(e)) throw TypeError();
                return r = iz.call(arguments, 2), n = function() {
                    if (!(this instanceof n)) return e.apply(t, r.concat(iz.call(arguments)));
                    var i = {};
                    i.prototype = e.prototype;
                    var o = new i;
                    i.prototype = null;
                    var s = e.apply(o, r.concat(iz.call(arguments)));
                    return Object(s) === s ? s : o
                }
            }, i3.each = function(e, t, r) {
                if (null != e) {
                    if (iK && e.forEach === iK) e.forEach(t, r);
                    else if (e.length === +e.length) {
                        for (var n = 0, i = e.length; n < i; n++)
                            if (n in e && t.call(r, e[n], n, e) === i2) return
                    } else
                        for (var o in e)
                            if (iV.call(e, o) && t.call(r, e[o], o, e) === i2) return
                }
            }, i3.extend = function(e) {
                return i3.each(iz.call(arguments, 1), function(t) {
                    for (var r in t) void 0 !== t[r] && (e[r] = t[r])
                }), e
            }, i3.isArray = i1 || function(e) {
                return "[object Array]" === iW.call(e)
            }, i3.isFunction = function(e) {
                try {
                    return /^\s*\bfunction\b/.test(e)
                } catch (e) {
                    return !1
                }
            }, i3.isArguments = function(e) {
                return !!(e && iV.call(e, "callee"))
            }, i3.toArray = function(e) {
                return e ? e.toArray ? e.toArray() : i3.isArray(e) || i3.isArguments(e) ? iz.call(e) : i3.values(e) : []
            }, i3.map = function(e, t, r) {
                if (i0 && e.map === i0) return e.map(t, r);
                var n = [];
                return i3.each(e, function(e) {
                    n.push(t.call(r, e))
                }), n
            }, i3.keys = function(e) {
                var t = [];
                return null === e || i3.each(e, function(e, r) {
                    t[t.length] = r
                }), t
            }, i3.values = function(e) {
                var t = [];
                return null === e || i3.each(e, function(e) {
                    t[t.length] = e
                }), t
            }, i3.include = function(e, t) {
                var r = !1;
                return null === e ? r : iQ && e.indexOf === iQ ? -1 != e.indexOf(t) : (i3.each(e, function(e) {
                    if (r || (r = e === t)) return i2
                }), r)
            }, i3.includes = function(e, t) {
                return -1 !== e.indexOf(t)
            }, i3.inherit = function(e, t) {
                return e.prototype = new t, e.prototype.constructor = e, e.superclass = t.prototype, e
            }, i3.isObject = function(e) {
                return e === Object(e) && !i3.isArray(e)
            }, i3.isEmptyObject = function(e) {
                if (i3.isObject(e)) {
                    for (var t in e)
                        if (iV.call(e, t)) return !1;
                    return !0
                }
                return !1
            }, i3.isUndefined = function(e) {
                return void 0 === e
            }, i3.isString = function(e) {
                return "[object String]" == iW.call(e)
            }, i3.isDate = function(e) {
                return "[object Date]" == iW.call(e)
            }, i3.isNumber = function(e) {
                return "[object Number]" == iW.call(e)
            }, i3.isElement = function(e) {
                return !!(e && 1 === e.nodeType)
            }, i3.encodeDates = function(e) {
                return i3.each(e, function(t, r) {
                    i3.isDate(t) ? e[r] = i3.formatDate(t) : i3.isObject(t) && (e[r] = i3.encodeDates(t))
                }), e
            }, i3.timestamp = function() {
                return Date.now = Date.now || function() {
                    return +new Date
                }, Date.now()
            }, i3.formatDate = function(e) {
                function t(e) {
                    return e < 10 ? "0" + e : e
                }
                return e.getUTCFullYear() + "-" + t(e.getUTCMonth() + 1) + "-" + t(e.getUTCDate()) + "T" + t(e.getUTCHours()) + ":" + t(e.getUTCMinutes()) + ":" + t(e.getUTCSeconds())
            }, i3.strip_empty_properties = function(e) {
                var t = {};
                return i3.each(e, function(e, r) {
                    i3.isString(e) && e.length > 0 && (t[r] = e)
                }), t
            }, i3.truncate = function(e, t) {
                var r;
                return "string" == typeof e ? r = e.slice(0, t) : i3.isArray(e) ? (r = [], i3.each(e, function(e) {
                    r.push(i3.truncate(e, t))
                })) : i3.isObject(e) ? (r = {}, i3.each(e, function(e, n) {
                    r[n] = i3.truncate(e, t)
                })) : r = e, r
            }, i3.JSONEncode = function(e) {
                var t = function(e) {
                        var t = /[\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
                            r = {
                                "\b": "\\b",
                                "	": "\\t",
                                "\n": "\\n",
                                "\f": "\\f",
                                "\r": "\\r",
                                '"': '\\"',
                                "\\": "\\\\"
                            };
                        return t.lastIndex = 0, t.test(e) ? '"' + e.replace(t, function(e) {
                            var t = r[e];
                            return "string" == typeof t ? t : "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4)
                        }) + '"' : '"' + e + '"'
                    },
                    r = function(e, n) {
                        var i = "",
                            o = 0,
                            s = "",
                            a = "",
                            c = 0,
                            u = i,
                            l = [],
                            p = n[e];
                        switch (p && "object" == typeof p && "function" == typeof p.toJSON && (p = p.toJSON(e)), typeof p) {
                            case "string":
                                return t(p);
                            case "number":
                                return isFinite(p) ? String(p) : "null";
                            case "boolean":
                            case "null":
                                return String(p);
                            case "object":
                                if (!p) return "null";
                                if (i += "    ", l = [], "[object Array]" === iW.apply(p)) {
                                    for (o = 0, c = p.length; o < c; o += 1) l[o] = r(o, p) || "null";
                                    return a = 0 === l.length ? "[]" : i ? "[\n" + i + l.join(",\n" + i) + "\n" + u + "]" : "[" + l.join(",") + "]", i = u, a
                                }
                                for (s in p) iV.call(p, s) && (a = r(s, p)) && l.push(t(s) + (i ? ": " : ":") + a);
                                return a = 0 === l.length ? "{}" : i ? "{" + l.join(",") + u + "}" : "{" + l.join(",") + "}", i = u, a
                        }
                    };
                return r("", {
                    "": e
                })
            }, i3.JSONDecode = function() {
                var e, t, r, n, i = {
                        '"': '"',
                        "\\": "\\",
                        "/": "/",
                        b: "\b",
                        f: "\f",
                        n: "\n",
                        r: "\r",
                        t: "	"
                    },
                    o = function(t) {
                        var n = SyntaxError(t);
                        throw n.at = e, n.text = r, n
                    },
                    s = function(n) {
                        return n && n !== t && o("Expected '" + n + "' instead of '" + t + "'"), t = r.charAt(e), e += 1, t
                    },
                    a = function() {
                        var e, r = "";
                        for ("-" === t && (r = "-", s("-")); t >= "0" && t <= "9";) r += t, s();
                        if ("." === t)
                            for (r += "."; s() && t >= "0" && t <= "9";) r += t;
                        if ("e" === t || "E" === t)
                            for (r += t, s(), ("-" === t || "+" === t) && (r += t, s()); t >= "0" && t <= "9";) r += t, s();
                        if (isFinite(e = +r)) return e;
                        o("Bad number")
                    },
                    c = function() {
                        var e, r, n, a = "";
                        if ('"' === t)
                            for (; s();) {
                                if ('"' === t) return s(), a;
                                if ("\\" === t)
                                    if (s(), "u" === t) {
                                        for (r = 0, n = 0; r < 4 && isFinite(e = parseInt(s(), 16)); r += 1) n = 16 * n + e;
                                        a += String.fromCharCode(n)
                                    } else if ("string" == typeof i[t]) a += i[t];
                                else break;
                                else a += t
                            }
                        o("Bad string")
                    },
                    u = function() {
                        for (; t && t <= " ";) s()
                    },
                    l = function() {
                        switch (t) {
                            case "t":
                                return s("t"), s("r"), s("u"), s("e"), !0;
                            case "f":
                                return s("f"), s("a"), s("l"), s("s"), s("e"), !1;
                            case "n":
                                return s("n"), s("u"), s("l"), s("l"), null
                        }
                        o('Unexpected "' + t + '"')
                    },
                    p = function() {
                        var e = [];
                        if ("[" === t) {
                            if (s("["), u(), "]" === t) return s("]"), e;
                            for (; t;) {
                                if (e.push(n()), u(), "]" === t) return s("]"), e;
                                s(","), u()
                            }
                        }
                        o("Bad array")
                    },
                    h = function() {
                        var e, r = {};
                        if ("{" === t) {
                            if (s("{"), u(), "}" === t) return s("}"), r;
                            for (; t;) {
                                if (e = c(), u(), s(":"), Object.hasOwnProperty.call(r, e) && o('Duplicate key "' + e + '"'), r[e] = n(), u(), "}" === t) return s("}"), r;
                                s(","), u()
                            }
                        }
                        o("Bad object")
                    };
                return n = function() {
                        switch (u(), t) {
                            case "{":
                                return h();
                            case "[":
                                return p();
                            case '"':
                                return c();
                            case "-":
                                return a();
                            default:
                                return t >= "0" && t <= "9" ? a() : l()
                        }
                    },
                    function(i) {
                        var s;
                        return r = i, e = 0, t = " ", s = n(), u(), t && o("Syntax error"), s
                    }
            }(), i3.base64Encode = function(e) {
                var t, r, n, i, o, s, a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                    c = 0,
                    u = 0,
                    l = "",
                    p = [];
                if (!e) return e;
                e = i3.utf8Encode(e);
                do t = e.charCodeAt(c++), r = (s = t << 16 | e.charCodeAt(c++) << 8 | e.charCodeAt(c++)) >> 18 & 63, n = s >> 12 & 63, i = s >> 6 & 63, o = 63 & s, p[u++] = a.charAt(r) + a.charAt(n) + a.charAt(i) + a.charAt(o); while (c < e.length);
                switch (l = p.join(""), e.length % 3) {
                    case 1:
                        l = l.slice(0, -2) + "==";
                        break;
                    case 2:
                        l = l.slice(0, -1) + "="
                }
                return l
            }, i3.utf8Encode = function(e) {
                e = (e + "").replace(/\r\n/g, "\n").replace(/\r/g, "\n");
                var t, r, n, i = "",
                    o = 0;
                for (n = 0, t = r = 0, o = e.length; n < o; n++) {
                    var s = e.charCodeAt(n),
                        a = null;
                    s < 128 ? r++ : a = s > 127 && s < 2048 ? String.fromCharCode(s >> 6 | 192, 63 & s | 128) : String.fromCharCode(s >> 12 | 224, s >> 6 & 63 | 128, 63 & s | 128), null !== a && (r > t && (i += e.substring(t, r)), i += a, t = r = n + 1)
                }
                return r > t && (i += e.substring(t, e.length)), i
            }, i3.UUID = function() {
                try {
                    return n4.crypto.randomUUID()
                } catch (r) {
                    for (var e = Array(36), t = 0; t < 36; t++) e[t] = Math.floor(16 * Math.random());
                    return e[14] = 4, e[19] = e[19] &= -5, e[19] = e[19] |= 8, e[8] = e[13] = e[18] = e[23] = "-", i3.map(e, function(e) {
                        return e.toString(16)
                    }).join("")
                }
            };
            var i8 = ["ahrefsbot", "ahrefssiteaudit", "amazonbot", "baiduspider", "bingbot", "bingpreview", "chrome-lighthouse", "facebookexternal", "petalbot", "pinterest", "screaming frog", "yahoo! slurp", "yandex", "adsbot-google", "apis-google", "duplexweb-google", "feedfetcher-google", "google favicon", "google web preview", "google-read-aloud", "googlebot", "googleweblight", "mediapartners-google", "storebot-google"];
            i3.isBlockedUA = function(e) {
                var t;
                for (t = 0, e = e.toLowerCase(); t < i8.length; t++)
                    if (-1 !== e.indexOf(i8[t])) return !0;
                return !1
            }, i3.HTTPBuildQuery = function(e, t) {
                var r, n, i = [];
                return i3.isUndefined(t) && (t = "&"), i3.each(e, function(e, t) {
                    r = encodeURIComponent(e.toString()), n = encodeURIComponent(t), i[i.length] = n + "=" + r
                }), i.join(t)
            }, i3.getQueryParam = function(e, t) {
                var r = RegExp("[\\?&]" + (t = t.replace(/[[]/g, "\\[").replace(/[\]]/g, "\\]")) + "=([^&#]*)").exec(e);
                if (null === r || r && "string" != typeof r[1] && r[1].length) return "";
                var n = r[1];
                try {
                    n = decodeURIComponent(n)
                } catch (e) {
                    i9.error("Skipping decoding for malformed query param: " + n)
                }
                return n.replace(/\+/g, " ")
            }, i3.cookie = {
                get: function(e) {
                    for (var t = e + "=", r = iY.cookie.split(";"), n = 0; n < r.length; n++) {
                        for (var i = r[n];
                            " " == i.charAt(0);) i = i.substring(1, i.length);
                        if (0 === i.indexOf(t)) return decodeURIComponent(i.substring(t.length, i.length))
                    }
                    return null
                },
                parse: function(e) {
                    var t;
                    try {
                        t = i3.JSONDecode(i3.cookie.get(e)) || {}
                    } catch (e) {}
                    return t
                },
                set_seconds: function(e, t, r, n, i, o, s) {
                    var a = "",
                        c = "",
                        u = "";
                    if (s) a = "; domain=" + s;
                    else if (n) {
                        var l = op(iY.location.hostname);
                        a = l ? "; domain=." + l : ""
                    }
                    if (r) {
                        var p = new Date;
                        p.setTime(p.getTime() + 1e3 * r), c = "; expires=" + p.toGMTString()
                    }
                    o && (i = !0, u = "; SameSite=None"), i && (u += "; secure"), iY.cookie = e + "=" + encodeURIComponent(t) + c + "; path=/" + a + u
                },
                set: function(e, t, r, n, i, o, s) {
                    var a = "",
                        c = "",
                        u = "";
                    if (s) a = "; domain=" + s;
                    else if (n) {
                        var l = op(iY.location.hostname);
                        a = l ? "; domain=." + l : ""
                    }
                    if (r) {
                        var p = new Date;
                        p.setTime(p.getTime() + 24 * r * 36e5), c = "; expires=" + p.toGMTString()
                    }
                    o && (i = !0, u = "; SameSite=None"), i && (u += "; secure");
                    var h = e + "=" + encodeURIComponent(t) + c + "; path=/" + a + u;
                    return iY.cookie = h, h
                },
                remove: function(e, t, r) {
                    i3.cookie.set(e, "", -1, t, !1, !1, r)
                }
            };
            var i7 = function(e) {
                    var t = !0;
                    try {
                        var r = "__mplss_" + oc(8);
                        e.setItem(r, "xyz"), "xyz" !== e.getItem(r) && (t = !1), e.removeItem(r)
                    } catch (e) {
                        t = !1
                    }
                    return t
                },
                oe = null,
                ot = function(e, t) {
                    return null === oe || t ? oe = i7(e || n4.localStorage) : oe
                },
                or = null;

            function on(e, t, r) {
                var n = function(e) {
                    i9.error(t + " error: " + e)
                };
                return {
                    is_supported: function(n) {
                        var i = r(e, n);
                        return i || i9.error(t + " unsupported"), i
                    },
                    error: n,
                    get: function(t) {
                        try {
                            return e.getItem(t)
                        } catch (e) {
                            n(e)
                        }
                        return null
                    },
                    parse: function(t) {
                        try {
                            return i3.JSONDecode(e.getItem(t)) || {}
                        } catch (e) {}
                        return null
                    },
                    set: function(t, r) {
                        try {
                            e.setItem(t, r)
                        } catch (e) {
                            n(e)
                        }
                    },
                    remove: function(t) {
                        try {
                            e.removeItem(t)
                        } catch (e) {
                            n(e)
                        }
                    }
                }
            }
            i3.localStorage = on(n4.localStorage, "localStorage", ot), i3.sessionStorage = on(n4.sessionStorage, "sessionStorage", function(e, t) {
                return null === or || t ? or = i7(e || n4.sessionStorage) : or
            }), i3.register_event = function() {
                function e(t) {
                    return t && (t.preventDefault = e.preventDefault, t.stopPropagation = e.stopPropagation), t
                }
                return e.preventDefault = function() {
                        this.returnValue = !1
                    }, e.stopPropagation = function() {
                        this.cancelBubble = !0
                    },
                    function(t, r, n, i, o) {
                        if (!t) return void i9.error("No valid element provided to register_event");
                        if (t.addEventListener && !i) t.addEventListener(r, n, !!o);
                        else {
                            var s, a, c, u = "on" + r,
                                l = t[u];
                            t[u] = (s = t, a = n, c = l, function(t) {
                                if (t = t || e(n4.event)) {
                                    var r, n, i = !0;
                                    return i3.isFunction(c) && (r = c(t)), n = a.call(s, t), (!1 === r || !1 === n) && (i = !1), i
                                }
                            })
                        }
                    }
            }();
            var oi = RegExp('^(\\w*)\\[(\\w+)([=~\\|\\^\\$\\*]?)=?"?([^\\]"]*)"?\\]$');
            i3.dom_query = function() {
                function e(e) {
                    return e.all ? e.all : e.getElementsByTagName("*")
                }
                var t = /[\t\r\n]/g;

                function r(r) {
                    if (!iY.getElementsByTagName) return [];
                    var n = r.split(" "),
                        i = [iY];
                    for (d = 0; d < n.length; d++) {
                        if ((l = n[d].replace(/^\s+/, "").replace(/\s+$/, "")).indexOf("#") > -1) {
                            b = (p = l.split("#"))[0];
                            var o = p[1],
                                s = iY.getElementById(o);
                            if (!s || b && s.nodeName.toLowerCase() != b) return [];
                            i = [s];
                            continue
                        }
                        if (l.indexOf(".") > -1) {
                            b = (p = l.split("."))[0];
                            var a, c = p[1];
                            for (b || (b = "*"), h = [], f = 0, m = 0; m < i.length; m++)
                                for (g = 0, v = "*" == b ? e(i[m]) : i[m].getElementsByTagName(b); g < v.length; g++) h[f++] = v[g];
                            for (m = 0, i = [], y = 0; m < h.length; m++) h[m].className && i3.isString(h[m].className) && (a = h[m], (" " + a.className + " ").replace(t, " ").indexOf(" " + c + " ") >= 0) && (i[y++] = h[m]);
                            continue
                        }
                        var u = l.match(oi);
                        if (u) {
                            var l, p, h, f, d, m, g, v, y, _, b = u[1],
                                w = u[2],
                                k = u[3],
                                S = u[4];
                            for (b || (b = "*"), h = [], f = 0, m = 0; m < i.length; m++)
                                for (g = 0, v = "*" == b ? e(i[m]) : i[m].getElementsByTagName(b); g < v.length; g++) h[f++] = v[g];
                            switch (i = [], y = 0, k) {
                                case "=":
                                    _ = function(e) {
                                        return e.getAttribute(w) == S
                                    };
                                    break;
                                case "~":
                                    _ = function(e) {
                                        return e.getAttribute(w).match(RegExp("\\b" + S + "\\b"))
                                    };
                                    break;
                                case "|":
                                    _ = function(e) {
                                        return e.getAttribute(w).match(RegExp("^" + S + "-?"))
                                    };
                                    break;
                                case "^":
                                    _ = function(e) {
                                        return 0 === e.getAttribute(w).indexOf(S)
                                    };
                                    break;
                                case "$":
                                    _ = function(e) {
                                        return e.getAttribute(w).lastIndexOf(S) == e.getAttribute(w).length - S.length
                                    };
                                    break;
                                case "*":
                                    _ = function(e) {
                                        return e.getAttribute(w).indexOf(S) > -1
                                    };
                                    break;
                                default:
                                    _ = function(e) {
                                        return e.getAttribute(w)
                                    }
                            }
                            for (m = 0, i = [], y = 0; m < h.length; m++) _(h[m]) && (i[y++] = h[m]);
                            continue
                        }
                        for (m = 0, b = l, h = [], f = 0; m < i.length; m++)
                            for (g = 0, v = i[m].getElementsByTagName(b); g < v.length; g++) h[f++] = v[g];
                        i = h
                    }
                    return i
                }
                return function(e) {
                    return i3.isElement(e) ? [e] : i3.isObject(e) && !i3.isUndefined(e.length) ? e : r.call(this, e)
                }
            }();
            var oo = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term", "utm_id", "utm_source_platform", "utm_campaign_id", "utm_creative_format", "utm_marketing_tactic"],
                os = ["dclid", "fbclid", "gclid", "ko_click_id", "li_fat_id", "msclkid", "sccid", "ttclid", "twclid", "wbraid"];
            i3.info = {
                campaignParams: function(e) {
                    var t = "",
                        r = {};
                    return i3.each(oo, function(n) {
                        (t = i3.getQueryParam(iY.URL, n)).length ? r[n] = t : void 0 !== e && (r[n] = e)
                    }), r
                },
                clickParams: function() {
                    var e = "",
                        t = {};
                    return i3.each(os, function(r) {
                        (e = i3.getQueryParam(iY.URL, r)).length && (t[r] = e)
                    }), t
                },
                marketingParams: function() {
                    return i3.extend(i3.info.campaignParams(), i3.info.clickParams())
                },
                searchEngine: function(e) {
                    return 0 === e.search("https?://(.*)google.([^/?]*)") ? "google" : 0 === e.search("https?://(.*)bing.com") ? "bing" : 0 === e.search("https?://(.*)yahoo.com") ? "yahoo" : 0 === e.search("https?://(.*)duckduckgo.com") ? "duckduckgo" : null
                },
                searchInfo: function(e) {
                    var t = i3.info.searchEngine(e),
                        r = {};
                    if (null !== t) {
                        r.$search_engine = t;
                        var n = i3.getQueryParam(e, "yahoo" != t ? "q" : "p");
                        n.length && (r.mp_keyword = n)
                    }
                    return r
                },
                browser: function(e, t, r) {
                    if (t = t || "", r || i3.includes(e, " OPR/")) return i3.includes(e, "Mini") ? "Opera Mini" : "Opera";
                    if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
                    if (i3.includes(e, "IEMobile") || i3.includes(e, "WPDesktop")) return "Internet Explorer Mobile";
                    if (i3.includes(e, "SamsungBrowser/")) return "Samsung Internet";
                    if (i3.includes(e, "Edge") || i3.includes(e, "Edg/")) return "Microsoft Edge";
                    else if (i3.includes(e, "FBIOS")) return "Facebook Mobile";
                    else if (i3.includes(e, "Chrome")) return "Chrome";
                    else if (i3.includes(e, "CriOS")) return "Chrome iOS";
                    else if (i3.includes(e, "UCWEB") || i3.includes(e, "UCBrowser")) return "UC Browser";
                    else if (i3.includes(e, "FxiOS")) return "Firefox iOS";
                    else if (i3.includes(t, "Apple")) return i3.includes(e, "Mobile") ? "Mobile Safari" : "Safari";
                    else if (i3.includes(e, "Android")) return "Android Mobile";
                    else if (i3.includes(e, "Konqueror")) return "Konqueror";
                    else if (i3.includes(e, "Firefox")) return "Firefox";
                    else if (i3.includes(e, "MSIE") || i3.includes(e, "Trident/")) return "Internet Explorer";
                    else if (i3.includes(e, "Gecko")) return "Mozilla";
                    else return ""
                },
                browserVersion: function(e, t, r) {
                    var n = {
                        "Internet Explorer Mobile": /rv:(\d+(\.\d+)?)/,
                        "Microsoft Edge": /Edge?\/(\d+(\.\d+)?)/,
                        Chrome: /Chrome\/(\d+(\.\d+)?)/,
                        "Chrome iOS": /CriOS\/(\d+(\.\d+)?)/,
                        "UC Browser": /(UCBrowser|UCWEB)\/(\d+(\.\d+)?)/,
                        Safari: /Version\/(\d+(\.\d+)?)/,
                        "Mobile Safari": /Version\/(\d+(\.\d+)?)/,
                        Opera: /(Opera|OPR)\/(\d+(\.\d+)?)/,
                        Firefox: /Firefox\/(\d+(\.\d+)?)/,
                        "Firefox iOS": /FxiOS\/(\d+(\.\d+)?)/,
                        Konqueror: /Konqueror:(\d+(\.\d+)?)/,
                        BlackBerry: /BlackBerry (\d+(\.\d+)?)/,
                        "Android Mobile": /android\s(\d+(\.\d+)?)/,
                        "Samsung Internet": /SamsungBrowser\/(\d+(\.\d+)?)/,
                        "Internet Explorer": /(rv:|MSIE )(\d+(\.\d+)?)/,
                        Mozilla: /rv:(\d+(\.\d+)?)/
                    }[i3.info.browser(e, t, r)];
                    if (void 0 === n) return null;
                    var i = e.match(n);
                    return i ? parseFloat(i[i.length - 2]) : null
                },
                os: function() {
                    if (/Windows/i.test(iH)) return /Phone/.test(iH) || /WPDesktop/.test(iH) ? "Windows Phone" : "Windows";
                    if (/(iPhone|iPad|iPod)/.test(iH)) return "iOS";
                    if (/Android/.test(iH)) return "Android";
                    if (/(BlackBerry|PlayBook|BB10)/i.test(iH)) return "BlackBerry";
                    if (/Mac/i.test(iH)) return "Mac OS X";
                    else if (/Linux/.test(iH)) return "Linux";
                    else if (/CrOS/.test(iH)) return "Chrome OS";
                    else return ""
                },
                device: function(e) {
                    if (/Windows Phone/i.test(e) || /WPDesktop/.test(e)) return "Windows Phone";
                    if (/iPad/.test(e)) return "iPad";
                    if (/iPod/.test(e)) return "iPod Touch";
                    if (/iPhone/.test(e)) return "iPhone";
                    if (/(BlackBerry|PlayBook|BB10)/i.test(e)) return "BlackBerry";
                    else if (/Android/.test(e)) return "Android";
                    else return ""
                },
                referringDomain: function(e) {
                    var t = e.split("/");
                    return t.length >= 3 ? t[2] : ""
                },
                currentUrl: function() {
                    return n4.location.href
                },
                properties: function(e) {
                    return "object" != typeof e && (e = {}), i3.extend(i3.strip_empty_properties({
                        $os: i3.info.os(),
                        $browser: i3.info.browser(iH, iG.vendor, iZ),
                        $referrer: iY.referrer,
                        $referring_domain: i3.info.referringDomain(iY.referrer),
                        $device: i3.info.device(iH)
                    }), {
                        $current_url: i3.info.currentUrl(),
                        $browser_version: i3.info.browserVersion(iH, iG.vendor, iZ),
                        $screen_height: iJ.height,
                        $screen_width: iJ.width,
                        mp_lib: "web",
                        $lib_version: iU.LIB_VERSION,
                        $insert_id: oc(),
                        time: i3.timestamp() / 1e3
                    }, i3.strip_empty_properties(e))
                },
                people_properties: function() {
                    return i3.extend(i3.strip_empty_properties({
                        $os: i3.info.os(),
                        $browser: i3.info.browser(iH, iG.vendor, iZ)
                    }), {
                        $browser_version: i3.info.browserVersion(iH, iG.vendor, iZ)
                    })
                },
                mpPageViewProperties: function() {
                    return i3.strip_empty_properties({
                        current_page_title: iY.title,
                        current_domain: n4.location.hostname,
                        current_url_path: n4.location.pathname,
                        current_url_protocol: n4.location.protocol,
                        current_url_search: n4.location.search
                    })
                }
            };
            var oa = function(e, t) {
                    var r = null,
                        i = [];
                    return function(o) {
                        var s = this;
                        return i.push(o), r || (r = new n(function(n) {
                            setTimeout(function() {
                                var t = e.apply(s, [i]);
                                r = null, i = [], n(t)
                            }, t)
                        })), r
                    }
                },
                oc = function(e) {
                    var t = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
                    return e ? t.substring(0, e) : t
                },
                ou = /[a-z0-9][a-z0-9-]*\.[a-z]+$/i,
                ol = /[a-z0-9][a-z0-9-]+\.[a-z.]{2,6}$/i,
                op = function(e) {
                    var t = ol,
                        r = e.split("."),
                        n = r[r.length - 1];
                    (n.length > 4 || "com" === n || "org" === n) && (t = ou);
                    var i = e.match(t);
                    return i ? i[0] : ""
                },
                oh = function() {
                    var e = n4.navigator.onLine;
                    return i3.isUndefined(e) || e
                },
                of = function() {},
                od = null,
                om = null;
            "undefined" != typeof JSON && (od = JSON.stringify, om = JSON.parse), od = od || i3.JSONEncode, om = om || i3.JSONDecode, i3.info = i3.info, i3.info.browser = i3.info.browser, i3.info.browserVersion = i3.info.browserVersion, i3.info.device = i3.info.device, i3.info.properties = i3.info.properties, i3.isBlockedUA = i3.isBlockedUA, i3.isEmptyObject = i3.isEmptyObject, i3.isObject = i3.isObject, i3.JSONDecode = i3.JSONDecode, i3.JSONEncode = i3.JSONEncode, i3.toArray = i3.toArray, i3.NPO = iL;
            var og = "mixpanelRecordingEvents",
                ov = "mixpanelRecordingRegistry",
                oy = [og, ov],
                o_ = function(e) {
                    this.dbPromise = null, this.storeName = e
                };

            function ob(e, t) {
                oA(!0, e, t)
            }

            function ow(e, t) {
                oA(!1, e, t)
            }

            function ok(e, t) {
                return "1" === oR(e, t)
            }

            function oS(e, t) {
                if (function(e) {
                        if (e && e.ignoreDnt) return !1;
                        var t = e && e.window || n4,
                            r = t.navigator || {},
                            n = !1;
                        return i3.each([r.doNotTrack, r.msDoNotTrack, t.doNotTrack], function(e) {
                            i3.includes([!0, 1, "1", "yes"], e) && (n = !0)
                        }), n
                    }(t)) return i9.warn('This browser has "Do Not Track" enabled. This will prevent the Mixpanel SDK from sending any data. To ignore the "Do Not Track" browser setting, initialize the Mixpanel instance with the config "ignore_dnt: true"'), !0;
                var r = "0" === oR(e, t);
                return r && i9.warn("You are opted out of Mixpanel tracking. This will prevent the Mixpanel SDK from sending any data."), r
            }

            function oC(e) {
                return oT(e, function(e) {
                    return this.get_config(e)
                })
            }

            function oI(e) {
                return oT(e, function(e) {
                    return this._get_config(e)
                })
            }

            function ox(e) {
                return oT(e, function(e) {
                    return this._get_config(e)
                })
            }

            function oO(e, t) {
                oE(t = t || {}).remove(oM(e, t), !!t.crossSubdomainCookie, t.cookieDomain)
            }

            function oE(e) {
                return "localStorage" === (e = e || {}).persistenceType ? i3.localStorage : i3.cookie
            }

            function oM(e, t) {
                return ((t = t || {}).persistencePrefix || "__mp_opt_in_out_") + e
            }

            function oR(e, t) {
                return oE(t).get(oM(e, t))
            }

            function oA(e, t, r) {
                if (!i3.isString(t) || !t.length) return void i9.error("gdpr." + (e ? "optIn" : "optOut") + " called with an invalid token");
                oE(r = r || {}).set(oM(t, r), +!!e, i3.isNumber(r.cookieExpiration) ? r.cookieExpiration : null, !!r.crossSubdomainCookie, !!r.secureCookie, !!r.crossSiteCookie, r.cookieDomain), r.track && e && r.track(r.trackEventName || "$opt_in", r.trackProperties, {
                    send_immediately: !0
                })
            }

            function oT(e, t) {
                return function() {
                    var r = !1;
                    try {
                        var n = t.call(this, "token"),
                            i = t.call(this, "ignore_dnt"),
                            o = t.call(this, "opt_out_tracking_persistence_type"),
                            s = t.call(this, "opt_out_tracking_cookie_prefix"),
                            a = t.call(this, "window");
                        n && (r = oS(n, {
                            ignoreDnt: i,
                            persistenceType: o,
                            persistencePrefix: s,
                            window: a
                        }))
                    } catch (e) {
                        i9.error("Unexpected error when checking tracking opt-out status: " + e)
                    }
                    if (!r) return e.apply(this, arguments);
                    var c = arguments[arguments.length - 1];
                    "function" == typeof c && c(0)
                }
            }
            o_.prototype._openDb = function() {
                return new n(function(e, t) {
                    var r = n4.indexedDB.open("mixpanelBrowserDb", 1);
                    r.onerror = function() {
                        t(r.error)
                    }, r.onsuccess = function() {
                        e(r.result)
                    }, r.onupgradeneeded = function(e) {
                        var t = e.target.result;
                        oy.forEach(function(e) {
                            t.createObjectStore(e)
                        })
                    }
                })
            }, o_.prototype.init = function() {
                return n4.indexedDB ? (this.dbPromise || (this.dbPromise = this._openDb()), this.dbPromise.then(function(e) {
                    return e instanceof n4.IDBDatabase ? n.resolve() : n.reject(e)
                })) : n.reject("indexedDB is not supported in this browser")
            }, o_.prototype.makeTransaction = function(e, t) {
                var r = this.storeName,
                    i = function(i) {
                        return new n(function(n, o) {
                            var s = i.transaction(r, e);
                            s.oncomplete = function() {
                                n(s)
                            }, s.onabort = s.onerror = function() {
                                o(s.error)
                            }, t(s.objectStore(r))
                        })
                    };
                return this.dbPromise.then(i).catch((function(e) {
                    return e && "InvalidStateError" === e.name ? (this.dbPromise = this._openDb(), this.dbPromise.then(i)) : n.reject(e)
                }).bind(this))
            }, o_.prototype.setItem = function(e, t) {
                return this.makeTransaction("readwrite", function(r) {
                    r.put(t, e)
                })
            }, o_.prototype.getItem = function(e) {
                var t;
                return this.makeTransaction("readonly", function(r) {
                    t = r.get(e)
                }).then(function() {
                    return t.result
                })
            }, o_.prototype.removeItem = function(e) {
                return this.makeTransaction("readwrite", function(t) {
                    t.delete(e)
                })
            }, o_.prototype.getAll = function() {
                var e;
                return this.makeTransaction("readonly", function(t) {
                    e = t.getAll()
                }).then(function() {
                    return e.result
                })
            };
            var oN = i5("lock"),
                oP = function(e, t) {
                    t = t || {}, this.storageKey = e, this.storage = t.storage || n4.localStorage, this.pollIntervalMS = t.pollIntervalMS || 100, this.timeoutMS = t.timeoutMS || 2e3, this.promiseImpl = t.promiseImpl || n
                };
            oP.prototype.withLock = function(e, t) {
                return new this.promiseImpl(i3.bind(function(r, n) {
                    var i = t || new Date().getTime() + "|" + Math.random(),
                        o = new Date().getTime(),
                        s = this.storageKey,
                        a = this.pollIntervalMS,
                        c = this.timeoutMS,
                        u = this.storage,
                        l = s + ":X",
                        p = s + ":Y",
                        h = s + ":Z",
                        f = function(e) {
                            if (new Date().getTime() - o > c) {
                                oN.error("Timeout waiting for mutex on " + s + "; clearing lock. [" + i + "]"), u.removeItem(h), u.removeItem(p), g();
                                return
                            }
                            setTimeout(function() {
                                try {
                                    e()
                                } catch (e) {
                                    n(e)
                                }
                            }, a * (Math.random() + .1))
                        },
                        d = function(e, t) {
                            e() ? t() : f(function() {
                                d(e, t)
                            })
                        },
                        m = function() {
                            var e = u.getItem(p);
                            return (!e || e === i) && (u.setItem(p, i), u.getItem(p) === i || (ot(u, !0) || n(Error("localStorage support dropped while acquiring lock")), !1))
                        },
                        g = function() {
                            u.setItem(l, i), d(m, function() {
                                if (u.getItem(l) === i) return void v();
                                f(function() {
                                    if (u.getItem(p) !== i) return void g();
                                    d(function() {
                                        return !u.getItem(h)
                                    }, v)
                                })
                            })
                        },
                        v = function() {
                            u.setItem(h, "1");
                            var t = function() {
                                u.removeItem(h), u.getItem(p) === i && u.removeItem(p), u.getItem(l) === i && u.removeItem(l)
                            };
                            e().then(function(e) {
                                t(), r(e)
                            }).catch(function(e) {
                                t(), n(e)
                            })
                        };
                    try {
                        if (ot(u, !0)) g();
                        else throw Error("localStorage support check failed")
                    } catch (e) {
                        n(e)
                    }
                }, this))
            };
            var oD = function(e) {
                this.storage = e || n4.localStorage
            };
            oD.prototype.init = function() {
                return n.resolve()
            }, oD.prototype.setItem = function(e, t) {
                return new n(i3.bind(function(r, n) {
                    try {
                        this.storage.setItem(e, od(t))
                    } catch (e) {
                        n(e)
                    }
                    r()
                }, this))
            }, oD.prototype.getItem = function(e) {
                return new n(i3.bind(function(t, r) {
                    var n;
                    try {
                        n = om(this.storage.getItem(e))
                    } catch (e) {
                        r(e)
                    }
                    t(n)
                }, this))
            }, oD.prototype.removeItem = function(e) {
                return new n(i3.bind(function(t, r) {
                    try {
                        this.storage.removeItem(e)
                    } catch (e) {
                        r(e)
                    }
                    t()
                }, this))
            };
            var oL = i5("batch"),
                oF = function(e, t) {
                    t = t || {}, this.storageKey = e, this.usePersistence = t.usePersistence, this.usePersistence && (this.queueStorage = t.queueStorage || new oD, this.lock = new oP(e, {
                        storage: t.sharedLockStorage || n4.localStorage,
                        timeoutMS: t.sharedLockTimeoutMS
                    })), this.reportError = t.errorReporter || i3.bind(oL.error, oL), this.pid = t.pid || null, this.memQueue = [], this.initialized = !1, t.enqueueThrottleMs ? this.enqueuePersisted = oa(i3.bind(this._enqueuePersisted, this), t.enqueueThrottleMs) : this.enqueuePersisted = i3.bind(function(e) {
                        return this._enqueuePersisted([e])
                    }, this)
                };
            oF.prototype.ensureInit = function() {
                return this.initialized ? n.resolve() : this.queueStorage.init().then(i3.bind(function() {
                    this.initialized = !0
                }, this)).catch(i3.bind(function(e) {
                    this.reportError("Error initializing queue persistence. Disabling persistence", e), this.initialized = !0, this.usePersistence = !1
                }, this))
            }, oF.prototype.enqueue = function(e, t) {
                var r = {
                    id: oc(),
                    flushAfter: new Date().getTime() + 2 * t,
                    payload: e
                };
                return this.usePersistence ? this.enqueuePersisted(r) : (this.memQueue.push(r), n.resolve(!0))
            }, oF.prototype._enqueuePersisted = function(e) {
                var t = i3.bind(function() {
                    return this.ensureInit().then(i3.bind(function() {
                        return this.readFromStorage()
                    }, this)).then(i3.bind(function(t) {
                        return this.saveToStorage(t.concat(e))
                    }, this)).then(i3.bind(function(t) {
                        return t && (this.memQueue = this.memQueue.concat(e)), t
                    }, this)).catch(i3.bind(function(t) {
                        return this.reportError("Error enqueueing items", t, e), !1
                    }, this))
                }, this);
                return this.lock.withLock(t, this.pid).catch(i3.bind(function(e) {
                    return this.reportError("Error acquiring storage lock", e), !1
                }, this))
            }, oF.prototype.fillBatch = function(e) {
                var t = this.memQueue.slice(0, e);
                return this.usePersistence && t.length < e ? this.ensureInit().then(i3.bind(function() {
                    return this.readFromStorage()
                }, this)).then(i3.bind(function(r) {
                    if (r.length) {
                        var n = {};
                        i3.each(t, function(e) {
                            n[e.id] = !0
                        });
                        for (var i = 0; i < r.length; i++) {
                            var o = r[i];
                            if (new Date().getTime() > o.flushAfter && !n[o.id] && (o.orphaned = !0, t.push(o), t.length >= e)) break
                        }
                    }
                    return t
                }, this)) : n.resolve(t)
            };
            var oU = function(e, t) {
                var r = [];
                return i3.each(e, function(e) {
                    e.id && !t[e.id] && r.push(e)
                }), r
            };
            oF.prototype.removeItemsByID = function(e) {
                var t = {};
                if (i3.each(e, function(e) {
                        t[e] = !0
                    }), this.memQueue = oU(this.memQueue, t), !this.usePersistence) return n.resolve(!0);
                var r = i3.bind(function() {
                    return this.ensureInit().then(i3.bind(function() {
                        return this.readFromStorage()
                    }, this)).then(i3.bind(function(e) {
                        return e = oU(e, t), this.saveToStorage(e)
                    }, this)).then(i3.bind(function() {
                        return this.readFromStorage()
                    }, this)).then(i3.bind(function(e) {
                        for (var r = 0; r < e.length; r++) {
                            var n = e[r];
                            if (n.id && t[n.id]) throw Error("Item not removed from storage")
                        }
                        return !0
                    }, this)).catch(i3.bind(function(t) {
                        return this.reportError("Error removing items", t, e), !1
                    }, this))
                }, this);
                return this.lock.withLock(r, this.pid).catch(i3.bind(function(e) {
                    return this.reportError("Error acquiring storage lock", e), !ot(this.lock.storage, !0) && r().then(i3.bind(function(e) {
                        return e || this.queueStorage.removeItem(this.storageKey).then(function() {
                            return e
                        })
                    }, this)).catch(i3.bind(function(e) {
                        return this.reportError("Error clearing queue", e), !1
                    }, this))
                }, this))
            };
            var oB = function(e, t) {
                var r = [];
                return i3.each(e, function(e) {
                    var n = e.id;
                    if (n in t) {
                        var i = t[n];
                        null !== i && (e.payload = i, r.push(e))
                    } else r.push(e)
                }), r
            };
            oF.prototype.updatePayloads = function(e) {
                return (this.memQueue = oB(this.memQueue, e), this.usePersistence) ? this.lock.withLock(i3.bind(function() {
                    return this.ensureInit().then(i3.bind(function() {
                        return this.readFromStorage()
                    }, this)).then(i3.bind(function(t) {
                        return t = oB(t, e), this.saveToStorage(t)
                    }, this)).catch(i3.bind(function(t) {
                        return this.reportError("Error updating items", e, t), !1
                    }, this))
                }, this), this.pid).catch(i3.bind(function(e) {
                    return this.reportError("Error acquiring storage lock", e), !1
                }, this)) : n.resolve(!0)
            }, oF.prototype.readFromStorage = function() {
                return this.ensureInit().then(i3.bind(function() {
                    return this.queueStorage.getItem(this.storageKey)
                }, this)).then(i3.bind(function(e) {
                    return e && !i3.isArray(e) && (this.reportError("Invalid storage entry:", e), e = null), e || []
                }, this)).catch(i3.bind(function(e) {
                    return this.reportError("Error retrieving queue", e), []
                }, this))
            }, oF.prototype.saveToStorage = function(e) {
                return this.ensureInit().then(i3.bind(function() {
                    return this.queueStorage.setItem(this.storageKey, e)
                }, this)).then(function() {
                    return !0
                }).catch(i3.bind(function(e) {
                    return this.reportError("Error saving queue", e), !1
                }, this))
            }, oF.prototype.clear = function() {
                return (this.memQueue = [], this.usePersistence) ? this.ensureInit().then(i3.bind(function() {
                    return this.queueStorage.removeItem(this.storageKey)
                }, this)) : n.resolve()
            };
            var oj = i5("batch"),
                oq = function(e, t) {
                    this.errorReporter = t.errorReporter, this.queue = new oF(e, {
                        errorReporter: i3.bind(this.reportError, this),
                        queueStorage: t.queueStorage,
                        sharedLockStorage: t.sharedLockStorage,
                        sharedLockTimeoutMS: t.sharedLockTimeoutMS,
                        usePersistence: t.usePersistence,
                        enqueueThrottleMs: t.enqueueThrottleMs
                    }), this.libConfig = t.libConfig, this.sendRequest = t.sendRequestFunc, this.beforeSendHook = t.beforeSendHook, this.stopAllBatching = t.stopAllBatchingFunc, this.batchSize = this.libConfig.batch_size, this.flushInterval = this.libConfig.batch_flush_interval_ms, this.stopped = !this.libConfig.batch_autostart, this.consecutiveRemovalFailures = 0, this.itemIdsSentSuccessfully = {}, this.flushOnlyOnInterval = t.flushOnlyOnInterval || !1, this._flushPromise = null
                };
            oq.prototype.enqueue = function(e) {
                return this.queue.enqueue(e, this.flushInterval)
            }, oq.prototype.start = function() {
                return this.stopped = !1, this.consecutiveRemovalFailures = 0, this.flush()
            }, oq.prototype.stop = function() {
                this.stopped = !0, this.timeoutID && (clearTimeout(this.timeoutID), this.timeoutID = null)
            }, oq.prototype.clear = function() {
                return this.queue.clear()
            }, oq.prototype.resetBatchSize = function() {
                this.batchSize = this.libConfig.batch_size
            }, oq.prototype.resetFlush = function() {
                this.scheduleFlush(this.libConfig.batch_flush_interval_ms)
            }, oq.prototype.scheduleFlush = function(e) {
                this.flushInterval = e, this.stopped || (this.timeoutID = setTimeout(i3.bind(function() {
                    this.stopped || (this._flushPromise = this.flush())
                }, this), this.flushInterval))
            }, oq.prototype.sendRequestPromise = function(e, t) {
                return new n(i3.bind(function(r) {
                    this.sendRequest(e, t, r)
                }, this))
            }, oq.prototype.flush = function(e) {
                if (this.requestInProgress) return oj.log("Flush: Request already in progress"), n.resolve();
                this.requestInProgress = !0, e = e || {};
                var t = this.libConfig.batch_request_timeout_ms,
                    r = new Date().getTime(),
                    i = this.batchSize;
                return this.queue.fillBatch(i).then(i3.bind(function(o) {
                    var s = o.length === i,
                        a = [],
                        c = {};
                    if (i3.each(o, function(e) {
                            var t = e.payload;
                            if (this.beforeSendHook && !e.orphaned && (t = this.beforeSendHook(t)), t) {
                                t.event && t.properties && (t.properties = i3.extend({}, t.properties, {
                                    mp_sent_by_lib_version: iU.LIB_VERSION
                                }));
                                var r = !0,
                                    n = e.id;
                                n ? (this.itemIdsSentSuccessfully[n] || 0) > 5 && (this.reportError("[dupe] item ID sent too many times, not sending", {
                                    item: e,
                                    batchSize: o.length,
                                    timesSent: this.itemIdsSentSuccessfully[n]
                                }), r = !1) : this.reportError("[dupe] found item with no ID", {
                                    item: e
                                }), r && a.push(t)
                            }
                            c[e.id] = t
                        }, this), a.length < 1) return this.requestInProgress = !1, this.resetFlush(), n.resolve();
                    var u = i3.bind(function() {
                            return this.queue.removeItemsByID(i3.map(o, function(e) {
                                return e.id
                            })).then(i3.bind(function(e) {
                                return (i3.each(o, i3.bind(function(e) {
                                    var t = e.id;
                                    t ? (this.itemIdsSentSuccessfully[t] = this.itemIdsSentSuccessfully[t] || 0, this.itemIdsSentSuccessfully[t]++, this.itemIdsSentSuccessfully[t] > 5 && this.reportError("[dupe] item ID sent too many times", {
                                        item: e,
                                        batchSize: o.length,
                                        timesSent: this.itemIdsSentSuccessfully[t]
                                    })) : this.reportError("[dupe] found item with no ID while removing", {
                                        item: e
                                    })
                                }, this)), e) ? (this.consecutiveRemovalFailures = 0, this.flushOnlyOnInterval && !s) ? (this.resetFlush(), n.resolve()) : this.flush() : (++this.consecutiveRemovalFailures > 5 ? (this.reportError("Too many queue failures; disabling batching system."), this.stopAllBatching()) : this.resetFlush(), n.resolve())
                            }, this))
                        }, this),
                        l = i3.bind(function(s) {
                            this.requestInProgress = !1;
                            try {
                                if (e.unloading) return this.queue.updatePayloads(c);
                                if (i3.isObject(s) && "timeout" === s.error && new Date().getTime() - r >= t) return this.reportError("Network timeout; retrying"), this.flush();
                                if (i3.isObject(s) && (s.httpStatusCode >= 500 || 429 === s.httpStatusCode || s.httpStatusCode <= 0 && !oh() || "timeout" === s.error)) {
                                    var a = 2 * this.flushInterval;
                                    return s.retryAfter && (a = 1e3 * parseInt(s.retryAfter, 10) || a), a = Math.min(6e5, a), this.reportError("Error; retry in " + a + " ms"), this.scheduleFlush(a), n.resolve()
                                } else {
                                    if (!i3.isObject(s) || 413 !== s.httpStatusCode) return u();
                                    if (!(o.length > 1)) return this.reportError("Single-event request too large; dropping", o), this.resetBatchSize(), u();
                                    var l = Math.max(1, Math.floor(i / 2));
                                    return this.batchSize = Math.min(this.batchSize, l, o.length - 1), this.reportError("413 response; reducing batch size to " + this.batchSize), this.resetFlush(), n.resolve()
                                }
                            } catch (e) {
                                this.reportError("Error handling API response", e), this.resetFlush()
                            }
                        }, this),
                        p = {
                            method: "POST",
                            verbose: !0,
                            ignore_json_errors: !0,
                            timeout_ms: t
                        };
                    return e.unloading && (p.transport = "sendBeacon"), oj.log("MIXPANEL REQUEST:", a), this.sendRequestPromise(a, p).then(l)
                }, this)).catch(i3.bind(function(e) {
                    this.reportError("Error flushing request queue", e), this.resetFlush()
                }, this))
            }, oq.prototype.reportError = function(e, t) {
                if (oj.error.apply(oj.error, arguments), this.errorReporter) try {
                    t instanceof Error || (t = Error(e)), this.errorReporter(e, t)
                } catch (e) {
                    oj.error(e)
                }
            };
            var oz = function(e) {
                    var t = Date.now();
                    return !e || t > e.maxExpires || t > e.idleExpires
                },
                oW = i5("recorder"),
                oV = n4.CompressionStream,
                o$ = {
                    batch_size: 1e3,
                    batch_flush_interval_ms: 1e4,
                    batch_request_timeout_ms: 9e4,
                    batch_autostart: !0
                },
                oG = new Set([np.MouseMove, np.MouseInteraction, np.Scroll, np.ViewportResize, np.Input, np.TouchMove, np.MediaInteraction, np.Drag, np.Selection]),
                oY = function(e) {
                    this._mixpanel = e.mixpanelInstance, this._onIdleTimeout = e.onIdleTimeout || of , this._onMaxLengthReached = e.onMaxLengthReached || of , this._onBatchSent = e.onBatchSent || of , this._rrwebRecord = e.rrwebRecord || null, this._stopRecording = null, this.replayId = e.replayId, this.batchStartUrl = e.batchStartUrl || null, this.replayStartUrl = e.replayStartUrl || null, this.idleExpires = e.idleExpires || null, this.maxExpires = e.maxExpires || null, this.replayStartTime = e.replayStartTime || null, this.seqNo = e.seqNo || 0, this.idleTimeoutId = null, this.maxTimeoutId = null, this.recordMaxMs = 864e5, this.recordMinMs = 0;
                    var t = ot(e.sharedLockStorage, !0);
                    this.batcherKey = "__mprec_" + this.getConfig("name") + "_" + this.getConfig("token") + "_" + this.replayId, this.queueStorage = new o_(og), this.batcher = new oq(this.batcherKey, {
                        errorReporter: this.reportError.bind(this),
                        flushOnlyOnInterval: !0,
                        libConfig: o$,
                        sendRequestFunc: this.flushEventsWithOptOut.bind(this),
                        queueStorage: this.queueStorage,
                        sharedLockStorage: e.sharedLockStorage,
                        usePersistence: t,
                        stopAllBatchingFunc: this.stopRecording.bind(this),
                        enqueueThrottleMs: 250,
                        sharedLockTimeoutMS: 1e4
                    })
                };
            oY.prototype.unloadPersistedData = function() {
                return this.batcher.stop(), this.batcher.flush().then((function() {
                    return this.queueStorage.removeItem(this.batcherKey)
                }).bind(this))
            }, oY.prototype.getConfig = function(e) {
                return this._mixpanel.get_config(e)
            }, oY.prototype.get_config = function(e) {
                return this.getConfig(e)
            }, oY.prototype.startRecording = function(e) {
                if (null === this._rrwebRecord) return void this.reportError("rrweb record function not provided. ");
                if (null !== this._stopRecording) return void oW.log("Recording already in progress, skipping startRecording.");
                this.recordMaxMs = this.getConfig("record_max_ms"), this.recordMaxMs > 864e5 && (this.recordMaxMs = 864e5, oW.critical("record_max_ms cannot be greater than 86400000ms. Capping value.")), this.maxExpires || (this.maxExpires = new Date().getTime() + this.recordMaxMs), this.recordMinMs = this.getConfig("record_min_ms"), this.recordMinMs > 8e3 && (this.recordMinMs = 8e3, oW.critical("record_min_ms cannot be greater than 8000ms. Capping value.")), this.replayStartTime || (this.replayStartTime = new Date().getTime(), this.batchStartUrl = i3.info.currentUrl(), this.replayStartUrl = i3.info.currentUrl()), e || this.recordMinMs > 0 ? this.batcher.stop() : this.batcher.start();
                var t = (function() {
                    clearTimeout(this.idleTimeoutId);
                    var e = this.getConfig("record_idle_timeout_ms");
                    this.idleTimeoutId = setTimeout(this._onIdleTimeout, e), this.idleExpires = new Date().getTime() + e
                }).bind(this);
                t();
                var r = this.getConfig("record_block_selector");
                ("" === r || null === r) && (r = void 0);
                try {
                    this._stopRecording = this._rrwebRecord({
                        emit: (function(e) {
                            if (this.idleExpires && this.idleExpires < e.timestamp) return void this._onIdleTimeout();
                            e.type === nl.IncrementalSnapshot && oG.has(e.data.source) && (this.batcher.stopped && new Date().getTime() - this.replayStartTime >= this.recordMinMs && this.batcher.start(), t()), this.__enqueuePromise = this.batcher.enqueue(e)
                        }).bind(this),
                        blockClass: this.getConfig("record_block_class"),
                        blockSelector: r,
                        collectFonts: this.getConfig("record_collect_fonts"),
                        dataURLOptions: {
                            type: "image/webp",
                            quality: .6
                        },
                        maskAllInputs: !0,
                        maskTextClass: this.getConfig("record_mask_text_class"),
                        maskTextSelector: this.getConfig("record_mask_text_selector"),
                        recordCanvas: this.getConfig("record_canvas"),
                        sampling: {
                            canvas: 15
                        }
                    })
                } catch (e) {
                    this.reportError("Unexpected error when starting rrweb recording.", e)
                }
                if ("function" != typeof this._stopRecording) {
                    this.reportError("rrweb failed to start, skipping this recording."), this._stopRecording = null, this.stopRecording();
                    return
                }
                var n = this.maxExpires - new Date().getTime();
                this.maxTimeoutId = setTimeout(this._onMaxLengthReached.bind(this), n)
            }, oY.prototype.stopRecording = function(e) {
                var t;
                if (!this.isRrwebStopped()) {
                    try {
                        this._stopRecording()
                    } catch (e) {
                        this.reportError("Error with rrweb stopRecording", e)
                    }
                    this._stopRecording = null
                }
                return this.batcher.stopped ? t = this.batcher.clear() : e || (t = this.batcher.flush()), this.batcher.stop(), clearTimeout(this.idleTimeoutId), clearTimeout(this.maxTimeoutId), t
            }, oY.prototype.isRrwebStopped = function() {
                return null === this._stopRecording
            }, oY.prototype.flushEventsWithOptOut = function(e, t, r) {
                var n = (function(e) {
                    0 === e && (this.stopRecording(), r({
                        error: "Tracking has been opted out, stopping recording."
                    }))
                }).bind(this);
                this._flushEvents(e, t, r, n)
            }, oY.prototype.serialize = function() {
                var e;
                try {
                    e = this._mixpanel.get_tab_id()
                } catch (t) {
                    this.reportError("Error getting tab ID for serialization ", t), e = null
                }
                return {
                    replayId: this.replayId,
                    seqNo: this.seqNo,
                    replayStartTime: this.replayStartTime,
                    batchStartUrl: this.batchStartUrl,
                    replayStartUrl: this.replayStartUrl,
                    idleExpires: this.idleExpires,
                    maxExpires: this.maxExpires,
                    tabId: e
                }
            }, oY.deserialize = function(e, t) {
                return new oY(i3.extend({}, t, {
                    replayId: e.replayId,
                    batchStartUrl: e.batchStartUrl,
                    replayStartUrl: e.replayStartUrl,
                    idleExpires: e.idleExpires,
                    maxExpires: e.maxExpires,
                    replayStartTime: e.replayStartTime,
                    seqNo: e.seqNo,
                    sharedLockStorage: t.sharedLockStorage
                }))
            }, oY.prototype._sendRequest = function(e, t, r, n) {
                var i = (function(t, r) {
                    200 === t.status && this.replayId === e && (this.seqNo++, this.batchStartUrl = i3.info.currentUrl()), this._onBatchSent(), n({
                        status: 0,
                        httpStatusCode: t.status,
                        responseBody: r,
                        retryAfter: t.headers.get("Retry-After")
                    })
                }).bind(this);
                n4.fetch(this.getConfig("api_host") + "/" + this.getConfig("api_routes").record + "?" + new URLSearchParams(t), {
                    method: "POST",
                    headers: {
                        Authorization: "Basic " + btoa(this.getConfig("token") + ":"),
                        "Content-Type": "application/octet-stream"
                    },
                    body: r
                }).then(function(e) {
                    e.json().then(function(t) {
                        i(e, t)
                    }).catch(function(e) {
                        n({
                            error: e
                        })
                    })
                }).catch(function(e) {
                    n({
                        error: e,
                        httpStatusCode: 0
                    })
                })
            }, oY.prototype._flushEvents = oC(function(e, t, r) {
                var n = e.length;
                if (n > 0) {
                    for (var i = this.replayId, o = 1 / 0, s = -1 / 0, a = !1, c = 0; c < n; c++) o = Math.min(o, e[c].timestamp), s = Math.max(s, e[c].timestamp), e[c].type === nl.FullSnapshot && (a = !0);
                    if (0 === this.seqNo) {
                        if (!a) {
                            r({
                                error: "First batch does not contain a full snapshot. Aborting recording."
                            }), this.stopRecording(!0);
                            return
                        }
                        this.replayStartTime = o
                    } else this.replayStartTime || (this.reportError("Replay start time not set but seqNo is not 0. Using current batch start time as a fallback."), this.replayStartTime = o);
                    var u = s - this.replayStartTime,
                        l = {
                            $current_url: this.batchStartUrl,
                            $lib_version: iU.LIB_VERSION,
                            batch_start_time: o / 1e3,
                            distinct_id: String(this._mixpanel.get_distinct_id()),
                            mp_lib: "web",
                            replay_id: i,
                            replay_length_ms: u,
                            replay_start_time: this.replayStartTime / 1e3,
                            replay_start_url: this.replayStartUrl,
                            seq: this.seqNo
                        },
                        p = JSON.stringify(e),
                        h = this._mixpanel.get_property("$device_id");
                    h && (l.$device_id = h);
                    var f = this._mixpanel.get_property("$user_id");
                    f && (l.$user_id = f), oV ? new Response(new Blob([p], {
                        type: "application/json"
                    }).stream().pipeThrough(new oV("gzip"))).blob().then((function(e) {
                        l.format = "gzip", this._sendRequest(i, l, e, r)
                    }).bind(this)) : (l.format = "body", this._sendRequest(i, l, p, r))
                }
            }), oY.prototype.reportError = function(e, t) {
                oW.error.apply(oW.error, arguments);
                try {
                    t || e instanceof Error || (e = Error(e)), this.getConfig("error_reporter")(e, t)
                } catch (e) {
                    oW.error(e)
                }
            };
            var oZ = function(e) {
                this.idb = new o_(ov), this.errorReporter = e.errorReporter, this.mixpanelInstance = e.mixpanelInstance, this.sharedLockStorage = e.sharedLockStorage
            };
            oZ.prototype.handleError = function(e) {
                this.errorReporter("IndexedDB error: ", e)
            }, oZ.prototype.setActiveRecording = function(e) {
                var t = e.tabId;
                return t ? this.idb.init().then((function() {
                    return this.idb.setItem(t, e)
                }).bind(this)).catch(this.handleError.bind(this)) : (console.warn("No tab ID is set, cannot persist recording metadata."), n.resolve())
            }, oZ.prototype.getActiveRecording = function() {
                return this.idb.init().then((function() {
                    return this.idb.getItem(this.mixpanelInstance.get_tab_id())
                }).bind(this)).then((function(e) {
                    return oz(e) ? null : e
                }).bind(this)).catch(this.handleError.bind(this))
            }, oZ.prototype.clearActiveRecording = function() {
                return this.getActiveRecording().then((function(e) {
                    if (e) return e.maxExpires = 0, this.setActiveRecording(e)
                }).bind(this)).catch(this.handleError.bind(this))
            }, oZ.prototype.flushInactiveRecordings = function() {
                return this.idb.init().then((function() {
                    return this.idb.getAll()
                }).bind(this)).then((function(e) {
                    var t = e.filter(function(e) {
                        return oz(e)
                    }).map((function(e) {
                        return oY.deserialize(e, {
                            mixpanelInstance: this.mixpanelInstance,
                            sharedLockStorage: this.sharedLockStorage
                        }).unloadPersistedData().then((function() {
                            return this.idb.removeItem(e.tabId)
                        }).bind(this)).catch(this.handleError.bind(this))
                    }).bind(this));
                    return n.all(t)
                }).bind(this)).catch(this.handleError.bind(this))
            };
            var oJ = i5("recorder"),
                oH = function(e, t, r) {
                    this.mixpanelInstance = e, this.rrwebRecord = t || n9, this.sharedLockStorage = r, this.recordingRegistry = new oZ({
                        mixpanelInstance: this.mixpanelInstance,
                        errorReporter: oJ.error,
                        sharedLockStorage: r
                    }), this._flushInactivePromise = this.recordingRegistry.flushInactiveRecordings(), this.activeRecording = null
                };
            oH.prototype.startRecording = function(e) {
                if (e = e || {}, this.activeRecording && !this.activeRecording.isRrwebStopped()) return void oJ.log("Recording already in progress, skipping startRecording.");
                var t = (function() {
                        oJ.log("Idle timeout reached, restarting recording."), this.resetRecording()
                    }).bind(this),
                    r = (function() {
                        oJ.log("Max recording length reached, stopping recording."), this.resetRecording()
                    }).bind(this),
                    n = (function() {
                        this.recordingRegistry.setActiveRecording(this.activeRecording.serialize()), this.__flushPromise = this.activeRecording.batcher._flushPromise
                    }).bind(this),
                    i = {
                        mixpanelInstance: this.mixpanelInstance,
                        onBatchSent: n,
                        onIdleTimeout: t,
                        onMaxLengthReached: r,
                        replayId: i3.UUID(),
                        rrwebRecord: this.rrwebRecord,
                        sharedLockStorage: this.sharedLockStorage
                    };
                return e.activeSerializedRecording ? this.activeRecording = oY.deserialize(e.activeSerializedRecording, i) : this.activeRecording = new oY(i), this.activeRecording.startRecording(e.shouldStopBatcher), this.recordingRegistry.setActiveRecording(this.activeRecording.serialize())
            }, oH.prototype.stopRecording = function() {
                var e = this._stopCurrentRecording(!1);
                return this.recordingRegistry.clearActiveRecording(), this.activeRecording = null, e
            }, oH.prototype.pauseRecording = function() {
                return this._stopCurrentRecording(!1)
            }, oH.prototype._stopCurrentRecording = function(e) {
                return this.activeRecording ? this.activeRecording.stopRecording(e) : n.resolve()
            }, oH.prototype.resumeRecording = function(e) {
                return this.activeRecording && this.activeRecording.isRrwebStopped() ? (this.activeRecording.startRecording(!1), n.resolve(null)) : this.recordingRegistry.getActiveRecording().then((function(t) {
                    return t ? this.startRecording({
                        activeSerializedRecording: t
                    }) : e ? this.startRecording({
                        shouldStopBatcher: !1
                    }) : (oJ.log("No resumable recording found."), null)
                }).bind(this))
            }, oH.prototype.resetRecording = function() {
                this.stopRecording(), this.startRecording({
                    shouldStopBatcher: !0
                })
            }, oH.prototype.getActiveReplayId = function() {
                return this.activeRecording && !this.activeRecording.isRrwebStopped() ? this.activeRecording.replayId : null
            }, Object.defineProperty(oH.prototype, "replayId", {
                get: function() {
                    return this.getActiveReplayId()
                }
            }), n4.__mp_recorder = oH;
            var oX = "change",
                oK = "click",
                oQ = "hashchange",
                o0 = "mp_locationchange",
                o1 = "popstate",
                o2 = "scrollend",
                o3 = "submit",
                o9 = ["clientX", "clientY", "offsetX", "offsetY", "pageX", "pageY", "screenX", "screenY", "x", "y"],
                o4 = ["mp-include"],
                o5 = ["mp-no-track"],
                o6 = o5.concat(["mp-sensitive"]),
                o8 = ["aria-label", "aria-labelledby", "aria-describedby", "href", "name", "role", "title", "type"],
                o7 = i5("autocapture");

            function se(e) {
                for (var t = {}, r = st(e).split(" "), n = 0; n < r.length; n++) {
                    var i = r[n];
                    i && (t[i] = !0)
                }
                return t
            }

            function st(e) {
                switch (typeof e.className) {
                    case "string":
                        return e.className;
                    case "object":
                        return e.className.baseVal || e.getAttribute("class") || "";
                    default:
                        return ""
                }
            }

            function sr(e, t, r, n, i, o) {
                var s = {
                        $classes: st(e).split(" "),
                        $tag_name: e.tagName.toLowerCase()
                    },
                    a = e.id;
                a && (s.$id = a), su(e, t, i, o) && i3.each(o8.concat(n), function(t) {
                    if (e.hasAttribute(t) && !r[t]) {
                        var n = e.getAttribute(t);
                        sl(n) && (s["$attr-" + t] = n)
                    }
                });
                for (var c = 1, u = 1, l = e; l = function(e) {
                        if (e.previousElementSibling) return e.previousElementSibling;
                        do e = e.previousSibling; while (e && !ss(e));
                        return e
                    }(l);) c++, l.tagName === e.tagName && u++;
                return s.$nth_child = c, s.$nth_of_type = u, s
            }

            function sn(e, t, r, n) {
                var i = "";
                return su(e, t, r, n) && e.childNodes && e.childNodes.length && i3.each(e.childNodes, function(e) {
                    sc(e) && e.textContent && (i += i3.trim(e.textContent).split(/(\s+)/).filter(sl).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255))
                }), i3.trim(i)
            }

            function si(e, t, r, n) {
                if (r) try {
                    if (!r(e, t)) return !1
                } catch (e) {
                    return o7.critical("Error while checking element in allowElementCallback", e), !1
                }
                if (!n.length) return !0;
                for (var i = 0; i < n.length; i++) {
                    var o = n[i];
                    try {
                        if (e.matches(o)) return !0
                    } catch (e) {
                        o7.critical("Error while checking selector: " + o, e)
                    }
                }
                return !1
            }

            function so(e, t, r, n) {
                if (r) try {
                    if (r(e, t)) return !0
                } catch (e) {
                    return o7.critical("Error while checking element in blockElementCallback", e), !0
                }
                if (n && n.length)
                    for (i = 0; i < n.length; i++) {
                        var i, o = n[i];
                        try {
                            if (e.matches(o)) return !0
                        } catch (e) {
                            o7.critical("Error while checking selector: " + o, e)
                        }
                    }
                var s = se(e);
                for (i = 0; i < o5.length; i++)
                    if (s[o5[i]]) return !0;
                return !1
            }

            function ss(e) {
                return e && 1 === e.nodeType
            }

            function sa(e, t) {
                return e && e.tagName && e.tagName.toLowerCase() === t.toLowerCase()
            }

            function sc(e) {
                return e && 3 === e.nodeType
            }

            function su(e, t, r, n) {
                if (!si(e, t, r, n)) return !1;
                for (var i, o = e; o.parentNode && !sa(o, "body"); o = o.parentNode) {
                    var s = se(o);
                    for (i = 0; i < o6.length; i++)
                        if (s[o6[i]]) return !1
                }
                var a = se(e);
                for (i = 0; i < o4.length; i++)
                    if (a[o4[i]]) return !0;
                if (sa(e, "input") || sa(e, "select") || sa(e, "textarea") || "true" === e.getAttribute("contenteditable")) return !1;
                var c = e.type || "";
                if ("string" == typeof c) switch (c.toLowerCase()) {
                    case "hidden":
                    case "password":
                        return !1
                }
                var u = e.name || e.id || "";
                return !("string" == typeof u && /^cc|cardnum|ccnum|creditcard|csc|cvc|cvv|exp|pass|pwd|routing|seccode|securitycode|securitynum|socialsec|socsec|ssn/i.test(u.replace(/[^a-zA-Z0-9]/g, ""))) && !0
            }

            function sl(e) {
                if (null === e || i3.isUndefined(e)) return !1;
                if ("string" == typeof e && (e = i3.trim(e), /^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11}))$/.test((e || "").replace(/[- ]/g, "")) || /(^\d{3}-?\d{2}-?\d{4}$)/.test(e))) return !1;
                return !0
            }
            var sp = "autocapture",
                sh = "full-url",
                sf = "allow_selectors",
                sd = "allow_url_regexes",
                sm = "block_attrs",
                sg = "block_element_callback",
                sv = "block_selectors",
                sy = "block_url_regexes",
                s_ = "capture_extra_attrs",
                sb = "capture_text_content",
                sw = "scroll_capture_all",
                sk = "scroll_depth_percent_checkpoints",
                sS = "click",
                sC = "input",
                sI = "pageview",
                sx = "scroll",
                sO = "submit",
                sE = {};
            sE[sf] = [], sE[sd] = [], sE[sm] = [], sE[sg] = null, sE[sv] = [], sE[sy] = [], sE[s_] = [], sE[sb] = !1, sE[sw] = !1, sE[sk] = [25, 50, 75, 100], sE[sS] = !0, sE[sC] = !0, sE[sI] = sh, sE[sx] = !0, sE[sO] = !0;
            var sM = {
                    $mp_autocapture: !0
                },
                sR = function(e) {
                    this.mp = e
                };
            sR.prototype.init = function() {
                    if (! function() {
                            try {
                                return !!iY.createElement("div").matches
                            } catch (e) {
                                return !1
                            }
                        }()) return void o7.critical("Autocapture unavailable: missing required DOM APIs");
                    this.initPageviewTracking(), this.initClickTracking(), this.initInputTracking(), this.initScrollTracking(), this.initSubmitTracking()
                }, sR.prototype.getFullConfig = function() {
                    var e = this.mp.get_config(sp);
                    return e ? i3.isObject(e) ? i3.extend({}, sE, e) : sE : {}
                }, sR.prototype.getConfig = function(e) {
                    return this.getFullConfig()[e]
                }, sR.prototype.currentUrlBlocked = function() {
                    var e, t = i3.info.currentUrl(),
                        r = this.getConfig(sd) || [];
                    if (r.length) {
                        var n = !1;
                        for (e = 0; e < r.length; e++) {
                            var i = r[e];
                            try {
                                if (t.match(i)) {
                                    n = !0;
                                    break
                                }
                            } catch (e) {
                                return o7.critical("Error while checking block URL regex: " + i, e), !0
                            }
                        }
                        if (!n) return !0
                    }
                    var o = this.getConfig(sy) || [];
                    if (!o || !o.length) return !1;
                    for (e = 0; e < o.length; e++) try {
                        if (t.match(o[e])) return !0
                    } catch (t) {
                        return o7.critical("Error while checking block URL regex: " + o[e], t), !0
                    }
                    return !1
                }, sR.prototype.pageviewTrackingConfig = function() {
                    return this.mp.get_config(sp) ? this.getConfig(sI) : this.mp.get_config("track_pageview")
                }, sR.prototype.trackDomEvent = function(e, t) {
                    if (!this.currentUrlBlocked()) {
                        var r = function(e, t) {
                            var r = t.allowElementCallback,
                                n = t.allowSelectors || [],
                                i = t.blockAttrs || [],
                                o = t.blockElementCallback,
                                s = t.blockSelectors || [],
                                a = t.captureTextContent || !1,
                                c = t.captureExtraAttrs || [],
                                u = {};
                            i3.each(i, function(e) {
                                u[e] = !0
                            });
                            var l = null,
                                p = void 0 === e.target ? e.srcElement : e.target;
                            if (sc(p) && (p = p.parentNode), function(e, t) {
                                    if (!e || sa(e, "html") || !ss(e)) return !1;
                                    switch (e.tagName.toLowerCase()) {
                                        case "form":
                                            return t.type === o3;
                                        case "input":
                                            if (-1 === ["button", "submit"].indexOf(e.getAttribute("type"))) return t.type === oX;
                                            return t.type === oK;
                                        case "select":
                                        case "textarea":
                                            return t.type === oX;
                                        default:
                                            return t.type === oK
                                    }
                                }(p, e) && si(p, e, r, n) && !so(p, e, o, s)) {
                                for (var h = [p], f = p; f.parentNode && !sa(f, "body");) h.push(f.parentNode), f = f.parentNode;
                                var d, m = [],
                                    g = !1;
                                if (i3.each(h, function(t) {
                                        var i = su(t, e, r, n);
                                        u.href || "a" !== t.tagName.toLowerCase() || (d = t.getAttribute("href"), d = i && sl(d) && d), so(t, e, o, s) && (g = !0), m.push(sr(t, e, u, c, r, n))
                                    }, this), !g) {
                                    var v = iY.documentElement;
                                    if (l = {
                                            $event_type: e.type,
                                            $host: n4.location.host,
                                            $pathname: n4.location.pathname,
                                            $elements: m,
                                            $el_attr__href: d,
                                            $viewportHeight: Math.max(v.clientHeight, n4.innerHeight || 0),
                                            $viewportWidth: Math.max(v.clientWidth, n4.innerWidth || 0)
                                        }, i3.each(c, function(e) {
                                            if (!u[e] && p.hasAttribute(e)) {
                                                var t = p.getAttribute(e);
                                                sl(t) && (l["$el_attr__" + e] = t)
                                            }
                                        }), a && (y = sn(p, e, r, n)) && y.length && (l.$el_text = y), e.type === oK && (i3.each(o9, function(t) {
                                            t in e && (l["$" + t] = e[t])
                                        }), p = function(e) {
                                            for (var t = e.target, r = e.composedPath(), n = 0; n < r.length; n++) {
                                                var i = r[n];
                                                if (sa(i, "a") || sa(i, "button") || sa(i, "input") || sa(i, "select") || i.getAttribute && "button" === i.getAttribute("role")) {
                                                    t = i;
                                                    break
                                                }
                                                if (i === t) break
                                            }
                                            return t
                                        }(e)), a) {
                                        var y = sn(p, e, r, n);
                                        y && y.length && (l.$el_text = y)
                                    }
                                    if (p) {
                                        if (!si(p, e, r, n) || so(p, e, o, s)) return null;
                                        var _ = sr(p, e, u, c, r, n);
                                        l.$target = _, l.$el_classes = _.$classes, i3.extend(l, i3.strip_empty_properties({
                                            $el_id: _.$id,
                                            $el_tag_name: _.$tag_name
                                        }))
                                    }
                                }
                            }
                            return l
                        }(e, {
                            allowElementCallback: this.getConfig("allow_element_callback"),
                            allowSelectors: this.getConfig(sf),
                            blockAttrs: this.getConfig(sm),
                            blockElementCallback: this.getConfig(sg),
                            blockSelectors: this.getConfig(sv),
                            captureExtraAttrs: this.getConfig(s_),
                            captureTextContent: this.getConfig(sb)
                        });
                        r && (i3.extend(r, sM), this.mp.track(t, r))
                    }
                }, sR.prototype.initClickTracking = function() {
                    n4.removeEventListener(oK, this.listenerClick), this.getConfig(sS) && (o7.log("Initializing click tracking"), this.listenerClick = n4.addEventListener(oK, (function(e) {
                        this.getConfig(sS) && this.trackDomEvent(e, "$mp_click")
                    }).bind(this)))
                }, sR.prototype.initInputTracking = function() {
                    n4.removeEventListener(oX, this.listenerChange), this.getConfig(sC) && (o7.log("Initializing input tracking"), this.listenerChange = n4.addEventListener(oX, (function(e) {
                        this.getConfig(sC) && this.trackDomEvent(e, "$mp_input_change")
                    }).bind(this)))
                }, sR.prototype.initPageviewTracking = function() {
                    if (n4.removeEventListener(o1, this.listenerPopstate), n4.removeEventListener(oQ, this.listenerHashchange), n4.removeEventListener(o0, this.listenerLocationchange), this.pageviewTrackingConfig()) {
                        o7.log("Initializing pageview tracking");
                        var e = "",
                            t = !1;
                        this.currentUrlBlocked() || (t = this.mp.track_pageview(sM)), t && (e = i3.info.currentUrl()), this.listenerPopstate = n4.addEventListener(o1, function() {
                            n4.dispatchEvent(new Event(o0))
                        }), this.listenerHashchange = n4.addEventListener(oQ, function() {
                            n4.dispatchEvent(new Event(o0))
                        });
                        var r = n4.history.pushState;
                        "function" == typeof r && (n4.history.pushState = function(e, t, n) {
                            r.call(n4.history, e, t, n), n4.dispatchEvent(new Event(o0))
                        });
                        var n = n4.history.replaceState;
                        "function" == typeof n && (n4.history.replaceState = function(e, t, r) {
                            n.call(n4.history, e, t, r), n4.dispatchEvent(new Event(o0))
                        }), this.listenerLocationchange = n4.addEventListener(o0, i6((function() {
                            if (!this.currentUrlBlocked()) {
                                var t = i3.info.currentUrl(),
                                    r = !1,
                                    n = t.split("#")[0].split("?")[0] !== e.split("#")[0].split("?")[0],
                                    i = this.pageviewTrackingConfig();
                                i === sh ? r = t !== e : "url-with-path-and-query-string" === i ? r = t.split("#")[0] !== e.split("#")[0] : "url-with-path" === i && (r = n), r && (this.mp.track_pageview(sM) && (e = t), n && (this.lastScrollCheckpoint = 0, o7.log("Path change: re-initializing scroll depth checkpoints")))
                            }
                        }).bind(this)))
                    }
                }, sR.prototype.initScrollTracking = function() {
                    n4.removeEventListener(o2, this.listenerScroll), this.getConfig(sx) && (o7.log("Initializing scroll tracking"), this.lastScrollCheckpoint = 0, this.listenerScroll = n4.addEventListener(o2, i6((function() {
                        if (this.getConfig(sx) && !this.currentUrlBlocked()) {
                            var e = this.getConfig(sw),
                                t = (this.getConfig(sk) || []).slice().sort(function(e, t) {
                                    return e - t
                                }),
                                r = n4.scrollY,
                                n = i3.extend({
                                    $scroll_top: r
                                }, sM);
                            try {
                                var i = iY.body.scrollHeight,
                                    o = Math.round(r / (i - n4.innerHeight) * 100);
                                if (n.$scroll_height = i, n.$scroll_percentage = o, o > this.lastScrollCheckpoint)
                                    for (var s = 0; s < t.length; s++) {
                                        var a = t[s];
                                        o >= a && this.lastScrollCheckpoint < a && (n.$scroll_checkpoint = a, this.lastScrollCheckpoint = a, e = !0)
                                    }
                            } catch (e) {
                                o7.critical("Error while calculating scroll percentage", e)
                            }
                            e && this.mp.track("$mp_scroll", n)
                        }
                    }).bind(this))))
                }, sR.prototype.initSubmitTracking = function() {
                    n4.removeEventListener(o3, this.listenerSubmit), this.getConfig(sO) && (o7.log("Initializing submit tracking"), this.listenerSubmit = n4.addEventListener(o3, (function(e) {
                        this.getConfig(sO) && this.trackDomEvent(e, "$mp_submit")
                    }).bind(this)))
                },
                function(e) {
                    var t = e.prototype;
                    for (var r in t) "function" == typeof t[r] && (t[r] = i6(t[r]))
                }(sR);
            var sA = function() {};
            sA.prototype.create_properties = function() {}, sA.prototype.event_handler = function() {}, sA.prototype.after_track_handler = function() {}, sA.prototype.init = function(e) {
                return this.mp = e, this
            }, sA.prototype.track = function(e, t, r, n) {
                var i = this,
                    o = i3.dom_query(e);
                return 0 === o.length ? void i9.error("The DOM query (" + e + ") returned 0 elements") : (i3.each(o, function(e) {
                    i3.register_event(e, this.override_event, function(e) {
                        var o = {},
                            s = i.create_properties(r, this),
                            a = i.mp.get_config("track_links_timeout");
                        i.event_handler(e, this, o), window.setTimeout(i.track_callback(n, s, o, !0), a), i.mp.track(t, s, i.track_callback(n, s, o))
                    })
                }, this), !0)
            }, sA.prototype.track_callback = function(e, t, r, n) {
                n = n || !1;
                var i = this;
                return function() {
                    !r.callback_fired && (r.callback_fired = !0, e && !1 === e(n, t) || i.after_track_handler(t, r, n))
                }
            }, sA.prototype.create_properties = function(e, t) {
                var r;
                return "function" == typeof e ? e(t) : i3.extend({}, e)
            };
            var sT = function() {
                this.override_event = "click"
            };
            i3.inherit(sT, sA), sT.prototype.create_properties = function(e, t) {
                var r = sT.superclass.create_properties.apply(this, arguments);
                return t.href && (r.url = t.href), r
            }, sT.prototype.event_handler = function(e, t, r) {
                r.new_tab = 2 === e.which || e.metaKey || e.ctrlKey || "_blank" === t.target, r.href = t.href, r.new_tab || e.preventDefault()
            }, sT.prototype.after_track_handler = function(e, t) {
                t.new_tab || setTimeout(function() {
                    window.location = t.href
                }, 0)
            };
            var sN = function() {
                this.override_event = "submit"
            };
            i3.inherit(sN, sA), sN.prototype.event_handler = function(e, t, r) {
                r.element = t, e.preventDefault()
            }, sN.prototype.after_track_handler = function(e, t) {
                setTimeout(function() {
                    t.element.submit()
                }, 0)
            };
            var sP = "$set",
                sD = "$set_once",
                sL = "$unset",
                sF = "$add",
                sU = "$append",
                sB = "$union",
                sj = "$remove",
                sq = {
                    set_action: function(e, t) {
                        var r = {},
                            n = {};
                        return i3.isObject(e) ? i3.each(e, function(e, t) {
                            this._is_reserved_property(t) || (n[t] = e)
                        }, this) : n[e] = t, r[sP] = n, r
                    },
                    unset_action: function(e) {
                        var t = {},
                            r = [];
                        return i3.isArray(e) || (e = [e]), i3.each(e, function(e) {
                            this._is_reserved_property(e) || r.push(e)
                        }, this), t[sL] = r, t
                    },
                    set_once_action: function(e, t) {
                        var r = {},
                            n = {};
                        return i3.isObject(e) ? i3.each(e, function(e, t) {
                            this._is_reserved_property(t) || (n[t] = e)
                        }, this) : n[e] = t, r[sD] = n, r
                    },
                    union_action: function(e, t) {
                        var r = {},
                            n = {};
                        return i3.isObject(e) ? i3.each(e, function(e, t) {
                            this._is_reserved_property(t) || (n[t] = i3.isArray(e) ? e : [e])
                        }, this) : n[e] = i3.isArray(t) ? t : [t], r[sB] = n, r
                    },
                    append_action: function(e, t) {
                        var r = {},
                            n = {};
                        return i3.isObject(e) ? i3.each(e, function(e, t) {
                            this._is_reserved_property(t) || (n[t] = e)
                        }, this) : n[e] = t, r[sU] = n, r
                    },
                    remove_action: function(e, t) {
                        var r = {},
                            n = {};
                        return i3.isObject(e) ? i3.each(e, function(e, t) {
                            this._is_reserved_property(t) || (n[t] = e)
                        }, this) : n[e] = t, r[sj] = n, r
                    },
                    delete_action: function() {
                        var e = {};
                        return e.$delete = "", e
                    }
                },
                sz = function() {};
            i3.extend(sz.prototype, sq), sz.prototype._init = function(e, t, r) {
                this._mixpanel = e, this._group_key = t, this._group_id = r
            }, sz.prototype.set = ox(function(e, t, r) {
                var n = this.set_action(e, t);
                return i3.isObject(e) && (r = t), this._send_request(n, r)
            }), sz.prototype.set_once = ox(function(e, t, r) {
                var n = this.set_once_action(e, t);
                return i3.isObject(e) && (r = t), this._send_request(n, r)
            }), sz.prototype.unset = ox(function(e, t) {
                var r = this.unset_action(e);
                return this._send_request(r, t)
            }), sz.prototype.union = ox(function(e, t, r) {
                i3.isObject(e) && (r = t);
                var n = this.union_action(e, t);
                return this._send_request(n, r)
            }), sz.prototype.delete = ox(function(e) {
                var t = this.delete_action();
                return this._send_request(t, e)
            }), sz.prototype.remove = ox(function(e, t, r) {
                var n = this.remove_action(e, t);
                return this._send_request(n, r)
            }), sz.prototype._send_request = function(e, t) {
                e.$group_key = this._group_key, e.$group_id = this._group_id, e.$token = this._get_config("token");
                var r = i3.encodeDates(e);
                return this._mixpanel._track_or_batch({
                    type: "groups",
                    data: r,
                    endpoint: this._get_config("api_host") + "/" + this._get_config("api_routes").groups,
                    batcher: this._mixpanel.request_batchers.groups
                }, t)
            }, sz.prototype._is_reserved_property = function(e) {
                return "$group_key" === e || "$group_id" === e
            }, sz.prototype._get_config = function(e) {
                return this._mixpanel.get_config(e)
            }, sz.prototype.toString = function() {
                return this._mixpanel.toString() + ".group." + this._group_key + "." + this._group_id
            }, sz.prototype.remove = sz.prototype.remove, sz.prototype.set = sz.prototype.set, sz.prototype.set_once = sz.prototype.set_once, sz.prototype.union = sz.prototype.union, sz.prototype.unset = sz.prototype.unset, sz.prototype.toString = sz.prototype.toString;
            var sW = function() {};
            i3.extend(sW.prototype, sq), sW.prototype._init = function(e) {
                this._mixpanel = e
            }, sW.prototype.set = oI(function(e, t, r) {
                var n = this.set_action(e, t);
                return i3.isObject(e) && (r = t), this._get_config("save_referrer") && this._mixpanel.persistence.update_referrer_info(document.referrer), n[sP] = i3.extend({}, i3.info.people_properties(), n[sP]), this._send_request(n, r)
            }), sW.prototype.set_once = oI(function(e, t, r) {
                var n = this.set_once_action(e, t);
                return i3.isObject(e) && (r = t), this._send_request(n, r)
            }), sW.prototype.unset = oI(function(e, t) {
                var r = this.unset_action(e);
                return this._send_request(r, t)
            }), sW.prototype.increment = oI(function(e, t, r) {
                var n = {},
                    i = {};
                return i3.isObject(e) ? (i3.each(e, function(e, t) {
                    if (!this._is_reserved_property(t))
                        if (isNaN(parseFloat(e))) return void i9.error("Invalid increment value passed to mixpanel.people.increment - must be a number");
                        else i[t] = e
                }, this), r = t) : (i3.isUndefined(t) && (t = 1), i[e] = t), n[sF] = i, this._send_request(n, r)
            }), sW.prototype.append = oI(function(e, t, r) {
                i3.isObject(e) && (r = t);
                var n = this.append_action(e, t);
                return this._send_request(n, r)
            }), sW.prototype.remove = oI(function(e, t, r) {
                i3.isObject(e) && (r = t);
                var n = this.remove_action(e, t);
                return this._send_request(n, r)
            }), sW.prototype.union = oI(function(e, t, r) {
                i3.isObject(e) && (r = t);
                var n = this.union_action(e, t);
                return this._send_request(n, r)
            }), sW.prototype.track_charge = oI(function(e, t, r) {
                return !i3.isNumber(e) && isNaN(e = parseFloat(e)) ? void i9.error("Invalid value passed to mixpanel.people.track_charge - must be a number") : this.append("$transactions", i3.extend({
                    $amount: e
                }, t), r)
            }), sW.prototype.clear_charges = function(e) {
                return this.set("$transactions", [], e)
            }, sW.prototype.delete_user = function() {
                if (!this._identify_called()) return void i9.error("mixpanel.people.delete_user() requires you to call identify() first");
                var e = {
                    $delete: this._mixpanel.get_distinct_id()
                };
                return this._send_request(e)
            }, sW.prototype.toString = function() {
                return this._mixpanel.toString() + ".people"
            }, sW.prototype._send_request = function(e, t) {
                e.$token = this._get_config("token"), e.$distinct_id = this._mixpanel.get_distinct_id();
                var r = this._mixpanel.get_property("$device_id"),
                    n = this._mixpanel.get_property("$user_id"),
                    i = this._mixpanel.get_property("$had_persisted_distinct_id");
                r && (e.$device_id = r), n && (e.$user_id = n), i && (e.$had_persisted_distinct_id = i);
                var o = i3.encodeDates(e);
                return this._identify_called() ? this._mixpanel._track_or_batch({
                    type: "people",
                    data: o,
                    endpoint: this._get_config("api_host") + "/" + this._get_config("api_routes").engage,
                    batcher: this._mixpanel.request_batchers.people
                }, t) : (this._enqueue(e), i3.isUndefined(t) || t(this._get_config("verbose") ? {
                    status: -1,
                    error: null
                } : -1), i3.truncate(o, 255))
            }, sW.prototype._get_config = function(e) {
                return this._mixpanel.get_config(e)
            }, sW.prototype._identify_called = function() {
                return !0 === this._mixpanel._flags.identify_called
            }, sW.prototype._enqueue = function(e) {
                sP in e ? this._mixpanel.persistence._add_to_people_queue(sP, e) : sD in e ? this._mixpanel.persistence._add_to_people_queue(sD, e) : sL in e ? this._mixpanel.persistence._add_to_people_queue(sL, e) : sF in e ? this._mixpanel.persistence._add_to_people_queue(sF, e) : sU in e ? this._mixpanel.persistence._add_to_people_queue(sU, e) : sj in e ? this._mixpanel.persistence._add_to_people_queue(sj, e) : sB in e ? this._mixpanel.persistence._add_to_people_queue(sB, e) : i9.error("Invalid call to _enqueue():", e)
            }, sW.prototype._flush_one_queue = function(e, t, r, n) {
                var i = this,
                    o = i3.extend({}, this._mixpanel.persistence.load_queue(e)),
                    s = o;
                !i3.isUndefined(o) && i3.isObject(o) && !i3.isEmptyObject(o) && (i._mixpanel.persistence._pop_from_people_queue(e, o), i._mixpanel.persistence.save(), n && (s = n(o)), t.call(i, s, function(t, n) {
                    0 === t && i._mixpanel.persistence._add_to_people_queue(e, o), i3.isUndefined(r) || r(t, n)
                }))
            }, sW.prototype._flush = function(e, t, r, n, i, o, s) {
                var a = this;
                this._flush_one_queue(sP, this.set, e), this._flush_one_queue(sD, this.set_once, n), this._flush_one_queue(sL, this.unset, o, function(e) {
                    return i3.keys(e)
                }), this._flush_one_queue(sF, this.increment, t), this._flush_one_queue(sB, this.union, i);
                var c = this._mixpanel.persistence.load_queue(sU);
                if (!i3.isUndefined(c) && i3.isArray(c) && c.length)
                    for (var u, l = function(e, t) {
                            0 === e && a._mixpanel.persistence._add_to_people_queue(sU, u), i3.isUndefined(r) || r(e, t)
                        }, p = c.length - 1; p >= 0; p--) u = (c = this._mixpanel.persistence.load_queue(sU)).pop(), a._mixpanel.persistence.save(), i3.isEmptyObject(u) || a.append(u, l);
                var h = this._mixpanel.persistence.load_queue(sj);
                if (!i3.isUndefined(h) && i3.isArray(h) && h.length)
                    for (var f, d = function(e, t) {
                            0 === e && a._mixpanel.persistence._add_to_people_queue(sj, f), i3.isUndefined(s) || s(e, t)
                        }, m = h.length - 1; m >= 0; m--) f = (h = this._mixpanel.persistence.load_queue(sj)).pop(), a._mixpanel.persistence.save(), i3.isEmptyObject(f) || a.remove(f, d)
            }, sW.prototype._is_reserved_property = function(e) {
                return "$distinct_id" === e || "$token" === e || "$device_id" === e || "$user_id" === e || "$had_persisted_distinct_id" === e
            }, sW.prototype.set = sW.prototype.set, sW.prototype.set_once = sW.prototype.set_once, sW.prototype.unset = sW.prototype.unset, sW.prototype.increment = sW.prototype.increment, sW.prototype.append = sW.prototype.append, sW.prototype.remove = sW.prototype.remove, sW.prototype.union = sW.prototype.union, sW.prototype.track_charge = sW.prototype.track_charge, sW.prototype.clear_charges = sW.prototype.clear_charges, sW.prototype.delete_user = sW.prototype.delete_user, sW.prototype.toString = sW.prototype.toString;
            var sV = "__mps",
                s$ = "__mpso",
                sG = "__mpus",
                sY = "__mpa",
                sZ = "__mpap",
                sJ = "__mpr",
                sH = "__mpu",
                sX = "$people_distinct_id",
                sK = "__alias",
                sQ = "__timers",
                s0 = [sV, s$, sG, sY, sZ, sJ, sH, sX, sK, sQ],
                s1 = function(e) {
                    this.props = {}, this.campaign_params_saved = !1, e.persistence_name ? this.name = "mp_" + e.persistence_name : this.name = "mp_" + e.token + "_mixpanel";
                    var t = e.persistence;
                    "cookie" !== t && "localStorage" !== t && (i9.critical("Unknown persistence type " + t + "; falling back to cookie"), t = e.persistence = "cookie"), "localStorage" === t && i3.localStorage.is_supported() ? this.storage = i3.localStorage : this.storage = i3.cookie, this.load(), this.update_config(e), this.upgrade(), this.save()
                };
            s1.prototype.properties = function() {
                var e = {};
                return this.load(), i3.each(this.props, function(t, r) {
                    i3.include(s0, r) || (e[r] = t)
                }), e
            }, s1.prototype.load = function() {
                if (!this.disabled) {
                    var e = this.storage.parse(this.name);
                    e && (this.props = i3.extend({}, e))
                }
            }, s1.prototype.upgrade = function() {
                var e, t;
                this.storage === i3.localStorage ? (e = i3.cookie.parse(this.name), i3.cookie.remove(this.name), i3.cookie.remove(this.name, !0), e && this.register_once(e)) : this.storage === i3.cookie && (t = i3.localStorage.parse(this.name), i3.localStorage.remove(this.name), t && this.register_once(t))
            }, s1.prototype.save = function() {
                this.disabled || this.storage.set(this.name, od(this.props), this.expire_days, this.cross_subdomain, this.secure, this.cross_site, this.cookie_domain)
            }, s1.prototype.load_prop = function(e) {
                return this.load(), this.props[e]
            }, s1.prototype.remove = function() {
                this.storage.remove(this.name, !1, this.cookie_domain), this.storage.remove(this.name, !0, this.cookie_domain)
            }, s1.prototype.clear = function() {
                this.remove(), this.props = {}
            }, s1.prototype.register_once = function(e, t, r) {
                return !!i3.isObject(e) && (void 0 === t && (t = "None"), this.expire_days = void 0 === r ? this.default_expiry : r, this.load(), i3.each(e, function(e, r) {
                    this.props.hasOwnProperty(r) && this.props[r] !== t || (this.props[r] = e)
                }, this), this.save(), !0)
            }, s1.prototype.register = function(e, t) {
                return !!i3.isObject(e) && (this.expire_days = void 0 === t ? this.default_expiry : t, this.load(), i3.extend(this.props, e), this.save(), !0)
            }, s1.prototype.unregister = function(e) {
                this.load(), e in this.props && (delete this.props[e], this.save())
            }, s1.prototype.update_search_keyword = function(e) {
                this.register(i3.info.searchInfo(e))
            }, s1.prototype.update_referrer_info = function(e) {
                this.register_once({
                    $initial_referrer: e || "$direct",
                    $initial_referring_domain: i3.info.referringDomain(e) || "$direct"
                }, "")
            }, s1.prototype.get_referrer_info = function() {
                return i3.strip_empty_properties({
                    $initial_referrer: this.props.$initial_referrer,
                    $initial_referring_domain: this.props.$initial_referring_domain
                })
            }, s1.prototype.update_config = function(e) {
                this.default_expiry = this.expire_days = e.cookie_expiration, this.set_disabled(e.disable_persistence), this.set_cookie_domain(e.cookie_domain), this.set_cross_site(e.cross_site_cookie), this.set_cross_subdomain(e.cross_subdomain_cookie), this.set_secure(e.secure_cookie)
            }, s1.prototype.set_disabled = function(e) {
                this.disabled = e, this.disabled ? this.remove() : this.save()
            }, s1.prototype.set_cookie_domain = function(e) {
                e !== this.cookie_domain && (this.remove(), this.cookie_domain = e, this.save())
            }, s1.prototype.set_cross_site = function(e) {
                e !== this.cross_site && (this.cross_site = e, this.remove(), this.save())
            }, s1.prototype.set_cross_subdomain = function(e) {
                e !== this.cross_subdomain && (this.cross_subdomain = e, this.remove(), this.save())
            }, s1.prototype.get_cross_subdomain = function() {
                return this.cross_subdomain
            }, s1.prototype.set_secure = function(e) {
                e !== this.secure && (this.secure = !!e, this.remove(), this.save())
            }, s1.prototype._add_to_people_queue = function(e, t) {
                var r = this._get_queue_key(e),
                    n = t[e],
                    i = this._get_or_create_queue(sP),
                    o = this._get_or_create_queue(sD),
                    s = this._get_or_create_queue(sL),
                    a = this._get_or_create_queue(sF),
                    c = this._get_or_create_queue(sB),
                    u = this._get_or_create_queue(sj, []),
                    l = this._get_or_create_queue(sU, []);
                r === sV ? (i3.extend(i, n), this._pop_from_people_queue(sF, n), this._pop_from_people_queue(sB, n), this._pop_from_people_queue(sL, n)) : r === s$ ? (i3.each(n, function(e, t) {
                    t in o || (o[t] = e)
                }), this._pop_from_people_queue(sL, n)) : r === sG ? i3.each(n, function(e) {
                    i3.each([i, o, a, c], function(t) {
                        e in t && delete t[e]
                    }), i3.each(l, function(t) {
                        e in t && delete t[e]
                    }), s[e] = !0
                }) : r === sY ? (i3.each(n, function(e, t) {
                    t in i ? i[t] += e : (t in a || (a[t] = 0), a[t] += e)
                }, this), this._pop_from_people_queue(sL, n)) : r === sH ? (i3.each(n, function(e, t) {
                    i3.isArray(e) && (t in c || (c[t] = []), i3.each(e, function(e) {
                        i3.include(c[t], e) || c[t].push(e)
                    }))
                }), this._pop_from_people_queue(sL, n)) : r === sJ ? (u.push(n), this._pop_from_people_queue(sU, n)) : r === sZ && (l.push(n), this._pop_from_people_queue(sL, n)), i9.log("MIXPANEL PEOPLE REQUEST (QUEUED, PENDING IDENTIFY):"), i9.log(t), this.save()
            }, s1.prototype._pop_from_people_queue = function(e, t) {
                var r = this.props[this._get_queue_key(e)];
                i3.isUndefined(r) || i3.each(t, function(t, n) {
                    e === sU || e === sj ? i3.each(r, function(e) {
                        e[n] === t && delete e[n]
                    }) : delete r[n]
                }, this)
            }, s1.prototype.load_queue = function(e) {
                return this.load_prop(this._get_queue_key(e))
            }, s1.prototype._get_queue_key = function(e) {
                return e === sP ? sV : e === sD ? s$ : e === sL ? sG : e === sF ? sY : e === sU ? sZ : e === sj ? sJ : e === sB ? sH : void i9.error("Invalid queue:", e)
            }, s1.prototype._get_or_create_queue = function(e, t) {
                var r = this._get_queue_key(e);
                return t = i3.isUndefined(t) ? {} : t, this.props[r] || (this.props[r] = t)
            }, s1.prototype.set_event_timer = function(e, t) {
                var r = this.load_prop(sQ) || {};
                r[e] = t, this.props[sQ] = r, this.save()
            }, s1.prototype.remove_event_timer = function(e) {
                var t = (this.load_prop(sQ) || {})[e];
                return i3.isUndefined(t) || (delete this.props[sQ][e], this.save()), t
            };
            var s2 = function(e, t) {
                    throw Error(e + " not available in this build.")
                },
                s3 = function(e) {
                    return e
                },
                s9 = "mixpanel",
                s4 = "base64",
                s5 = "$device:",
                s6 = n4.XMLHttpRequest && "withCredentials" in new XMLHttpRequest,
                s8 = !s6 && -1 === iH.indexOf("MSIE") && -1 === iH.indexOf("Mozilla"),
                s7 = null;
            iG.sendBeacon && (s7 = function() {
                return iG.sendBeacon.apply(iG, arguments)
            });
            var ae = {
                    track: "track/",
                    engage: "engage/",
                    groups: "groups/",
                    record: "record/"
                },
                at = {
                    api_host: "https://api-js.mixpanel.com",
                    api_routes: ae,
                    api_method: "POST",
                    api_transport: "XHR",
                    api_payload_format: s4,
                    app_host: "https://mixpanel.com",
                    autocapture: !1,
                    cdn: "https://cdn.mxpnl.com",
                    cross_site_cookie: !1,
                    cross_subdomain_cookie: !0,
                    error_reporter: of ,
                    persistence: "cookie",
                    persistence_name: "",
                    cookie_domain: "",
                    cookie_name: "",
                    loaded: of ,
                    mp_loader: null,
                    track_marketing: !0,
                    track_pageview: !1,
                    skip_first_touch_marketing: !1,
                    store_google: !0,
                    stop_utm_persistence: !1,
                    save_referrer: !0,
                    test: !1,
                    verbose: !1,
                    img: !1,
                    debug: !1,
                    track_links_timeout: 300,
                    cookie_expiration: 365,
                    upgrade: !1,
                    disable_persistence: !1,
                    disable_cookie: !1,
                    secure_cookie: !1,
                    ip: !0,
                    opt_out_tracking_by_default: !1,
                    opt_out_persistence_by_default: !1,
                    opt_out_tracking_persistence_type: "localStorage",
                    opt_out_tracking_cookie_prefix: null,
                    property_blacklist: [],
                    xhr_headers: {},
                    ignore_dnt: !1,
                    batch_requests: !0,
                    batch_size: 50,
                    batch_flush_interval_ms: 5e3,
                    batch_request_timeout_ms: 9e4,
                    batch_autostart: !0,
                    hooks: {},
                    record_block_class: RegExp("^(mp-block|fs-exclude|amp-block|rr-block|ph-no-capture)$"),
                    record_block_selector: "img, video",
                    record_canvas: !1,
                    record_collect_fonts: !1,
                    record_idle_timeout_ms: 18e5,
                    record_mask_text_class: RegExp("^(mp-mask|fs-mask|amp-mask|rr-mask|ph-mask)$"),
                    record_mask_text_selector: "*",
                    record_max_ms: 864e5,
                    record_min_ms: 0,
                    record_sessions_percent: 0,
                    recorder_src: "https://cdn.mxpnl.com/libs/mixpanel-recorder.min.js"
                },
                ar = !1,
                an = function() {},
                ai = function(e, t, r) {
                    var n, s = r === s9 ? o : o[r];
                    if (s && 0 === i) n = s;
                    else {
                        if (s && !i3.isArray(s)) return void i9.error("You have already initialized " + r);
                        n = new an
                    }
                    if (n._cached_groups = {}, n._init(e, t, r), n.people = new sW, n.people._init(n), !n.get_config("skip_first_touch_marketing")) {
                        var a = i3.info.campaignParams(null),
                            c = {},
                            u = !1;
                        i3.each(a, function(e, t) {
                            c["initial_" + t] = e, e && (u = !0)
                        }), u && n.people.set_once(c)
                    }
                    return iU.DEBUG = iU.DEBUG || n.get_config("debug"), !i3.isUndefined(s) && i3.isArray(s) && (n._execute_array.call(n.people, s.people), n._execute_array(s)), n
                };
            an.prototype.init = function(e, t, r) {
                if (i3.isUndefined(r)) return void this.report_error("You must name your new library: init(token, config, name)");
                if (r === s9) return void this.report_error("You must initialize the main mixpanel object right after you include the Mixpanel js snippet");
                var n = ai(e, t, r);
                return o[r] = n, n._loaded(), n
            }, an.prototype._init = function(e, t, r) {
                t = t || {}, this.__loaded = !0, this.config = {};
                var n = {};
                if ("api_payload_format" in t || (t.api_host || at.api_host).match(/\.mixpanel\.com/) && (n.api_payload_format = "json"), this.set_config(i3.extend({}, at, n, t, {
                        name: r,
                        token: e,
                        callback_fn: (r === s9 ? r : s9 + "." + r) + "._jsc"
                    })), this._jsc = of , this.__dom_loaded_queue = [], this.__request_queue = [], this.__disabled_events = [], this._flags = {
                        disable_all_events: !1,
                        identify_called: !1
                    }, this.request_batchers = {}, this._batch_requests = this.get_config("batch_requests"), this._batch_requests)
                    if (i3.localStorage.is_supported(!0) && s6) {
                        if (this.init_batchers(), s7 && n4.addEventListener) {
                            var i = i3.bind(function() {
                                this.request_batchers.events.stopped || this.request_batchers.events.flush({
                                    unloading: !0
                                })
                            }, this);
                            n4.addEventListener("pagehide", function(e) {
                                e.persisted && i()
                            }), n4.addEventListener("visibilitychange", function() {
                                "hidden" === iY.visibilityState && i()
                            })
                        }
                    } else this._batch_requests = !1, i9.log("Turning off Mixpanel request-queueing; needs XHR and localStorage support"), i3.each(this.get_batcher_configs(), function(e) {
                        i9.log("Clearing batch queue " + e.queue_key), i3.localStorage.remove(e.queue_key)
                    });
                this.persistence = this.cookie = new s1(this.config), this.unpersisted_superprops = {}, this._gdpr_init();
                var o = i3.UUID();
                this.get_distinct_id() || this.register_once({
                    distinct_id: s5 + o,
                    $device_id: o
                }, ""), this.autocapture = new sR(this), this.autocapture.init(), this._init_tab_id(), this._check_and_start_session_recording()
            }, an.prototype._init_tab_id = function() {
                if (i3.sessionStorage.is_supported()) try {
                    var e = this.get_config("name") + "_" + this.get_config("token"),
                        t = "mp_tab_id_" + e,
                        r = "mp_gen_new_tab_id_" + e;
                    (i3.sessionStorage.get(r) || !i3.sessionStorage.get(t)) && i3.sessionStorage.set(t, "$tab-" + i3.UUID()), i3.sessionStorage.set(r, "1"), this.tab_id = i3.sessionStorage.get(t), n4.addEventListener("beforeunload", function() {
                        i3.sessionStorage.remove(r)
                    })
                } catch (e) {
                    this.report_error("Error initializing tab id", e)
                } else this.report_error("Session storage is not supported, cannot keep track of unique tab ID.")
            }, an.prototype.get_tab_id = function() {
                return this.tab_id || null
            }, an.prototype._should_load_recorder = function() {
                var e = new o_(ov),
                    t = this.get_tab_id();
                return e.init().then(function() {
                    return e.getAll()
                }).then(function(e) {
                    for (var r = 0; r < e.length; r++)
                        if (oz(e[r]) || e[r].tabId === t) return !0;
                    return !1
                }).catch(i3.bind(function(e) {
                    this.report_error("Error checking recording registry", e)
                }, this))
            }, an.prototype._check_and_start_session_recording = oC(function(e) {
                if (!n4.MutationObserver) return void i9.critical("Browser does not support MutationObserver; skipping session recording");
                var t = i3.bind(function(e) {
                        var t = i3.bind(function() {
                            this._recorder = this._recorder || new n4.__mp_recorder(this), this._recorder.resumeRecording(e)
                        }, this);
                        i3.isUndefined(n4.__mp_recorder) ? s2(this.get_config("recorder_src"), t) : t()
                    }, this),
                    r = this.get_config("record_sessions_percent") > 0 && 100 * Math.random() <= this.get_config("record_sessions_percent");
                e || r ? t(!0) : this._should_load_recorder().then(function(e) {
                    e && t(!1)
                })
            }), an.prototype.start_session_recording = function() {
                this._check_and_start_session_recording(!0)
            }, an.prototype.stop_session_recording = function() {
                this._recorder && this._recorder.stopRecording()
            }, an.prototype.pause_session_recording = function() {
                this._recorder && this._recorder.pauseRecording()
            }, an.prototype.resume_session_recording = function() {
                this._recorder && this._recorder.resumeRecording()
            }, an.prototype.get_session_recording_properties = function() {
                var e = {},
                    t = this._get_session_replay_id();
                return t && (e.$mp_replay_id = t), e
            }, an.prototype.get_session_replay_url = function() {
                var e = null,
                    t = this._get_session_replay_id();
                return t && (e = "https://mixpanel.com/projects/replay-redirect?" + i3.HTTPBuildQuery({
                    replay_id: t,
                    distinct_id: this.get_distinct_id(),
                    token: this.get_config("token")
                })), e
            }, an.prototype._get_session_replay_id = function() {
                var e = null;
                return this._recorder && (e = this._recorder.replayId), e || null
            }, an.prototype.__get_recorder = function() {
                return this._recorder
            }, an.prototype._loaded = function() {
                if (this.get_config("loaded")(this), this._set_default_superprops(), this.people.set_once(this.persistence.get_referrer_info()), this.get_config("store_google") && this.get_config("stop_utm_persistence")) {
                    var e = i3.info.campaignParams(null);
                    i3.each(e, (function(e, t) {
                        this.unregister(t)
                    }).bind(this))
                }
            }, an.prototype._set_default_superprops = function() {
                this.persistence.update_search_keyword(iY.referrer), this.get_config("store_google") && !this.get_config("stop_utm_persistence") && this.register(i3.info.campaignParams()), this.get_config("save_referrer") && this.persistence.update_referrer_info(iY.referrer)
            }, an.prototype._dom_loaded = function() {
                i3.each(this.__dom_loaded_queue, function(e) {
                    this._track_dom.apply(this, e)
                }, this), this.has_opted_out_tracking() || i3.each(this.__request_queue, function(e) {
                    this._send_request.apply(this, e)
                }, this), delete this.__dom_loaded_queue, delete this.__request_queue
            }, an.prototype._track_dom = function(e, t) {
                if (this.get_config("img")) return this.report_error("You can't use DOM tracking functions with img = true."), !1;
                if (!ar) return this.__dom_loaded_queue.push([e, t]), !1;
                var r = new e().init(this);
                return r.track.apply(r, t)
            }, an.prototype._prepare_callback = function(e, t) {
                if (i3.isUndefined(e)) return null;
                if (s6) return function(r) {
                    e(r, t)
                };
                var r = this._jsc,
                    n = "" + Math.floor(1e8 * Math.random()),
                    i = this.get_config("callback_fn") + "[" + n + "]";
                return r[n] = function(i) {
                    delete r[n], e(i, t)
                }, i
            }, an.prototype._send_request = function(e, t, r, n) {
                var i = !0;
                if (s8) return this.__request_queue.push(arguments), i;
                var o = {
                        method: this.get_config("api_method"),
                        transport: this.get_config("api_transport"),
                        verbose: this.get_config("verbose")
                    },
                    s = null;
                !n && (i3.isFunction(r) || "string" == typeof r) && (n = r, r = null), r = i3.extend(o, r || {}), s6 || (r.method = "GET");
                var a = "POST" === r.method,
                    c = s7 && a && "sendbeacon" === r.transport.toLowerCase(),
                    u = r.verbose;
                t.verbose && (u = !0), this.get_config("test") && (t.test = 1), u && (t.verbose = 1), this.get_config("img") && (t.img = 1), !s6 && (n ? t.callback = n : (u || this.get_config("test")) && (t.callback = "(function(){})")), t.ip = +!!this.get_config("ip"), t._ = new Date().getTime().toString(), a && (s = "data=" + encodeURIComponent(t.data), delete t.data), e += "?" + i3.HTTPBuildQuery(t);
                var l = this;
                if ("img" in t) {
                    var p = iY.createElement("img");
                    p.src = e, iY.body.appendChild(p)
                } else if (c) {
                    try {
                        i = s7(e, s)
                    } catch (e) {
                        l.report_error(e), i = !1
                    }
                    try {
                        n && n(+!!i)
                    } catch (e) {
                        l.report_error(e)
                    }
                } else if (s6) try {
                    var h = new XMLHttpRequest;
                    h.open(r.method, e, !0);
                    var f = this.get_config("xhr_headers");
                    if (a && (f["Content-Type"] = "application/x-www-form-urlencoded"), i3.each(f, function(e, t) {
                            h.setRequestHeader(t, e)
                        }), r.timeout_ms && void 0 !== h.timeout) {
                        h.timeout = r.timeout_ms;
                        var d = new Date().getTime()
                    }
                    h.withCredentials = !0, h.onreadystatechange = function() {
                        if (4 === h.readyState) {
                            if (200 === h.status) {
                                if (n)
                                    if (u) {
                                        try {
                                            e = i3.JSONDecode(h.responseText)
                                        } catch (t) {
                                            if (l.report_error(t), !r.ignore_json_errors) return;
                                            e = h.responseText
                                        }
                                        n(e)
                                    } else n(Number(h.responseText))
                            } else if (t = h.timeout && !h.status && new Date().getTime() - d >= h.timeout ? "timeout" : "Bad HTTP status: " + h.status + " " + h.statusText, l.report_error(t), n)
                                if (u) {
                                    var e, t, i = h.responseHeaders || {};
                                    n({
                                        status: 0,
                                        httpStatusCode: h.status,
                                        error: t,
                                        retryAfter: i["Retry-After"]
                                    })
                                } else n(0)
                        }
                    }, h.send(s)
                } catch (e) {
                    l.report_error(e), i = !1
                } else {
                    var m = iY.createElement("script");
                    m.type = "text/javascript", m.async = !0, m.defer = !0, m.src = e;
                    var g = iY.getElementsByTagName("script")[0];
                    g.parentNode.insertBefore(m, g)
                }
                return i
            }, an.prototype._execute_array = function(e) {
                var t, r = [],
                    n = [],
                    i = [];
                i3.each(e, function(e) {
                    e && (t = e[0], i3.isArray(t) ? i.push(e) : "function" == typeof e ? e.call(this) : i3.isArray(e) && "alias" === t ? r.push(e) : i3.isArray(e) && -1 !== t.indexOf("track") && "function" == typeof this[t] ? i.push(e) : n.push(e))
                }, this);
                var o = function(e, t) {
                    i3.each(e, function(e) {
                        if (i3.isArray(e[0])) {
                            var r = t;
                            i3.each(e, function(e) {
                                r = r[e[0]].apply(r, e.slice(1))
                            })
                        } else this[e[0]].apply(this, e.slice(1))
                    }, t)
                };
                o(r, this), o(n, this), o(i, this)
            }, an.prototype.are_batchers_initialized = function() {
                return !!this.request_batchers.events
            }, an.prototype.get_batcher_configs = function() {
                var e = "__mpq_" + this.get_config("token"),
                    t = this.get_config("api_routes");
                return this._batcher_configs = this._batcher_configs || {
                    events: {
                        type: "events",
                        endpoint: "/" + t.track,
                        queue_key: e + "_ev"
                    },
                    people: {
                        type: "people",
                        endpoint: "/" + t.engage,
                        queue_key: e + "_pp"
                    },
                    groups: {
                        type: "groups",
                        endpoint: "/" + t.groups,
                        queue_key: e + "_gr"
                    }
                }, this._batcher_configs
            }, an.prototype.init_batchers = function() {
                if (!this.are_batchers_initialized()) {
                    var e = i3.bind(function(e) {
                            return new oq(e.queue_key, {
                                libConfig: this.config,
                                errorReporter: this.get_config("error_reporter"),
                                sendRequestFunc: i3.bind(function(t, r, n) {
                                    this._send_request(this.get_config("api_host") + e.endpoint, this._encode_data_for_request(t), r, this._prepare_callback(n, t))
                                }, this),
                                beforeSendHook: i3.bind(function(t) {
                                    return this._run_hook("before_send_" + e.type, t)
                                }, this),
                                stopAllBatchingFunc: i3.bind(this.stop_batch_senders, this),
                                usePersistence: !0
                            })
                        }, this),
                        t = this.get_batcher_configs();
                    this.request_batchers = {
                        events: e(t.events),
                        people: e(t.people),
                        groups: e(t.groups)
                    }
                }
                this.get_config("batch_autostart") && this.start_batch_senders()
            }, an.prototype.start_batch_senders = function() {
                this._batchers_were_started = !0, this.are_batchers_initialized() && (this._batch_requests = !0, i3.each(this.request_batchers, function(e) {
                    e.start()
                }))
            }, an.prototype.stop_batch_senders = function() {
                this._batch_requests = !1, i3.each(this.request_batchers, function(e) {
                    e.stop(), e.clear()
                })
            }, an.prototype.push = function(e) {
                this._execute_array([e])
            }, an.prototype.disable = function(e) {
                void 0 === e ? this._flags.disable_all_events = !0 : this.__disabled_events = this.__disabled_events.concat(e)
            }, an.prototype._encode_data_for_request = function(e) {
                var t = od(e);
                return this.get_config("api_payload_format") === s4 && (t = i3.base64Encode(t)), {
                    data: t
                }
            }, an.prototype._track_or_batch = function(e, t) {
                var r = i3.truncate(e.data, 255),
                    n = e.endpoint,
                    i = e.batcher,
                    o = e.should_send_immediately,
                    s = e.send_request_options || {};
                t = t || of ;
                var a = !0,
                    c = i3.bind(function() {
                        return (s.skip_hooks || (r = this._run_hook("before_send_" + e.type, r)), r) ? (i9.log("MIXPANEL REQUEST:"), i9.log(r), this._send_request(n, this._encode_data_for_request(r), s, this._prepare_callback(t, r))) : null
                    }, this);
                return this._batch_requests && !o ? i.enqueue(r).then(function(e) {
                    e ? t(1, r) : c()
                }) : a = c(), a && r
            }, an.prototype.track = oC(function(e, t, r, n) {
                n || "function" != typeof r || (n = r, r = null);
                var i = (r = r || {}).transport;
                i && (r.transport = i);
                var o = r.send_immediately;
                if ("function" != typeof n && (n = of ), i3.isUndefined(e)) return void this.report_error("No event name provided to mixpanel.track");
                if (this._event_is_disabled(e)) return void n(0);
                (t = i3.extend({}, t)).token = this.get_config("token");
                var s = this.persistence.remove_event_timer(e);
                if (!i3.isUndefined(s)) {
                    var a = new Date().getTime() - s;
                    t.$duration = parseFloat((a / 1e3).toFixed(3))
                }
                this._set_default_superprops();
                var c = this.get_config("track_marketing") ? i3.info.marketingParams() : {};
                t = i3.extend({}, i3.info.properties({
                    mp_loader: this.get_config("mp_loader")
                }), c, this.persistence.properties(), this.unpersisted_superprops, this.get_session_recording_properties(), t);
                var u = this.get_config("property_blacklist");
                i3.isArray(u) ? i3.each(u, function(e) {
                    delete t[e]
                }) : this.report_error("Invalid value for property_blacklist config: " + u);
                var l = {
                    event: e,
                    properties: t
                };
                return this._track_or_batch({
                    type: "events",
                    data: l,
                    endpoint: this.get_config("api_host") + "/" + this.get_config("api_routes").track,
                    batcher: this.request_batchers.events,
                    should_send_immediately: o,
                    send_request_options: r
                }, n)
            }), an.prototype.set_group = oC(function(e, t, r) {
                i3.isArray(t) || (t = [t]);
                var n = {};
                return n[e] = t, this.register(n), this.people.set(e, t, r)
            }), an.prototype.add_group = oC(function(e, t, r) {
                var n = this.get_property(e),
                    i = {};
                return void 0 === n ? (i[e] = [t], this.register(i)) : -1 === n.indexOf(t) && (n.push(t), i[e] = n, this.register(i)), this.people.union(e, t, r)
            }), an.prototype.remove_group = oC(function(e, t, r) {
                var n = this.get_property(e);
                if (void 0 !== n) {
                    var i = n.indexOf(t);
                    i > -1 && (n.splice(i, 1), this.register({
                        group_key: n
                    })), 0 === n.length && this.unregister(e)
                }
                return this.people.remove(e, t, r)
            }), an.prototype.track_with_groups = oC(function(e, t, r, n) {
                var i = i3.extend({}, t || {});
                return i3.each(r, function(e, t) {
                    null != e && (i[t] = e)
                }), this.track(e, i, n)
            }), an.prototype._create_map_key = function(e, t) {
                return e + "_" + JSON.stringify(t)
            }, an.prototype._remove_group_from_cache = function(e, t) {
                delete this._cached_groups[this._create_map_key(e, t)]
            }, an.prototype.get_group = function(e, t) {
                var r = this._create_map_key(e, t),
                    n = this._cached_groups[r];
                return (void 0 === n || n._group_key !== e || n._group_id !== t) && ((n = new sz)._init(this, e, t), this._cached_groups[r] = n), n
            }, an.prototype.track_pageview = oC(function(e, t) {
                "object" != typeof e && (e = {});
                var r = (t = t || {}).event_name || "$mp_web_page_view",
                    n = i3.extend(i3.info.mpPageViewProperties(), i3.info.campaignParams(), i3.info.clickParams()),
                    i = i3.extend({}, n, e);
                return this.track(r, i)
            }), an.prototype.track_links = function() {
                return this._track_dom.call(this, sT, arguments)
            }, an.prototype.track_forms = function() {
                return this._track_dom.call(this, sN, arguments)
            }, an.prototype.time_event = function(e) {
                if (i3.isUndefined(e)) return void this.report_error("No event name provided to mixpanel.time_event");
                this._event_is_disabled(e) || this.persistence.set_event_timer(e, new Date().getTime())
            };
            var ao = {
                    persistent: !0
                },
                as = function(e) {
                    var t;
                    return t = i3.isObject(e) ? e : i3.isUndefined(e) ? {} : {
                        days: e
                    }, i3.extend({}, ao, t)
                };
            an.prototype.register = function(e, t) {
                var r = as(t);
                r.persistent ? this.persistence.register(e, r.days) : i3.extend(this.unpersisted_superprops, e)
            }, an.prototype.register_once = function(e, t, r) {
                var n = as(r);
                n.persistent ? this.persistence.register_once(e, t, n.days) : (void 0 === t && (t = "None"), i3.each(e, function(e, r) {
                    this.unpersisted_superprops.hasOwnProperty(r) && this.unpersisted_superprops[r] !== t || (this.unpersisted_superprops[r] = e)
                }, this))
            }, an.prototype.unregister = function(e, t) {
                (t = as(t)).persistent ? this.persistence.unregister(e) : delete this.unpersisted_superprops[e]
            }, an.prototype._register_single = function(e, t) {
                var r = {};
                r[e] = t, this.register(r)
            }, an.prototype.identify = function(e, t, r, n, i, o, s, a) {
                var c = this.get_distinct_id();
                if (e && c !== e) {
                    if ("string" == typeof e && 0 === e.indexOf(s5)) return this.report_error("distinct_id cannot have $device: prefix"), -1;
                    this.register({
                        $user_id: e
                    })
                }
                this.get_property("$device_id") || this.register_once({
                    $had_persisted_distinct_id: !0,
                    $device_id: c
                }, ""), e !== c && e !== this.get_property(sK) && (this.unregister(sK), this.register({
                    distinct_id: e
                })), this._flags.identify_called = !0, this.people._flush(t, r, n, i, o, s, a), e !== c && this.track("$identify", {
                    distinct_id: e,
                    $anon_distinct_id: c
                }, {
                    skip_hooks: !0
                })
            }, an.prototype.reset = function() {
                this.persistence.clear(), this._flags.identify_called = !1;
                var e = i3.UUID();
                this.register_once({
                    distinct_id: s5 + e,
                    $device_id: e
                }, "")
            }, an.prototype.get_distinct_id = function() {
                return this.get_property("distinct_id")
            }, an.prototype.alias = function(e, t) {
                if (e === this.get_property(sX)) return this.report_error("Attempting to create alias for existing People user - aborting."), -2;
                var r = this;
                return (i3.isUndefined(t) && (t = this.get_distinct_id()), e !== t) ? (this._register_single(sK, e), this.track("$create_alias", {
                    alias: e,
                    distinct_id: t
                }, {
                    skip_hooks: !0
                }, function() {
                    r.identify(e)
                })) : (this.report_error("alias matches current distinct_id - skipping api call."), this.identify(e), -1)
            }, an.prototype.name_tag = function(e) {
                this._register_single("mp_name_tag", e)
            }, an.prototype.set_config = function(e) {
                i3.isObject(e) && (i3.extend(this.config, e), e.batch_size && i3.each(this.request_batchers, function(e) {
                    e.resetBatchSize()
                }), this.get_config("persistence_name") || (this.config.persistence_name = this.config.cookie_name), this.get_config("disable_persistence") || (this.config.disable_persistence = this.config.disable_cookie), this.persistence && this.persistence.update_config(this.config), iU.DEBUG = iU.DEBUG || this.get_config("debug"), "autocapture" in e && this.autocapture && this.autocapture.init())
            }, an.prototype.get_config = function(e) {
                return this.config[e]
            }, an.prototype._run_hook = function(e) {
                var t = (this.config.hooks[e] || s3).apply(this, iz.call(arguments, 1));
                return void 0 === t && (this.report_error(e + " hook did not return a value"), t = null), t
            }, an.prototype.get_property = function(e) {
                return this.persistence.load_prop([e])
            }, an.prototype.toString = function() {
                var e = this.get_config("name");
                return e !== s9 && (e = s9 + "." + e), e
            }, an.prototype._event_is_disabled = function(e) {
                return i3.isBlockedUA(iH) || this._flags.disable_all_events || i3.include(this.__disabled_events, e)
            }, an.prototype._gdpr_init = function() {
                "localStorage" === this.get_config("opt_out_tracking_persistence_type") && i3.localStorage.is_supported() && (!this.has_opted_in_tracking() && this.has_opted_in_tracking({
                    persistence_type: "cookie"
                }) && this.opt_in_tracking({
                    enable_persistence: !1
                }), !this.has_opted_out_tracking() && this.has_opted_out_tracking({
                    persistence_type: "cookie"
                }) && this.opt_out_tracking({
                    clear_persistence: !1
                }), this.clear_opt_in_out_tracking({
                    persistence_type: "cookie",
                    enable_persistence: !1
                })), this.has_opted_out_tracking() ? this._gdpr_update_persistence({
                    clear_persistence: !0
                }) : !this.has_opted_in_tracking() && (this.get_config("opt_out_tracking_by_default") || i3.cookie.get("mp_optout")) && (i3.cookie.remove("mp_optout"), this.opt_out_tracking({
                    clear_persistence: this.get_config("opt_out_persistence_by_default")
                }))
            }, an.prototype._gdpr_update_persistence = function(e) {
                var t;
                if (e && e.clear_persistence) t = !0;
                else {
                    if (!e || !e.enable_persistence) return;
                    t = !1
                }
                this.get_config("disable_persistence") || this.persistence.disabled === t || this.persistence.set_disabled(t), t ? (this.stop_batch_senders(), this.stop_session_recording()) : this._batchers_were_started && this.start_batch_senders()
            }, an.prototype._gdpr_call_func = function(e, t) {
                return t = i3.extend({
                    track: i3.bind(this.track, this),
                    persistence_type: this.get_config("opt_out_tracking_persistence_type"),
                    cookie_prefix: this.get_config("opt_out_tracking_cookie_prefix"),
                    cookie_expiration: this.get_config("cookie_expiration"),
                    cross_site_cookie: this.get_config("cross_site_cookie"),
                    cross_subdomain_cookie: this.get_config("cross_subdomain_cookie"),
                    cookie_domain: this.get_config("cookie_domain"),
                    secure_cookie: this.get_config("secure_cookie"),
                    ignore_dnt: this.get_config("ignore_dnt")
                }, t), i3.localStorage.is_supported() || (t.persistence_type = "cookie"), e(this.get_config("token"), {
                    track: t.track,
                    trackEventName: t.track_event_name,
                    trackProperties: t.track_properties,
                    persistenceType: t.persistence_type,
                    persistencePrefix: t.cookie_prefix,
                    cookieDomain: t.cookie_domain,
                    cookieExpiration: t.cookie_expiration,
                    crossSiteCookie: t.cross_site_cookie,
                    crossSubdomainCookie: t.cross_subdomain_cookie,
                    secureCookie: t.secure_cookie,
                    ignoreDnt: t.ignore_dnt
                })
            }, an.prototype.opt_in_tracking = function(e) {
                e = i3.extend({
                    enable_persistence: !0
                }, e), this._gdpr_call_func(ob, e), this._gdpr_update_persistence(e)
            }, an.prototype.opt_out_tracking = function(e) {
                (e = i3.extend({
                    clear_persistence: !0,
                    delete_user: !0
                }, e)).delete_user && this.people && this.people._identify_called() && (this.people.delete_user(), this.people.clear_charges()), this._gdpr_call_func(ow, e), this._gdpr_update_persistence(e)
            }, an.prototype.has_opted_in_tracking = function(e) {
                return this._gdpr_call_func(ok, e)
            }, an.prototype.has_opted_out_tracking = function(e) {
                return this._gdpr_call_func(oS, e)
            }, an.prototype.clear_opt_in_out_tracking = function(e) {
                e = i3.extend({
                    enable_persistence: !0
                }, e), this._gdpr_call_func(oO, e), this._gdpr_update_persistence(e)
            }, an.prototype.report_error = function(e, t) {
                i9.error.apply(i9.error, arguments);
                try {
                    t || e instanceof Error || (e = Error(e)), this.get_config("error_reporter")(e, t)
                } catch (e) {
                    i9.error(e)
                }
            }, an.prototype.init = an.prototype.init, an.prototype.reset = an.prototype.reset, an.prototype.disable = an.prototype.disable, an.prototype.time_event = an.prototype.time_event, an.prototype.track = an.prototype.track, an.prototype.track_links = an.prototype.track_links, an.prototype.track_forms = an.prototype.track_forms, an.prototype.track_pageview = an.prototype.track_pageview, an.prototype.register = an.prototype.register, an.prototype.register_once = an.prototype.register_once, an.prototype.unregister = an.prototype.unregister, an.prototype.identify = an.prototype.identify, an.prototype.alias = an.prototype.alias, an.prototype.name_tag = an.prototype.name_tag, an.prototype.set_config = an.prototype.set_config, an.prototype.get_config = an.prototype.get_config, an.prototype.get_property = an.prototype.get_property, an.prototype.get_distinct_id = an.prototype.get_distinct_id, an.prototype.toString = an.prototype.toString, an.prototype.opt_out_tracking = an.prototype.opt_out_tracking, an.prototype.opt_in_tracking = an.prototype.opt_in_tracking, an.prototype.has_opted_out_tracking = an.prototype.has_opted_out_tracking, an.prototype.has_opted_in_tracking = an.prototype.has_opted_in_tracking, an.prototype.clear_opt_in_out_tracking = an.prototype.clear_opt_in_out_tracking, an.prototype.get_group = an.prototype.get_group, an.prototype.set_group = an.prototype.set_group, an.prototype.add_group = an.prototype.add_group, an.prototype.remove_group = an.prototype.remove_group, an.prototype.track_with_groups = an.prototype.track_with_groups, an.prototype.start_batch_senders = an.prototype.start_batch_senders, an.prototype.stop_batch_senders = an.prototype.stop_batch_senders, an.prototype.start_session_recording = an.prototype.start_session_recording, an.prototype.stop_session_recording = an.prototype.stop_session_recording, an.prototype.pause_session_recording = an.prototype.pause_session_recording, an.prototype.resume_session_recording = an.prototype.resume_session_recording, an.prototype.get_session_recording_properties = an.prototype.get_session_recording_properties, an.prototype.get_session_replay_url = an.prototype.get_session_replay_url, an.prototype.get_tab_id = an.prototype.get_tab_id, an.prototype.DEFAULT_API_ROUTES = ae, an.prototype.__get_recorder = an.prototype.__get_recorder, s1.prototype.properties = s1.prototype.properties, s1.prototype.update_search_keyword = s1.prototype.update_search_keyword, s1.prototype.update_referrer_info = s1.prototype.update_referrer_info, s1.prototype.get_cross_subdomain = s1.prototype.get_cross_subdomain, s1.prototype.clear = s1.prototype.clear;
            var aa = {},
                ac = function() {
                    i3.each(aa, function(e, t) {
                        t !== s9 && (o[t] = e)
                    }), o._ = i3
                },
                au = (s2 = function(e, t) {
                    t()
                }, i = 0, (o = new an).init = function(e, t, r) {
                    if (r) return o[r] || (o[r] = aa[r] = ai(e, t, r), o[r]._loaded()), o[r];
                    var n = o;
                    aa[s9] ? n = aa[s9] : e && ((n = ai(e, t, s9))._loaded(), aa[s9] = n), o = n, 1 === i && (n4[s9] = o), ac()
                }, o.init(), function() {
                    function e() {
                        e.done || (e.done = !0, ar = !0, s8 = !1, i3.each(aa, function(e) {
                            e._dom_loaded()
                        }))
                    }
                    if (iY.addEventListener) "complete" === iY.readyState ? e() : iY.addEventListener("DOMContentLoaded", e, !1);
                    else if (iY.attachEvent) {
                        iY.attachEvent("onreadystatechange", e);
                        var t = !1;
                        try {
                            t = null === n4.frameElement
                        } catch (e) {}
                        iY.documentElement.doScroll && t && function t() {
                            try {
                                iY.documentElement.doScroll("left")
                            } catch (e) {
                                setTimeout(t, 1);
                                return
                            }
                            e()
                        }()
                    }
                    i3.register_event(n4, "load", e, !0)
                }(), o)
        }
    }
]);