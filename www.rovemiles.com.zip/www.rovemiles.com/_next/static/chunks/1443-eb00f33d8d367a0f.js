! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "e4a46f9d-34b5-4682-a5c9-45288a4533f8", e._sentryDebugIdIdentifier = "sentry-dbid-e4a46f9d-34b5-4682-a5c9-45288a4533f8")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [1443], {
        980: (e, t, a) => {
            a.d(t, {
                A: () => o,
                s: () => l
            });
            var n = a(12115),
                r = a(14679),
                s = a(75329);
            let l = () => ({
                    trackMixPanelEvent: (0, n.useCallback)((e, t) => {
                        r.A.track(e, { ...t,
                            platform: "web"
                        })
                    }, [])
                }),
                o = e => {
                    (0, n.useEffect)(() => {
                        var t, a;
                        if (r.A.init(s.A.NEXT_PUBLIC_MIXPANEL_TOKEN || "", {
                                debug: "production" !== s.A.NEXT_PUBLIC_ENV
                            }), !e) return void r.A.reset();
                        r.A.identify(e.id), r.A.people.set({
                            $email: e.email,
                            $name: "".concat((null == (t = e.user_metadata) ? void 0 : t.first_name) || "", " ").concat((null == (a = e.user_metadata) ? void 0 : a.last_name) || "").trim()
                        })
                    }, [e])
                }
        },
        8155: (e, t, a) => {
            a.d(t, {
                b: () => n,
                s: () => r
            });
            let n = {
                    SIGN_IN_CLICK: "sign_in_click",
                    FLIGHT_SEARCH_CLICK: "flight_search_click",
                    HOTEL_SEARCH_CLICK: "hotel_search_click",
                    EXPLORE_DEAL_CLICK: "deal_click",
                    HOTEL_CARD_CLICK: "hotel_card_click",
                    FLIGHT_MENU_CLICK: "flight_menu_click",
                    HOTELS_MENU_CLICK: "hotels_menu_click",
                    SELECT_FLIGHT_CLICK: "select_flight_click",
                    CONFIRM_FLIGHT_CLICK: "confirm_flight_click",
                    SELECT_HOTEL_CLICK: "select_hotel_click",
                    COMPLETE_HOTEL_BOOKING_CLICK: "complete_hotel_booking_click",
                    HOMEPAGE_DEAL_CLICK: "homepage_deal_click",
                    REFER_BUTTON_CLICK: "refer_button_click",
                    EXPLORE_TOP_DEALS_CLICK: "explore_top_deals_click",
                    EARN_TAB_CLICK: "earn_tab_click",
                    EARN_SHOPPING_CARD_CLICK: "earn_shopping_card_click",
                    ADD_TO_CHROME_CLICK: "add_to_chrome_click ",
                    SIGN_UP_SUCCESS: "sign_up_success"
                },
                r = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                        event: e,
                        ...t
                    })
                }
        },
        16244: (e, t, a) => {
            a.d(t, {
                Cf: () => h,
                De: () => g,
                L3: () => x,
                c7: () => _,
                lG: () => u,
                zM: () => p
            });
            var n = a(95155),
                r = a(12115),
                s = a(47650),
                l = a(26615),
                o = a(71408),
                i = a(6410),
                d = a(64269);
            let c = r.createContext(null),
                u = e => {
                    let {
                        children: t,
                        open: a,
                        onOpenChange: s
                    } = e, [l, o] = r.useState(!1), i = void 0 !== a, d = i ? a : l, u = r.useCallback(e => {
                        i || o(e), null == s || s(e)
                    }, [i, s]);
                    return r.useEffect(() => (d ? document.body.style.overflow = "hidden" : document.body.style.overflow = "", () => {
                        document.body.style.overflow = ""
                    }), [d]), (0, n.jsx)(c.Provider, {
                        value: {
                            open: d,
                            onOpenChange: u
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "Dialog",
                        "data-sentry-source-file": "Dialog.tsx",
                        children: t
                    })
                },
                p = e => {
                    let {
                        children: t,
                        className: a,
                        ...s
                    } = e, l = r.useContext(c);
                    if (!l) throw Error("DialogTrigger must be used within a Dialog");
                    return (0, n.jsx)("div", { ...s,
                        onClick: () => l.onOpenChange(!0),
                        className: (0, d.cn)("cursor-pointer", a),
                        "data-sentry-component": "DialogTrigger",
                        "data-sentry-source-file": "Dialog.tsx",
                        children: t
                    })
                },
                m = e => {
                    let {
                        children: t
                    } = e;
                    return (0, s.createPortal)(t, document.body)
                },
                f = r.forwardRef((e, t) => {
                    let {
                        className: a,
                        ...r
                    } = e;
                    return (0, n.jsx)("div", {
                        ref: t,
                        className: (0, d.cn)("absolute inset-0 bg-black/60", a),
                        ...r
                    })
                });
            f.displayName = "DialogOverlay";
            let h = r.forwardRef((e, t) => {
                let {
                    className: a,
                    children: s,
                    closeButton: u = !0,
                    ...p
                } = e, h = r.useContext(c);
                if (!h) throw Error("DialogContent must be used within a Dialog");
                return (0, n.jsx)(m, {
                    children: (0, n.jsx)(o.N, {
                        children: h.open && (0, n.jsxs)(i.P.div, {
                            className: "fixed inset-0 z-[1010] flex items-center justify-center h-screen overflow-y-auto",
                            initial: {
                                opacity: 0
                            },
                            animate: {
                                opacity: 1
                            },
                            exit: {
                                opacity: 0
                            },
                            transition: {
                                duration: .3
                            },
                            onClick: e => {
                                e.stopPropagation(), h.onOpenChange(!1)
                            },
                            children: [(0, n.jsx)(f, {}), (0, n.jsxs)(i.P.div, {
                                ref: t,
                                initial: {
                                    opacity: 0,
                                    scale: .95
                                },
                                animate: {
                                    opacity: 1,
                                    scale: 1
                                },
                                exit: {
                                    opacity: 0,
                                    scale: .95
                                },
                                transition: {
                                    duration: .3,
                                    type: "spring",
                                    stiffness: 300,
                                    damping: 30
                                },
                                className: (0, d.cn)("relative z-10 w-full max-w-lg bg-[#111]/80 p-9 shadow-lg text-white rounded-xl backdrop-blur-lg", a),
                                onClick: e => e.stopPropagation(),
                                ...p,
                                children: [s, u && (0, n.jsxs)(i.P.button, {
                                    className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-[#1E1D25] transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 disabled:pointer-events-none",
                                    onClick: () => h.onOpenChange(!1),
                                    whileHover: {
                                        scale: 1.1
                                    },
                                    whileTap: {
                                        scale: .9
                                    },
                                    children: [(0, n.jsx)(l.A, {
                                        className: "h-4 w-4"
                                    }), (0, n.jsx)("span", {
                                        className: "sr-only",
                                        children: "Close"
                                    })]
                                })]
                            })]
                        })
                    })
                })
            });
            h.displayName = "DialogContent";
            let g = () => {
                let e = r.useContext(c);
                if (!e) throw Error("DialogCloseButton must be used within a Dialog");
                return (0, n.jsxs)(i.P.button, {
                    className: "rounded-sm opacity-70 ring-offset-[#1E1D25] transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 disabled:pointer-events-none",
                    onClick: () => e.onOpenChange(!1),
                    whileHover: {
                        scale: 1.1
                    },
                    whileTap: {
                        scale: .9
                    },
                    "data-sentry-element": "unknown",
                    "data-sentry-component": "DialogCloseButton",
                    "data-sentry-source-file": "Dialog.tsx",
                    children: [(0, n.jsx)(l.A, {
                        className: "h-5 w-5",
                        "data-sentry-element": "X",
                        "data-sentry-source-file": "Dialog.tsx"
                    }), (0, n.jsx)("span", {
                        className: "sr-only",
                        children: "Close"
                    })]
                })
            };
            g.displayName = "DialogCloseButton";
            let _ = e => {
                    let {
                        className: t,
                        ...a
                    } = e;
                    return (0, n.jsx)("div", {
                        className: (0, d.cn)("flex flex-col space-y-1.5", t),
                        ...a,
                        "data-sentry-component": "DialogHeader",
                        "data-sentry-source-file": "Dialog.tsx"
                    })
                },
                x = r.forwardRef((e, t) => {
                    let {
                        className: a,
                        ...r
                    } = e;
                    return (0, n.jsx)("h2", {
                        ref: t,
                        className: (0, d.cn)("text-base leading-none tracking-tight text-white", a),
                        ...r
                    })
                });
            x.displayName = "DialogTitle", r.forwardRef((e, t) => {
                let {
                    className: a,
                    ...r
                } = e;
                return (0, n.jsx)("p", {
                    ref: t,
                    className: (0, d.cn)("text-sm text-[#786F90]", a),
                    ...r
                })
            }).displayName = "DialogDescription"
        },
        18125: (e, t, a) => {
            a.d(t, {
                C5: () => x,
                MJ: () => g,
                eI: () => h,
                lV: () => c,
                mN: () => d,
                y1: () => _,
                zB: () => p
            });
            var n = a(95155),
                r = a(12115),
                s = a(32467),
                l = a(22544),
                o = a(66942),
                i = a(64269);
            let d = e => {
                    let {
                        schema: t,
                        options: a = {}
                    } = e;
                    return (0, l.mN)({
                        resolver: (0, o.u)(t),
                        mode: "onBlur",
                        ...a
                    })
                },
                c = l.Op,
                u = r.createContext({}),
                p = e => {
                    let { ...t
                    } = e;
                    return (0, n.jsx)(u.Provider, {
                        value: {
                            name: t.name
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "FormField",
                        "data-sentry-source-file": "Form.tsx",
                        children: (0, n.jsx)(l.xI, { ...t,
                            "data-sentry-element": "Controller",
                            "data-sentry-source-file": "Form.tsx"
                        })
                    })
                },
                m = () => {
                    let e = r.useContext(u),
                        t = r.useContext(f),
                        {
                            getFieldState: a,
                            formState: n
                        } = (0, l.xW)(),
                        s = a(e.name, n);
                    if (!e) throw Error("useFormField should be used within <FormField>");
                    let {
                        id: o
                    } = t;
                    return {
                        id: o,
                        name: e.name,
                        formItemId: "".concat(o, "-form-item"),
                        formDescriptionId: "".concat(o, "-form-item-description"),
                        formMessageId: "".concat(o, "-form-item-message"),
                        ...s
                    }
                },
                f = r.createContext({}),
                h = e => {
                    let {
                        className: t,
                        ref: a,
                        ...s
                    } = e, l = r.useId();
                    return (0, n.jsx)(f.Provider, {
                        value: {
                            id: l
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "FormItem",
                        "data-sentry-source-file": "Form.tsx",
                        children: (0, n.jsx)("div", {
                            ref: a,
                            className: (0, i.cn)("space-y-2", t),
                            ...s
                        })
                    })
                };
            h.displayName = "FormItem";
            let g = e => {
                let {
                    ref: t,
                    ...a
                } = e, {
                    error: r,
                    formItemId: l,
                    formDescriptionId: o,
                    formMessageId: i
                } = m();
                return (0, n.jsx)(s.DX, {
                    ref: t,
                    id: l,
                    "aria-describedby": r ? "".concat(o, " ").concat(i) : "".concat(o),
                    "aria-invalid": !!r,
                    ...a,
                    "data-sentry-element": "Slot",
                    "data-sentry-component": "FormControl",
                    "data-sentry-source-file": "Form.tsx"
                })
            };
            g.displayName = "FormControl";
            let _ = e => {
                let {
                    className: t,
                    children: a,
                    ref: r,
                    ...s
                } = e;
                return (0, n.jsx)("p", {
                    ref: r,
                    className: (0, i.cn)("text-[12px] text-[#F77064]/75", t),
                    ...s,
                    "data-sentry-component": "AgnosticFormMessage",
                    "data-sentry-source-file": "Form.tsx",
                    children: a
                })
            };
            _.displayName = "AgnosticFormMessage";
            let x = e => {
                let {
                    className: t,
                    children: a,
                    ref: r,
                    ...s
                } = e, {
                    error: l,
                    formMessageId: o
                } = m(), i = l ? String(null == l ? void 0 : l.message) : a;
                return i ? (0, n.jsx)(_, {
                    ref: r,
                    id: o,
                    className: t,
                    ...s,
                    "data-sentry-element": "AgnosticFormMessage",
                    "data-sentry-component": "FormMessage",
                    "data-sentry-source-file": "Form.tsx",
                    children: i
                }) : null
            };
            x.displayName = "FormMessage"
        },
        24135: (e, t, a) => {
            a.d(t, {
                QJ: () => s,
                rN: () => r
            });
            let n = ["referralCode", "referral"],
                r = e => {
                    for (let t of n) {
                        let a = e.get(t);
                        if (a) return a
                    }
                    return null
                },
                s = e => {
                    for (let t of n) e.delete(t)
                }
        },
        38728: (e, t, a) => {
            a.d(t, {
                A: () => u,
                O: () => c
            });
            var n = a(95155),
                r = a(12115),
                s = a(99776),
                l = a(53455),
                o = a(20063),
                i = a(77650);
            let d = (0, r.createContext)({
                    user: null,
                    isAuthenticated: !1,
                    isLoading: !0,
                    authRef: {
                        current: null
                    },
                    signOut: async () => {}
                }),
                c = e => {
                    let {
                        children: t
                    } = e, a = (0, i.U)(), c = (0, o.useRouter)(), u = (0, s.jE)(), p = (0, r.useRef)(null), {
                        data: m,
                        isLoading: f
                    } = (0, l.I)({
                        queryKey: ["auth", "user"],
                        queryFn: async () => {
                            let {
                                data: e,
                                error: t
                            } = await a.auth.getUser();
                            if (t) throw t;
                            return p.current = e.user, e.user
                        },
                        staleTime: 3e5,
                        gcTime: 6e5
                    });
                    (0, r.useEffect)(() => {
                        let {
                            data: {
                                subscription: e
                            }
                        } = a.auth.onAuthStateChange(() => {
                            u.invalidateQueries({
                                queryKey: ["auth", "user"]
                            })
                        });
                        return () => e.unsubscribe()
                    }, [u, a]);
                    let h = (0, r.useCallback)(async () => {
                        try {
                            let {
                                error: e
                            } = await a.auth.signOut();
                            if (e) throw e;
                            u.setQueryData(["auth", "user"], null), p.current = null, setTimeout(() => {
                                c.push("/"), c.refresh()
                            }, 100)
                        } catch (e) {
                            console.error("Error during sign out:", e), c.push("/")
                        }
                    }, [a, u, c]);
                    return (0, n.jsx)(d.Provider, {
                        value: {
                            user: m || null,
                            isAuthenticated: !!m,
                            isLoading: f,
                            authRef: p,
                            signOut: h
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "AuthProvider",
                        "data-sentry-source-file": "AuthContext.tsx",
                        children: t
                    })
                },
                u = () => (0, r.useContext)(d)
        },
        48904: (e, t, a) => {
            a.d(t, {
                A: () => x
            });
            var n = a(95155),
                r = a(64269),
                s = a(12115),
                l = a(28127),
                o = a(71418),
                i = a(36654),
                d = a(12710);
            let c = (e, t) => a => Math.min(Math.max(a, e), t),
                u = e => {
                    let {
                        className: t,
                        filledClassName: a,
                        containerClassName: s,
                        value: l,
                        placeholder: o,
                        onValueChange: i,
                        padLength: d,
                        onChange: c,
                        ...u
                    } = e, p = !!l && 0 !== l, m = l ? l.toString().padStart(d || 2, "0") : 0 === l ? "0" : "";
                    return (0, n.jsx)("div", {
                        className: (0, r.cn)("relative", s),
                        "data-sentry-component": "CustomNumberInput",
                        "data-sentry-source-file": "FloatingDateInputPart.tsx",
                        children: (0, n.jsx)("input", {
                            type: "text",
                            className: (0, r.cn)("text-white relative bg-transparent outline-none border-none [&::-webkit-outer-spin-button]:hidden [&::-webkit-inner-spin-button]:hidden", t, p && a),
                            autoComplete: "off",
                            ...u,
                            placeholder: o,
                            onChange: e => {
                                let t = e.target.value;
                                if (!t && "0" !== t) {
                                    null == i || i(void 0, !1);
                                    return
                                }
                                try {
                                    let e = parseInt(t);
                                    if (isNaN(e)) return;
                                    null == i || i(e)
                                } catch (e) {
                                    console.error(e)
                                }
                            },
                            value: m,
                            onKeyDown: e => {
                                "Backspace" !== e.key || l || null == i || i(void 0, !1);
                                try {
                                    let t = parseInt(l);
                                    if (isNaN(t)) return;
                                    "ArrowDown" === e.key && (e.preventDefault(), e.stopPropagation(), null == i || i(t ? t - 1 : 1, !0)), "ArrowUp" === e.key && (e.preventDefault(), e.stopPropagation(), null == i || i(t ? t + 1 : 1, !0))
                                } catch (e) {}
                            }
                        })
                    })
                },
                p = e => {
                    var t;
                    let a = null == (t = e.match(/^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/)) ? void 0 : t[0];
                    if (!a) return console.error("Invalid date format supplied to CustomDateInput. RFC3339 format required!", e), null;
                    let [n, r, s] = a.split("-").map(Number);
                    return {
                        day: s,
                        month: r,
                        year: n
                    }
                },
                m = (e, t, a) => e <= 31 && e > 0 && t <= 12 && t > 0 && a > 0 && a <= 9999 ? "".concat(String(a).padStart(4, "0"), "-").concat(String(t).padStart(2, "0"), "-").concat(String(e).padStart(2, "0")) : null,
                f = (e, t) => new Date(e, t, 0).getDate(),
                h = e => {
                    let {
                        value: t,
                        onChange: a
                    } = e, [r, l] = (0, s.useState)(void 0), [o, i] = (0, s.useState)(void 0), [d, h] = (0, s.useState)(void 0), [g, _] = (0, s.useState)(31), x = (0, s.useRef)(null), E = (0, s.useRef)(null), y = (0, s.useRef)(null);
                    return (0, s.useEffect)(() => {
                        if (!t) {
                            l(void 0), i(void 0), h(void 0);
                            return
                        }
                        let e = p(t);
                        e && (l(e.day), i(e.month), h(e.year))
                    }, [t]), (0, s.useEffect)(() => {
                        if (!r || !o || !d || d < 100) return;
                        let e = m(r, o, d);
                        e && a(e)
                    }, [r, o, d]), (0, s.useEffect)(() => {
                        if (!d || !o) return void _(31);
                        let e = f(d, o);
                        _(e), r && r > e && l(e)
                    }, [o, d, r]), (0, n.jsx)("div", {
                        className: "absolute left-6 top-6 text-sm",
                        "data-sentry-component": "CustomDateInput",
                        "data-sentry-source-file": "FloatingDateInputPart.tsx",
                        children: (0, n.jsxs)("div", {
                            className: "flex",
                            children: [(0, n.jsx)(u, {
                                className: "w-6 text-center",
                                filledClassName: "w-5",
                                value: o,
                                onValueChange: (e, t) => {
                                    let a = e || 0 === e ? c(0, 99)(e) : void 0;
                                    if (i(a), !t && a && a > 1) {
                                        var n;
                                        null == (n = x.current) || n.focus()
                                    }
                                },
                                placeholder: "MM",
                                ref: E,
                                padLength: 2,
                                "data-sentry-element": "CustomNumberInput",
                                "data-sentry-source-file": "FloatingDateInputPart.tsx"
                            }), (0, n.jsx)("span", {
                                className: "text-white/80",
                                children: "/"
                            }), (0, n.jsx)(u, {
                                className: "w-5",
                                filledClassName: "w-[1.1rem]",
                                value: r,
                                onValueChange: (e, t) => {
                                    var a, n;
                                    let r = e || 0 === e ? c(0, 99)(e) : void 0;
                                    l(r), !t && (void 0 === r && (null == (a = E.current) || a.focus()), r && r > 9 && (null == (n = y.current) || n.focus()))
                                },
                                placeholder: "DD",
                                ref: x,
                                padLength: 2,
                                "data-sentry-element": "CustomNumberInput",
                                "data-sentry-source-file": "FloatingDateInputPart.tsx"
                            }), (0, n.jsx)("span", {
                                className: "text-white/80",
                                children: "/"
                            }), (0, n.jsx)(u, {
                                className: "w-12",
                                filledClassName: "ml-1",
                                value: d,
                                onValueChange: e => {
                                    let t = e ? c(1, 9999)(e) : void 0;
                                    if (h(t), void 0 === t) {
                                        var a;
                                        null == (a = x.current) || a.focus()
                                    }
                                },
                                placeholder: "YYYY",
                                ref: y,
                                padLength: 4,
                                "data-sentry-element": "CustomNumberInput",
                                "data-sentry-source-file": "FloatingDateInputPart.tsx"
                            })]
                        })
                    })
                },
                g = (0, d.tv)({
                    base: "w-full bg-[#111] rounded-xl px-6 border focus:outline-none focus:ring-1 [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-calendar-picker-indicator]:hidden placeholder:text-sm text-sm appearance-none [&::-webkit-date-and-time-value]:text-left min-h-[54px] [&::-webkit-datetime-edit-year-field]:focus:bg-transparent [&::-webkit-datetime-edit-year-field]:focus:text-white [&::-webkit-datetime-edit-month-field]:focus:bg-transparent [&::-webkit-datetime-edit-month-field]:focus:text-white [&::-webkit-datetime-edit-day-field]:focus:bg-transparent [&::-webkit-datetime-edit-day-field]:focus:text-white [&::-webkit-datetime-edit-text]:focus:bg-transparent [&::-webkit-datetime-edit-text]:focus:text-white",
                    variants: {
                        variant: {
                            default: "text-white border-[#4B4B4B6B] focus:border-[#4b4b4bb3] focus:ring-[#4b4b4bb3] autofill:text-input",
                            error: "text-[#F77064] border-[#F7706433] focus:border-[#F7706433] focus:ring-[#F7706433] autofill:text-input-error",
                            disabled: "cursor-not-allowed text-white/50 border-[#4B4B4B6B] focus:border-[#4b4b4bb3] focus:ring-[#4b4b4bb3] autofill:text-input"
                        },
                        type: {
                            password: "pr-12"
                        },
                        onlyPlaceholder: {
                            false: "pt-6 pb-2 placeholder:text-white/30",
                            true: "py-4 placeholder:text-white/50"
                        },
                        isDatePicker: {
                            false: "",
                            true: "[&::-webkit-datetime-edit-year-field]:hidden [&::-webkit-datetime-edit-month-field]:hidden [&::-webkit-datetime-edit-day-field]:hidden [&::-webkit-datetime-edit-text]:hidden text-transparent"
                        }
                    }
                }),
                _ = e => {
                    let {
                        id: t,
                        label: a,
                        type: d = "text",
                        required: c = !1,
                        value: u,
                        className: p,
                        labelClassName: m,
                        containerClassName: f,
                        onChange: _,
                        onClick: x,
                        variant: E = "default",
                        style: y,
                        additionalContent: b,
                        small: C,
                        ref: N,
                        ...I
                    } = e, v = (0, s.useRef)(null), [w, L] = (0, s.useState)(!1), [D, k] = (0, s.useState)(!!u), [T, P] = (0, s.useState)(!1), R = (0, s.useMemo)(() => !!a && (w || D) || !!I.placeholder || "date" === d, [a, w, D, I.placeholder, d]), F = !!I.placeholder && !a, B = e => {
                        u || k(!!e.target.value), null == _ || _(e)
                    };
                    return (0, s.useEffect)(() => {
                        k(!!u)
                    }, [u]), (0, n.jsxs)("div", {
                        className: (0, r.cn)("relative w-full", f),
                        "data-sentry-component": "FloatingLabelInput",
                        "data-sentry-source-file": "FloatingLabelInput.tsx",
                        children: [(0, n.jsx)("input", {
                            type: "password" === d ? T ? "text" : "password" : d,
                            id: t,
                            required: c,
                            className: g({
                                type: "password" === d ? "password" : void 0,
                                onlyPlaceholder: F,
                                variant: I.disabled ? "disabled" : E,
                                isDatePicker: "date" === d,
                                className: p
                            }),
                            style: {
                                colorScheme: "dark",
                                ...y
                            },
                            ref: e => {
                                N && ("current" in N && (N.current = e), "function" == typeof N && N(e)), v.current = e
                            },
                            onFocus: () => L(!0),
                            onBlur: () => L(!1),
                            value: u,
                            onChange: B,
                            onClick: x,
                            ...I
                        }), "date" === d && (0, n.jsxs)(n.Fragment, {
                            children: [(0, n.jsx)(h, {
                                value: u,
                                onChange: e => {
                                    B({
                                        target: {
                                            value: e
                                        }
                                    })
                                }
                            }), (0, n.jsx)("button", {
                                className: (0, r.cn)("absolute right-[1.6rem] top-1/2 -translate-y-1/2", C && "right-4"),
                                onClick: e => {
                                    if (e.preventDefault(), e.stopPropagation(), v.current) v.current.showPicker();
                                    else if (N && "current" in N) {
                                        var t;
                                        null == (t = N.current) || t.showPicker()
                                    }
                                },
                                children: (0, n.jsx)(l.A, {
                                    className: "w-4 h-4 text-white"
                                })
                            })]
                        }), "password" === d && (R || !a) && (0, n.jsx)("button", {
                            type: "button",
                            onClick: () => {
                                P(e => !e)
                            },
                            className: "absolute right-[1.6rem] top-1/2 -translate-y-1/2 text-white/50 hover:text-white/80",
                            children: T ? (0, n.jsx)(o.A, {
                                className: "w-5 h-5"
                            }) : (0, n.jsx)(i.A, {
                                className: "w-5 h-5"
                            })
                        }), b && (0, n.jsx)("div", {
                            className: "absolute pointer-events-none right-4 top-1/2 -translate-y-1/2",
                            children: b
                        }), !!a && (0, n.jsx)("label", {
                            htmlFor: t,
                            className: (0, r.cn)("absolute left-6 transition-all duration-200 pointer-events-none text-white/50 ".concat(R ? "top-2 text-[9px]" : "top-4 text-sm"), m),
                            children: a
                        })]
                    })
                };
            _.displayName = "FloatingLabelInput";
            let x = _
        },
        51849: (e, t, a) => {
            a.d(t, {
                A: () => u
            });
            var n = a(95155),
                r = a(12710);
            a(12115);
            var s = a(92033),
                l = a(64269);
            let o = (0, r.tv)({
                    base: "relative",
                    variants: {
                        fullWidth: {
                            true: "w-full"
                        },
                        size: {
                            sm: "",
                            md: ""
                        }
                    }
                }),
                i = (0, r.tv)({
                    base: "bg-[#0D0D0D] rounded-full w-full h-full",
                    variants: {
                        size: {
                            sm: "px-3 py-[2px]",
                            md: "px-4 py-[9px]"
                        }
                    }
                }),
                d = (0, r.tv)({
                    base: "text-base text-[#FFFFFF] opacity-80",
                    variants: {
                        size: {
                            sm: "text-sm",
                            md: "text-base"
                        },
                        xPadding: {
                            single: "",
                            double: ""
                        },
                        disabled: {
                            true: "text-gray-400",
                            false: ""
                        }
                    },
                    compoundVariants: [{
                        xPadding: "double",
                        size: "sm",
                        class: "px-3"
                    }, {
                        xPadding: "double",
                        size: "md",
                        class: "px-4"
                    }]
                }),
                c = e => {
                    let {
                        size: t = "md",
                        xPadding: a = "single",
                        innerClassName: r,
                        children: c,
                        onClick: u,
                        style: p,
                        className: m,
                        fullWidth: f = !1,
                        isLoading: h = !1,
                        disabled: g = !1,
                        innerBgColor: _ = "#0D0D0D",
                        borderVariant: x = "default",
                        ...E
                    } = e;
                    return (0, n.jsx)("button", {
                        className: o({
                            fullWidth: f,
                            className: m
                        }),
                        onClick: u,
                        style: {
                            background: g ? "linear-gradient(90deg, #333333 0%, #333333 28%, #555555 66%, #333333 100%)" : "default" === x ? "linear-gradient(90deg, #464646 0%, #333333 28%, #9C9C9C 66%, #464646 100%)" : "linear-gradient(90deg, #00000000 0%, #FFFFFF 42%, #9C9C9C 66%, #00000000 100%)",
                            borderRadius: "40px",
                            padding: "1px",
                            ...p
                        },
                        disabled: g || h,
                        ...E,
                        "data-sentry-component": "ButtonCapsule",
                        "data-sentry-source-file": "ButtonCapsule.tsx",
                        children: (0, n.jsx)("div", {
                            className: (0, l.cn)(i({
                                size: t
                            }), r),
                            style: {
                                background: _
                            },
                            children: (0, n.jsx)("span", {
                                className: d({
                                    size: t,
                                    xPadding: a,
                                    disabled: g
                                }),
                                children: h ? (0, n.jsx)(s.A, {
                                    className: "h-6 animate-spin w-full"
                                }) : c
                            })
                        })
                    })
                };
            c.displayName = "ButtonCapsule";
            let u = c
        },
        61464: (e, t, a) => {
            a.d(t, {
                T: () => o
            });
            let n = [{
                    path: "/search/flights",
                    params: ["origin", "destination", "start_date", "return_date", "end_date", "mode", "cabin", "adults", "children", "infants", "payment", "departingFlightId", "returningFlightId"]
                }, {
                    path: "/search/flights/cash",
                    params: ["origin", "destination", "start_date", "return_date", "end_date", "mode", "cabin", "adults", "children", "infants", "payment", "departingFlightId", "returningFlightId"]
                }, {
                    path: "/transfer-miles",
                    params: []
                }, {
                    path: "/transfer-miles/*",
                    params: []
                }, {
                    path: "/hotels/booking",
                    params: ["bookingId"]
                }, {
                    path: "/profile",
                    params: []
                }, {
                    path: "/flights/booking",
                    params: ["offerId", "paymentMethod"]
                }],
                r = (e, t) => {
                    if (e.startsWith("/")) {
                        var a;
                        let r = new URL((null == (a = window.location) ? void 0 : a.origin) + e),
                            s = r.pathname,
                            l = r.searchParams,
                            o = n.find(e => {
                                if (e.path.endsWith("*")) {
                                    let t = e.path.slice(0, -1);
                                    return s.startsWith(t)
                                }
                                return e.path === s
                            });
                        if (!o) return t;
                        l.forEach((e, t) => {
                            o.params.includes(t) || l.delete(t)
                        });
                        let i = l.toString();
                        return r.pathname + (i ? "?" + i : "")
                    }
                    return t
                };
            var s = a(20063),
                l = a(12115);
            let o = () => {
                let e = (0, s.useSearchParams)().get("redirect");
                return (0, l.useMemo)(() => e ? r(decodeURIComponent(e), "/") : null, [e])
            }
        },
        64269: (e, t, a) => {
            a.d(t, {
                cn: () => s
            });
            var n = a(2821),
                r = a(75889);

            function s() {
                for (var e = arguments.length, t = Array(e), a = 0; a < e; a++) t[a] = arguments[a];
                return (0, r.QP)((0, n.$)(t))
            }
        },
        75329: (e, t, a) => {
            a.d(t, {
                A: () => s
            });
            var n = a(15653);
            let r = n.z.object({
                    NEXT_PUBLIC_SUPABASE_URL: n.z.string(),
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: n.z.string(),
                    NEXT_PUBLIC_ENV: n.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_MIXPANEL_TOKEN: n.z.string(),
                    NEXT_PUBLIC_SENTRY_DSN: n.z.string(),
                    NEXT_PUBLIC_SENTRY_ORG: n.z.string(),
                    NEXT_PUBLIC_SENTRY_PROJECT: n.z.string(),
                    NEXT_PUBLIC_SENTRY_ENV: n.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_ENABLE_BANNER: n.z.coerce.boolean().default(!1),
                    NEXT_PUBLIC_FACEBOOK_PIXEL_ID: n.z.string(),
                    NEXT_PUBLIC_TIKTOK_PIXEL_ID: n.z.string(),
                    NEXT_PUBLIC_REDDIT_PIXEL_ID: n.z.string()
                }),
                s = (() => {
                    try {
                        return r.parse({
                            NEXT_PUBLIC_SUPABASE_URL: "https://api.rovemiles.com",
                            NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4d3BpcWh3cmtxYXl6a3BkZXJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkwMjM5MDMsImV4cCI6MjA0NDU5OTkwM30.9bm_de4Zwm8gM1tILRZyYvuBe7ymJxycP4dYYxzo8Kw",
                            NEXT_PUBLIC_ENV: "production",
                            NEXT_PUBLIC_MIXPANEL_TOKEN: "9da7db12d48488485c9d6cfac54831b3",
                            NEXT_PUBLIC_SENTRY_DSN: "https://d2b1818c4d1059a71206cf1a19342e14@o4508490297638912.ingest.us.sentry.io/4508490311532544",
                            NEXT_PUBLIC_SENTRY_ORG: "rove-22",
                            NEXT_PUBLIC_SENTRY_PROJECT: "rove-miles-portal",
                            NEXT_PUBLIC_SENTRY_ENV: "production",
                            NEXT_PUBLIC_ENABLE_BANNER: "true",
                            NEXT_PUBLIC_FACEBOOK_PIXEL_ID: "1877255199716926",
                            NEXT_PUBLIC_TIKTOK_PIXEL_ID: "D0R4033C77UBLRIEQ98G",
                            NEXT_PUBLIC_REDDIT_PIXEL_ID: "a2_gw72ldodzgpx"
                        })
                    } catch (e) {
                        throw e instanceof n.z.ZodError && console.error("❌ Invalid environment variables:", e.errors.map(e => "".concat(e.path, ": ").concat(e.message))), e
                    }
                })()
        },
        77650: (e, t, a) => {
            a.d(t, {
                U: () => s
            });
            var n = a(62471),
                r = a(75329);

            function s(e) {
                return (0, n.createBrowserClient)(r.A.NEXT_PUBLIC_SUPABASE_URL, r.A.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
                    db: {
                        schema: e
                    }
                })
            }
        },
        81264: (e, t, a) => {
            a.d(t, {
                Toaster: () => d,
                o: () => c
            });
            var n = a(95155),
                r = a(12115),
                s = a(22663),
                l = a(74233),
                o = a(26615);
            let i = "rgba(255, 255, 255, 0.11)",
                d = () => {
                    let {
                        toasts: e
                    } = (0, s.Nk)();
                    return (0, r.useEffect)(() => {
                        e.filter(e => e.visible).filter((e, t) => t >= 6).forEach(e => c.dismiss(e.id))
                    }, [e]), (0, n.jsx)(s.l$, {
                        position: "top-center",
                        toastOptions: {
                            style: {
                                background: i,
                                color: "white",
                                fontFamily: "var(--font-untitled-sans), sans-serif",
                                fontWeight: "400",
                                backdropFilter: "blur(12px)",
                                borderRadius: "8px",
                                padding: "12px 14px"
                            }
                        },
                        "data-sentry-element": "ReactHotToaster",
                        "data-sentry-component": "Toaster",
                        "data-sentry-source-file": "Toaster.tsx",
                        children: e => (0, n.jsx)(s.bv, {
                            toast: e,
                            children: t => {
                                let {
                                    icon: a,
                                    message: r
                                } = t;
                                return (0, n.jsxs)(n.Fragment, {
                                    children: [(0, n.jsx)("span", {
                                        className: "opacity-90 text-sm",
                                        children: a
                                    }), (0, n.jsx)("span", {
                                        className: "pl-1 opacity-90 text-[13px] leading-[20px]",
                                        children: r
                                    }), "loading" !== e.type && e.closeButton && (0, n.jsx)("button", {
                                        onClick: () => c.dismiss(e.id),
                                        children: (0, n.jsx)(o.A, {
                                            className: "text-[12px] opacity-90"
                                        })
                                    })]
                                })
                            }
                        })
                    })
                },
                c = { ...s.oR,
                    plain: (e, t) => (0, s.oR)(e, { ...t
                    }),
                    info: (e, t) => (0, s.oR)(e, {
                        icon: (0, n.jsx)(l.Izb, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(59, 130, 246, 0.11)" : i,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    success: (e, t) => (0, s.oR)(e, {
                        icon: (0, n.jsx)(l.v_8, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(34, 197, 94, 0.11)" : i,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    warn: (e, t) => (0, s.oR)(e, {
                        icon: (0, n.jsx)(l.qVL, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(234, 179, 8, 0.11)" : i,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    error: (e, t) => (0, s.oR)(e, {
                        icon: (0, n.jsx)(l.Edw, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(239, 68, 68, 0.11)" : i,
                            ...null == t ? void 0 : t.style
                        },
                        duration: 1e4,
                        ...t
                    }),
                    loading: (e, t) => s.oR.loading(e, { ...t,
                        icon: (0, n.jsx)(s.hz, {
                            style: {
                                width: "24px",
                                height: "24px"
                            }
                        })
                    }),
                    promise: async function(e, t, a) {
                        let n = { ...a
                        };
                        try {
                            n.id = c.loading(t.loading, n);
                            let a = await e;
                            return c.success(t.success, n), a
                        } catch (e) {
                            c.error(t.error, n)
                        }
                    }
                }
        },
        85163: (e, t, a) => {
            a.d(t, {
                $: () => n
            });
            let n = {
                FLIGHT_SEARCH_PERFORMED: "FlightSearchPerformed",
                FLIGHT_SELECTED: "FlightSelected",
                FLIGHT_BOOKED: "FlightBooked",
                MILES_TRANSFERRED: "MilesTransferred",
                HOTEL_SEARCH_PERFORMED: "HotelSearchPerformed",
                HOTEL_ROOM_SELECTED: "HotelRoomSelected",
                HOTEL_BOOKED: "HotelBooked",
                USER_LOGGED_IN: "UserLoggedIn",
                BOOKING_STARTED: "BookingStarted",
                BOOKING_ABANDONED: "BookingAbandoned",
                ONBOARDING_COMPLETED: "OnboardingCompleted",
                FIRST_BOOKING_COMPLETED: "FirstBookingCompleted",
                USER_RETURNED: "UserReturned",
                REFERRAL_USED: "ReferralUsed",
                MILES_REDEEMED: "MilesRedeemed",
                MILES_EARNED: "MilesEarned"
            }
        }
    }
]);