! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            s = (new e.Error).stack;
        s && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[s] = "f686d317-7444-477c-a717-c3af7d4af874", e._sentryDebugIdIdentifier = "sentry-dbid-f686d317-7444-477c-a717-c3af7d4af874")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7708], {
        1188: (e, s, a) => {
            a.d(s, {
                A: () => i
            });
            var t = a(95155);
            let l = (0, a(67909).default)(() => a.e(1438).then(a.bind(a, 51438)), {
                loadableGenerated: {
                    webpack: () => [51438]
                },
                ssr: !1,
                loading: () => (0, t.jsx)("div", {
                    className: "w-full h-full bg-black"
                })
            });

            function i(e) {
                return (0, t.jsx)(l, { ...e,
                    "data-sentry-element": "DynamicStarField",
                    "data-sentry-component": "LazyStarField",
                    "data-sentry-source-file": "LazyStarField.tsx"
                })
            }
        },
        5963: (e, s, a) => {
            a.d(s, {
                L: () => d
            });
            var t = a(95155),
                l = a(12115),
                i = a(56297),
                n = a(81264),
                r = a(92033);
            let d = () => {
                let [e, s] = (0, l.useState)(""), [a, d] = (0, l.useState)(!1);
                return (0, t.jsx)("div", {
                    className: "flex flex-col items-center justify-center py-6 sm:py-0 relative px-4 sm:px-8 bg-[#0d0d0d]",
                    "data-sentry-component": "NewsletterSection",
                    "data-sentry-source-file": "NewsletterSection.tsx",
                    children: (0, t.jsxs)("div", {
                        className: "flex flex-col w-[1100px] max-w-full h-full items-center justify-center py-12",
                        children: [(0, t.jsx)("div", {
                            className: "w-full h-[1px]",
                            style: {
                                background: "linear-gradient(90deg, rgba(0,0,0,0) 0%, #333333 28%, #9C9C9C 66%, rgba(0,0,0,0) 100%)"
                            }
                        }), (0, t.jsxs)("div", {
                            className: "flex flex-col sm:flex-row items-center justify-center py-6 sm:py-12 w-full gap-6 sm:gap-12",
                            children: [(0, t.jsx)("p", {
                                className: "text-center text-base sm:text-3xl text-white",
                                children: "Get free, exclusive travel deals."
                            }), (0, t.jsx)("div", {
                                className: "w-full px-4 sm:px-0 max-w-[450px]",
                                children: (0, t.jsx)(i.A, {
                                    placeholder: "Email",
                                    type: "email",
                                    className: "p-4 sm:p-5 pr-28 sm:pr-32",
                                    onChange: e => {
                                        s(e.target.value)
                                    },
                                    value: e,
                                    "data-sentry-element": "LandingSearchInput",
                                    "data-sentry-source-file": "NewsletterSection.tsx",
                                    children: (0, t.jsx)("button", {
                                        className: "right-3 bg-[#D8CEFF] text-[#28262F] rounded-lg sm:rounded-xl px-4 py-2 text-xs sm:text-base disabled:opacity-75 relative",
                                        disabled: a,
                                        onClick: async () => {
                                            d(!0);
                                            try {
                                                let l = await fetch("/api/newsletter/register", {
                                                        method: "POST",
                                                        headers: {
                                                            "Content-Type": "application/json"
                                                        },
                                                        body: JSON.stringify({
                                                            email: e
                                                        })
                                                    }),
                                                    i = await l.json();
                                                if (!l.ok) {
                                                    var a, t;
                                                    let e = (null == (t = i.details) || null == (a = t[0]) ? void 0 : a.message) || i.error || "Email submission failed";
                                                    n.o.error(e);
                                                    return
                                                }
                                                s(""), n.o.success("Thank you for subscribing!")
                                            } catch (e) {
                                                n.o.error("Subscription failed. Please try again.")
                                            } finally {
                                                d(!1)
                                            }
                                        },
                                        children: a ? (0, t.jsx)(r.A, {
                                            className: "animate-spin h-5 w-5 text-[#28262F]"
                                        }) : "Subscribe"
                                    })
                                })
                            })]
                        }), (0, t.jsx)("div", {
                            className: "w-full h-[1px]",
                            style: {
                                background: "linear-gradient(90deg, rgba(0,0,0,0) 0%, #333333 28%, #9C9C9C 66%, rgba(0,0,0,0) 100%)"
                            }
                        })]
                    })
                })
            }
        },
        17059: (e, s, a) => {
            a.d(s, {
                V: () => m
            });
            var t = a(95155),
                l = a(64269),
                i = a(15239),
                n = a(12115),
                r = a(86758);
            let d = e => 1 - Math.pow(1 - e, 3),
                c = e => {
                    let {
                        label: s,
                        points: a,
                        multiplier: r,
                        widthMultiplier: c,
                        isRoveMiles: o,
                        fieldWidth: x = 0,
                        isMobile: m = !1,
                        cpm: u = ""
                    } = e, h = a * r, g = c ? c * a : h, f = h > 0 ? "$" + Number(h.toFixed(0)).toLocaleString() : "-", p = o ? .018 * a : 0, v = p > 0 ? "$" + Number(p.toFixed(2)).toLocaleString() : "-", w = o ? .022 * a : 0, y = w > 0 ? "$" + Number(w.toFixed(2)).toLocaleString() : "-", N = o ? .06 * a : 0, A = N > 0 ? "$" + Number(N.toFixed(2)).toLocaleString() + "+" : "-", b = 3e4 * d(a / 5e5), j = Math.min((m ? 100 : 220) / x, 1), E = (j + p / b + .05 * !m) * x, S = (j + w / b + .07 * !m) * x, R = (0, n.useMemo)(() => o ? Math.min(1, j + N / b) : j + g / b, [o, N, b, j, g]), T = (0, n.useMemo)(() => R > .7, [R]), C = (0, n.useMemo)(() => R > .95, [R]);
                    return (0, t.jsxs)("div", {
                        className: "flex flex-col gap-1 select-none",
                        "data-sentry-component": "Column",
                        "data-sentry-source-file": "PointsChartSection.tsx",
                        children: [!o && (0, t.jsx)("div", {
                            className: "block sm:hidden text-xs text-white/80",
                            children: s
                        }), (0, t.jsxs)("div", {
                            className: "flex gap-2 relative transition-all duration-300",
                            style: {
                                width: "".concat(100 * R, "%")
                            },
                            children: [(0, t.jsx)("div", {
                                className: "relative rounded-lg w-full",
                                style: {
                                    background: o ? "linear-gradient(13deg, #9C9C9C 19%, #333333 34%, #fff 100%)" : void 0,
                                    padding: o ? "1px" : void 0
                                },
                                children: (0, t.jsxs)("div", {
                                    className: (0, l.cn)("bg-[#161618] rounded-lg relative w-full"),
                                    children: [o && (0, t.jsx)(t.Fragment, {
                                        children: (0, t.jsx)("div", {
                                            className: "absolute w-full h-full rounded-lg",
                                            style: {
                                                background: "linear-gradient(13deg, #0D0D0D 0%, #18171B 35%, #232129 50%, #18171B 65%, #0D0D0D 100%)"
                                            }
                                        })
                                    }), (0, t.jsxs)("div", {
                                        className: "w-full h-full relative px-3 sm:px-6 py-2 sm:py-3 flex justify-between items-center",
                                        children: [o && (0, t.jsx)("div", {
                                            className: "relative w-[80px] sm:w-[160px] h-[20px] sm:h-[27px]",
                                            children: (0, t.jsx)(i.default, {
                                                src: "/full-logo.png",
                                                alt: "Rove Miles",
                                                fill: !0,
                                                className: "object-contain",
                                                sizes: "1500px"
                                            })
                                        }), (0, t.jsxs)("div", {
                                            className: "flex flex-col gap-1 relative",
                                            children: [(0, t.jsx)("p", {
                                                className: (0, l.cn)("text-white/80 text-xs sm:text-xl whitespace-nowrap hidden sm:block", o && "text-white text-end"),
                                                children: o ? A : s
                                            }), (0, t.jsx)("p", {
                                                className: (0, l.cn)("text-white/50 text-xs sm:text-base whitespace-nowrap", o && "text-center"),
                                                children: o ? (0, t.jsxs)(t.Fragment, {
                                                    children: [(0, t.jsxs)("span", {
                                                        className: "hidden sm:block",
                                                        children: ["Business & First ", (0, t.jsx)("span", {
                                                            className: "text-[#6ACD85]",
                                                            children: "(6.0\xa2 each)"
                                                        })]
                                                    }), (0, t.jsxs)("span", {
                                                        className: "block sm:hidden",
                                                        children: ["Business & First", " ", (T || C) && (0, t.jsx)("span", {
                                                            className: "text-[#6ACD85]",
                                                            children: "(6.0\xa2 each)"
                                                        })]
                                                    })]
                                                }) : (0, t.jsxs)(t.Fragment, {
                                                    children: [(0, t.jsxs)("span", {
                                                        className: "hidden sm:block",
                                                        children: [f, " ", u && (0, t.jsx)("span", {
                                                            className: 1 >= parseFloat(u) ? "text-[#F77064]" : "text-[#FFD352]",
                                                            children: " (".concat(u, "\xa2 each)")
                                                        })]
                                                    }), (0, t.jsx)("span", {
                                                        className: "block sm:hidden",
                                                        children: f
                                                    })]
                                                })
                                            })]
                                        })]
                                    }), o && (0, t.jsxs)(t.Fragment, {
                                        children: [(0, t.jsxs)("div", {
                                            className: "absolute top-0 -translate-y-full transition-all duration-300",
                                            style: {
                                                left: isNaN(E) ? 0 : E
                                            },
                                            children: [(0, t.jsxs)("div", {
                                                className: "text-white/80 text-xs sm:text-xl relative translate-y-3/4 translate-x-5 flex flex-col gap-[2px]",
                                                children: [(0, t.jsxs)("div", {
                                                    className: "hidden sm:block whitespace-nowrap",
                                                    children: ["Average ", v, " for hotels", (0, t.jsx)("p", {
                                                        className: "text-[#6ACD85] text-xs sm:text-base",
                                                        children: "(1.8\xa2 each)"
                                                    })]
                                                }), (0, t.jsxs)("div", {
                                                    className: "block sm:hidden whitespace-nowrap",
                                                    children: [v, (0, t.jsx)("span", {
                                                        className: "text-[#6ACD85] text-xs sm:text-base",
                                                        children: " (1.8\xa2 each)"
                                                    })]
                                                }), (0, t.jsx)("div", {
                                                    className: "block sm:hidden text-[10px] text-white/50 whitespace-nowrap",
                                                    children: "Avg. for hotels"
                                                })]
                                            }), (0, t.jsx)("div", {
                                                className: "w-3 h-3 rounded-full bg-white/50 border border-white/30 border-solid relative -translate-x-1/2"
                                            }), (0, t.jsx)("div", {
                                                className: "h-5 sm:h-8 w-[1px] bg-white/30"
                                            })]
                                        }), (0, t.jsxs)("div", {
                                            className: "absolute left-[22%] transition-all duration-300",
                                            style: {
                                                left: isNaN(S) ? 0 : S
                                            },
                                            children: [(0, t.jsx)("div", {
                                                className: "h-5 sm:h-8 w-[1px] bg-white/30"
                                            }), (0, t.jsx)("div", {
                                                className: "w-3 h-3 rounded-full bg-white/50 border border-white/30 border-solid relative -translate-x-1/2"
                                            }), (0, t.jsxs)("div", {
                                                className: "text-white/80 text-xs sm:text-xl relative -translate-y-3/4 translate-x-5 flex flex-col gap-[2px]",
                                                children: [(0, t.jsxs)("div", {
                                                    className: "hidden sm:block whitespace-nowrap",
                                                    children: ["Average ", y, " for economy flights", (0, t.jsx)("p", {
                                                        className: "text-[#6ACD85] text-xs sm:text-base",
                                                        children: "(2.2\xa2 each)"
                                                    })]
                                                }), (0, t.jsxs)("div", {
                                                    className: "block sm:hidden whitespace-nowrap",
                                                    children: [y, (0, t.jsx)("span", {
                                                        className: "text-[#6ACD85] text-xs sm:text-base",
                                                        children: " (2.2\xa2 each)"
                                                    })]
                                                }), (0, t.jsx)("div", {
                                                    className: "block sm:hidden text-[10px] text-white/50 whitespace-nowrap",
                                                    children: "Avg. for economy flights"
                                                })]
                                            })]
                                        })]
                                    })]
                                })
                            }), o && (0, t.jsx)(t.Fragment, {
                                children: !(T || C) && (0, t.jsx)("div", {
                                    className: "text-xs text-[#6ACD85] whitespace-nowrap flex sm:hidden items-center absolute -right-2 translate-x-full h-full",
                                    children: "(6.0\xa2 each)"
                                })
                            }), !o && u && (0, t.jsx)("div", {
                                className: "flex sm:hidden items-center justify-center ml-2 whitespace-nowrap",
                                children: (0, t.jsx)("div", {
                                    className: "".concat(1 >= parseFloat(u) ? "text-[#F77064]" : "text-[#FFD352]", " text-xs sm:text-base"),
                                    children: "(".concat(u, "\xa2 each)")
                                })
                            })]
                        })]
                    })
                },
                o = e => {
                    let {
                        points: s,
                        isMobile: a
                    } = e, i = (0, n.useRef)(null), [r, d] = (0, n.useState)(0);
                    return (0, n.useEffect)(() => {
                        if (!i.current) return;
                        let e = new ResizeObserver(e => {
                            d(e[0].contentRect.width)
                        });
                        return e.observe(i.current), d(i.current.clientWidth), () => {
                            e.disconnect()
                        }
                    }, []), (0, t.jsxs)("div", {
                        className: "w-full relative",
                        ref: i,
                        "data-sentry-component": "Charts",
                        "data-sentry-source-file": "PointsChartSection.tsx",
                        children: [(0, t.jsx)("div", {
                            className: "absolute -top-[5%] left-0 right-0 w-full h-[110%] flex justify-between px-6 select-none",
                            children: Array.from({
                                length: 7
                            }).map((e, s) => (0, t.jsx)("div", {
                                className: "h-full w-[1px] bg-white/10"
                            }, s))
                        }), (0, t.jsxs)("div", {
                            className: "relative w-full space-y-8 sm:space-y-8",
                            children: [(0, t.jsx)(c, {
                                label: "Cash back",
                                points: s,
                                multiplier: .006,
                                fieldWidth: r,
                                isMobile: a,
                                cpm: "0.6",
                                "data-sentry-element": "Column",
                                "data-sentry-source-file": "PointsChartSection.tsx"
                            }), (0, t.jsx)(c, {
                                label: "Gift cards",
                                points: s,
                                multiplier: .0075,
                                fieldWidth: r,
                                isMobile: a,
                                cpm: "0.75",
                                "data-sentry-element": "Column",
                                "data-sentry-source-file": "PointsChartSection.tsx"
                            }), (0, t.jsx)(c, {
                                label: "Credit card travel portal",
                                points: s,
                                multiplier: .01,
                                widthMultiplier: .012,
                                fieldWidth: r,
                                isMobile: a,
                                cpm: "1.0",
                                "data-sentry-element": "Column",
                                "data-sentry-source-file": "PointsChartSection.tsx"
                            }), (0, t.jsx)("div", {
                                className: (0, l.cn)(a ? "pt-4" : ""),
                                children: (0, t.jsx)(c, {
                                    label: "Rove Miles",
                                    points: s,
                                    multiplier: 1,
                                    isRoveMiles: !0,
                                    fieldWidth: r,
                                    isMobile: a,
                                    "data-sentry-element": "Column",
                                    "data-sentry-source-file": "PointsChartSection.tsx"
                                })
                            })]
                        })]
                    })
                },
                x = e => e <= 25e3 ? 1e3 * Math.round(e / 1e3) : e <= 1e5 ? 25e3 * Math.round(e / 25e3) : 5e4 * Math.round(e / 5e4),
                m = e => {
                    let {
                        isMobile: s
                    } = e, [a, l] = (0, n.useState)(5e4), [i, d] = (0, n.useState)(!1), c = a.toLocaleString(), m = Math.max(1e4, Math.min(5e5, a)), u = (0, n.useRef)(null);
                    (0, n.useEffect)(() => () => {
                        u.current && clearTimeout(u.current)
                    }, []);
                    let h = e => {
                        l(x(e))
                    };
                    return (0, t.jsx)("section", {
                        className: "relative flex items-center justify-center overflow-hidden pb-32",
                        "data-sentry-component": "PointsChartSection",
                        "data-sentry-source-file": "PointsChartSection.tsx",
                        children: (0, t.jsx)("div", {
                            className: "max-w-7xl w-full mx-auto px-6 pt-6 xl:px-0",
                            children: (0, t.jsxs)("div", {
                                className: "flex flex-col gap-8",
                                children: [(0, t.jsxs)("div", {
                                    className: "flex items-center justify-center gap-2 sm:gap-4 text-base sm:text-2xl md:text-3xl select-none",
                                    children: [(0, t.jsx)("span", {
                                        className: "text-white/80 w-[110px] sm:w-[195px] text-right",
                                        children: "How much are"
                                    }), (0, t.jsx)("input", {
                                        type: "text",
                                        value: isNaN(a) ? 1e4 : c,
                                        onFocus: () => d(!0),
                                        onBlur: () => {
                                            d(!1), h(Math.max(1e4, Math.min(5e5, m)))
                                        },
                                        onChange: e => {
                                            let s = Number(e.target.value.replace(/,/g, ""));
                                            if (!isNaN(s)) {
                                                if (s < 1e4 || i) {
                                                    l(s), u.current && clearTimeout(u.current), u.current = setTimeout(() => {
                                                        h(Math.max(1e4, Math.min(5e5, x(s))))
                                                    }, 2e3);
                                                    return
                                                }
                                                h(Math.min(s, 5e5))
                                            }
                                        },
                                        className: "text-2xl sm:text-5xl text-center px-1 sm:px-4 py-2 rounded border border-[#4B4B4B] border-solid bg-transparent w-[7rem] sm:w-[15rem] text-white"
                                    }), (0, t.jsx)("span", {
                                        className: "text-white/80 w-[110px] sm:w-[195px] text-left",
                                        children: "points worth?"
                                    })]
                                }), (0, t.jsx)("div", {
                                    className: "relative h-12 w-[500px] max-w-full px-5 mx-auto",
                                    children: (0, t.jsx)(r.A, {
                                        min: 1e4,
                                        max: 5e5,
                                        value: m,
                                        onChange: e => h(Math.round(e)),
                                        step: 13,
                                        size: s ? "sm" : "md",
                                        "data-sentry-element": "RangeSlider",
                                        "data-sentry-source-file": "PointsChartSection.tsx"
                                    })
                                }), (0, t.jsx)(o, {
                                    points: m !== a ? 0 : m,
                                    isMobile: s,
                                    "data-sentry-element": "Charts",
                                    "data-sentry-source-file": "PointsChartSection.tsx"
                                })]
                            })
                        })
                    })
                }
        },
        19979: (e, s, a) => {
            a.d(s, {
                V: () => c
            });
            var t = a(95155);
            a(12115);
            var l = a(15239),
                i = a(52619),
                n = a.n(i);
            let r = e => {
                    let {
                        children: s
                    } = e;
                    return (0, t.jsx)("span", {
                        className: "bg-gradient-to-b from-[#F9F9FB] to-[#9F97BF] bg-clip-text text-transparent",
                        "data-sentry-component": "GradientText",
                        "data-sentry-source-file": "FooterSection.tsx",
                        children: s
                    })
                },
                d = [{
                    title: "CONTACT",
                    links: [{
                        title: "BY EMAIL",
                        href: "mailto:contact@rovemiles.com"
                    }, {
                        title: "X / TWITTER",
                        href: "https://x.com/rovemiles"
                    }, {
                        title: "INSTAGRAM",
                        href: "https://www.instagram.com/joinrove"
                    }, {
                        title: "LINKEDIN",
                        href: "https://www.linkedin.com/company/rovemiles"
                    }, {
                        title: "TIKTOK",
                        href: "https://www.tiktok.com/@rovemiles"
                    }]
                }, {
                    title: "LEGAL",
                    links: [{
                        title: "PRIVACY POLICY",
                        href: "/privacy-policy"
                    }, {
                        title: "TERMS OF USE",
                        href: "/terms-of-use"
                    }, {
                        title: "PROGRAM TERMS",
                        href: "/program-terms"
                    }]
                }],
                c = () => (0, t.jsxs)("footer", {
                    className: "relative bg-[#0d0d0d] text-white pt-8 pb-16 sm:py-16 overflow-hidden flex flex-col items-center",
                    "data-sentry-component": "FooterSection",
                    "data-sentry-source-file": "FooterSection.tsx",
                    children: [(0, t.jsx)("div", {
                        className: "absolute opacity-20 top-[250px] sm:top-8 w-full -translate-x-1/2 sm:-translate-x-1/4 max-w-7xl",
                        children: (0, t.jsx)("div", {
                            className: "w-[250%] sm:w-[150%] aspect-[204/115] relative",
                            children: (0, t.jsx)(l.default, {
                                src: "/landing-assets/world-map.png",
                                alt: "World Map",
                                fill: !0,
                                sizes: "100vw",
                                className: "object-contain",
                                "data-sentry-element": "Image",
                                "data-sentry-source-file": "FooterSection.tsx"
                            })
                        })
                    }), (0, t.jsx)("div", {
                        className: "container mx-auto px-6 relative z-10 max-w-4xl w-full",
                        children: (0, t.jsxs)("div", {
                            className: "flex gap-4 flex-col sm:flex-row mb-12 sm:mb-32",
                            children: [(0, t.jsx)("div", {
                                className: "mb-6 sm:mb-12",
                                children: (0, t.jsx)(l.default, {
                                    src: "/logo.png",
                                    alt: "Rove Logo",
                                    width: 84,
                                    height: 27,
                                    priority: !0,
                                    "data-sentry-element": "Image",
                                    "data-sentry-source-file": "FooterSection.tsx"
                                })
                            }), (0, t.jsx)("div", {
                                className: "grid gap-8 w-full sm:pl-32",
                                style: {
                                    gridTemplateColumns: "repeat(".concat(d.length, ", 1fr)")
                                },
                                children: d.map(e => (0, t.jsxs)("div", {
                                    children: [(0, t.jsx)("h4", {
                                        className: "font-medium mb-6",
                                        children: (0, t.jsx)(r, {
                                            children: e.title
                                        })
                                    }), (0, t.jsx)("ul", {
                                        className: "space-y-6 text-xs sm:text-sm",
                                        children: e.links.map(e => (0, t.jsx)("li", {
                                            children: (0, t.jsx)(n(), {
                                                href: e.href,
                                                target: e.href.startsWith("http") ? "_blank" : void 0,
                                                className: "hover:text-white text-[#F4F2F7] transition-colors duration-300",
                                                children: e.title
                                            })
                                        }, e.href))
                                    })]
                                }, e.title))
                            }), (0, t.jsxs)("div", {
                                className: "mt-6 sm:mt-12 text-sm text-gray-400 relative sm:absolute sm:bottom-0 sm:left-3",
                                children: ["\xa9 ", new Date().getFullYear(), " ROVE CARD, INC."]
                            })]
                        })
                    }), (0, t.jsx)("div", {
                        className: "absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-[#0d0d0d] to-transparent pointer-events-none"
                    })]
                })
        },
        41992: (e, s, a) => {
            a.d(s, {
                C: () => i
            }), a(95155);
            var t = a(12115);
            a(56297), a(20063), a(2981);
            let l = ["New York", "Los Angeles", "London", "Paris", "Tokyo", "Sydney", "Berlin", "Rome", "Madrid", "Barcelona"],
                i = e => {
                    let {
                        pause: s = !1
                    } = e, [a, i] = (0, t.useState)(0), [n, r] = (0, t.useState)(""), [d, c] = (0, t.useState)(!0);
                    return (0, t.useEffect)(() => {
                        if (s) return;
                        let e = 0,
                            t = "",
                            n = null,
                            o = () => {
                                let s = l[a];
                                e < s.length ? (r(t += s[e]), e++, n = setTimeout(o, 100)) : (c(!1), setTimeout(() => {
                                    let e = () => {
                                        t.length > 0 ? (r(t = t.slice(0, -1)), n = setTimeout(e, 50)) : (c(!0), r(""), i(e => (e + 1) % l.length))
                                    };
                                    e()
                                }, 1e3))
                            };
                        return d && (e = 0, o()), () => {
                            n && clearTimeout(n)
                        }
                    }, [a, d, s]), {
                        currentCity: n || ""
                    }
                }
        },
        56297: (e, s, a) => {
            a.d(s, {
                A: () => n
            });
            var t = a(95155),
                l = a(64269);
            let i = (0, a(12115).memo)(e => {
                let {
                    children: s,
                    onClick: a,
                    style: i,
                    className: n,
                    as: r = "input",
                    ...d
                } = e;
                return (0, t.jsx)("div", {
                    className: "relative rounded-xl w-full",
                    onClick: a,
                    style: {
                        background: "linear-gradient(90deg, #464646 0%, #333333 28%, #9C9C9C 66%, #464646 100%)",
                        padding: "1px",
                        ...i
                    },
                    children: (0, t.jsxs)("div", {
                        className: "bg-[#0D0E0E] rounded-xl w-full h-full text-base text-[#FFFFFF] overflow-hidden relative flex justify-center items-center",
                        children: ["input" === r ? (0, t.jsx)("input", {
                            className: (0, l.cn)("bg-transparent w-full h-full text-base text-[#FFFFFF] opacity-80 p-5 focus:outline-none", n),
                            ...d
                        }) : (0, t.jsx)("div", {
                            className: (0, l.cn)("bg-transparent w-full h-full text-base text-[#FFFFFF]/50 opacity-80 p-5 focus:outline-none flex items-center", n),
                            ...d,
                            children: d.placeholder
                        }), s]
                    })
                })
            });
            i.displayName = "LandingSearchInput";
            let n = i
        },
        66947: (e, s, a) => {
            a.d(s, {
                o: () => t.o5
            });
            var t = a(71424)
        },
        71424: (e, s, a) => {
            a.d(s, {
                o5: () => x
            });
            var t = a(95155);
            a(12115);
            var l = a(64269);
            let i = {
                    light: "font-light",
                    regular: "font-normal",
                    medium: "font-medium",
                    bold: "font-bold"
                },
                n = {
                    primary: "text-fg-primary",
                    secondary: "text-fg-secondary",
                    tertiary: "text-fg-tertiary",
                    hushed: "text-fg-hushed"
                },
                r = {
                    xs: "text-xs leading-[1.125rem]",
                    sm: "text-sm leading-[1.25rem]",
                    md: "text-base leading-6",
                    lg: "text-lg leading-7",
                    xl: "text-xl leading-[1.875rem]",
                    "2xl": "text-2xl leading-[1.875rem]"
                },
                d = {
                    xs: "text-2xl leading-8",
                    sm: "text-[1.875rem] leading-[2.375rem]",
                    md: "text-4xl leading-[2.75rem] tracking-[-0.02em]",
                    lg: "text-5xl leading-[3.75rem] tracking-[-0.02em]",
                    xl: "text-[3.75rem] leading-[4.5rem] tracking-[-0.02em]",
                    "2xl": "text-[4.5rem] leading-[5.625rem] tracking-[-0.02em]"
                },
                c = (e, s) => "text" === e ? r[s] : d[s],
                o = (e, s) => {
                    if ("text" === e) return "span";
                    switch (s) {
                        case "xs":
                            return "h3";
                        case "sm":
                        case "md":
                            return "h2";
                        default:
                            return "h1"
                    }
                },
                x = e => {
                    let {
                        children: s,
                        className: a,
                        variant: r = "text",
                        size: d = "md",
                        weight: x = "regular",
                        as: m,
                        color: u = "primary",
                        ...h
                    } = e, g = m || o(r, d), f = c(r, d);
                    return (0, t.jsx)(g, {
                        className: (0, l.cn)(f, i[x], n[u], a),
                        ...h,
                        "data-sentry-element": "Component",
                        "data-sentry-component": "Typography",
                        "data-sentry-source-file": "Typography.tsx",
                        children: s
                    })
                }
        },
        86758: (e, s, a) => {
            a.d(s, {
                A: () => o
            });
            var t = a(95155),
                l = a(12115),
                i = a(47605),
                n = a(53902),
                r = a(64269);
            let d = e => e,
                c = e => e,
                o = e => {
                    let {
                        min: s,
                        max: a,
                        value: o,
                        onChange: x,
                        step: m,
                        size: u,
                        disabled: h = !1,
                        ignoreStep: g = !1
                    } = e, f = (0, l.useRef)(null), p = (0, l.useRef)(null), [v, w] = (0, l.useState)(0), [y, N] = (0, l.useState)(!1), A = (0, l.useRef)(0);
                    (0, l.useEffect)(() => {
                        let e = () => {
                            f.current && w(f.current.offsetWidth)
                        };
                        return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                    }, []);
                    let b = e => {
                        if (!h) {
                            let t = Date.now();
                            t - A.current > 50 && (A.current = t, x(Math.max(s, Math.min(a, e))))
                        }
                    };
                    (0, l.useEffect)(() => {
                        if (!f.current || !p.current || h) return;
                        i.Ay.registerPlugin(n.s);
                        let e = f.current,
                            t = p.current,
                            l = n.s.create(t, {
                                type: "x",
                                bounds: e,
                                inertia: !0,
                                zIndexBoost: !1,
                                zIndex: 10,
                                onDrag: function() {
                                    N(!0);
                                    let l = t.offsetWidth;
                                    b(s + (a - s) * d(this.x / (e.offsetWidth - l)))
                                },
                                onDragEnd: () => {
                                    N(!1)
                                }
                            })[0];
                        return () => {
                            l.kill()
                        }
                    }, [s, a, h]), (0, l.useEffect)(() => {
                        if (!p.current || !f.current || y) return;
                        let e = (o - s) / (a - s),
                            t = e * v;
                        i.Ay.to(p.current, {
                            x: t - p.current.offsetWidth * e,
                            duration: .3,
                            ease: "power2.out"
                        })
                    }, [o, s, a, v, y]);
                    let j = (0, l.useMemo)(() => Array.from({
                        length: m
                    }).map((e, s) => (0, t.jsx)("div", {
                        className: "w-[1px] h-full bg-white select-none",
                        style: {
                            opacity: Number((.1 + .7 * Math.sin(s / m * Math.PI)).toFixed(2))
                        }
                    }, s)), [m]);
                    return (0, t.jsxs)("div", {
                        ref: f,
                        className: (0, r.cn)("w-full relative cursor-pointer", "sm" === u ? "h-2" : "h-4", h && "opacity-50 cursor-not-allowed"),
                        "data-sentry-component": "RangeSlider",
                        "data-sentry-source-file": "RangeSlider.tsx",
                        children: [(0, t.jsx)("div", {
                            className: (0, r.cn)("absolute top-0 left-0 right-0 w-full h-full flex items-center justify-between", "sm" === u ? "px-6" : "px-3"),
                            onClick: e => {
                                if (h) return;
                                let t = e.currentTarget.getBoundingClientRect(),
                                    l = s + (a - s) * c((e.clientX - t.left) / e.currentTarget.offsetWidth),
                                    i = (a - s) / (m - 1);
                                b(g ? l : Math.round(l / i) * i + s)
                            },
                            children: j
                        }), (0, t.jsx)("div", {
                            ref: p,
                            className: (0, r.cn)("thumb absolute top-1/2 -translate-y-1/2 select-none flex justify-center items-center rounded-full", "sm" === u ? "w-12 h-12" : "w-6 h-6", h ? "cursor-not-allowed" : "cursor-grab active:cursor-grabbing"),
                            children: (0, t.jsx)("div", {
                                className: (0, r.cn)("rounded-full flex justify-center items-center active:border active:border-white/60", "sm" === u ? "w-5 h-5" : "w-6 h-6"),
                                children: (0, t.jsx)("div", {
                                    className: (0, r.cn)("rounded-full bg-white", "sm" === u ? "w-2 h-2" : "w-4 h-4")
                                })
                            })
                        })]
                    })
                }
        },
        87708: (e, s, a) => {
            a.d(s, {
                F8: () => n,
                VK: () => i.V,
                CD: () => l.C
            });
            var t = a(95155);
            a(15239), a(12115), a(1188);
            var l = a(41992);
            a(5963);
            var i = a(19979);
            a(49474), [{
                alliance: "oneworld",
                airlines: [{
                    url: "/landing-assets/airlines/oneworld/alaska-airlines.svg",
                    alt: "Alaska Airlines"
                }, {
                    url: "/landing-assets/airlines/oneworld/american-airlines.svg",
                    alt: "American Airlines"
                }, {
                    url: "/landing-assets/airlines/oneworld/british-airways.svg",
                    alt: "British Airways"
                }, {
                    url: "/landing-assets/airlines/oneworld/cathay-pacific.svg",
                    alt: "Cathay Pacific"
                }, {
                    url: "/landing-assets/airlines/oneworld/fiji-airways.svg",
                    alt: "Fiji Airways"
                }, {
                    url: "/landing-assets/airlines/oneworld/finnair.svg",
                    alt: "Finnair"
                }, {
                    url: "/landing-assets/airlines/oneworld/iberia.svg",
                    alt: "Iberia"
                }, {
                    url: "/landing-assets/airlines/oneworld/japan-airlines.svg",
                    alt: "Japan Airlines"
                }, {
                    url: "/landing-assets/airlines/oneworld/malaysia-airlines.svg",
                    alt: "Malaysia Airlines"
                }, {
                    url: "/landing-assets/airlines/oneworld/oman-air.svg",
                    alt: "Oman Air"
                }, {
                    url: "/landing-assets/airlines/oneworld/qantas.svg",
                    alt: "Qantas"
                }, {
                    url: "/landing-assets/airlines/oneworld/qatar-airways.svg",
                    alt: "Qatar Airways"
                }, {
                    url: "/landing-assets/airlines/oneworld/royal-air-maroc.svg",
                    alt: "Royal Air Maroc"
                }, {
                    url: "/landing-assets/airlines/oneworld/royal-jordanian.svg",
                    alt: "Royal Jordanian"
                }, {
                    url: "/landing-assets/airlines/oneworld/srilankan-airlines.svg",
                    alt: "SriLankan Airlines"
                }]
            }, {
                alliance: "skyteam",
                airlines: [{
                    url: "/landing-assets/airlines/skyteam/saudi-arabia-airlines.svg",
                    alt: "Saudi Arabia Airlines"
                }, {
                    url: "/landing-assets/airlines/skyteam/aerolineas-argentinas.svg",
                    alt: "Aerolineas Argentinas"
                }, {
                    url: "/landing-assets/airlines/skyteam/aeromexico.svg",
                    alt: "Aeromexico"
                }, {
                    url: "/landing-assets/airlines/skyteam/air-france.svg",
                    alt: "Air France"
                }, {
                    url: "/landing-assets/airlines/skyteam/aireuropa.svg",
                    alt: "Air Europa"
                }, {
                    url: "/landing-assets/airlines/skyteam/china-airlines.svg",
                    alt: "China Airlines"
                }, {
                    url: "/landing-assets/airlines/skyteam/china-eastern-air.svg",
                    alt: "China Eastern Air"
                }, {
                    url: "/landing-assets/airlines/skyteam/delta.svg",
                    alt: "Delta"
                }, {
                    url: "/landing-assets/airlines/skyteam/garuda-indonesia.svg",
                    alt: "Garuda Indonesia"
                }, {
                    url: "/landing-assets/airlines/skyteam/kenya-airlines.svg",
                    alt: "Kenya Airlines"
                }, {
                    url: "/landing-assets/airlines/skyteam/klm.svg",
                    alt: "KLM"
                }, {
                    url: "/landing-assets/airlines/skyteam/korean-air-lines.svg",
                    alt: "Korean Air Lines"
                }, {
                    url: "/landing-assets/airlines/skyteam/middle-east-airlines.svg",
                    alt: "Middle East Airlines"
                }, {
                    url: "/landing-assets/airlines/skyteam/sas.svg",
                    alt: "SAS"
                }, {
                    url: "/landing-assets/airlines/skyteam/tarom.svg",
                    alt: "TAROM"
                }, {
                    url: "/landing-assets/airlines/skyteam/vietnam-airlines.svg",
                    alt: "Vietnam Airlines"
                }, {
                    url: "/landing-assets/airlines/skyteam/virgin-atlantic.svg",
                    alt: "Virgin Atlantic"
                }, {
                    url: "/landing-assets/airlines/skyteam/xiamen-airlines.svg",
                    alt: "Xiamen Airlines"
                }]
            }, {
                alliance: "star-alliance",
                airlines: [{
                    url: "/landing-assets/airlines/star-alliance/aegean.svg",
                    alt: "Aegean Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/air-canada.svg",
                    alt: "Air Canada"
                }, {
                    url: "/landing-assets/airlines/star-alliance/air-china.svg",
                    alt: "Air China"
                }, {
                    url: "/landing-assets/airlines/star-alliance/air-india.svg",
                    alt: "Air India"
                }, {
                    url: "/landing-assets/airlines/star-alliance/air-new-zealand.svg",
                    alt: "Air New Zealand"
                }, {
                    url: "/landing-assets/airlines/star-alliance/asiana-airlines.svg",
                    alt: "Asiana Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/austrian-airlines.svg",
                    alt: "Austrian Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/avianca.svg",
                    alt: "Avianca"
                }, {
                    url: "/landing-assets/airlines/star-alliance/brussels-airlines.svg",
                    alt: "Brussels Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/copa-airlines.svg",
                    alt: "Copa Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/croatia-airlines.svg",
                    alt: "Croatia Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/egypt-air.svg",
                    alt: "Egypt Air"
                }, {
                    url: "/landing-assets/airlines/star-alliance/ethiopian.svg",
                    alt: "Ethiopian Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/eva-air.svg",
                    alt: "EVA Air"
                }, {
                    url: "/landing-assets/airlines/star-alliance/lot-polish-airlines.svg",
                    alt: "LOT Polish Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/lufthansa.svg",
                    alt: "Lufthansa"
                }, {
                    url: "/landing-assets/airlines/star-alliance/shenzhen-airlines.svg",
                    alt: "Shenzhen Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/singapore-air.svg",
                    alt: "Singapore Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/swiss-intl-air.svg",
                    alt: "SWISS"
                }, {
                    url: "/landing-assets/airlines/star-alliance/tap-portugal.svg",
                    alt: "TAP Air Portugal"
                }, {
                    url: "/landing-assets/airlines/star-alliance/thai-airways.svg",
                    alt: "Thai Airways"
                }, {
                    url: "/landing-assets/airlines/star-alliance/turkish-airlines.svg",
                    alt: "Turkish Airlines"
                }, {
                    url: "/landing-assets/airlines/star-alliance/united-airlines.svg",
                    alt: "United Airlines"
                }]
            }].flatMap(e => e.airlines), a(17059), a(66947), a(51849);
            let n = () => (0, t.jsx)("section", {
                className: "bg-[#0D0D0D] text-white/50 text-left py-16 sm:py-32 text-[10px] sm:text-xs flex justify-center items-center w-full px-6",
                "data-sentry-component": "DisclaimerSection",
                "data-sentry-source-file": "DisclaimerSection.tsx",
                children: (0, t.jsxs)("div", {
                    className: "flex flex-col gap-4 max-w-7xl w-full",
                    children: [(0, t.jsxs)("ol", {
                        className: "list-decimal pl-3",
                        children: [(0, t.jsx)("li", {
                            children: "ROVE DOES NOT GUARANTEE AVAILABILITY WITH ITS TRANSFER PARTNERS AND SIMPLY PROVIDES A TOOL FOR USERS TO SEARCH ON THEIR OWN."
                        }), (0, t.jsx)("li", {
                            children: "MILES TRANSFERS ARE USUALLY INSTANT BUT CAN TAKE UP TO ONE BUSINESS DAY TO PROCESS AND CANNOT BE REVERSED OR REFUNDED."
                        }), (0, t.jsx)("li", {
                            children: "ROVE PARTNERS WITH SELECT LOYALTY PROGRAMS FOR MILES TRANSFERS BUT IS NOT AFFILIATED WITH ALL AIRLINES FEATURED IN ITS DEALS."
                        }), (0, t.jsx)("li", {
                            children: "HOTEL EARN AND REDEMPTION RATES FLUCTUATE WITH DEMAND, WITH USERS POTENTIALLY EARNING UP TO 25X AND REDEEMING AT A RATE OF UP TO 2 CENTS PER MILE ON HOTEL BOOKINGS."
                        }), (0, t.jsx)("li", {
                            children: "ROVE’S CHROME EXTENSION HELPS USERS EARN MILES ON PURCHASES BUT DOES NOT GUARANTEE MILES OR REWARDS FROM PARTNER MERCHANTS."
                        }), (0, t.jsx)("li", {
                            children: "ALL LOGOS AND TRADEMARKS FEATURED HEREIN ARE THE SOLE PROPERTY OF THEIR RESPECTIVE OWNERS."
                        })]
                    }), (0, t.jsx)("p", {
                        children: "ROVE CARD, INC. IS A FINANCIAL TECHNOLOGY COMPANY, NOT AN AIRLINE, BANK, OR HOTEL OPERATOR."
                    })]
                })
            })
        }
    }
]);