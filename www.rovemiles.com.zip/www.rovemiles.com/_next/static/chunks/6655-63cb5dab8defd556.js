! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "9d4a6ccb-6504-411a-adc3-381b419c1223", t._sentryDebugIdIdentifier = "sentry-dbid-9d4a6ccb-6504-411a-adc3-381b419c1223")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6655], {
        3938: (t, e, n) => {
            "use strict";

            function r(t) {
                return t >= 500
            }

            function i(t) {
                try {
                    return t.clone()
                } catch (t) {
                    return
                }
            }
            n.d(e, {
                G: () => r,
                i: () => i
            })
        },
        6706: (t, e, n) => {
            "use strict";

            function r(t) {
                return { ...t
                }
            }

            function i(t, e) {
                return Object.keys(t).some(n => t[n] === e)
            }

            function a(t) {
                return 0 === Object.keys(t).length
            }

            function o(t, e) {
                let n = {};
                for (let r of Object.keys(t)) n[r] = e(t[r]);
                return n
            }
            n.d(e, {
                LG: () => o,
                RI: () => a,
                Rj: () => i,
                yG: () => r
            })
        },
        10676: (t, e, n) => {
            "use strict";

            function r() {
                if ("object" == typeof globalThis) return globalThis;
                Object.defineProperty(Object.prototype, "_dd_temp_", {
                    get() {
                        return this
                    },
                    configurable: !0
                });
                let t = _dd_temp_;
                return delete Object.prototype._dd_temp_, "object" != typeof t && (t = "object" == typeof self ? self : "object" == typeof window ? window : {}), t
            }
            n.d(e, {
                V: () => r
            })
        },
        11696: (t, e, n) => {
            "use strict";
            n.d(e, {
                l: () => o,
                q: () => a
            });
            var r = n(85590),
                i = n(14531);

            function a(t, e, n, r, i) {
                return o(t, e, [n], r, i)
            }

            function o(t, e, n, a, {
                once: s,
                capture: u,
                passive: l
            } = {}) {
                let c = (0, r.dm)(e => {
                        (e.isTrusted || e.__ddIsTrusted || t.allowUntrustedEvents) && (s && h(), a(e))
                    }),
                    d = l ? {
                        capture: u,
                        passive: l
                    } : u,
                    f = window.EventTarget && e instanceof EventTarget ? window.EventTarget.prototype : e,
                    p = (0, i.W)(f, "addEventListener");

                function h() {
                    let t = (0, i.W)(f, "removeEventListener");
                    n.forEach(n => t.call(e, n, c, d))
                }
                return n.forEach(t => p.call(e, t, c, d)), {
                    stop: h
                }
            }
        },
        14531: (t, e, n) => {
            "use strict";
            n.d(e, {
                W: () => i
            });
            var r = n(10676);

            function i(t, e) {
                let n, i = (0, r.V)();
                return i.Zone && "function" == typeof i.Zone.__symbol__ && (n = t[i.Zone.__symbol__(e)]), n || (n = t[e]), n
            }
        },
        15843: (t, e, n) => {
            "use strict";

            function r(t) {
                return null === t ? "null" : Array.isArray(t) ? "array" : typeof t
            }
            n.d(e, {
                P: () => r
            })
        },
        16878: (t, e, n) => {
            "use strict";
            n.d(e, {
                $A: () => u,
                Bb: () => r,
                Ih: () => l,
                NW: () => a,
                R8: () => s,
                TC: () => i,
                dV: () => o
            });
            let r = "datad0g.com",
                i = "dd0g-gov.com",
                a = "datadoghq.com",
                o = "datadoghq.eu",
                s = "ddog-gov.com",
                u = "pci.browser-intake-datadoghq.com",
                l = ["ddsource", "ddtags"]
        },
        19155: (t, e, n) => {
            "use strict";
            n.d(e, {
                y: () => i
            });
            var r = n(38954);

            function i(t, e) {
                return (...n) => {
                    try {
                        return t(...n)
                    } catch (t) {
                        r.Vy.error(e, t)
                    }
                }
            }
        },
        20063: (t, e, n) => {
            "use strict";
            var r = n(47260);
            n.o(r, "redirect") && n.d(e, {
                redirect: function() {
                    return r.redirect
                }
            }), n.o(r, "useParams") && n.d(e, {
                useParams: function() {
                    return r.useParams
                }
            }), n.o(r, "usePathname") && n.d(e, {
                usePathname: function() {
                    return r.usePathname
                }
            }), n.o(r, "useRouter") && n.d(e, {
                useRouter: function() {
                    return r.useRouter
                }
            }), n.o(r, "useSearchParams") && n.d(e, {
                useSearchParams: function() {
                    return r.useSearchParams
                }
            })
        },
        20405: (t, e, n) => {
            "use strict";
            n.d(e, {
                F: () => i,
                c: () => r
            });
            class r {
                constructor(t) {
                    this.onFirstSubscribe = t, this.observers = []
                }
                subscribe(t) {
                    return this.observers.push(t), 1 === this.observers.length && this.onFirstSubscribe && (this.onLastUnsubscribe = this.onFirstSubscribe(this) || void 0), {
                        unsubscribe: () => {
                            this.observers = this.observers.filter(e => t !== e), !this.observers.length && this.onLastUnsubscribe && this.onLastUnsubscribe()
                        }
                    }
                }
                notify(t) {
                    this.observers.forEach(e => e(t))
                }
            }

            function i(...t) {
                return new r(e => {
                    let n = t.map(t => t.subscribe(t => e.notify(t)));
                    return () => n.forEach(t => t.unsubscribe())
                })
            }
        },
        21096: (t, e, n) => {
            "use strict";
            n.d(e, {
                H: () => s,
                t: () => u
            });
            var r = n(94357),
                i = n(85590),
                a = n(98595),
                o = n(96605);

            function s(t, e, n, {
                computeHandlingStack: r
            } = {}) {
                let u = t[e];
                if ("function" != typeof u)
                    if (!(e in t && e.startsWith("on"))) return {
                        stop: a.l
                    };
                    else u = a.l;
                let l = !1,
                    c = function() {
                        let t;
                        if (l) return u.apply(this, arguments);
                        let e = Array.from(arguments);
                        (0, i.um)(n, null, [{
                            target: this,
                            parameters: e,
                            onPostCall: e => {
                                t = e
                            },
                            handlingStack: r ? (0, o.uC)("instrumented method") : void 0
                        }]);
                        let a = u.apply(this, e);
                        return t && (0, i.um)(t, null, [a]), a
                    };
                return t[e] = c, {
                    stop: () => {
                        l = !0, t[e] === c && (t[e] = u)
                    }
                }
            }

            function u(t, e, n) {
                let i = Object.getOwnPropertyDescriptor(t, e);
                if (!i || !i.set || !i.configurable) return {
                    stop: a.l
                };
                let o = a.l,
                    s = (t, e) => {
                        (0, r.wg)(() => {
                            s !== o && n(t, e)
                        }, 0)
                    },
                    u = function(t) {
                        i.set.call(this, t), s(this, t)
                    };
                return Object.defineProperty(t, e, {
                    set: u
                }), {
                    stop: () => {
                        var n;
                        (null == (n = Object.getOwnPropertyDescriptor(t, e)) ? void 0 : n.set) === u && Object.defineProperty(t, e, i), s = o
                    }
                }
            }
        },
        25909: (t, e, n) => {
            "use strict";
            n.d(e, {
                a: () => s
            });
            var r = n(38954),
                i = n(97617),
                a = n(58961);
            let o = 220 * i._m;

            function s(t, e = o) {
                let n = (0, a.M)(Object.prototype),
                    r = (0, a.M)(Array.prototype),
                    i = [],
                    c = new WeakMap,
                    d = u(t, "$", void 0, i, c),
                    f = JSON.stringify(d),
                    p = f ? f.length : 0;
                if (p > e) return void l(e, "discarded", t);
                for (; i.length > 0 && p < e;) {
                    let n = i.shift(),
                        r = 0;
                    if (Array.isArray(n.source))
                        for (let a = 0; a < n.source.length; a++) {
                            let o = u(n.source[a], n.path, a, i, c);
                            if (void 0 !== o ? p += JSON.stringify(o).length : p += 4, p += r, r = 1, p > e) {
                                l(e, "truncated", t);
                                break
                            }
                            n.target[a] = o
                        } else
                            for (let a in n.source)
                                if (Object.prototype.hasOwnProperty.call(n.source, a)) {
                                    let o = u(n.source[a], n.path, a, i, c);
                                    if (void 0 !== o && (p += JSON.stringify(o).length + r + a.length + 3, r = 1), p > e) {
                                        l(e, "truncated", t);
                                        break
                                    }
                                    n.target[a] = o
                                }
                }
                return n(), r(), d
            }

            function u(t, e, n, r, i) {
                let a = function(t) {
                    if (t && "function" == typeof t.toJSON) try {
                        return t.toJSON()
                    } catch (t) {}
                    return t
                }(t);
                if (!a || "object" != typeof a) {
                    var o;
                    return "bigint" == typeof(o = a) ? `[BigInt] ${o.toString()}` : "function" == typeof o ? `[Function] ${o.name||"unknown"}` : "symbol" == typeof o ? `[Symbol] ${o.description||o.toString()}` : o
                }
                let s = function t(e) {
                    try {
                        if (e instanceof Event) {
                            var n;
                            return {
                                type: (n = e).type,
                                isTrusted: n.isTrusted,
                                currentTarget: n.currentTarget ? t(n.currentTarget) : null,
                                target: n.target ? t(n.target) : null
                            }
                        }
                        if (e instanceof RegExp) return `[RegExp] ${e.toString()}`;
                        let r = Object.prototype.toString.call(e).match(/\[object (.*)\]/);
                        if (r && r[1]) return `[${r[1]}]`
                    } catch (t) {}
                    return "[Unserializable]"
                }(a);
                if ("[Object]" !== s && "[Array]" !== s && "[Error]" !== s) return s;
                if (i.has(t)) return `[Reference seen at ${i.get(t)}]`;
                let u = void 0 !== n ? `${e}.${n}` : e,
                    l = Array.isArray(a) ? [] : {};
                return i.set(t, u), r.push({
                    source: a,
                    target: l,
                    path: u
                }), l
            }

            function l(t, e, n) {
                r.Vy.warn(`The data provided has been ${e} as it is over the limit of ${t} characters:`, n)
            }
        },
        26664: (t, e, n) => {
            "use strict";
            let r;
            n.d(e, {
                $H: () => u,
                $S: () => m,
                FR: () => l,
                Gw: () => _,
                M8: () => g,
                MA: () => s,
                OY: () => a,
                Oc: () => y,
                TP: () => d,
                Zj: () => f,
                gs: () => b,
                iW: () => o,
                jR: () => c,
                nx: () => h,
                pu: () => w,
                vk: () => v,
                x3: () => p
            });
            var i = n(31352);
            let a = 1e3,
                o = 6e4,
                s = 36e5,
                u = 31536e6;

            function l(t) {
                return {
                    relative: t,
                    timeStamp: function(t) {
                        var e;
                        let n = p() - performance.now();
                        return n > S() ? Math.round(function(t, e) {
                            return t + e
                        }(n, t)) : (e = t, Math.round(S() + e))
                    }(t)
                }
            }

            function c(t) {
                return {
                    relative: b(t),
                    timeStamp: t
                }
            }

            function d() {
                var t;
                return Math.round(p() - (t = S(), t + performance.now()))
            }

            function f(t) {
                return (0, i.Et)(t) ? (0, i.LI)(1e6 * t, 0) : t
            }

            function p() {
                return new Date().getTime()
            }

            function h() {
                return p()
            }

            function m() {
                return performance.now()
            }

            function g() {
                return {
                    relative: m(),
                    timeStamp: h()
                }
            }

            function y() {
                return {
                    relative: 0,
                    timeStamp: S()
                }
            }

            function v(t, e) {
                return e - t
            }

            function _(t, e) {
                return t + e
            }

            function b(t) {
                return t - S()
            }

            function w(t) {
                return t < u
            }

            function S() {
                return void 0 === r && (r = performance.timing.navigationStart), r
            }
        },
        29259: (t, e, n) => {
            "use strict";
            n.d(e, {
                L: () => P
            });
            var r = n(59831),
                i = n(10676),
                a = n(91625),
                o = n(88647),
                s = n(98595),
                u = n(82120),
                l = n(11696),
                c = n(45350),
                d = n(97617);

            function f(t, e, n) {
                let r, i = 0,
                    a = [],
                    o = 0,
                    s = [],
                    {
                        stop: u
                    } = (0, l.q)(t, e, "message", ({
                        data: t
                    }) => {
                        if ("wrote" !== t.type || t.streamId !== n) return;
                        i += t.additionalBytesCount, a.push(t.result), r = t.trailer;
                        let e = s.shift();
                        e && e.id === t.id ? e.writeCallback ? e.writeCallback(t.result.byteLength) : e.finishCallback && e.finishCallback() : (u(), (0, c.A2)("Worker responses received out of order."))
                    });

                function f() {
                    let t = 0 === a.length ? new Uint8Array(0) : (0, d.wh)(a.concat(r)),
                        e = {
                            rawBytesCount: i,
                            output: t,
                            outputBytesCount: t.byteLength,
                            encoding: "deflate"
                        };
                    return i = 0, a = [], e
                }

                function p() {
                    o > 0 && (e.postMessage({
                        action: "reset",
                        streamId: n
                    }), o = 0)
                }
                return {
                    isAsync: !0,
                    get isEmpty() {
                        return 0 === o
                    },
                    write(t, r) {
                        e.postMessage({
                            action: "write",
                            id: o,
                            data: t,
                            streamId: n
                        }), s.push({
                            id: o,
                            writeCallback: r,
                            data: t
                        }), o += 1
                    },
                    finish(t) {
                        p(), s.length ? (s.forEach(t => {
                            delete t.writeCallback
                        }), s[s.length - 1].finishCallback = () => t(f())) : t(f())
                    },
                    finishSync() {
                        p();
                        let t = s.map(t => (delete t.writeCallback, delete t.finishCallback, t.data)).join("");
                        return { ...f(),
                            pendingData: t
                        }
                    },
                    estimateEncodedBytesCount: t => t.length / 8,
                    stop() {
                        u()
                    }
                }
            }
            var p = n(26664),
                h = n(94357),
                m = n(38954);

            function g({
                configuredUrl: t,
                error: e,
                source: n,
                scriptType: r
            }) {
                var i;
                if (m.Vy.error(`${n} failed to start: an error occurred while initializing the ${r}:`, e), e instanceof Event || e instanceof Error && ((i = e.message).includes("Content Security Policy") || i.includes("requires 'TrustedScriptURL'"))) {
                    let e;
                    e = t ? `Please make sure the ${r} URL ${t} is correct and CSP is correctly configured.` : "Please make sure CSP is correctly configured.", m.Vy.error(`${e} See documentation at ${m.fH}/integrations/content_security_policy_logs/#use-csp-with-real-user-monitoring-and-session-replay`)
                } else "worker" === r && (0, c.VJ)(e)
            }
            let y = 30 * p.OY;

            function v(t) {
                return new Worker(t.workerUrl || URL.createObjectURL(new Blob(['(()=>{function t(t){const e=t.reduce(((t,e)=>t+e.length),0),a=new Uint8Array(e);let n=0;for(const e of t)a.set(e,n),n+=e.length;return a}function e(t){for(var e=t.length;--e>=0;)t[e]=0}var a=new Uint8Array([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0]),n=new Uint8Array([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13]),r=new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7]),i=new Uint8Array([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),s=Array(576);e(s);var h=Array(60);e(h);var l=Array(512);e(l);var _=Array(256);e(_);var o=Array(29);e(o);var d,u,f,c=Array(30);function p(t,e,a,n,r){this.static_tree=t,this.extra_bits=e,this.extra_base=a,this.elems=n,this.max_length=r,this.has_stree=t&&t.length}function g(t,e){this.dyn_tree=t,this.max_code=0,this.stat_desc=e}e(c);var v=function(t){return t<256?l[t]:l[256+(t>>>7)]},w=function(t,e){t.pending_buf[t.pending++]=255&e,t.pending_buf[t.pending++]=e>>>8&255},m=function(t,e,a){t.bi_valid>16-a?(t.bi_buf|=e<<t.bi_valid&65535,w(t,t.bi_buf),t.bi_buf=e>>16-t.bi_valid,t.bi_valid+=a-16):(t.bi_buf|=e<<t.bi_valid&65535,t.bi_valid+=a)},b=function(t,e,a){m(t,a[2*e],a[2*e+1])},y=function(t,e){var a=0;do{a|=1&t,t>>>=1,a<<=1}while(--e>0);return a>>>1},z=function(t,e,a){var n,r,i=Array(16),s=0;for(n=1;n<=15;n++)i[n]=s=s+a[n-1]<<1;for(r=0;r<=e;r++){var h=t[2*r+1];0!==h&&(t[2*r]=y(i[h]++,h))}},k=function(t){var e;for(e=0;e<286;e++)t.dyn_ltree[2*e]=0;for(e=0;e<30;e++)t.dyn_dtree[2*e]=0;for(e=0;e<19;e++)t.bl_tree[2*e]=0;t.dyn_ltree[512]=1,t.opt_len=t.static_len=0,t.last_lit=t.matches=0},x=function(t){t.bi_valid>8?w(t,t.bi_buf):t.bi_valid>0&&(t.pending_buf[t.pending++]=t.bi_buf),t.bi_buf=0,t.bi_valid=0},A=function(t,e,a,n){var r=2*e,i=2*a;return t[r]<t[i]||t[r]===t[i]&&n[e]<=n[a]},U=function(t,e,a){for(var n=t.heap[a],r=a<<1;r<=t.heap_len&&(r<t.heap_len&&A(e,t.heap[r+1],t.heap[r],t.depth)&&r++,!A(e,n,t.heap[r],t.depth));)t.heap[a]=t.heap[r],a=r,r<<=1;t.heap[a]=n},B=function(t,e,r){var i,s,h,l,d=0;if(0!==t.last_lit)do{i=t.pending_buf[t.d_buf+2*d]<<8|t.pending_buf[t.d_buf+2*d+1],s=t.pending_buf[t.l_buf+d],d++,0===i?b(t,s,e):(h=_[s],b(t,h+256+1,e),0!==(l=a[h])&&(s-=o[h],m(t,s,l)),i--,h=v(i),b(t,h,r),0!==(l=n[h])&&(i-=c[h],m(t,i,l)))}while(d<t.last_lit);b(t,256,e)},I=function(t,e){var a,n,r,i=e.dyn_tree,s=e.stat_desc.static_tree,h=e.stat_desc.has_stree,l=e.stat_desc.elems,_=-1;for(t.heap_len=0,t.heap_max=573,a=0;a<l;a++)0!==i[2*a]?(t.heap[++t.heap_len]=_=a,t.depth[a]=0):i[2*a+1]=0;for(;t.heap_len<2;)i[2*(r=t.heap[++t.heap_len]=_<2?++_:0)]=1,t.depth[r]=0,t.opt_len--,h&&(t.static_len-=s[2*r+1]);for(e.max_code=_,a=t.heap_len>>1;a>=1;a--)U(t,i,a);r=l;do{a=t.heap[1],t.heap[1]=t.heap[t.heap_len--],U(t,i,1),n=t.heap[1],t.heap[--t.heap_max]=a,t.heap[--t.heap_max]=n,i[2*r]=i[2*a]+i[2*n],t.depth[r]=(t.depth[a]>=t.depth[n]?t.depth[a]:t.depth[n])+1,i[2*a+1]=i[2*n+1]=r,t.heap[1]=r++,U(t,i,1)}while(t.heap_len>=2);t.heap[--t.heap_max]=t.heap[1],function(t,e){var a,n,r,i,s,h,l=e.dyn_tree,_=e.max_code,o=e.stat_desc.static_tree,d=e.stat_desc.has_stree,u=e.stat_desc.extra_bits,f=e.stat_desc.extra_base,c=e.stat_desc.max_length,p=0;for(i=0;i<=15;i++)t.bl_count[i]=0;for(l[2*t.heap[t.heap_max]+1]=0,a=t.heap_max+1;a<573;a++)(i=l[2*l[2*(n=t.heap[a])+1]+1]+1)>c&&(i=c,p++),l[2*n+1]=i,n>_||(t.bl_count[i]++,s=0,n>=f&&(s=u[n-f]),h=l[2*n],t.opt_len+=h*(i+s),d&&(t.static_len+=h*(o[2*n+1]+s)));if(0!==p){do{for(i=c-1;0===t.bl_count[i];)i--;t.bl_count[i]--,t.bl_count[i+1]+=2,t.bl_count[c]--,p-=2}while(p>0);for(i=c;0!==i;i--)for(n=t.bl_count[i];0!==n;)(r=t.heap[--a])>_||(l[2*r+1]!==i&&(t.opt_len+=(i-l[2*r+1])*l[2*r],l[2*r+1]=i),n--)}}(t,e),z(i,_,t.bl_count)},E=function(t,e,a){var n,r,i=-1,s=e[1],h=0,l=7,_=4;for(0===s&&(l=138,_=3),e[2*(a+1)+1]=65535,n=0;n<=a;n++)r=s,s=e[2*(n+1)+1],++h<l&&r===s||(h<_?t.bl_tree[2*r]+=h:0!==r?(r!==i&&t.bl_tree[2*r]++,t.bl_tree[32]++):h<=10?t.bl_tree[34]++:t.bl_tree[36]++,h=0,i=r,0===s?(l=138,_=3):r===s?(l=6,_=3):(l=7,_=4))},C=function(t,e,a){var n,r,i=-1,s=e[1],h=0,l=7,_=4;for(0===s&&(l=138,_=3),n=0;n<=a;n++)if(r=s,s=e[2*(n+1)+1],!(++h<l&&r===s)){if(h<_)do{b(t,r,t.bl_tree)}while(0!=--h);else 0!==r?(r!==i&&(b(t,r,t.bl_tree),h--),b(t,16,t.bl_tree),m(t,h-3,2)):h<=10?(b(t,17,t.bl_tree),m(t,h-3,3)):(b(t,18,t.bl_tree),m(t,h-11,7));h=0,i=r,0===s?(l=138,_=3):r===s?(l=6,_=3):(l=7,_=4)}},D=!1,M=function(t,e,a,n){m(t,0+(n?1:0),3),function(t,e,a){x(t),w(t,a),w(t,~a),t.pending_buf.set(t.window.subarray(e,e+a),t.pending),t.pending+=a}(t,e,a)},j=M,L=function(t,e,a,n){for(var r=65535&t,i=t>>>16&65535,s=0;0!==a;){a-=s=a>2e3?2e3:a;do{i=i+(r=r+e[n++]|0)|0}while(--s);r%=65521,i%=65521}return r|i<<16},S=new Uint32Array(function(){for(var t,e=[],a=0;a<256;a++){t=a;for(var n=0;n<8;n++)t=1&t?3988292384^t>>>1:t>>>1;e[a]=t}return e}()),T=function(t,e,a,n){var r=S,i=n+a;t^=-1;for(var s=n;s<i;s++)t=t>>>8^r[255&(t^e[s])];return~t},O={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"},q=j,F=function(t,e,a){return t.pending_buf[t.d_buf+2*t.last_lit]=e>>>8&255,t.pending_buf[t.d_buf+2*t.last_lit+1]=255&e,t.pending_buf[t.l_buf+t.last_lit]=255&a,t.last_lit++,0===e?t.dyn_ltree[2*a]++:(t.matches++,e--,t.dyn_ltree[2*(_[a]+256+1)]++,t.dyn_dtree[2*v(e)]++),t.last_lit===t.lit_bufsize-1},G=-2,H=258,J=262,K=103,N=113,P=666,Q=function(t,e){return t.msg=O[e],e},R=function(t){return(t<<1)-(t>4?9:0)},V=function(t){for(var e=t.length;--e>=0;)t[e]=0},W=function(t,e,a){return(e<<t.hash_shift^a)&t.hash_mask},X=function(t){var e=t.state,a=e.pending;a>t.avail_out&&(a=t.avail_out),0!==a&&(t.output.set(e.pending_buf.subarray(e.pending_out,e.pending_out+a),t.next_out),t.next_out+=a,e.pending_out+=a,t.total_out+=a,t.avail_out-=a,e.pending-=a,0===e.pending&&(e.pending_out=0))},Y=function(t,e){(function(t,e,a,n){var r,l,_=0;t.level>0?(2===t.strm.data_type&&(t.strm.data_type=function(t){var e,a=4093624447;for(e=0;e<=31;e++,a>>>=1)if(1&a&&0!==t.dyn_ltree[2*e])return 0;if(0!==t.dyn_ltree[18]||0!==t.dyn_ltree[20]||0!==t.dyn_ltree[26])return 1;for(e=32;e<256;e++)if(0!==t.dyn_ltree[2*e])return 1;return 0}(t)),I(t,t.l_desc),I(t,t.d_desc),_=function(t){var e;for(E(t,t.dyn_ltree,t.l_desc.max_code),E(t,t.dyn_dtree,t.d_desc.max_code),I(t,t.bl_desc),e=18;e>=3&&0===t.bl_tree[2*i[e]+1];e--);return t.opt_len+=3*(e+1)+5+5+4,e}(t),r=t.opt_len+3+7>>>3,(l=t.static_len+3+7>>>3)<=r&&(r=l)):r=l=a+5,a+4<=r&&-1!==e?M(t,e,a,n):4===t.strategy||l===r?(m(t,2+(n?1:0),3),B(t,s,h)):(m(t,4+(n?1:0),3),function(t,e,a,n){var r;for(m(t,e-257,5),m(t,a-1,5),m(t,n-4,4),r=0;r<n;r++)m(t,t.bl_tree[2*i[r]+1],3);C(t,t.dyn_ltree,e-1),C(t,t.dyn_dtree,a-1)}(t,t.l_desc.max_code+1,t.d_desc.max_code+1,_+1),B(t,t.dyn_ltree,t.dyn_dtree)),k(t),n&&x(t)})(t,t.block_start>=0?t.block_start:-1,t.strstart-t.block_start,e),t.block_start=t.strstart,X(t.strm)},Z=function(t,e){t.pending_buf[t.pending++]=e},$=function(t,e){t.pending_buf[t.pending++]=e>>>8&255,t.pending_buf[t.pending++]=255&e},tt=function(t,e){var a,n,r=t.max_chain_length,i=t.strstart,s=t.prev_length,h=t.nice_match,l=t.strstart>t.w_size-J?t.strstart-(t.w_size-J):0,_=t.window,o=t.w_mask,d=t.prev,u=t.strstart+H,f=_[i+s-1],c=_[i+s];t.prev_length>=t.good_match&&(r>>=2),h>t.lookahead&&(h=t.lookahead);do{if(_[(a=e)+s]===c&&_[a+s-1]===f&&_[a]===_[i]&&_[++a]===_[i+1]){i+=2,a++;do{}while(_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&_[++i]===_[++a]&&i<u);if(n=H-(u-i),i=u-H,n>s){if(t.match_start=e,s=n,n>=h)break;f=_[i+s-1],c=_[i+s]}}}while((e=d[e&o])>l&&0!=--r);return s<=t.lookahead?s:t.lookahead},et=function(t){var e,a,n,r,i,s,h,l,_,o,d=t.w_size;do{if(r=t.window_size-t.lookahead-t.strstart,t.strstart>=d+(d-J)){t.window.set(t.window.subarray(d,d+d),0),t.match_start-=d,t.strstart-=d,t.block_start-=d,e=a=t.hash_size;do{n=t.head[--e],t.head[e]=n>=d?n-d:0}while(--a);e=a=d;do{n=t.prev[--e],t.prev[e]=n>=d?n-d:0}while(--a);r+=d}if(0===t.strm.avail_in)break;if(s=t.strm,h=t.window,l=t.strstart+t.lookahead,_=r,o=void 0,(o=s.avail_in)>_&&(o=_),a=0===o?0:(s.avail_in-=o,h.set(s.input.subarray(s.next_in,s.next_in+o),l),1===s.state.wrap?s.adler=L(s.adler,h,o,l):2===s.state.wrap&&(s.adler=T(s.adler,h,o,l)),s.next_in+=o,s.total_in+=o,o),t.lookahead+=a,t.lookahead+t.insert>=3)for(i=t.strstart-t.insert,t.ins_h=t.window[i],t.ins_h=W(t,t.ins_h,t.window[i+1]);t.insert&&(t.ins_h=W(t,t.ins_h,t.window[i+3-1]),t.prev[i&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=i,i++,t.insert--,!(t.lookahead+t.insert<3)););}while(t.lookahead<J&&0!==t.strm.avail_in)},at=function(t,e){for(var a,n;;){if(t.lookahead<J){if(et(t),t.lookahead<J&&0===e)return 1;if(0===t.lookahead)break}if(a=0,t.lookahead>=3&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),0!==a&&t.strstart-a<=t.w_size-J&&(t.match_length=tt(t,a)),t.match_length>=3)if(n=F(t,t.strstart-t.match_start,t.match_length-3),t.lookahead-=t.match_length,t.match_length<=t.max_lazy_match&&t.lookahead>=3){t.match_length--;do{t.strstart++,t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart}while(0!=--t.match_length);t.strstart++}else t.strstart+=t.match_length,t.match_length=0,t.ins_h=t.window[t.strstart],t.ins_h=W(t,t.ins_h,t.window[t.strstart+1]);else n=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++;if(n&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=t.strstart<2?t.strstart:2,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2},nt=function(t,e){for(var a,n,r;;){if(t.lookahead<J){if(et(t),t.lookahead<J&&0===e)return 1;if(0===t.lookahead)break}if(a=0,t.lookahead>=3&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),t.prev_length=t.match_length,t.prev_match=t.match_start,t.match_length=2,0!==a&&t.prev_length<t.max_lazy_match&&t.strstart-a<=t.w_size-J&&(t.match_length=tt(t,a),t.match_length<=5&&(1===t.strategy||3===t.match_length&&t.strstart-t.match_start>4096)&&(t.match_length=2)),t.prev_length>=3&&t.match_length<=t.prev_length){r=t.strstart+t.lookahead-3,n=F(t,t.strstart-1-t.prev_match,t.prev_length-3),t.lookahead-=t.prev_length-1,t.prev_length-=2;do{++t.strstart<=r&&(t.ins_h=W(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart)}while(0!=--t.prev_length);if(t.match_available=0,t.match_length=2,t.strstart++,n&&(Y(t,!1),0===t.strm.avail_out))return 1}else if(t.match_available){if((n=F(t,0,t.window[t.strstart-1]))&&Y(t,!1),t.strstart++,t.lookahead--,0===t.strm.avail_out)return 1}else t.match_available=1,t.strstart++,t.lookahead--}return t.match_available&&(n=F(t,0,t.window[t.strstart-1]),t.match_available=0),t.insert=t.strstart<2?t.strstart:2,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2};function rt(t,e,a,n,r){this.good_length=t,this.max_lazy=e,this.nice_length=a,this.max_chain=n,this.func=r}var it=[new rt(0,0,0,0,(function(t,e){var a=65535;for(a>t.pending_buf_size-5&&(a=t.pending_buf_size-5);;){if(t.lookahead<=1){if(et(t),0===t.lookahead&&0===e)return 1;if(0===t.lookahead)break}t.strstart+=t.lookahead,t.lookahead=0;var n=t.block_start+a;if((0===t.strstart||t.strstart>=n)&&(t.lookahead=t.strstart-n,t.strstart=n,Y(t,!1),0===t.strm.avail_out))return 1;if(t.strstart-t.block_start>=t.w_size-J&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):(t.strstart>t.block_start&&(Y(t,!1),t.strm.avail_out),1)})),new rt(4,4,8,4,at),new rt(4,5,16,8,at),new rt(4,6,32,32,at),new rt(4,4,16,16,nt),new rt(8,16,32,32,nt),new rt(8,16,128,128,nt),new rt(8,32,128,256,nt),new rt(32,128,258,1024,nt),new rt(32,258,258,4096,nt)];function st(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=8,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new Uint16Array(1146),this.dyn_dtree=new Uint16Array(122),this.bl_tree=new Uint16Array(78),V(this.dyn_ltree),V(this.dyn_dtree),V(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new Uint16Array(16),this.heap=new Uint16Array(573),V(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new Uint16Array(573),V(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}for(var ht=function(t){var e,i=function(t){if(!t||!t.state)return Q(t,G);t.total_in=t.total_out=0,t.data_type=2;var e=t.state;return e.pending=0,e.pending_out=0,e.wrap<0&&(e.wrap=-e.wrap),e.status=e.wrap?42:N,t.adler=2===e.wrap?0:1,e.last_flush=0,function(t){D||(function(){var t,e,i,g,v,w=Array(16);for(i=0,g=0;g<28;g++)for(o[g]=i,t=0;t<1<<a[g];t++)_[i++]=g;for(_[i-1]=g,v=0,g=0;g<16;g++)for(c[g]=v,t=0;t<1<<n[g];t++)l[v++]=g;for(v>>=7;g<30;g++)for(c[g]=v<<7,t=0;t<1<<n[g]-7;t++)l[256+v++]=g;for(e=0;e<=15;e++)w[e]=0;for(t=0;t<=143;)s[2*t+1]=8,t++,w[8]++;for(;t<=255;)s[2*t+1]=9,t++,w[9]++;for(;t<=279;)s[2*t+1]=7,t++,w[7]++;for(;t<=287;)s[2*t+1]=8,t++,w[8]++;for(z(s,287,w),t=0;t<30;t++)h[2*t+1]=5,h[2*t]=y(t,5);d=new p(s,a,257,286,15),u=new p(h,n,0,30,15),f=new p([],r,0,19,7)}(),D=!0),t.l_desc=new g(t.dyn_ltree,d),t.d_desc=new g(t.dyn_dtree,u),t.bl_desc=new g(t.bl_tree,f),t.bi_buf=0,t.bi_valid=0,k(t)}(e),0}(t);return 0===i&&((e=t.state).window_size=2*e.w_size,V(e.head),e.max_lazy_match=it[e.level].max_lazy,e.good_match=it[e.level].good_length,e.nice_match=it[e.level].nice_length,e.max_chain_length=it[e.level].max_chain,e.strstart=0,e.block_start=0,e.lookahead=0,e.insert=0,e.match_length=e.prev_length=2,e.match_available=0,e.ins_h=0),i},lt=function(t,e){var a,n;if(!t||!t.state||e>5||e<0)return t?Q(t,G):G;var r=t.state;if(!t.output||!t.input&&0!==t.avail_in||r.status===P&&4!==e)return Q(t,0===t.avail_out?-5:G);r.strm=t;var i=r.last_flush;if(r.last_flush=e,42===r.status)if(2===r.wrap)t.adler=0,Z(r,31),Z(r,139),Z(r,8),r.gzhead?(Z(r,(r.gzhead.text?1:0)+(r.gzhead.hcrc?2:0)+(r.gzhead.extra?4:0)+(r.gzhead.name?8:0)+(r.gzhead.comment?16:0)),Z(r,255&r.gzhead.time),Z(r,r.gzhead.time>>8&255),Z(r,r.gzhead.time>>16&255),Z(r,r.gzhead.time>>24&255),Z(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Z(r,255&r.gzhead.os),r.gzhead.extra&&r.gzhead.extra.length&&(Z(r,255&r.gzhead.extra.length),Z(r,r.gzhead.extra.length>>8&255)),r.gzhead.hcrc&&(t.adler=T(t.adler,r.pending_buf,r.pending,0)),r.gzindex=0,r.status=69):(Z(r,0),Z(r,0),Z(r,0),Z(r,0),Z(r,0),Z(r,9===r.level?2:r.strategy>=2||r.level<2?4:0),Z(r,3),r.status=N);else{var h=8+(r.w_bits-8<<4)<<8;h|=(r.strategy>=2||r.level<2?0:r.level<6?1:6===r.level?2:3)<<6,0!==r.strstart&&(h|=32),h+=31-h%31,r.status=N,$(r,h),0!==r.strstart&&($(r,t.adler>>>16),$(r,65535&t.adler)),t.adler=1}if(69===r.status)if(r.gzhead.extra){for(a=r.pending;r.gzindex<(65535&r.gzhead.extra.length)&&(r.pending!==r.pending_buf_size||(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending!==r.pending_buf_size));)Z(r,255&r.gzhead.extra[r.gzindex]),r.gzindex++;r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),r.gzindex===r.gzhead.extra.length&&(r.gzindex=0,r.status=73)}else r.status=73;if(73===r.status)if(r.gzhead.name){a=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending===r.pending_buf_size)){n=1;break}n=r.gzindex<r.gzhead.name.length?255&r.gzhead.name.charCodeAt(r.gzindex++):0,Z(r,n)}while(0!==n);r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),0===n&&(r.gzindex=0,r.status=91)}else r.status=91;if(91===r.status)if(r.gzhead.comment){a=r.pending;do{if(r.pending===r.pending_buf_size&&(r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),X(t),a=r.pending,r.pending===r.pending_buf_size)){n=1;break}n=r.gzindex<r.gzhead.comment.length?255&r.gzhead.comment.charCodeAt(r.gzindex++):0,Z(r,n)}while(0!==n);r.gzhead.hcrc&&r.pending>a&&(t.adler=T(t.adler,r.pending_buf,r.pending-a,a)),0===n&&(r.status=K)}else r.status=K;if(r.status===K&&(r.gzhead.hcrc?(r.pending+2>r.pending_buf_size&&X(t),r.pending+2<=r.pending_buf_size&&(Z(r,255&t.adler),Z(r,t.adler>>8&255),t.adler=0,r.status=N)):r.status=N),0!==r.pending){if(X(t),0===t.avail_out)return r.last_flush=-1,0}else if(0===t.avail_in&&R(e)<=R(i)&&4!==e)return Q(t,-5);if(r.status===P&&0!==t.avail_in)return Q(t,-5);if(0!==t.avail_in||0!==r.lookahead||0!==e&&r.status!==P){var l=2===r.strategy?function(t,e){for(var a;;){if(0===t.lookahead&&(et(t),0===t.lookahead)){if(0===e)return 1;break}if(t.match_length=0,a=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++,a&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2}(r,e):3===r.strategy?function(t,e){for(var a,n,r,i,s=t.window;;){if(t.lookahead<=H){if(et(t),t.lookahead<=H&&0===e)return 1;if(0===t.lookahead)break}if(t.match_length=0,t.lookahead>=3&&t.strstart>0&&(n=s[r=t.strstart-1])===s[++r]&&n===s[++r]&&n===s[++r]){i=t.strstart+H;do{}while(n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&n===s[++r]&&r<i);t.match_length=H-(i-r),t.match_length>t.lookahead&&(t.match_length=t.lookahead)}if(t.match_length>=3?(a=F(t,1,t.match_length-3),t.lookahead-=t.match_length,t.strstart+=t.match_length,t.match_length=0):(a=F(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++),a&&(Y(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,4===e?(Y(t,!0),0===t.strm.avail_out?3:4):t.last_lit&&(Y(t,!1),0===t.strm.avail_out)?1:2}(r,e):it[r.level].func(r,e);if(3!==l&&4!==l||(r.status=P),1===l||3===l)return 0===t.avail_out&&(r.last_flush=-1),0;if(2===l&&(1===e?function(t){m(t,2,3),b(t,256,s),function(t){16===t.bi_valid?(w(t,t.bi_buf),t.bi_buf=0,t.bi_valid=0):t.bi_valid>=8&&(t.pending_buf[t.pending++]=255&t.bi_buf,t.bi_buf>>=8,t.bi_valid-=8)}(t)}(r):5!==e&&(q(r,0,0,!1),3===e&&(V(r.head),0===r.lookahead&&(r.strstart=0,r.block_start=0,r.insert=0))),X(t),0===t.avail_out))return r.last_flush=-1,0}return 4!==e?0:r.wrap<=0?1:(2===r.wrap?(Z(r,255&t.adler),Z(r,t.adler>>8&255),Z(r,t.adler>>16&255),Z(r,t.adler>>24&255),Z(r,255&t.total_in),Z(r,t.total_in>>8&255),Z(r,t.total_in>>16&255),Z(r,t.total_in>>24&255)):($(r,t.adler>>>16),$(r,65535&t.adler)),X(t),r.wrap>0&&(r.wrap=-r.wrap),0!==r.pending?0:1)},_t=function(t){if(!t||!t.state)return G;var e=t.state.status;return 42!==e&&69!==e&&73!==e&&91!==e&&e!==K&&e!==N&&e!==P?Q(t,G):(t.state=null,e===N?Q(t,-3):0)},ot=new Uint8Array(256),dt=0;dt<256;dt++)ot[dt]=dt>=252?6:dt>=248?5:dt>=240?4:dt>=224?3:dt>=192?2:1;ot[254]=ot[254]=1;var ut=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0},ft=Object.prototype.toString;function ct(){this.options={level:-1,method:8,chunkSize:16384,windowBits:15,memLevel:8,strategy:0};var t=this.options;t.raw&&t.windowBits>0?t.windowBits=-t.windowBits:t.gzip&&t.windowBits>0&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new ut,this.strm.avail_out=0;var e,a,n=function(t,e,a,n,r,i){if(!t)return G;var s=1;if(-1===e&&(e=6),n<0?(s=0,n=-n):n>15&&(s=2,n-=16),r<1||r>9||8!==a||n<8||n>15||e<0||e>9||i<0||i>4)return Q(t,G);8===n&&(n=9);var h=new st;return t.state=h,h.strm=t,h.wrap=s,h.gzhead=null,h.w_bits=n,h.w_size=1<<h.w_bits,h.w_mask=h.w_size-1,h.hash_bits=r+7,h.hash_size=1<<h.hash_bits,h.hash_mask=h.hash_size-1,h.hash_shift=~~((h.hash_bits+3-1)/3),h.window=new Uint8Array(2*h.w_size),h.head=new Uint16Array(h.hash_size),h.prev=new Uint16Array(h.w_size),h.lit_bufsize=1<<r+6,h.pending_buf_size=4*h.lit_bufsize,h.pending_buf=new Uint8Array(h.pending_buf_size),h.d_buf=1*h.lit_bufsize,h.l_buf=3*h.lit_bufsize,h.level=e,h.strategy=i,h.method=a,ht(t)}(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy);if(0!==n)throw Error(O[n]);if(t.header&&(e=this.strm,a=t.header,e&&e.state&&(2!==e.state.wrap||(e.state.gzhead=a))),t.dictionary){var r;if(r="[object ArrayBuffer]"===ft.call(t.dictionary)?new Uint8Array(t.dictionary):t.dictionary,0!==(n=function(t,e){var a=e.length;if(!t||!t.state)return G;var n=t.state,r=n.wrap;if(2===r||1===r&&42!==n.status||n.lookahead)return G;if(1===r&&(t.adler=L(t.adler,e,a,0)),n.wrap=0,a>=n.w_size){0===r&&(V(n.head),n.strstart=0,n.block_start=0,n.insert=0);var i=new Uint8Array(n.w_size);i.set(e.subarray(a-n.w_size,a),0),e=i,a=n.w_size}var s=t.avail_in,h=t.next_in,l=t.input;for(t.avail_in=a,t.next_in=0,t.input=e,et(n);n.lookahead>=3;){var _=n.strstart,o=n.lookahead-2;do{n.ins_h=W(n,n.ins_h,n.window[_+3-1]),n.prev[_&n.w_mask]=n.head[n.ins_h],n.head[n.ins_h]=_,_++}while(--o);n.strstart=_,n.lookahead=2,et(n)}return n.strstart+=n.lookahead,n.block_start=n.strstart,n.insert=n.lookahead,n.lookahead=0,n.match_length=n.prev_length=2,n.match_available=0,t.next_in=h,t.input=l,t.avail_in=s,n.wrap=r,0}(this.strm,r)))throw Error(O[n]);this._dict_set=!0}}function pt(t,e,a){try{t.postMessage({type:"errored",error:e,streamId:a})}catch(n){t.postMessage({type:"errored",error:e+"",streamId:a})}}function gt(t){const e=t.strm.adler;return new Uint8Array([3,0,e>>>24&255,e>>>16&255,e>>>8&255,255&e])}ct.prototype.push=function(t,e){var a,n,r=this.strm,i=this.options.chunkSize;if(this.ended)return!1;for(n=e===~~e?e:!0===e?4:0,"[object ArrayBuffer]"===ft.call(t)?r.input=new Uint8Array(t):r.input=t,r.next_in=0,r.avail_in=r.input.length;;)if(0===r.avail_out&&(r.output=new Uint8Array(i),r.next_out=0,r.avail_out=i),(2===n||3===n)&&r.avail_out<=6)this.onData(r.output.subarray(0,r.next_out)),r.avail_out=0;else{if(1===(a=lt(r,n)))return r.next_out>0&&this.onData(r.output.subarray(0,r.next_out)),a=_t(this.strm),this.onEnd(a),this.ended=!0,0===a;if(0!==r.avail_out){if(n>0&&r.next_out>0)this.onData(r.output.subarray(0,r.next_out)),r.avail_out=0;else if(0===r.avail_in)break}else this.onData(r.output)}return!0},ct.prototype.onData=function(t){this.chunks.push(t)},ct.prototype.onEnd=function(t){0===t&&(this.result=function(t){for(var e=0,a=0,n=t.length;a<n;a++)e+=t[a].length;for(var r=new Uint8Array(e),i=0,s=0,h=t.length;i<h;i++){var l=t[i];r.set(l,s),s+=l.length}return r}(this.chunks)),this.chunks=[],this.err=t,this.msg=this.strm.msg},function(e=self){try{const a=new Map;e.addEventListener("message",(n=>{try{const r=function(e,a){switch(a.action){case"init":return{type:"initialized",version:"6.6.3"};case"write":{let n=e.get(a.streamId);n||(n=new ct,e.set(a.streamId,n));const r=n.chunks.length,i=function(t){if("function"==typeof TextEncoder&&TextEncoder.prototype.encode)return(new TextEncoder).encode(t);let e,a,n,r,i,s=t.length,h=0;for(r=0;r<s;r++)a=t.charCodeAt(r),55296==(64512&a)&&r+1<s&&(n=t.charCodeAt(r+1),56320==(64512&n)&&(a=65536+(a-55296<<10)+(n-56320),r++)),h+=a<128?1:a<2048?2:a<65536?3:4;for(e=new Uint8Array(h),i=0,r=0;i<h;r++)a=t.charCodeAt(r),55296==(64512&a)&&r+1<s&&(n=t.charCodeAt(r+1),56320==(64512&n)&&(a=65536+(a-55296<<10)+(n-56320),r++)),a<128?e[i++]=a:a<2048?(e[i++]=192|a>>>6,e[i++]=128|63&a):a<65536?(e[i++]=224|a>>>12,e[i++]=128|a>>>6&63,e[i++]=128|63&a):(e[i++]=240|a>>>18,e[i++]=128|a>>>12&63,e[i++]=128|a>>>6&63,e[i++]=128|63&a);return e}(a.data);return n.push(i,2),{type:"wrote",id:a.id,streamId:a.streamId,result:t(n.chunks.slice(r)),trailer:gt(n),additionalBytesCount:i.length}}case"reset":e.delete(a.streamId)}}(a,n.data);r&&e.postMessage(r)}catch(t){pt(e,t,n.data&&"streamId"in n.data?n.data.streamId:void 0)}}))}catch(t){pt(e,t)}}()})();'])))
            }
            let _ = {
                status: 0
            };

            function b(t, e, n, r = v) {
                switch (0 === _.status && function(t, e, n = v) {
                    try {
                        let r = n(t),
                            {
                                stop: i
                            } = (0, l.q)(t, r, "error", n => {
                                w(t, e, n)
                            }),
                            {
                                stop: a
                            } = (0, l.q)(t, r, "message", ({
                                data: n
                            }) => {
                                var r;
                                "errored" === n.type ? w(t, e, n.error, n.streamId) : "initialized" === n.type && (r = n.version, 1 === _.status && (_ = {
                                    status: 3,
                                    worker: _.worker,
                                    stop: _.stop,
                                    version: r
                                }))
                            });
                        r.postMessage({
                            action: "init"
                        }), (0, h.wg)(() => {
                            var t;
                            return t = e, void(1 === _.status && (m.Vy.error(`${t} failed to start: a timeout occurred while initializing the Worker`), _.initializationFailureCallbacks.forEach(t => t()), _ = {
                                status: 2
                            }))
                        }, y), _ = {
                            status: 1,
                            worker: r,
                            stop: () => {
                                i(), a()
                            },
                            initializationFailureCallbacks: []
                        }
                    } catch (n) {
                        w(t, e, n)
                    }
                }(t, e, r), _.status) {
                    case 1:
                        return _.initializationFailureCallbacks.push(n), _.worker;
                    case 3:
                        return _.worker
                }
            }

            function w(t, e, n, r) {
                1 === _.status || 0 === _.status ? (g({
                    configuredUrl: t.workerUrl,
                    error: n,
                    source: e,
                    scriptType: "worker"
                }), 1 === _.status && _.initializationFailureCallbacks.forEach(t => t()), _ = {
                    status: 2
                }) : (0, c.VJ)(n, {
                    worker_version: 3 === _.status && _.version,
                    stream_id: r
                })
            }

            function S() {
                return "function" == typeof Array.from && "function" == typeof CSSSupportsRule && "function" == typeof URL.createObjectURL && "forEach" in NodeList.prototype
            }
            var x = n(32563),
                k = n(85590);
            async function C(t = A) {
                try {
                    return await t()
                } catch (t) {
                    g({
                        error: t,
                        source: "Recorder",
                        scriptType: "module"
                    })
                }
            }
            async function A() {
                return (await n.e(9777).then(n.bind(n, 22484))).startRecording
            }
            var T = n(31352);
            async function E(t = R) {
                try {
                    return await t()
                } catch (t) {
                    g({
                        error: t,
                        source: "Profiler",
                        scriptType: "module"
                    })
                }
            }
            async function R() {
                return (await n.e(12).then(n.bind(n, 13814))).createRumProfiler
            }
            let I = function(t, e) {
                    let n;
                    if ((0, o.d0)() && !(0, o.Ww)("records") || !S()) return {
                        start: s.l,
                        stop: s.l,
                        getReplayStats: () => void 0,
                        onRumStart: s.l,
                        isRecording: () => !1,
                        getSessionReplayLink: () => void 0
                    };
                    let {
                        strategy: r,
                        shouldStartImmediately: i
                    } = (n = 0, {
                        strategy: {
                            start() {
                                n = 1
                            },
                            stop() {
                                n = 2
                            },
                            isRecording: () => !1,
                            getSessionReplayLink: s.l
                        },
                        shouldStartImmediately: t => 1 === n || 0 === n && !t.startSessionReplayRecordingManually
                    });
                    return {
                        start: t => r.start(t),
                        stop: () => r.stop(),
                        getSessionReplayLink: () => r.getSessionReplayLink(),
                        onRumStart: function(e, n, o, s, u) {
                            let l;
                            r = function(t, e, n, r, i, o) {
                                let s, u = 0;
                                e.subscribe(9, () => {
                                    (2 === u || 3 === u) && (d(), u = 1)
                                }), e.subscribe(10, () => {
                                    1 === u && c()
                                });
                                let l = async () => {
                                    let [a] = await Promise.all([i(), (0, x.N)(t, "interactive")]);
                                    if (2 !== u) return;
                                    let l = o();
                                    if (!l || !a) {
                                        u = 0;
                                        return
                                    }({
                                        stop: s
                                    } = a(e, t, n, r, l)), u = 3
                                };

                                function c(t) {
                                    var e, r, i, a, o;
                                    let s = n.findTrackedSession();
                                    if (e = s, r = t, !e || 0 === e.sessionReplay && (!r || !r.force)) {
                                        u = 1;
                                        return
                                    }
                                    2 !== (i = u) && 3 !== i && (u = 2, l().catch(k.Dx), a = s, (o = t) && o.force && 0 === a.sessionReplay && n.setForcedReplay())
                                }

                                function d() {
                                    3 === u && (null == s || s()), u = 0
                                }
                                return {
                                    start: c,
                                    stop: d,
                                    getSessionReplayLink: () => (function(t, e, n, r) {
                                        var i, o;
                                        let s = e.findTrackedSession(),
                                            u = (i = s, o = r, S() ? i ? 0 === i.sessionReplay ? "incorrect-session-plan" : o ? void 0 : "replay-not-started" : "rum-not-tracked" : "browser-not-supported"),
                                            l = n.findView();
                                        return (0, a.dx)(t, {
                                            viewContext: l,
                                            errorType: u,
                                            session: s
                                        })
                                    })(t, n, r, 0 !== u),
                                    isRecording: () => 3 === u
                                }
                            }(n, e, o, s, t, function() {
                                return !l && (null != u || (u = b(n, "Datadog Session Replay", () => {
                                    r.stop()
                                }, void 0)), u && (l = f(n, u, 1))), l
                            }), i(n) && r.start()
                        },
                        isRecording: () => 3 === _.status && r.isRecording(),
                        getReplayStats: t => 3 === _.status ? (0, u.lv)(t) : void 0
                    }
                }(C),
                O = function() {
                    let t;
                    return {
                        onRumStart: function(e, n, r, a) {
                            void 0 !== (0, i.V)().Profiler && (0, T.ic)(n.profilingSampleRate) && E().then(i => {
                                if (!i) return void(0, c.A2)("[DD_RUM] Failed to lazy load the RUM Profiler");
                                (t = i(n, e, r)).start(a.findView())
                            }).catch(k.Dx)
                        },
                        stop: () => {
                            null == t || t.stop().catch(k.Dx)
                        }
                    }
                }(),
                P = (0, a.AB)(a.rJ, I, O, {
                    startDeflateWorker: b,
                    createDeflateEncoder: f
                });
            (0, r.Z)((0, i.V)(), "DD_RUM", P)
        },
        30789: (t, e, n) => {
            "use strict";
            let r;

            function i() {
                return 0 === o()
            }

            function a() {
                return 1 === o()
            }

            function o() {
                return null != r ? r : r = function(t = window) {
                    var e;
                    let n = t.navigator.userAgent;
                    return t.chrome || /HeadlessChrome/.test(n) ? 0 : (null == (e = t.navigator.vendor) ? void 0 : e.indexOf("Apple")) === 0 || /safari/i.test(n) && !/chrome|android/i.test(n) ? 1 : 2
                }()
            }
            n.d(e, {
                F2: () => i,
                nr: () => a
            })
        },
        31352: (t, e, n) => {
            "use strict";

            function r(t) {
                return 0 !== t && 100 * Math.random() <= t
            }

            function i(t, e) {
                return +t.toFixed(e)
            }

            function a(t) {
                return o(t) && t >= 0 && t <= 100
            }

            function o(t) {
                return "number" == typeof t
            }
            n.d(e, {
                Et: () => o,
                LI: () => i,
                fp: () => a,
                ic: () => r
            })
        },
        31461: (t, e, n) => {
            "use strict";
            n.d(e, {
                E: () => h
            });
            var r = n(34049),
                i = n(31668),
                a = n(74268),
                o = n(38445),
                s = class extends o.Q {
                    constructor(t = {}) {
                        super(), this.config = t, this.#t = new Map
                    }#
                    t;
                    build(t, e, n) {
                        let a = e.queryKey,
                            o = e.queryHash ? ? (0, r.F$)(a, e),
                            s = this.get(o);
                        return s || (s = new i.X({
                            cache: this,
                            queryKey: a,
                            queryHash: o,
                            options: t.defaultQueryOptions(e),
                            state: n,
                            defaultOptions: t.getQueryDefaults(a)
                        }), this.add(s)), s
                    }
                    add(t) {
                        this.#t.has(t.queryHash) || (this.#t.set(t.queryHash, t), this.notify({
                            type: "added",
                            query: t
                        }))
                    }
                    remove(t) {
                        let e = this.#t.get(t.queryHash);
                        e && (t.destroy(), e === t && this.#t.delete(t.queryHash), this.notify({
                            type: "removed",
                            query: t
                        }))
                    }
                    clear() {
                        a.j.batch(() => {
                            this.getAll().forEach(t => {
                                this.remove(t)
                            })
                        })
                    }
                    get(t) {
                        return this.#t.get(t)
                    }
                    getAll() {
                        return [...this.#t.values()]
                    }
                    find(t) {
                        let e = {
                            exact: !0,
                            ...t
                        };
                        return this.getAll().find(t => (0, r.MK)(e, t))
                    }
                    findAll(t = {}) {
                        let e = this.getAll();
                        return Object.keys(t).length > 0 ? e.filter(e => (0, r.MK)(t, e)) : e
                    }
                    notify(t) {
                        a.j.batch(() => {
                            this.listeners.forEach(e => {
                                e(t)
                            })
                        })
                    }
                    onFocus() {
                        a.j.batch(() => {
                            this.getAll().forEach(t => {
                                t.onFocus()
                            })
                        })
                    }
                    onOnline() {
                        a.j.batch(() => {
                            this.getAll().forEach(t => {
                                t.onOnline()
                            })
                        })
                    }
                },
                u = n(38559),
                l = class extends o.Q {
                    constructor(t = {}) {
                        super(), this.config = t, this.#e = new Set, this.#n = new Map, this.#r = 0
                    }#
                    e;#
                    n;#
                    r;
                    build(t, e, n) {
                        let r = new u.s({
                            mutationCache: this,
                            mutationId: ++this.#r,
                            options: t.defaultMutationOptions(e),
                            state: n
                        });
                        return this.add(r), r
                    }
                    add(t) {
                        this.#e.add(t);
                        let e = c(t);
                        if ("string" == typeof e) {
                            let n = this.#n.get(e);
                            n ? n.push(t) : this.#n.set(e, [t])
                        }
                        this.notify({
                            type: "added",
                            mutation: t
                        })
                    }
                    remove(t) {
                        if (this.#e.delete(t)) {
                            let e = c(t);
                            if ("string" == typeof e) {
                                let n = this.#n.get(e);
                                if (n)
                                    if (n.length > 1) {
                                        let e = n.indexOf(t); - 1 !== e && n.splice(e, 1)
                                    } else n[0] === t && this.#n.delete(e)
                            }
                        }
                        this.notify({
                            type: "removed",
                            mutation: t
                        })
                    }
                    canRun(t) {
                        let e = c(t);
                        if ("string" != typeof e) return !0; {
                            let n = this.#n.get(e),
                                r = n ? .find(t => "pending" === t.state.status);
                            return !r || r === t
                        }
                    }
                    runNext(t) {
                        let e = c(t);
                        if ("string" != typeof e) return Promise.resolve(); {
                            let n = this.#n.get(e) ? .find(e => e !== t && e.state.isPaused);
                            return n ? .continue() ? ? Promise.resolve()
                        }
                    }
                    clear() {
                        a.j.batch(() => {
                            this.#e.forEach(t => {
                                this.notify({
                                    type: "removed",
                                    mutation: t
                                })
                            }), this.#e.clear(), this.#n.clear()
                        })
                    }
                    getAll() {
                        return Array.from(this.#e)
                    }
                    find(t) {
                        let e = {
                            exact: !0,
                            ...t
                        };
                        return this.getAll().find(t => (0, r.nJ)(e, t))
                    }
                    findAll(t = {}) {
                        return this.getAll().filter(e => (0, r.nJ)(t, e))
                    }
                    notify(t) {
                        a.j.batch(() => {
                            this.listeners.forEach(e => {
                                e(t)
                            })
                        })
                    }
                    resumePausedMutations() {
                        let t = this.getAll().filter(t => t.state.isPaused);
                        return a.j.batch(() => Promise.all(t.map(t => t.continue().catch(r.lQ))))
                    }
                };

            function c(t) {
                return t.options.scope ? .id
            }
            var d = n(56195),
                f = n(63122),
                p = n(66902),
                h = class {#
                    i;#
                    a;#
                    o;#
                    s;#
                    u;#
                    l;#
                    c;#
                    d;
                    constructor(t = {}) {
                        this.#i = t.queryCache || new s, this.#a = t.mutationCache || new l, this.#o = t.defaultOptions || {}, this.#s = new Map, this.#u = new Map, this.#l = 0
                    }
                    mount() {
                        this.#l++, 1 === this.#l && (this.#c = d.m.subscribe(async t => {
                            t && (await this.resumePausedMutations(), this.#i.onFocus())
                        }), this.#d = f.t.subscribe(async t => {
                            t && (await this.resumePausedMutations(), this.#i.onOnline())
                        }))
                    }
                    unmount() {
                        this.#l--, 0 === this.#l && (this.#c ? .(), this.#c = void 0, this.#d ? .(), this.#d = void 0)
                    }
                    isFetching(t) {
                        return this.#i.findAll({ ...t,
                            fetchStatus: "fetching"
                        }).length
                    }
                    isMutating(t) {
                        return this.#a.findAll({ ...t,
                            status: "pending"
                        }).length
                    }
                    getQueryData(t) {
                        let e = this.defaultQueryOptions({
                            queryKey: t
                        });
                        return this.#i.get(e.queryHash) ? .state.data
                    }
                    ensureQueryData(t) {
                        let e = this.defaultQueryOptions(t),
                            n = this.#i.build(this, e),
                            i = n.state.data;
                        return void 0 === i ? this.fetchQuery(t) : (t.revalidateIfStale && n.isStaleByTime((0, r.d2)(e.staleTime, n)) && this.prefetchQuery(e), Promise.resolve(i))
                    }
                    getQueriesData(t) {
                        return this.#i.findAll(t).map(({
                            queryKey: t,
                            state: e
                        }) => [t, e.data])
                    }
                    setQueryData(t, e, n) {
                        let i = this.defaultQueryOptions({
                                queryKey: t
                            }),
                            a = this.#i.get(i.queryHash),
                            o = a ? .state.data,
                            s = (0, r.Zw)(e, o);
                        if (void 0 !== s) return this.#i.build(this, i).setData(s, { ...n,
                            manual: !0
                        })
                    }
                    setQueriesData(t, e, n) {
                        return a.j.batch(() => this.#i.findAll(t).map(({
                            queryKey: t
                        }) => [t, this.setQueryData(t, e, n)]))
                    }
                    getQueryState(t) {
                        let e = this.defaultQueryOptions({
                            queryKey: t
                        });
                        return this.#i.get(e.queryHash) ? .state
                    }
                    removeQueries(t) {
                        let e = this.#i;
                        a.j.batch(() => {
                            e.findAll(t).forEach(t => {
                                e.remove(t)
                            })
                        })
                    }
                    resetQueries(t, e) {
                        let n = this.#i,
                            r = {
                                type: "active",
                                ...t
                            };
                        return a.j.batch(() => (n.findAll(t).forEach(t => {
                            t.reset()
                        }), this.refetchQueries(r, e)))
                    }
                    cancelQueries(t, e = {}) {
                        let n = {
                            revert: !0,
                            ...e
                        };
                        return Promise.all(a.j.batch(() => this.#i.findAll(t).map(t => t.cancel(n)))).then(r.lQ).catch(r.lQ)
                    }
                    invalidateQueries(t, e = {}) {
                        return a.j.batch(() => {
                            if (this.#i.findAll(t).forEach(t => {
                                    t.invalidate()
                                }), t ? .refetchType === "none") return Promise.resolve();
                            let n = { ...t,
                                type: t ? .refetchType ? ? t ? .type ? ? "active"
                            };
                            return this.refetchQueries(n, e)
                        })
                    }
                    refetchQueries(t, e = {}) {
                        let n = { ...e,
                            cancelRefetch: e.cancelRefetch ? ? !0
                        };
                        return Promise.all(a.j.batch(() => this.#i.findAll(t).filter(t => !t.isDisabled()).map(t => {
                            let e = t.fetch(void 0, n);
                            return n.throwOnError || (e = e.catch(r.lQ)), "paused" === t.state.fetchStatus ? Promise.resolve() : e
                        }))).then(r.lQ)
                    }
                    fetchQuery(t) {
                        let e = this.defaultQueryOptions(t);
                        void 0 === e.retry && (e.retry = !1);
                        let n = this.#i.build(this, e);
                        return n.isStaleByTime((0, r.d2)(e.staleTime, n)) ? n.fetch(e) : Promise.resolve(n.state.data)
                    }
                    prefetchQuery(t) {
                        return this.fetchQuery(t).then(r.lQ).catch(r.lQ)
                    }
                    fetchInfiniteQuery(t) {
                        return t.behavior = (0, p.PL)(t.pages), this.fetchQuery(t)
                    }
                    prefetchInfiniteQuery(t) {
                        return this.fetchInfiniteQuery(t).then(r.lQ).catch(r.lQ)
                    }
                    ensureInfiniteQueryData(t) {
                        return t.behavior = (0, p.PL)(t.pages), this.ensureQueryData(t)
                    }
                    resumePausedMutations() {
                        return f.t.isOnline() ? this.#a.resumePausedMutations() : Promise.resolve()
                    }
                    getQueryCache() {
                        return this.#i
                    }
                    getMutationCache() {
                        return this.#a
                    }
                    getDefaultOptions() {
                        return this.#o
                    }
                    setDefaultOptions(t) {
                        this.#o = t
                    }
                    setQueryDefaults(t, e) {
                        this.#s.set((0, r.EN)(t), {
                            queryKey: t,
                            defaultOptions: e
                        })
                    }
                    getQueryDefaults(t) {
                        let e = [...this.#s.values()],
                            n = {};
                        return e.forEach(e => {
                            (0, r.Cp)(t, e.queryKey) && Object.assign(n, e.defaultOptions)
                        }), n
                    }
                    setMutationDefaults(t, e) {
                        this.#u.set((0, r.EN)(t), {
                            mutationKey: t,
                            defaultOptions: e
                        })
                    }
                    getMutationDefaults(t) {
                        let e = [...this.#u.values()],
                            n = {};
                        return e.forEach(e => {
                            (0, r.Cp)(t, e.mutationKey) && (n = { ...n,
                                ...e.defaultOptions
                            })
                        }), n
                    }
                    defaultQueryOptions(t) {
                        if (t._defaulted) return t;
                        let e = { ...this.#o.queries,
                            ...this.getQueryDefaults(t.queryKey),
                            ...t,
                            _defaulted: !0
                        };
                        return e.queryHash || (e.queryHash = (0, r.F$)(e.queryKey, e)), void 0 === e.refetchOnReconnect && (e.refetchOnReconnect = "always" !== e.networkMode), void 0 === e.throwOnError && (e.throwOnError = !!e.suspense), !e.networkMode && e.persister && (e.networkMode = "offlineFirst"), e.queryFn === r.hT && (e.enabled = !1), e
                    }
                    defaultMutationOptions(t) {
                        return t ? ._defaulted ? t : { ...this.#o.mutations,
                            ...t ? .mutationKey && this.getMutationDefaults(t.mutationKey),
                            ...t,
                            _defaulted : !0
                        }
                    }
                    clear() {
                        this.#i.clear(), this.#a.clear()
                    }
                }
        },
        32563: (t, e, n) => {
            "use strict";
            n.d(e, {
                H: () => a,
                N: () => o
            });
            var r = n(98595),
                i = n(11696);

            function a(t, e, n) {
                return document.readyState === e || "complete" === document.readyState ? (n(), {
                    stop: r.l
                }) : (0, i.q)(t, window, "complete" === e ? "load" : "DOMContentLoaded", n, {
                    once: !0
                })
            }

            function o(t, e) {
                return new Promise(n => {
                    a(t, e, n)
                })
            }
        },
        34353: (t, e, n) => {
            "use strict";
            n.d(e, {
                Aq: () => o,
                R9: () => r,
                q7: () => u,
                sr: () => s
            });
            var r, i = n(6706);
            ! function(t) {
                t.WRITABLE_RESOURCE_GRAPHQL = "writable_resource_graphql", t.MISSING_URL_CONTEXT_TELEMETRY = "missing_url_context_telemetry", t.USER_ACCOUNT_TRACE_HEADER = "user_account_trace_header", t.PROFILING = "profiling"
            }(r || (r = {}));
            let a = new Set;

            function o(t) {
                Array.isArray(t) && t.filter(t => (0, i.Rj)(r, t)).forEach(t => {
                    a.add(t)
                })
            }

            function s(t) {
                return a.has(t)
            }

            function u() {
                return a
            }
        },
        38559: (t, e, n) => {
            "use strict";
            n.d(e, {
                $: () => s,
                s: () => o
            });
            var r = n(74268),
                i = n(69781),
                a = n(93049),
                o = class extends i.k {#
                    f;#
                    a;#
                    p;
                    constructor(t) {
                        super(), this.mutationId = t.mutationId, this.#a = t.mutationCache, this.#f = [], this.state = t.state || s(), this.setOptions(t.options), this.scheduleGc()
                    }
                    setOptions(t) {
                        this.options = t, this.updateGcTime(this.options.gcTime)
                    }
                    get meta() {
                        return this.options.meta
                    }
                    addObserver(t) {
                        this.#f.includes(t) || (this.#f.push(t), this.clearGcTimeout(), this.#a.notify({
                            type: "observerAdded",
                            mutation: this,
                            observer: t
                        }))
                    }
                    removeObserver(t) {
                        this.#f = this.#f.filter(e => e !== t), this.scheduleGc(), this.#a.notify({
                            type: "observerRemoved",
                            mutation: this,
                            observer: t
                        })
                    }
                    optionalRemove() {
                        this.#f.length || ("pending" === this.state.status ? this.scheduleGc() : this.#a.remove(this))
                    }
                    continue () {
                        return this.#p ? .continue() ? ? this.execute(this.state.variables)
                    }
                    async execute(t) {
                        this.#p = (0, a.II)({
                            fn: () => this.options.mutationFn ? this.options.mutationFn(t) : Promise.reject(Error("No mutationFn found")),
                            onFail: (t, e) => {
                                this.#h({
                                    type: "failed",
                                    failureCount: t,
                                    error: e
                                })
                            },
                            onPause: () => {
                                this.#h({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#h({
                                    type: "continue"
                                })
                            },
                            retry: this.options.retry ? ? 0,
                            retryDelay: this.options.retryDelay,
                            networkMode: this.options.networkMode,
                            canRun: () => this.#a.canRun(this)
                        });
                        let e = "pending" === this.state.status,
                            n = !this.#p.canStart();
                        try {
                            if (!e) {
                                this.#h({
                                    type: "pending",
                                    variables: t,
                                    isPaused: n
                                }), await this.#a.config.onMutate ? .(t, this);
                                let e = await this.options.onMutate ? .(t);
                                e !== this.state.context && this.#h({
                                    type: "pending",
                                    context: e,
                                    variables: t,
                                    isPaused: n
                                })
                            }
                            let r = await this.#p.start();
                            return await this.#a.config.onSuccess ? .(r, t, this.state.context, this), await this.options.onSuccess ? .(r, t, this.state.context), await this.#a.config.onSettled ? .(r, null, this.state.variables, this.state.context, this), await this.options.onSettled ? .(r, null, t, this.state.context), this.#h({
                                type: "success",
                                data: r
                            }), r
                        } catch (e) {
                            try {
                                throw await this.#a.config.onError ? .(e, t, this.state.context, this), await this.options.onError ? .(e, t, this.state.context), await this.#a.config.onSettled ? .(void 0, e, this.state.variables, this.state.context, this), await this.options.onSettled ? .(void 0, e, t, this.state.context), e
                            } finally {
                                this.#h({
                                    type: "error",
                                    error: e
                                })
                            }
                        } finally {
                            this.#a.runNext(this)
                        }
                    }#
                    h(t) {
                        this.state = (e => {
                            switch (t.type) {
                                case "failed":
                                    return { ...e,
                                        failureCount: t.failureCount,
                                        failureReason: t.error
                                    };
                                case "pause":
                                    return { ...e,
                                        isPaused: !0
                                    };
                                case "continue":
                                    return { ...e,
                                        isPaused: !1
                                    };
                                case "pending":
                                    return { ...e,
                                        context: t.context,
                                        data: void 0,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        isPaused: t.isPaused,
                                        status: "pending",
                                        variables: t.variables,
                                        submittedAt: Date.now()
                                    };
                                case "success":
                                    return { ...e,
                                        data: t.data,
                                        failureCount: 0,
                                        failureReason: null,
                                        error: null,
                                        status: "success",
                                        isPaused: !1
                                    };
                                case "error":
                                    return { ...e,
                                        data: void 0,
                                        error: t.error,
                                        failureCount: e.failureCount + 1,
                                        failureReason: t.error,
                                        isPaused: !1,
                                        status: "error"
                                    }
                            }
                        })(this.state), r.j.batch(() => {
                            this.#f.forEach(e => {
                                e.onMutationUpdate(t)
                            }), this.#a.notify({
                                mutation: this,
                                type: "updated",
                                action: t
                            })
                        })
                    }
                };

            function s() {
                return {
                    context: void 0,
                    data: void 0,
                    error: null,
                    failureCount: 0,
                    failureReason: null,
                    isPaused: !1,
                    status: "idle",
                    variables: void 0,
                    submittedAt: 0
                }
            }
        },
        38954: (t, e, n) => {
            "use strict";
            n.d(e, {
                JZ: () => i,
                Vy: () => s,
                Xs: () => l,
                bP: () => r,
                fH: () => u,
                xG: () => c
            });
            let r = {
                    log: "log",
                    debug: "debug",
                    info: "info",
                    warn: "warn",
                    error: "error"
                },
                i = console,
                a = {};
            Object.keys(r).forEach(t => {
                a[t] = i[t]
            });
            let o = "Datadog Browser SDK:",
                s = {
                    debug: a.debug.bind(i, o),
                    log: a.log.bind(i, o),
                    info: a.info.bind(i, o),
                    warn: a.warn.bind(i, o),
                    error: a.error.bind(i, o)
                },
                u = "https://docs.datadoghq.com",
                l = `${u}/real_user_monitoring/browser/troubleshooting`,
                c = "More details:"
        },
        40176: (t, e, n) => {
            "use strict";
            let r;
            n.d(e, {
                AY: () => o,
                L2: () => s,
                c$: () => u,
                l2: () => a
            });
            var i = n(58961);

            function a(t) {
                return u(t, location.href).href
            }

            function o(t) {
                try {
                    return !!u(t)
                } catch (t) {
                    return !1
                }
            }

            function s(t) {
                let e = u(t).pathname;
                return "/" === e[0] ? e : `/${e}`
            }

            function u(t, e) {
                let n = function() {
                    if (void 0 === r) try {
                        let t = new l("http://test/path");
                        r = "http://test/path" === t.href
                    } catch (t) {
                        r = !1
                    }
                    return r ? l : void 0
                }();
                if (n) try {
                    return void 0 !== e ? new n(t, e) : new n(t)
                } catch (n) {
                    throw Error(`Failed to construct URL: ${String(n)} ${(0,i.s)({url:t,base:e})}`)
                }
                if (void 0 === e && !/:/.test(t)) throw Error(`Invalid URL: '${t}'`);
                let a = document,
                    o = a.createElement("a");
                if (void 0 !== e) {
                    let t = (a = document.implementation.createHTMLDocument("")).createElement("base");
                    t.href = e, a.head.appendChild(t), a.body.appendChild(o)
                }
                return o.href = t, o
            }
            let l = URL
        },
        45350: (t, e, n) => {
            "use strict";
            n.d(e, {
                Rr: () => E,
                A2: () => A,
                VJ: () => T,
                Q6: () => R,
                JK: () => k,
                Wb: () => C,
                a5: () => x
            });
            var r = n(38954),
                i = n(46532),
                a = n(96605),
                o = n(34353),
                s = n(16878),
                u = n(20405),
                l = n(26664),
                c = n(85590),
                d = n(47884),
                f = n(31352),
                p = n(58961),
                h = n(77078),
                m = n(46866),
                g = n(94404),
                y = n(94727);
            let v = {
                    log: "log",
                    configuration: "configuration",
                    usage: "usage"
                },
                _ = ["https://www.datadoghq-browser-agent.com", "https://www.datad0g-browser-agent.com", "https://d3uc069fcn7uxw.cloudfront.net", "https://d20xtzwzcl0ceb.cloudfront.net", "http://localhost", "<anonymous>"],
                b = [s.R8],
                w = (0, y.O)(),
                S = t => {
                    w.add(() => S(t))
                };

            function x(t, e) {
                let n, r = new u.c,
                    i = new Set,
                    a = !b.includes(e.site) && (0, f.ic)(e.telemetrySampleRate),
                    s = {
                        [v.log]: a,
                        [v.configuration]: a && (0, f.ic)(e.telemetryConfigurationSampleRate),
                        [v.usage]: a && (0, f.ic)(e.telemetryUsageSampleRate)
                    },
                    m = {
                        is_local_file: "file:" === window.location.protocol,
                        is_worker: "WorkerGlobalScope" in self
                    };
                return S = a => {
                    let u = (0, p.s)(a);
                    if (s[a.type] && i.size < e.maxTelemetryEventsPerPage && !i.has(u)) {
                        var c, f, y;
                        let e = (c = t, f = a, y = m, (0, h.kg)({
                            type: "telemetry",
                            date: (0, l.nx)(),
                            service: c,
                            version: "6.6.3",
                            source: "browser",
                            _dd: {
                                format_version: 2
                            },
                            telemetry: (0, h.kg)(f, {
                                runtime_env: y,
                                connectivity: (0, g.q)(),
                                sdk_setup: "npm"
                            }),
                            experimental_features: Array.from((0, o.q7)())
                        }, void 0 !== n ? n() : {}));
                        r.notify(e), (0, d.b)("telemetry", e), i.add(u)
                    }
                }, (0, c.Bd)(T), {
                    setContextProvider: t => {
                        n = t
                    },
                    observable: r,
                    enabled: a
                }
            }

            function k() {
                w.drain()
            }

            function C(t) {
                return t.site === s.Bb
            }

            function A(t, e) {
                (0, c.oO)(r.bP.debug, t, e), S({
                    type: v.log,
                    message: t,
                    status: "debug",
                    ...e
                })
            }

            function T(t, e) {
                S({
                    type: v.log,
                    status: "error",
                    ... function(t) {
                        if ((0, i.bJ)(t)) {
                            var e;
                            let n = (0, m.T)(t);
                            return {
                                error: {
                                    kind: n.name,
                                    stack: (0, a.Yn)(((e = n).stack = e.stack.filter(t => !t.url || _.some(e => t.url.startsWith(e))), e))
                                },
                                message: n.message
                            }
                        }
                        return {
                            error: {
                                stack: i.e6
                            },
                            message: `Uncaught ${(0,p.s)(t)}`
                        }
                    }(t),
                    ...e
                })
            }

            function E(t) {
                S({
                    type: v.configuration,
                    configuration: t
                })
            }

            function R(t) {
                S({
                    type: v.usage,
                    usage: t
                })
            }
        },
        45460: (t, e, n) => {
            "use strict";
            let r, i, a;
            n.d(e, {
                tx: () => l
            });
            var o = n(12115);
            n(96605), n(26664), n(85590);
            let s = [],
                u = [];

            function l(t = {}) {
                return {
                    name: "react",
                    onInit({
                        publicApi: e,
                        initConfiguration: n
                    }) {
                        for (let n of (r = e, i = t, s)) n(i, r);
                        t.router && (n.trackViewsManually = !0)
                    },
                    onRumStart({
                        strategy: t
                    }) {
                        for (let e of u) e(t)
                    },
                    getConfigurationTelemetry: () => ({
                        router: !!t.router
                    })
                }
            }
            o.Component
        },
        46532: (t, e, n) => {
            "use strict";
            n.d(e, {
                As: () => u,
                Dr: () => f,
                Nt: () => l,
                Qb: () => c,
                bJ: () => d,
                e6: () => s
            });
            var r = n(25909),
                i = n(58961),
                a = n(46866),
                o = n(96605);
            let s = "No stack, consider using an instance of Error";

            function u({
                stackTrace: t,
                originalError: e,
                handlingStack: n,
                componentStack: a,
                startClocks: u,
                nonErrorPrefix: p,
                source: h,
                handling: m
            }) {
                var g, y, v, _, b, w;
                let S = d(e),
                    x = (g = t, y = S, v = p, _ = e, (null == g ? void 0 : g.message) && (null == g ? void 0 : g.name) ? g.message : y ? "Empty message" : `${v} ${(0,i.s)((0,r.a)(_))}`),
                    k = (b = S, void 0 !== (w = t) && (b || w.stack.length > 0 && (w.stack.length > 1 || void 0 !== w.stack[0].url))) ? (0, o.Yn)(t) : s,
                    C = S ? f(e, h) : void 0,
                    A = t ? t.name : void 0,
                    T = l(e),
                    E = c(e);
                return {
                    startClocks: u,
                    source: h,
                    handling: m,
                    handlingStack: n,
                    componentStack: a,
                    originalError: e,
                    type: A,
                    message: x,
                    stack: k,
                    causes: C,
                    fingerprint: T,
                    context: E
                }
            }

            function l(t) {
                return d(t) && "dd_fingerprint" in t ? String(t.dd_fingerprint) : void 0
            }

            function c(t) {
                if (null !== t && "object" == typeof t && "dd_context" in t) return t.dd_context
            }

            function d(t) {
                return t instanceof Error || "[object Error]" === Object.prototype.toString.call(t)
            }

            function f(t, e) {
                let n = t,
                    r = [];
                for (; d(null == n ? void 0 : n.cause) && r.length < 10;) {
                    let t = (0, a.T)(n.cause);
                    r.push({
                        message: n.cause.message,
                        source: e,
                        type: null == t ? void 0 : t.name,
                        stack: t && (0, o.Yn)(t)
                    }), n = n.cause
                }
                return r.length ? r : void 0
            }
        },
        46866: (t, e, n) => {
            "use strict";

            function r(t) {
                let e = [],
                    n = f(t, "stack"),
                    r = String(t);
                return n && n.startsWith(r) && (n = n.slice(r.length)), n && n.split("\n").forEach(t => {
                    let n = function(t) {
                        let e = o.exec(t);
                        if (!e) return;
                        let n = e[2] && 0 === e[2].indexOf("native"),
                            r = e[2] && 0 === e[2].indexOf("eval"),
                            i = s.exec(e[2]);
                        return r && i && (e[2] = i[1], e[3] = i[2], e[4] = i[3]), {
                            args: n ? [e[2]] : [],
                            column: e[4] ? +e[4] : void 0,
                            func: e[1] || "?",
                            line: e[3] ? +e[3] : void 0,
                            url: n ? void 0 : e[2]
                        }
                    }(t) || function(t) {
                        let e = u.exec(t);
                        if (e) return {
                            args: [],
                            column: e[3] ? +e[3] : void 0,
                            func: "?",
                            line: e[2] ? +e[2] : void 0,
                            url: e[1]
                        }
                    }(t) || function(t) {
                        let e = l.exec(t);
                        if (e) return {
                            args: [],
                            column: e[4] ? +e[4] : void 0,
                            func: e[1] || "?",
                            line: +e[3],
                            url: e[2]
                        }
                    }(t) || function(t) {
                        let e = c.exec(t);
                        if (!e) return;
                        let n = e[3] && e[3].indexOf(" > eval") > -1,
                            r = d.exec(e[3]);
                        return n && r && (e[3] = r[1], e[4] = r[2], e[5] = void 0), {
                            args: e[2] ? e[2].split(",") : [],
                            column: e[5] ? +e[5] : void 0,
                            func: e[1] || "?",
                            line: e[4] ? +e[4] : void 0,
                            url: e[3]
                        }
                    }(t);
                    n && (!n.func && n.line && (n.func = "?"), e.push(n))
                }), {
                    message: f(t, "message"),
                    name: f(t, "name"),
                    stack: e
                }
            }
            n.d(e, {
                T: () => r,
                h: () => p
            });
            let i = "((?:file|https?|blob|chrome-extension|electron|native|eval|webpack|snippet|<anonymous>|\\w+\\.|\\/).*?)",
                a = "(?::(\\d+))",
                o = RegExp(`^\\s*at (.*?) ?\\(${i}${a}?${a}?\\)?\\s*$`, "i"),
                s = RegExp(`\\((\\S*)${a}${a}\\)`),
                u = RegExp(`^\\s*at ?${i}${a}?${a}??\\s*$`, "i"),
                l = /^\s*at (?:((?:\[object object\])?.+) )?\(?((?:file|ms-appx|https?|webpack|blob):.*?):(\d+)(?::(\d+))?\)?\s*$/i,
                c = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)((?:file|https?|blob|chrome|webpack|resource|capacitor|\[native).*?|[^@]*bundle)(?::(\d+))?(?::(\d+))?\s*$/i,
                d = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;

            function f(t, e) {
                if ("object" != typeof t || !t || !(e in t)) return;
                let n = t[e];
                return "string" == typeof n ? n : void 0
            }

            function p(t, e, n, r) {
                var i;
                let a, o, {
                    name: s,
                    message: u
                } = (i = t, "[object String]" === ({}).toString.call(i) && ([, a, o] = h.exec(i)), {
                    name: a,
                    message: o
                });
                return {
                    name: s,
                    message: u,
                    stack: [{
                        url: e,
                        column: r,
                        line: n
                    }]
                }
            }
            let h = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?([\s\S]*)$/
        },
        47884: (t, e, n) => {
            "use strict";

            function r(t, e) {
                let n = window.__ddBrowserSdkExtensionCallback;
                n && n({
                    type: t,
                    payload: e
                })
            }
            n.d(e, {
                b: () => r
            })
        },
        52331: t => {
            t.exports = {
                style: {
                    fontFamily: "'untitledSans', 'untitledSans Fallback'"
                },
                className: "__className_648035",
                variable: "__variable_648035"
            }
        },
        57445: (t, e, n) => {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = function(t) {
                let {
                    html: e,
                    height: n = null,
                    width: a = null,
                    children: o,
                    dataNtpc: s = ""
                } = t;
                return (0, i.useEffect)(() => {
                    s && performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-".concat(s)
                        }
                    })
                }, [s]), (0, r.jsxs)(r.Fragment, {
                    children: [o, e ? (0, r.jsx)("div", {
                        style: {
                            height: null != n ? "".concat(n, "px") : "auto",
                            width: null != a ? "".concat(a, "px") : "auto"
                        },
                        "data-ntpc": s,
                        dangerouslySetInnerHTML: {
                            __html: e
                        }
                    }) : null]
                })
            };
            let r = n(95155),
                i = n(12115)
        },
        58961: (t, e, n) => {
            "use strict";
            n.d(e, {
                M: () => a,
                s: () => i
            });
            var r = n(98595);

            function i(t, e, n) {
                if ("object" != typeof t || null === t) return JSON.stringify(t);
                let r = a(Object.prototype),
                    i = a(Array.prototype),
                    o = a(Object.getPrototypeOf(t)),
                    s = a(t);
                try {
                    return JSON.stringify(t, e, n)
                } catch (t) {
                    return "<error: unable to serialize object>"
                } finally {
                    r(), i(), o(), s()
                }
            }

            function a(t) {
                let e = t.toJSON;
                return e ? (delete t.toJSON, () => {
                    t.toJSON = e
                }) : r.l
            }
        },
        59831: (t, e, n) => {
            "use strict";
            n.d(e, {
                Z: () => s,
                m: () => o
            });
            var r = n(19155),
                i = n(85590),
                a = n(38954);

            function o(t) {
                let e = {
                    version: "6.6.3",
                    onReady(t) {
                        t()
                    },
                    ...t
                };
                return Object.defineProperty(e, "_setDebug", {
                    get: () => i.pM,
                    enumerable: !1
                }), e
            }

            function s(t, e, n) {
                let i = t[e];
                i && !i.q && i.version && a.Vy.warn("SDK is loaded more than once. This is unsupported and might have unexpected behavior."), t[e] = n, i && i.q && i.q.forEach(t => (0, r.y)(t, "onReady callback threw an error:")())
            }
        },
        61540: (t, e, n) => {
            "use strict";

            function r(t, e) {
                let n = t.indexOf(e);
                n >= 0 && t.splice(n, 1)
            }
            n.d(e, {
                A: () => r
            })
        },
        63002: (t, e, n) => {
            "use strict";

            function r(t, e) {
                for (let n = t.length - 1; n >= 0; n -= 1) {
                    let r = t[n];
                    if (e(r, n, t)) return r
                }
            }

            function i(t) {
                return Object.values(t)
            }

            function a(t) {
                return Object.entries(t)
            }
            n.d(e, {
                KQ: () => i,
                Uk: () => r,
                WP: () => a
            })
        },
        66902: (t, e, n) => {
            "use strict";
            n.d(e, {
                PL: () => i,
                RQ: () => u,
                rB: () => s
            });
            var r = n(34049);

            function i(t) {
                return {
                    onFetch: (e, n) => {
                        let i = e.options,
                            s = e.fetchOptions ? .meta ? .fetchMore ? .direction,
                            u = e.state.data ? .pages || [],
                            l = e.state.data ? .pageParams || [],
                            c = {
                                pages: [],
                                pageParams: []
                            },
                            d = 0,
                            f = async () => {
                                let n = !1,
                                    f = t => {
                                        Object.defineProperty(t, "signal", {
                                            enumerable: !0,
                                            get: () => (e.signal.aborted ? n = !0 : e.signal.addEventListener("abort", () => {
                                                n = !0
                                            }), e.signal)
                                        })
                                    },
                                    p = (0, r.ZM)(e.options, e.fetchOptions),
                                    h = async (t, i, a) => {
                                        if (n) return Promise.reject();
                                        if (null == i && t.pages.length) return Promise.resolve(t);
                                        let o = {
                                            queryKey: e.queryKey,
                                            pageParam: i,
                                            direction: a ? "backward" : "forward",
                                            meta: e.options.meta
                                        };
                                        f(o);
                                        let s = await p(o),
                                            {
                                                maxPages: u
                                            } = e.options,
                                            l = a ? r.ZZ : r.y9;
                                        return {
                                            pages: l(t.pages, s, u),
                                            pageParams: l(t.pageParams, i, u)
                                        }
                                    };
                                if (s && u.length) {
                                    let t = "backward" === s,
                                        e = {
                                            pages: u,
                                            pageParams: l
                                        },
                                        n = (t ? o : a)(i, e);
                                    c = await h(e, n, t)
                                } else {
                                    let e = t ? ? u.length;
                                    do {
                                        let t = 0 === d ? l[0] ? ? i.initialPageParam : a(i, c);
                                        if (d > 0 && null == t) break;
                                        c = await h(c, t), d++
                                    } while (d < e)
                                }
                                return c
                            };
                        e.options.persister ? e.fetchFn = () => e.options.persister ? .(f, {
                            queryKey: e.queryKey,
                            meta: e.options.meta,
                            signal: e.signal
                        }, n) : e.fetchFn = f
                    }
                }
            }

            function a(t, {
                pages: e,
                pageParams: n
            }) {
                let r = e.length - 1;
                return e.length > 0 ? t.getNextPageParam(e[r], e, n[r], n) : void 0
            }

            function o(t, {
                pages: e,
                pageParams: n
            }) {
                return e.length > 0 ? t.getPreviousPageParam ? .(e[0], e, n[0], n) : void 0
            }

            function s(t, e) {
                return !!e && null != a(t, e)
            }

            function u(t, e) {
                return !!e && !!t.getPreviousPageParam && null != o(t, e)
            }
        },
        68321: (t, e, n) => {
            "use strict";
            n.r(e), n.d(e, {
                default: () => i.a
            });
            var r = n(41402),
                i = n.n(r),
                a = {};
            for (let t in r) "default" !== t && (a[t] = () => r[t]);
            n.d(e, a)
        },
        68332: (t, e, n) => {
            "use strict";
            let r;
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.GoogleAnalytics = function(t) {
                let {
                    gaId: e,
                    debugMode: n,
                    dataLayerName: s = "dataLayer",
                    nonce: u
                } = t;
                return void 0 === r && (r = s), (0, a.useEffect)(() => {
                    performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-ga"
                        }
                    })
                }, []), (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsx)(o.default, {
                        id: "_next-ga-init",
                        dangerouslySetInnerHTML: {
                            __html: "\n          window['".concat(s, "'] = window['").concat(s, "'] || [];\n          function gtag(){window['").concat(s, "'].push(arguments);}\n          gtag('js', new Date());\n\n          gtag('config', '").concat(e, "' ").concat(n ? ",{ 'debug_mode': true }" : "", ");")
                        },
                        nonce: u
                    }), (0, i.jsx)(o.default, {
                        id: "_next-ga",
                        src: "https://www.googletagmanager.com/gtag/js?id=".concat(e),
                        nonce: u
                    })]
                })
            }, e.sendGAEvent = function() {
                for (var t = arguments.length, e = Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                if (void 0 === r) return void console.warn("@next/third-parties: GA has not been initialized");
                window[r] ? window[r].push(arguments) : console.warn("@next/third-parties: GA dataLayer ".concat(r, " does not exist"))
            };
            let i = n(95155),
                a = n(12115),
                o = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(68321))
        },
        77078: (t, e, n) => {
            "use strict";
            n.d(e, {
                Go: () => a,
                kg: () => o
            });
            var r = n(15843);

            function i(t, e, n = function() {
                if ("undefined" != typeof WeakSet) {
                    let t = new WeakSet;
                    return {
                        hasAlreadyBeenSeen(e) {
                            let n = t.has(e);
                            return n || t.add(e), n
                        }
                    }
                }
                let t = [];
                return {
                    hasAlreadyBeenSeen(e) {
                        let n = t.indexOf(e) >= 0;
                        return n || t.push(e), n
                    }
                }
            }()) {
                if (void 0 === e) return t;
                if ("object" != typeof e || null === e) return e;
                if (e instanceof Date) return new Date(e.getTime());
                if (e instanceof RegExp) {
                    let t = e.flags || [e.global ? "g" : "", e.ignoreCase ? "i" : "", e.multiline ? "m" : "", e.sticky ? "y" : "", e.unicode ? "u" : ""].join("");
                    return new RegExp(e.source, t)
                }
                if (n.hasAlreadyBeenSeen(e)) return;
                if (Array.isArray(e)) {
                    let r = Array.isArray(t) ? t : [];
                    for (let t = 0; t < e.length; ++t) r[t] = i(r[t], e[t], n);
                    return r
                }
                let a = "object" === (0, r.P)(t) ? t : {};
                for (let t in e) Object.prototype.hasOwnProperty.call(e, t) && (a[t] = i(a[t], e[t], n));
                return a
            }

            function a(t) {
                return i(void 0, t)
            }

            function o(...t) {
                let e;
                for (let n of t) null != n && (e = i(e, n));
                return e
            }
        },
        81135: (t, e, n) => {
            "use strict";
            n.d(e, {
                g: () => r
            });
            let r = {
                AGENT: "agent",
                CONSOLE: "console",
                CUSTOM: "custom",
                LOGGER: "logger",
                NETWORK: "network",
                SOURCE: "source",
                REPORT: "report"
            }
        },
        81154: (t, e, n) => {
            "use strict";
            n.d(e, {
                Kp: () => u,
                _T: () => s,
                y5: () => o
            });
            var r = n(20405),
                i = n(63002),
                a = n(11696);
            let o = {
                HIDDEN: "visibility_hidden",
                UNLOADING: "before_unload",
                PAGEHIDE: "page_hide",
                FROZEN: "page_frozen"
            };

            function s(t) {
                return new r.c(e => {
                    let {
                        stop: n
                    } = (0, a.l)(t, window, ["visibilitychange", "freeze"], t => {
                        "visibilitychange" === t.type && "hidden" === document.visibilityState ? e.notify({
                            reason: o.HIDDEN
                        }) : "freeze" === t.type && e.notify({
                            reason: o.FROZEN
                        })
                    }, {
                        capture: !0
                    }), r = (0, a.q)(t, window, "beforeunload", () => {
                        e.notify({
                            reason: o.UNLOADING
                        })
                    }).stop;
                    return () => {
                        n(), r()
                    }
                })
            }

            function u(t) {
                return (0, i.KQ)(o).includes(t)
            }
        },
        82120: (t, e, n) => {
            "use strict";
            let r;

            function i(t) {
                return l(t).segments_count
            }

            function a(t) {
                l(t).segments_count += 1
            }

            function o(t) {
                l(t).records_count += 1
            }

            function s(t, e) {
                l(t).segments_total_raw_size += e
            }

            function u(t) {
                return null == r ? void 0 : r.get(t)
            }

            function l(t) {
                let e;
                return r || (r = new Map), r.has(t) ? e = r.get(t) : (e = {
                    records_count: 0,
                    segments_count: 0,
                    segments_total_raw_size: 0
                }, r.set(t, e), r.size > 1e3 && function() {
                    if (!r) return;
                    let t = r.keys().next().value;
                    t && r.delete(t)
                }()), e
            }
            n.d(e, {
                $1: () => o,
                H5: () => a,
                K_: () => i,
                L7: () => s,
                lv: () => u
            })
        },
        85520: (t, e, n) => {
            "use strict";
            n.d(e, {
                sA: () => y
            });
            var r = n(85590),
                i = n(94357),
                a = n(26664),
                o = n(97617),
                s = n(3938),
                u = n(81135);
            let l = 80 * o._m,
                c = 3 * o.iH,
                d = a.iW,
                f = a.OY;

            function p(t, e, n, r, a) {
                0 === e.transportStatus && 0 === e.queuedPayloads.size() && e.bandwidthMonitor.canHandle(t) ? h(t, e, n, {
                    onSuccess: () => m(0, e, n, r, a),
                    onFailure: () => {
                        e.queuedPayloads.enqueue(t),
                            function t(e, n, r, a) {
                                2 === e.transportStatus && (0, i.wg)(() => {
                                    h(e.queuedPayloads.first(), e, n, {
                                        onSuccess: () => {
                                            e.queuedPayloads.dequeue(), e.currentBackoffTime = f, m(1, e, n, r, a)
                                        },
                                        onFailure: () => {
                                            e.currentBackoffTime = Math.min(d, 2 * e.currentBackoffTime), t(e, n, r, a)
                                        }
                                    })
                                }, e.currentBackoffTime)
                            }(e, n, r, a)
                    }
                }) : e.queuedPayloads.enqueue(t)
            }

            function h(t, e, n, {
                onSuccess: r,
                onFailure: i
            }) {
                e.bandwidthMonitor.add(t), n(t, n => {
                    var a;
                    e.bandwidthMonitor.remove(t), "opaque" !== (a = n).type && (0 === a.status && !navigator.onLine || 408 === a.status || 429 === a.status || (0, s.G)(a.status)) ? (e.transportStatus = e.bandwidthMonitor.ongoingRequestCount > 0 ? 1 : 2, t.retry = {
                        count: t.retry ? t.retry.count + 1 : 1,
                        lastFailureStatus: n.status
                    }, i()) : (e.transportStatus = 0, r())
                })
            }

            function m(t, e, n, r, i) {
                0 === t && e.queuedPayloads.isFull() && !e.queueFullReported && (i({
                    message: `Reached max ${r} events size queued for upload: ${c/o.iH}MiB`,
                    source: u.g.AGENT,
                    startClocks: (0, a.M8)()
                }), e.queueFullReported = !0);
                let s = e.queuedPayloads;
                for (e.queuedPayloads = g(); s.size() > 0;) p(s.dequeue(), e, n, r, i)
            }

            function g() {
                let t = [];
                return {
                    bytesCount: 0,
                    enqueue(e) {
                        this.isFull() || (t.push(e), this.bytesCount += e.bytesCount)
                    },
                    first: () => t[0],
                    dequeue() {
                        let e = t.shift();
                        return e && (this.bytesCount -= e.bytesCount), e
                    },
                    size: () => t.length,
                    isFull() {
                        return this.bytesCount >= c
                    }
                }
            }

            function y(t, e, n) {
                let i = {
                        transportStatus: 0,
                        currentBackoffTime: f,
                        bandwidthMonitor: {
                            ongoingRequestCount: 0,
                            ongoingByteCount: 0,
                            canHandle(t) {
                                return 0 === this.ongoingRequestCount || this.ongoingByteCount + t.bytesCount <= l && this.ongoingRequestCount < 32
                            },
                            add(t) {
                                this.ongoingRequestCount += 1, this.ongoingByteCount += t.bytesCount
                            },
                            remove(t) {
                                this.ongoingRequestCount -= 1, this.ongoingByteCount -= t.bytesCount
                            }
                        },
                        queuedPayloads: g(),
                        queueFullReported: !1
                    },
                    a = (n, i) => {
                        var a, o, s, u;
                        return a = t, o = e, s = n, u = i, void(function() {
                            try {
                                return window.Request && "keepalive" in new Request("http://a")
                            } catch (t) {
                                return !1
                            }
                        }() && s.bytesCount < o ? fetch(a.build("fetch-keepalive", s), {
                            method: "POST",
                            body: s.data,
                            keepalive: !0,
                            mode: "cors"
                        }).then((0, r.dm)(t => null == u ? void 0 : u({
                            status: t.status,
                            type: t.type
                        }))).catch((0, r.dm)(() => _(a, s, u))) : _(a, s, u))
                    };
                return {
                    send: e => {
                        p(e, i, a, t.trackType, n)
                    },
                    sendOnExit: n => {
                        ! function(t, e, n) {
                            if (navigator.sendBeacon && n.bytesCount < e) try {
                                let e = t.build("beacon", n);
                                if (navigator.sendBeacon(e, n.data)) return
                            } catch (t) {
                                var i;
                                i = t, v || (v = !0, (0, r.Dx)(i))
                            }
                            _(t, n)
                        }(t, e, n)
                    }
                }
            }
            let v = !1;

            function _(t, e, n) {
                fetch(t.build("fetch", e), {
                    method: "POST",
                    body: e.data,
                    mode: "cors"
                }).then((0, r.dm)(t => null == n ? void 0 : n({
                    status: t.status,
                    type: t.type
                }))).catch((0, r.dm)(() => null == n ? void 0 : n({
                    status: 0
                })))
            }
        },
        85590: (t, e, n) => {
            "use strict";
            let r;
            n.d(e, {
                Bd: () => o,
                Dx: () => c,
                dm: () => u,
                oO: () => d,
                pM: () => s,
                um: () => l
            });
            var i = n(38954);
            let a = !1;

            function o(t) {
                r = t
            }

            function s(t) {
                a = t
            }

            function u(t) {
                return function() {
                    return l(t, this, arguments)
                }
            }

            function l(t, e, n) {
                try {
                    return t.apply(e, n)
                } catch (t) {
                    c(t)
                }
            }

            function c(t) {
                if (d(t), r) try {
                    r(t)
                } catch (t) {
                    d(t)
                }
            }

            function d(...t) {
                a && i.Vy.error("[MONITOR]", ...t)
            }
        },
        88647: (t, e, n) => {
            "use strict";
            n.d(e, {
                Ww: () => a,
                Y9: () => i,
                d0: () => o
            });
            var r = n(10676);

            function i() {
                let t = (0, r.V)().DatadogEventBridge;
                if (t) return {
                    getCapabilities() {
                        var e;
                        return JSON.parse((null == (e = t.getCapabilities) ? void 0 : e.call(t)) || "[]")
                    },
                    getPrivacyLevel() {
                        var e;
                        return null == (e = t.getPrivacyLevel) ? void 0 : e.call(t)
                    },
                    getAllowedWebViewHosts: () => JSON.parse(t.getAllowedWebViewHosts()),
                    send(e, n, r) {
                        t.send(JSON.stringify({
                            eventType: e,
                            event: n,
                            view: r ? {
                                id: r
                            } : void 0
                        }))
                    }
                }
            }

            function a(t) {
                let e = i();
                return !!e && e.getCapabilities().includes(t)
            }

            function o(t) {
                var e;
                void 0 === t && (t = null == (e = (0, r.V)().location) ? void 0 : e.hostname);
                let n = i();
                return !!n && n.getAllowedWebViewHosts().some(e => t === e || t.endsWith(`.${e}`))
            }
        },
        91625: (t, e, n) => {
            "use strict";
            let r, i, a, o, s, u, l, c, d, f, p, h;
            n.d(e, {
                eT: () => eM,
                o: () => eN,
                $m: () => eI,
                NT: () => eO,
                Wd: () => eP,
                do: () => m,
                yF: () => e0,
                wI: () => eE,
                W3: () => tX,
                PJ: () => eD,
                dT: () => eU,
                $4: () => eR,
                Gn: () => nq,
                zL: () => nV,
                dx: () => ra,
                rf: () => ez,
                pB: () => nF,
                wR: () => eT,
                g1: () => nz,
                YR: () => ef,
                XS: () => eC,
                p_: () => eA,
                AB: () => tQ,
                jR: () => e$,
                jK: () => ep,
                Ie: () => ej,
                rJ: () => ri,
                s5: () => e_
            });
            var m, g = n(20405);
            let y = {
                GRANTED: "granted",
                NOT_GRANTED: "not-granted"
            };
            var v = n(97617);

            function _() {
                let t = "",
                    e = 0;
                return {
                    isAsync: !1,
                    get isEmpty() {
                        return !t
                    },
                    write(n, r) {
                        let i = (0, v.WW)(n);
                        e += i, t += n, r && r(i)
                    },
                    finish(t) {
                        t(this.finishSync())
                    },
                    finishSync() {
                        let n = {
                            output: t,
                            outputBytesCount: e,
                            rawBytesCount: e,
                            pendingData: ""
                        };
                        return t = "", e = 0, n
                    },
                    estimateEncodedBytesCount: t => t.length
                }
            }
            var b = n(85590),
                w = n(45350),
                S = n(59831),
                x = n(77078),
                k = n(96605),
                C = n(25909),
                A = n(26664);
            let T = {
                    userContext: "userContext",
                    globalContext: "globalContext",
                    accountContext: "accountContext"
                },
                E = {
                    getContext: "getContext",
                    setContext: "setContext",
                    setContextProperty: "setContextProperty",
                    removeContextProperty: "removeContextProperty",
                    clearContext: "clearContext"
                };
            var R = n(38954);

            function I(t, e) {
                e.silentMultipleInit || R.Vy.error(`${t} is already initialized.`)
            }

            function O(t) {
                return t ? (parseInt(t, 10) ^ 16 * Math.random() >> parseInt(t, 10) / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, O)
            }
            let P = /([\w-]+)\s*=\s*([^;]+)/g;

            function N(t, e) {
                for (P.lastIndex = 0;;) {
                    let n = P.exec(t);
                    if (n) {
                        if (n[1] === e) return n[2]
                    } else break
                }
            }

            function M(t, e, n = "") {
                let r = t.charCodeAt(e - 1),
                    i = r >= 55296 && r <= 56319 ? e + 1 : e;
                return t.length <= i ? t : `${t.slice(0,i)}${n}`
            }

            function L({
                vitalsByName: t,
                vitalsByReference: e
            }, n, r = {}) {
                let i = {
                        name: n,
                        startClocks: (0, A.M8)(),
                        context: r.context,
                        description: r.description
                    },
                    a = {
                        __dd_vital_reference: !0
                    };
                return t.set(n, i), e.set(a, i), a
            }

            function D(t, {
                vitalsByName: e,
                vitalsByReference: n
            }, r, i = {}) {
                var a, o, s, u, l;
                let c = "string" == typeof r ? e.get(r) : n.get(r);
                c && (t((a = c, o = c.startClocks, s = i, u = (0, A.M8)(), {
                    name: a.name,
                    type: "duration",
                    startClocks: o,
                    duration: (0, A.vk)(o.timeStamp, u.timeStamp),
                    context: (0, x.kg)(a.context, s.context),
                    description: null != (l = s.description) ? l : a.description
                })), "string" == typeof r ? e.delete(r) : n.delete(r))
            }

            function $(t, e, n) {
                if (t)
                    for (let r of t) {
                        let t = r[e];
                        t && t(n)
                    }
            }
            var U = n(94727),
                j = n(88647),
                q = n(98595),
                V = n(21096),
                z = n(40176);

            function F() {
                return r || (r = new g.c(t => {
                    if (!window.fetch) return;
                    let {
                        stop: e
                    } = (0, V.H)(window, "fetch", e => (function({
                        parameters: t,
                        onPostCall: e,
                        handlingStack: n
                    }, r) {
                        let [i, a] = t, o = a && a.method;
                        void 0 === o && i instanceof Request && (o = i.method);
                        let s = void 0 !== o ? String(o).toUpperCase() : "GET",
                            u = i instanceof Request ? i.url : (0, z.l2)(String(i)),
                            l = {
                                state: "start",
                                init: a,
                                input: i,
                                method: s,
                                startClocks: (0, A.M8)(),
                                url: u,
                                handlingStack: n
                            };
                        r.notify(l), t[0] = l.input, t[1] = l.init, e(t => (function(t, e, n) {
                            function r(e) {
                                n.state = "resolve", Object.assign(n, e), t.notify(n)
                            }
                            e.then((0, b.dm)(t => {
                                r({
                                    response: t,
                                    responseType: t.type,
                                    status: t.status,
                                    isAborted: !1
                                })
                            }), (0, b.dm)(t => {
                                var e, i;
                                r({
                                    status: 0,
                                    isAborted: (null == (i = null == (e = n.init) ? void 0 : e.signal) ? void 0 : i.aborted) || t instanceof DOMException && t.code === DOMException.ABORT_ERR,
                                    error: t
                                })
                            }))
                        })(r, t, l))
                    })(e, t), {
                        computeHandlingStack: !0
                    });
                    return e
                })), r
            }
            var B = n(34353);

            function G(t, e, n = 0, r) {
                let i = new Date;
                i.setTime(i.getTime() + n);
                let a = `expires=${i.toUTCString()}`,
                    o = r && r.crossSite ? "none" : "strict",
                    s = r && r.domain ? `;domain=${r.domain}` : "",
                    u = r && r.secure ? ";secure" : "",
                    l = r && r.partitioned ? ";partitioned" : "";
                document.cookie = `${t}=${e};${a};path=/;samesite=${o}${s}${u}${l}`
            }

            function H(t) {
                return N(document.cookie, t)
            }

            function Z(t) {
                return i || (i = function(t) {
                    let e = new Map;
                    for (P.lastIndex = 0;;) {
                        let n = P.exec(t);
                        if (n) e.set(n[1], n[2]);
                        else break
                    }
                    return e
                }(document.cookie)), i.get(t)
            }

            function W() {
                return !!(window._DATADOG_SYNTHETICS_INJECTS_RUM || Z("datadog-synthetics-injects-rum"))
            }
            var Q = n(19155),
                J = n(31352),
                Y = n(6706),
                K = n(94357),
                X = n(30789);
            let tt = "_dd_s";
            var te = n(63002);
            let tn = 4 * A.MA,
                tr = 15 * A.iW,
                ti = A.$H,
                ta = {
                    COOKIE: "cookie",
                    LOCAL_STORAGE: "local-storage"
                },
                to = /^([a-zA-Z]+)=([a-z0-9-]+)$/;

            function ts(t, e) {
                let n = {
                    isExpired: "1"
                };
                return e.trackAnonymousUser && ((null == t ? void 0 : t.anonymousId) ? n.anonymousId = null == t ? void 0 : t.anonymousId : n.anonymousId = O()), n
            }

            function tu(t) {
                return (0, Y.RI)(t)
            }

            function tl(t) {
                var e;
                return void 0 !== t.isExpired || !((void 0 === (e = t).created || (0, A.x3)() - Number(e.created) < tn) && (void 0 === e.expire || (0, A.x3)() < Number(e.expire)))
            }

            function tc(t) {
                t.expire = String((0, A.x3)() + tr)
            }

            function td(t) {
                return (0, te.WP)(t).map(([t, e]) => "anonymousId" === t ? `aid=${e}` : `${t}=${e}`).join("&")
            }

            function tf(t) {
                let e = {};
                return t && (-1 !== t.indexOf("&") || to.test(t)) && t.split("&").forEach(t => {
                    let n = to.exec(t);
                    if (null !== n) {
                        let [, t, r] = n;
                        "aid" === t ? e.anonymousId = r : e[t] = r
                    }
                }), e
            }

            function tp(t) {
                let e = function(t) {
                    let e = {};
                    return e.secure = !!t.useSecureSessionCookie || !!t.usePartitionedCrossSiteSessionCookie, e.crossSite = !!t.usePartitionedCrossSiteSessionCookie, e.partitioned = !!t.usePartitionedCrossSiteSessionCookie, t.trackSessionAcrossSubdomains && (e.domain = function() {
                        if (void 0 === a) {
                            let t = `dd_site_test_${O()}`,
                                e = window.location.hostname.split("."),
                                n = e.pop();
                            for (; e.length && !H(t);) n = `${e.pop()}.${n}`, G(t, "test", A.OY, {
                                domain: n
                            });
                            G(t, "", 0, {
                                domain: n
                            }), a = n
                        }
                        return a
                    }()), e
                }(t);
                return ! function(t) {
                    if (void 0 === document.cookie || null === document.cookie) return !1;
                    try {
                        let e = `dd_cookie_test_${O()}`,
                            n = "test";
                        G(e, n, A.iW, t);
                        let r = H(e) === n;
                        return G(e, "", 0, t), r
                    } catch (t) {
                        return R.Vy.error(t), !1
                    }
                }(e) ? void 0 : {
                    type: ta.COOKIE,
                    cookieOptions: e
                }
            }

            function th() {
                return tf(H(tt))
            }

            function tm() {
                try {
                    let t = O(),
                        e = `_dd_test_${t}`;
                    localStorage.setItem(e, t);
                    let n = localStorage.getItem(e);
                    return localStorage.removeItem(e), t === n ? {
                        type: ta.LOCAL_STORAGE
                    } : void 0
                } catch (t) {
                    return
                }
            }

            function tg(t) {
                localStorage.setItem(tt, td(t))
            }

            function ty() {
                return tf(localStorage.getItem(tt))
            }
            let tv = [];

            function t_(t, e, n = 0) {
                var r;
                let i, {
                        isLockEnabled: a,
                        persistSession: s,
                        expireSession: u
                    } = e,
                    l = t => s({ ...t,
                        lock: i
                    }),
                    c = () => {
                        let t = e.retrieveSession(),
                            n = t.lock;
                        return t.lock && delete t.lock, {
                            session: t,
                            lock: n
                        }
                    };
                if (o || (o = t), t !== o) return void tv.push(t);
                if (a && n >= 100) return void tw(e);
                let d = c();
                if (a && (d.lock || (i = O(), l(d.session), (d = c()).lock !== i))) return void tb(t, e, n);
                let f = t.process(d.session);
                if (a && (d = c()).lock !== i) return void tb(t, e, n);
                if (f && (tl(f) ? u(f) : (tc(f), a ? l(f) : s(f))), a && !(f && tl(f))) {
                    if ((d = c()).lock !== i) return void tb(t, e, n);
                    s(d.session), f = d.session
                }
                null == (r = t.after) || r.call(t, f || d.session), tw(e)
            }

            function tb(t, e, n) {
                (0, K.wg)(() => {
                    t_(t, e, n + 1)
                }, 10)
            }

            function tw(t) {
                o = void 0;
                let e = tv.shift();
                e && t_(e, t)
            }
            let tS = A.OY;
            var tx = n(16878);

            function tk(t, e, n) {
                let r = function(t, e) {
                    let n = `/api/v2/${e}`,
                        r = t.proxy;
                    if ("string" == typeof r) {
                        let t = (0, z.l2)(r);
                        return e => `${t}?ddforward=${encodeURIComponent(`${n}?${e}`)}`
                    }
                    if ("function" == typeof r) return t => r({
                        path: n,
                        parameters: t
                    });
                    let i = tC(e, t);
                    return t => `https://${i}${n}?${t}`
                }(t, e);
                return {
                    build: (i, a) => r(function({
                        clientToken: t,
                        internalAnalyticsSubdomain: e
                    }, n, r, i, {
                        retry: a,
                        encoding: o
                    }) {
                        let s = ["sdk_version:6.6.3", `api:${i}`].concat(r);
                        a && s.push(`retry_count:${a.count}`, `retry_after:${a.lastFailureStatus}`);
                        let u = ["ddsource=browser", `ddtags=${encodeURIComponent(s.join(","))}`, `dd-api-key=${t}`, `dd-evp-origin-version=${encodeURIComponent("6.6.3")}`, "dd-evp-origin=browser", `dd-request-id=${O()}`];
                        return o && u.push(`dd-evp-encoding=${o}`), "rum" === n && u.push(`batch_time=${(0,A.nx)()}`), e && u.reverse(), u.join("&")
                    }(t, e, n, i, a)),
                    tags: n,
                    urlPrefix: r(""),
                    trackType: e
                }
            }

            function tC(t, e) {
                let {
                    site: n = tx.NW,
                    internalAnalyticsSubdomain: r
                } = e;
                if ("logs" === t && e.usePciIntake && n === tx.NW) return tx.$A;
                if (r && n === tx.NW) return `${r}.${tx.NW}`;
                if (n === tx.TC) return `http-intake.logs.${n}`;
                let i = n.split("."),
                    a = i.pop();
                return `browser-intake-${i.join("-")}.${a}`
            }

            function tA(t, e) {
                var n;
                let r = 200 - t.length - 1;
                (e.length > r || (n = e, function() {
                    try {
                        return RegExp("[\\p{Ll}]", "u"), !0
                    } catch (t) {
                        return !1
                    }
                }() && RegExp("[^\\p{Ll}\\p{Lo}0-9_:./-]", "u").test(n))) && R.Vy.warn(`${t} value doesn't meet tag requirements and will be sanitized. ${R.xG} ${R.fH}/getting_started/tagging/#defining-tags`);
                let i = e.replace(/,/g, "_");
                return `${t}:${i}`
            }
            let tT = {
                    ALLOW: "allow",
                    MASK: "mask",
                    MASK_USER_INPUT: "mask-user-input"
                },
                tE = {
                    ALL: "all",
                    SAMPLED: "sampled"
                };

            function tR(t, e) {
                return null == t || "string" == typeof t || (R.Vy.error(`${e} must be defined as a string`), !1)
            }

            function tI(t, e) {
                return void 0 === t || !!(0, J.fp)(t) || (R.Vy.error(`${e} Sample Rate should be a number between 0 and 100`), !1)
            }
            var tO = n(15843);

            function tP(t) {
                let e = (0, tO.P)(t);
                return "string" === e || "function" === e || t instanceof RegExp
            }

            function tN(t, e, n = !1) {
                return t.some(t => {
                    try {
                        if ("function" == typeof t) return t(e);
                        if (t instanceof RegExp) return t.test(e);
                        if ("string" == typeof t) return n ? e.startsWith(t) : t === e
                    } catch (t) {
                        R.Vy.error(t)
                    }
                    return !1
                })
            }

            function tM(t) {
                let e = crypto.getRandomValues(new Uint32Array(2));
                return 63 === t && (e[e.length - 1] >>>= 1), {
                    toString(t = 10) {
                        let n = e[1],
                            r = e[0],
                            i = "";
                        do {
                            let e = n % t * 0x100000000 + r;
                            n = Math.floor(n / t), r = Math.floor(e / t), i = (e % t).toString(t) + i
                        } while (n || r);
                        return i
                    }
                }
            }

            function tL(t) {
                return t.toString(16).padStart(16, "0")
            }

            function tD(t) {
                0 !== t.status || t.isAborted || (t.traceId = void 0, t.spanId = void 0, t.traceSampled = void 0)
            }

            function t$(t, e, n, r, i) {
                var a, o;
                let u, l = n.findTrackedSession();
                if (!l) return;
                let c = t.allowedTracingUrls.find(t => tN([t.match], e.url, !0));
                if (!c) return;
                let d = (a = l.id, 100 === (o = t.traceSampleRate) || 0 !== o && (s && a === s.sessionId ? s.decision : (u = window.BigInt ? function(t, e) {
                    let n = BigInt("1111111111111111111"),
                        r = BigInt("0x10000000000000000");
                    return Number(t * n % r) <= e / 100 * Number(r)
                }(BigInt(`0x${a.split("-")[4]}`), o) : (0, J.ic)(o), s = {
                    sessionId: a,
                    decision: u
                }, u)));
                (d || t.traceContextInjection === tE.ALL) && (e.traceSampled = d, e.traceId = tM(64), e.spanId = tM(63), i(function(t, e, n, r, i, a) {
                    let o = {};
                    if (r.forEach(r => {
                            switch (r) {
                                case "datadog":
                                    Object.assign(o, {
                                        "x-datadog-origin": "rum",
                                        "x-datadog-parent-id": e.toString(),
                                        "x-datadog-sampling-priority": n ? "1" : "0",
                                        "x-datadog-trace-id": t.toString()
                                    });
                                    break;
                                case "tracecontext":
                                    Object.assign(o, {
                                        traceparent: `00-0000000000000000${tL(t)}-${tL(e)}-0${n?"1":"0"}`,
                                        tracestate: `dd=s:${n?"1":"0"};o:rum`
                                    });
                                    break;
                                case "b3":
                                    Object.assign(o, {
                                        b3: `${tL(t)}-${tL(e)}-${n?"1":"0"}`
                                    });
                                    break;
                                case "b3multi":
                                    Object.assign(o, {
                                        "X-B3-TraceId": tL(t),
                                        "X-B3-SpanId": tL(e),
                                        "X-B3-Sampled": n ? "1" : "0"
                                    })
                            }
                        }), (0, B.sr)(B.R9.USER_ACCOUNT_TRACE_HEADER) && a.propagateTraceBaggage) {
                        let t = i().user.id,
                            e = i().account.id,
                            n = [];
                        "string" == typeof t && n.push(`usr.id=${encodeURIComponent(t)}`), "string" == typeof e && n.push(`account.id=${encodeURIComponent(e)}`), n.length > 0 && (o.baggage = n.join(","))
                    }
                    return o
                }(e.traceId, e.spanId, e.traceSampled, c.propagatorTypes, r, t)))
            }
            let tU = ["tracecontext", "datadog"];
            var tj = n(11696);

            function tq() {
                R.Vy.error("Error fetching the remote configuration.")
            }
            let tV = [];

            function tz(t, e, n, r) {
                var i, a;
                let o = (i = n, a = r, `_dd_c_${i}_${a}`);
                tV.push((0, tj.q)(t, window, "storage", ({
                    key: t
                }) => {
                    o === t && e.setContext(u())
                })), e.changeObservable.subscribe(function() {
                    localStorage.setItem(o, JSON.stringify(e.getContext()))
                });
                let s = (0, x.kg)(u(), e.getContext());

                function u() {
                    let t = localStorage.getItem(o);
                    return t ? JSON.parse(t) : {}
                }(0, Y.RI)(s) || e.setContext(s)
            }

            function tF(t, e, n) {
                let r = { ...t
                };
                for (let [i, {
                        required: a,
                        type: o
                    }] of Object.entries(e)) "string" === o && i in r && (r[i] = String(r[i])), !a || i in t || R.Vy.warn(`The property ${i} of ${n} is required; context will not be sent to the intake.`);
                return r
            }

            function tB(t = "", {
                propertiesConfig: e = {}
            } = {}) {
                let n = {},
                    r = new g.c,
                    i = {
                        getContext: () => (0, x.Go)(n),
                        setContext: a => {
                            ! function(t) {
                                let e = "object" === (0, tO.P)(t);
                                return e || R.Vy.error("Unsupported context:", t), e
                            }(a) ? i.clearContext(): n = (0, C.a)(tF(a, e, t)), r.notify()
                        },
                        setContextProperty: (i, a) => {
                            n = (0, C.a)(tF({ ...n,
                                [i]: a
                            }, e, t)), r.notify()
                        },
                        removeContextProperty: i => {
                            delete n[i], tF(n, e, t), r.notify()
                        },
                        clearContext: () => {
                            n = {}, r.notify()
                        },
                        changeObservable: r
                    };
                return i
            }

            function tG() {
                return tB("global context")
            }

            function tH() {
                return tB("user", {
                    propertiesConfig: {
                        id: {
                            type: "string"
                        },
                        name: {
                            type: "string"
                        },
                        email: {
                            type: "string"
                        }
                    }
                })
            }

            function tZ() {
                return tB("account", {
                    propertiesConfig: {
                        id: {
                            type: "string",
                            required: !0
                        },
                        name: {
                            type: "string"
                        }
                    }
                })
            }

            function tW(t, e, n) {
                t.changeObservable.subscribe(() => {
                    let r = t.getContext();
                    n.add(t => t[e].setContext(r))
                })
            }

            function tQ(t, e, n, r = {}) {
                let i = function(t) {
                        let e = new g.c;
                        return {
                            tryToInit(e) {
                                t || (t = e)
                            },
                            update(n) {
                                t = n, e.notify()
                            },
                            isGranted: () => t === y.GRANTED,
                            observable: e
                        }
                    }(),
                    a = {
                        vitalsByName: new Map,
                        vitalsByReference: new WeakMap
                    },
                    o = function({
                        ignoreInitIfSyntheticsWillInjectRum: t,
                        startDeflateWorker: e
                    }, n, r, i) {
                        let a, o, s, u, l = (0, U.O)(),
                            c = tG();
                        tW(c, T.globalContext, l);
                        let d = tH();
                        tW(d, T.userContext, l);
                        let f = tZ();
                        tW(f, T.accountContext, l);
                        let p = n.observable.subscribe(m),
                            h = {};

                        function m() {
                            let t;
                            if (!s || !u || !n.isGranted()) return;
                            if (p.unsubscribe(), u.trackViewsManually) {
                                if (!a) return;
                                l.remove(a.callback), t = a.options
                            }
                            let e = i(u, o, t);
                            l.drain(e)
                        }

                        function g(t) {
                            var r, i, a;
                            let l = (0, j.d0)();
                            if (l && (t = { ...r = t,
                                    applicationId: "00000000-aaaa-0000-aaaa-000000000000",
                                    clientToken: "empty",
                                    sessionSampleRate: 100,
                                    defaultPrivacyLevel: null != (i = r.defaultPrivacyLevel) ? i : null == (a = (0, j.Y9)()) ? void 0 : a.getPrivacyLevel()
                                }), s = t, (0, w.Rr)(function(t) {
                                    var e;
                                    let n = {
                                        session_sample_rate: t.sessionSampleRate,
                                        telemetry_sample_rate: t.telemetrySampleRate,
                                        telemetry_configuration_sample_rate: t.telemetryConfigurationSampleRate,
                                        telemetry_usage_sample_rate: t.telemetryUsageSampleRate,
                                        use_before_send: !!t.beforeSend,
                                        use_partitioned_cross_site_session_cookie: t.usePartitionedCrossSiteSessionCookie,
                                        use_secure_session_cookie: t.useSecureSessionCookie,
                                        use_proxy: !!t.proxy,
                                        silent_multiple_init: t.silentMultipleInit,
                                        track_session_across_subdomains: t.trackSessionAcrossSubdomains,
                                        track_anonymous_user: t.trackAnonymousUser,
                                        session_persistence: t.sessionPersistence,
                                        allow_fallback_to_local_storage: !!t.allowFallbackToLocalStorage,
                                        store_contexts_across_pages: !!t.storeContextsAcrossPages,
                                        allow_untrusted_events: !!t.allowUntrustedEvents,
                                        tracking_consent: t.trackingConsent
                                    };
                                    return {
                                        session_replay_sample_rate: t.sessionReplaySampleRate,
                                        start_session_replay_recording_manually: t.startSessionReplayRecordingManually,
                                        trace_sample_rate: t.traceSampleRate,
                                        trace_context_injection: t.traceContextInjection,
                                        action_name_attribute: t.actionNameAttribute,
                                        use_allowed_tracing_urls: Array.isArray(t.allowedTracingUrls) && t.allowedTracingUrls.length > 0,
                                        selected_tracing_propagators: function(t) {
                                            let e = new Set;
                                            return Array.isArray(t.allowedTracingUrls) && t.allowedTracingUrls.length > 0 && t.allowedTracingUrls.forEach(t => {
                                                tP(t) ? tU.forEach(t => e.add(t)) : "object" === (0, tO.P)(t) && Array.isArray(t.propagatorTypes) && t.propagatorTypes.forEach(t => e.add(t))
                                            }), Array.from(e)
                                        }(t),
                                        default_privacy_level: t.defaultPrivacyLevel,
                                        enable_privacy_for_action_name: t.enablePrivacyForActionName,
                                        use_excluded_activity_urls: Array.isArray(t.excludedActivityUrls) && t.excludedActivityUrls.length > 0,
                                        use_worker_url: !!t.workerUrl,
                                        compress_intake_requests: t.compressIntakeRequests,
                                        track_views_manually: t.trackViewsManually,
                                        track_user_interactions: t.trackUserInteractions,
                                        track_resources: t.trackResources,
                                        track_long_task: t.trackLongTasks,
                                        plugins: null == (e = t.plugins) ? void 0 : e.map(t => {
                                            var e;
                                            return {
                                                name: t.name,
                                                ...null == (e = t.getConfigurationTelemetry) ? void 0 : e.call(t)
                                            }
                                        }),
                                        track_feature_flags_for_events: t.trackFeatureFlagsForEvents,
                                        ...n
                                    }
                                }(t)), u) return void I("DD_RUM", t);
                            let c = function(t) {
                                var e, n, r, i, a, o, s, u, l, c, d, f, p, h, m;
                                if (void 0 === t.trackFeatureFlagsForEvents || Array.isArray(t.trackFeatureFlagsForEvents) || R.Vy.warn("trackFeatureFlagsForEvents should be an array"), !t.applicationId) return void R.Vy.error("Application ID is not configured, no RUM data will be collected.");
                                if (!tI(t.sessionReplaySampleRate, "Session Replay") || !tI(t.traceSampleRate, "Trace")) return;
                                if (void 0 !== t.excludedActivityUrls && !Array.isArray(t.excludedActivityUrls)) return void R.Vy.error("Excluded Activity Urls should be an array");
                                let g = function(t) {
                                    if (void 0 === t.allowedTracingUrls) return [];
                                    if (!Array.isArray(t.allowedTracingUrls)) return void R.Vy.error("Allowed Tracing URLs should be an array");
                                    if (0 !== t.allowedTracingUrls.length && void 0 === t.service) return void R.Vy.error("Service needs to be configured when tracing is enabled");
                                    let e = [];
                                    return t.allowedTracingUrls.forEach(t => {
                                        if (tP(t)) e.push({
                                            match: t,
                                            propagatorTypes: tU
                                        });
                                        else "object" === (0, tO.P)(t) && tP(t.match) && Array.isArray(t.propagatorTypes) ? e.push(t) : R.Vy.warn("Allowed Tracing Urls parameters should be a string, RegExp, function, or an object. Ignoring parameter", t)
                                    }), e
                                }(t);
                                if (!g) return;
                                let _ = (u = t) && u.clientToken ? (!(m = u.site) || "string" != typeof m || /(datadog|ddog|datad0g|dd0g)/.test(m) || (R.Vy.error(`Site should be a valid Datadog site. ${R.xG} ${R.fH}/getting_started/site/.`), 0)) && tI(u.sessionSampleRate, "Session") && tI(u.telemetrySampleRate, "Telemetry") && tI(u.telemetryConfigurationSampleRate, "Telemetry Configuration") && tI(u.telemetryUsageSampleRate, "Telemetry Usage") && tR(u.version, "Version") && tR(u.env, "Env") && tR(u.service, "Service") ? void 0 === u.trackingConsent || (0, Y.Rj)(y, u.trackingConsent) ? {
                                    beforeSend: u.beforeSend && (0, Q.y)(u.beforeSend, "beforeSend threw an error:"),
                                    sessionStoreStrategyType: function(t) {
                                        switch (t.sessionPersistence) {
                                            case ta.COOKIE:
                                                return tp(t);
                                            case ta.LOCAL_STORAGE:
                                                return tm();
                                            case void 0:
                                                {
                                                    let e = tp(t);
                                                    return !e && t.allowFallbackToLocalStorage && (e = tm()),
                                                    e
                                                }
                                            default:
                                                R.Vy.error(`Invalid session persistence '${String(t.sessionPersistence)}'`)
                                        }
                                    }(u),
                                    sessionSampleRate: null != (l = u.sessionSampleRate) ? l : 100,
                                    telemetrySampleRate: null != (c = u.telemetrySampleRate) ? c : 20,
                                    telemetryConfigurationSampleRate: null != (d = u.telemetryConfigurationSampleRate) ? d : 5,
                                    telemetryUsageSampleRate: null != (f = u.telemetryUsageSampleRate) ? f : 5,
                                    service: u.service || void 0,
                                    silentMultipleInit: !!u.silentMultipleInit,
                                    allowUntrustedEvents: !!u.allowUntrustedEvents,
                                    trackingConsent: null != (p = u.trackingConsent) ? p : y.GRANTED,
                                    trackAnonymousUser: null == (h = u.trackAnonymousUser) || h,
                                    storeContextsAcrossPages: !!u.storeContextsAcrossPages,
                                    batchBytesLimit: 16 * v._m,
                                    eventRateLimiterThreshold: 3e3,
                                    maxTelemetryEventsPerPage: 15,
                                    flushTimeout: 30 * A.OY,
                                    batchMessagesLimit: 50,
                                    messageBytesLimit: 256 * v._m,
                                    ... function(t) {
                                        var e, n;
                                        let r = t.site || tx.NW,
                                            i = function(t) {
                                                let {
                                                    env: e,
                                                    service: n,
                                                    version: r,
                                                    datacenter: i
                                                } = t, a = [];
                                                return e && a.push(tA("env", e)), n && a.push(tA("service", n)), r && a.push(tA("version", r)), i && a.push(tA("datacenter", i)), a
                                            }(t),
                                            a = {
                                                logsEndpointBuilder: tk(e = t, "logs", n = i),
                                                rumEndpointBuilder: tk(e, "rum", n),
                                                profilingEndpointBuilder: tk(e, "profile", n),
                                                sessionReplayEndpointBuilder: tk(e, "replay", n)
                                            };
                                        return {
                                            replica: function(t, e) {
                                                if (!t.replica) return;
                                                let n = { ...t,
                                                        site: tx.NW,
                                                        clientToken: t.replica.clientToken
                                                    },
                                                    r = {
                                                        logsEndpointBuilder: tk(n, "logs", e),
                                                        rumEndpointBuilder: tk(n, "rum", e)
                                                    };
                                                return {
                                                    applicationId: t.replica.applicationId,
                                                    ...r
                                                }
                                            }(t, i),
                                            site: r,
                                            ...a
                                        }
                                    }(u)
                                } : void R.Vy.error('Tracking Consent should be either "granted" or "not-granted"') : void 0 : void R.Vy.error("Client Token is not configured, we will not send any data.");
                                if (!_) return;
                                let b = (0, B.sr)(B.R9.PROFILING),
                                    w = null != (e = t.sessionReplaySampleRate) ? e : 0;
                                return {
                                    applicationId: t.applicationId,
                                    version: t.version || void 0,
                                    actionNameAttribute: t.actionNameAttribute,
                                    sessionReplaySampleRate: w,
                                    startSessionReplayRecordingManually: void 0 !== t.startSessionReplayRecordingManually ? !!t.startSessionReplayRecordingManually : 0 === w,
                                    traceSampleRate: null != (n = t.traceSampleRate) ? n : 100,
                                    rulePsr: (0, J.Et)(t.traceSampleRate) ? t.traceSampleRate / 100 : void 0,
                                    allowedTracingUrls: g,
                                    excludedActivityUrls: null != (r = t.excludedActivityUrls) ? r : [],
                                    workerUrl: t.workerUrl,
                                    compressIntakeRequests: !!t.compressIntakeRequests,
                                    trackUserInteractions: !!(null == (i = t.trackUserInteractions) || i),
                                    trackViewsManually: !!t.trackViewsManually,
                                    trackResources: !!(null == (a = t.trackResources) || a),
                                    trackLongTasks: !!(null == (o = t.trackLongTasks) || o),
                                    subdomain: t.subdomain,
                                    defaultPrivacyLevel: (0, Y.Rj)(tT, t.defaultPrivacyLevel) ? t.defaultPrivacyLevel : tT.MASK,
                                    enablePrivacyForActionName: !!t.enablePrivacyForActionName,
                                    customerDataTelemetrySampleRate: 1,
                                    traceContextInjection: (0, Y.Rj)(tE, t.traceContextInjection) ? t.traceContextInjection : tE.SAMPLED,
                                    plugins: t.plugins || [],
                                    trackFeatureFlagsForEvents: t.trackFeatureFlagsForEvents || [],
                                    profilingSampleRate: b && null != (s = t.profilingSampleRate) ? s : 0,
                                    propagateTraceBaggage: !!t.propagateTraceBaggage,
                                    ..._
                                }
                            }(t);
                            if (c) {
                                if (!l && !c.sessionStoreStrategyType) return void R.Vy.warn("No storage available for session. We will not send any data.");
                                if (c.compressIntakeRequests && !l && e && !(o = e(c, "Datadog RUM", q.l))) return;
                                u = c, F().subscribe(q.l), n.tryToInit(c.trackingConsent), m()
                            }
                        }
                        let _ = t => {
                            l.add(e => e.addDurationVital(t))
                        };
                        return {
                            init(e, n) {
                                if (!e) return void R.Vy.error("Missing configuration");
                                if ((0, B.Aq)(e.enableExperimentalFeatures), s = e, !(t && W()))
                                    if ($(e.plugins, "onInit", {
                                            initConfiguration: e,
                                            publicApi: n
                                        }), e.remoteConfigurationId) {
                                        var r, i = e,
                                            a = t => {
                                                var n, r;
                                                g((n = e, r = t, { ...n,
                                                    ...r
                                                }))
                                            };
                                        let t = new XMLHttpRequest;
                                        (0, tj.q)(i, t, "load", function() {
                                            200 === t.status ? a(JSON.parse(t.responseText).rum) : tq()
                                        }), (0, tj.q)(i, t, "error", function() {
                                            tq()
                                        }), t.open("GET", (r = i, `https://sdk-configuration.${tC("rum",r)}/v1/${encodeURIComponent(r.remoteConfigurationId)}.json`)), t.send()
                                    } else g(e)
                            },
                            get initConfiguration() {
                                return s
                            },
                            getInternalContext: q.l,
                            stopSession: q.l,
                            addTiming(t, e = (0, A.nx)()) {
                                l.add(n => n.addTiming(t, e))
                            },
                            startView(t, e = (0, A.M8)()) {
                                let n = n => {
                                    n.startView(t, e)
                                };
                                l.add(n), a || (a = {
                                    options: t,
                                    callback: n
                                }, m())
                            },
                            setViewName(t) {
                                l.add(e => e.setViewName(t))
                            },
                            setViewContext(t) {
                                l.add(e => e.setViewContext(t))
                            },
                            setViewContextProperty(t, e) {
                                l.add(n => n.setViewContextProperty(t, e))
                            },
                            getViewContext: () => h,
                            globalContext: c,
                            userContext: d,
                            accountContext: f,
                            addAction(t) {
                                l.add(e => e.addAction(t))
                            },
                            addError(t) {
                                l.add(e => e.addError(t))
                            },
                            addFeatureFlagEvaluation(t, e) {
                                l.add(n => n.addFeatureFlagEvaluation(t, e))
                            },
                            startDurationVital: (t, e) => L(r, t, e),
                            stopDurationVital(t, e) {
                                D(_, r, t, e)
                            },
                            addDurationVital: _
                        }
                    }(r, i, a, (s, u, l) => {
                        var c, d;
                        let f = t(s, e, n, l, u && r.createDeflateEncoder ? t => r.createDeflateEncoder(s, u, t) : _, i, a);
                        return e.onRumStart(f.lifeCycle, s, f.session, f.viewHistory, u), n.onRumStart(f.lifeCycle, s, f.session, f.viewHistory), c = o, d = f, o = {
                            init: t => {
                                I("DD_RUM", t)
                            },
                            initConfiguration: c.initConfiguration,
                            ...d
                        }, $(s.plugins, "onRumStart", {
                            strategy: o
                        }), f
                    }),
                    s = (0, b.dm)(t => {
                        o.startView("object" == typeof t ? t : {
                            name: t
                        }), (0, w.Q6)({
                            feature: "start-view"
                        })
                    });

                function u(t, e, n) {
                    return (0, b.dm)((...r) => ((0, w.Q6)({
                        feature: n
                    }), o[t][e](...r)))
                }
                let l = (0, S.m)({
                    init: (0, b.dm)(t => {
                        o.init(t, l)
                    }),
                    setTrackingConsent: (0, b.dm)(t => {
                        i.update(t), (0, w.Q6)({
                            feature: "set-tracking-consent",
                            tracking_consent: t
                        })
                    }),
                    setViewName: (0, b.dm)(t => {
                        o.setViewName(t), (0, w.Q6)({
                            feature: "set-view-name"
                        })
                    }),
                    setViewContext: (0, b.dm)(t => {
                        o.setViewContext(t), (0, w.Q6)({
                            feature: "set-view-context"
                        })
                    }),
                    setViewContextProperty: (0, b.dm)((t, e) => {
                        o.setViewContextProperty(t, e), (0, w.Q6)({
                            feature: "set-view-context-property"
                        })
                    }),
                    getViewContext: (0, b.dm)(() => ((0, w.Q6)({
                        feature: "set-view-context-property"
                    }), o.getViewContext())),
                    getInternalContext: (0, b.dm)(t => o.getInternalContext(t)),
                    getInitConfiguration: (0, b.dm)(() => (0, x.Go)(o.initConfiguration)),
                    addAction: (t, e) => {
                        let n = (0, k.uC)("action");
                        (0, b.um)(() => {
                            o.addAction({
                                name: (0, C.a)(t),
                                context: (0, C.a)(e),
                                startClocks: (0, A.M8)(),
                                type: "custom",
                                handlingStack: n
                            }), (0, w.Q6)({
                                feature: "add-action"
                            })
                        })
                    },
                    addError: (t, e) => {
                        let n = (0, k.uC)("error");
                        (0, b.um)(() => {
                            o.addError({
                                error: t,
                                handlingStack: n,
                                context: (0, C.a)(e),
                                startClocks: (0, A.M8)()
                            }), (0, w.Q6)({
                                feature: "add-error"
                            })
                        })
                    },
                    addTiming: (0, b.dm)((t, e) => {
                        o.addTiming((0, C.a)(t), e)
                    }),
                    setGlobalContext: u(T.globalContext, E.setContext, "set-global-context"),
                    getGlobalContext: u(T.globalContext, E.getContext, "get-global-context"),
                    setGlobalContextProperty: u(T.globalContext, E.setContextProperty, "set-global-context-property"),
                    removeGlobalContextProperty: u(T.globalContext, E.removeContextProperty, "remove-global-context-property"),
                    clearGlobalContext: u(T.globalContext, E.clearContext, "clear-global-context"),
                    setUser: u(T.userContext, E.setContext, "set-user"),
                    getUser: u(T.userContext, E.getContext, "get-user"),
                    setUserProperty: u(T.userContext, E.setContextProperty, "set-user-property"),
                    removeUserProperty: u(T.userContext, E.removeContextProperty, "remove-user-property"),
                    clearUser: u(T.userContext, E.clearContext, "clear-user"),
                    setAccount: u(T.accountContext, E.setContext, "set-account"),
                    getAccount: u(T.accountContext, E.getContext, "get-account"),
                    setAccountProperty: u(T.accountContext, E.setContextProperty, "set-account-property"),
                    removeAccountProperty: u(T.accountContext, E.removeContextProperty, "remove-account-property"),
                    clearAccount: u(T.accountContext, E.clearContext, "clear-account"),
                    startView: s,
                    stopSession: (0, b.dm)(() => {
                        o.stopSession(), (0, w.Q6)({
                            feature: "stop-session"
                        })
                    }),
                    addFeatureFlagEvaluation: (0, b.dm)((t, e) => {
                        o.addFeatureFlagEvaluation((0, C.a)(t), (0, C.a)(e)), (0, w.Q6)({
                            feature: "add-feature-flag-evaluation"
                        })
                    }),
                    getSessionReplayLink: (0, b.dm)(() => e.getSessionReplayLink()),
                    startSessionReplayRecording: (0, b.dm)(t => {
                        e.start(t), (0, w.Q6)({
                            feature: "start-session-replay-recording",
                            force: t && t.force
                        })
                    }),
                    stopSessionReplayRecording: (0, b.dm)(() => e.stop()),
                    addDurationVital: (0, b.dm)((t, e) => {
                        (0, w.Q6)({
                            feature: "add-duration-vital"
                        }), o.addDurationVital({
                            name: (0, C.a)(t),
                            type: "duration",
                            startClocks: (0, A.jR)(e.startTime),
                            duration: e.duration,
                            context: (0, C.a)(e && e.context),
                            description: (0, C.a)(e && e.description)
                        })
                    }),
                    startDurationVital: (0, b.dm)((t, e) => ((0, w.Q6)({
                        feature: "start-duration-vital"
                    }), o.startDurationVital((0, C.a)(t), {
                        context: (0, C.a)(e && e.context),
                        description: (0, C.a)(e && e.description)
                    }))),
                    stopDurationVital: (0, b.dm)((t, e) => {
                        (0, w.Q6)({
                            feature: "stop-duration-vital"
                        }), o.stopDurationVital("string" == typeof t ? (0, C.a)(t) : t, {
                            context: (0, C.a)(e && e.context),
                            description: (0, C.a)(e && e.description)
                        })
                    })
                });
                return l
            }
            var tJ = n(47884),
                tY = n(81154),
                tK = n(14531);

            function tX() {
                let t, e = window;
                if (e.Zone && (t = (0, tK.W)(e, "MutationObserver"), e.MutationObserver && t === e.MutationObserver)) {
                    let n = new e.MutationObserver(q.l),
                        r = (0, tK.W)(n, "originalInstance");
                    t = r && r.constructor
                }
                return t || (t = e.MutationObserver), t
            }
            class t0 {
                constructor() {
                    this.callbacks = {}
                }
                notify(t, e) {
                    let n = this.callbacks[t];
                    n && n.forEach(t => t(e))
                }
                subscribe(t, e) {
                    return this.callbacks[t] || (this.callbacks[t] = []), this.callbacks[t].push(e), {
                        unsubscribe: () => {
                            this.callbacks[t] = this.callbacks[t].filter(t => e !== t)
                        }
                    }
                }
            }
            var t1 = n(61540);
            let t2 = 1 / 0,
                t5 = A.iW,
                t3 = null,
                t6 = new Set;

            function t4({
                expireDelay: t,
                maxEntries: e
            }) {
                let n = [],
                    r = [];
                t3 || (t3 = (0, K.yb)(() => void t6.forEach(t => t()), t5));
                let i = () => {
                    let e = (0, A.$S)() - t;
                    for (; n.length > 0 && n[n.length - 1].endTime < e;) {
                        let t = n.pop();
                        t && r.push(t.startTime)
                    }
                };
                return t6.add(i), {
                    add: function(t, r) {
                        let i = {
                            value: t,
                            startTime: r,
                            endTime: t2,
                            remove: () => {
                                (0, t1.A)(n, i)
                            },
                            close: t => {
                                i.endTime = t
                            }
                        };
                        return e && n.length >= e && n.pop(), n.unshift(i), i
                    },
                    find: function(t = t2, e = {
                        returnInactive: !1
                    }) {
                        for (let r of n)
                            if (r.startTime <= t) {
                                if (e.returnInactive || t <= r.endTime) return r.value;
                                break
                            }
                    },
                    closeActive: function(t) {
                        let e = n[0];
                        e && e.endTime === t2 && e.close(t)
                    },
                    findAll: function(t = t2, e = 0) {
                        let r = (0, A.Gw)(t, e);
                        return n.filter(e => e.startTime <= r && t <= e.endTime).map(t => t.value)
                    },
                    reset: function() {
                        n = []
                    },
                    stop: function() {
                        t6.delete(i), 0 === t6.size && t3 && ((0, K.vG)(t3), t3 = null)
                    },
                    getAllEntries: function() {
                        return n.map(({
                            startTime: t,
                            endTime: e,
                            value: n
                        }) => ({
                            startTime: t,
                            endTime: e === t2 ? "Infinity" : e,
                            value: n
                        }))
                    },
                    getDeletedEntries: function() {
                        return r
                    }
                }
            }
            let t8 = new WeakMap;

            function t9({
                target: t,
                parameters: [e, n]
            }) {
                t8.set(t, {
                    state: "open",
                    method: String(e).toUpperCase(),
                    url: (0, z.l2)(String(n))
                })
            }

            function t7({
                target: t
            }) {
                let e = t8.get(t);
                e && (e.isAborted = !0)
            }
            var et = n(3938);
            let ee = "initial_document",
                en = [
                    ["document", t => ee === t],
                    ["xhr", t => "xmlhttprequest" === t],
                    ["fetch", t => "fetch" === t],
                    ["beacon", t => "beacon" === t],
                    ["css", (t, e) => /\.css$/i.test(e)],
                    ["js", (t, e) => /\.js$/i.test(e)],
                    ["image", (t, e) => ["image", "img", "icon"].includes(t) || null !== /\.(gif|jpg|jpeg|tiff|png|svg|ico)$/i.exec(e)],
                    ["font", (t, e) => null !== /\.(woff|eot|woff2|ttf)$/i.exec(e)],
                    ["media", (t, e) => ["audio", "video"].includes(t) || null !== /\.(mp3|mp4)$/i.exec(e)]
                ];

            function er(...t) {
                for (let e = 1; e < t.length; e += 1)
                    if (t[e - 1] > t[e]) return !1;
                return !0
            }

            function ei(t) {
                let {
                    duration: e,
                    startTime: n,
                    responseEnd: r
                } = t;
                return 0 === e && n < r ? (0, A.vk)(n, r) : e
            }

            function ea(t) {
                return t.duration >= 0
            }

            function eo(t) {
                var e;
                let n = er(t.startTime, t.fetchStart, t.domainLookupStart, t.domainLookupEnd, t.connectStart, t.connectEnd, t.requestStart, t.responseStart, t.responseEnd),
                    r = !((e = t).redirectEnd > e.startTime) || er(t.startTime, t.redirectStart, t.redirectEnd, t.fetchStart);
                return n && r
            }

            function es(t, e, n) {
                if (t <= e && e <= n) return {
                    duration: (0, A.Zj)((0, A.vk)(e, n)),
                    start: (0, A.Zj)((0, A.vk)(t, e))
                }
            }

            function eu(t) {
                return "" === t.nextHopProtocol ? void 0 : t.nextHopProtocol
            }

            function el(t) {
                return "" === t.deliveryType ? "other" : t.deliveryType
            }

            function ec(t) {
                return t && !tx.Ih.every(e => t.includes(e))
            }
            let ed = /data:(.+)?(;base64)?,/g;

            function ef(t) {
                if (t.length <= 24e3);
                else if ("data:" === t.substring(0, 5)) return t = t.substring(0, 24e3), !0;
                return !1
            }

            function ep(t) {
                return `${t.match(ed)[0]}[...]`
            }
            let eh = 1;

            function em() {
                let t = eh;
                return eh += 1, t
            }

            function eg(t) {
                return (0, J.Et)(t) && t < 0 ? void 0 : t
            }

            function ey({
                lifeCycle: t,
                isChildEvent: e,
                onChange: n = q.l
            }) {
                let r = {
                        errorCount: 0,
                        longTaskCount: 0,
                        resourceCount: 0,
                        actionCount: 0,
                        frustrationCount: 0
                    },
                    i = t.subscribe(13, t => {
                        var i;
                        if ("view" !== t.type && "vital" !== t.type && e(t)) switch (t.type) {
                            case "error":
                                r.errorCount += 1, n();
                                break;
                            case "action":
                                r.actionCount += 1, t.action.frustration && (r.frustrationCount += t.action.frustration.type.length), n();
                                break;
                            case "long_task":
                                r.longTaskCount += 1, n();
                                break;
                            case "resource":
                                (null == (i = t._dd) ? void 0 : i.discarded) || (r.resourceCount += 1, n())
                        }
                    });
                return {
                    stop: () => {
                        i.unsubscribe()
                    },
                    eventCounts: r
                }
            }

            function ev(t, e) {
                return new g.c(n => {
                    var r;
                    let i, a;
                    if (!window.PerformanceObserver) return;
                    let o = t => {
                            let e = t.filter(t => {
                                var e;
                                return !((e = t).entryType === m.RESOURCE && (!ec(e.name) || !ea(e)))
                            });
                            e.length > 0 && n.notify(e)
                        },
                        s = !0,
                        u = new PerformanceObserver((0, b.dm)(t => {
                            s ? i = (0, K.wg)(() => o(t.getEntries())) : o(t.getEntries())
                        }));
                    try {
                        u.observe(e)
                    } catch (t) {
                        if ([m.RESOURCE, m.NAVIGATION, m.LONG_TASK, m.PAINT].includes(e.type)) {
                            e.buffered && (i = (0, K.wg)(() => o(performance.getEntriesByType(e.type))));
                            try {
                                u.observe({
                                    entryTypes: [e.type]
                                })
                            } catch (t) {
                                return
                            }
                        }
                    }
                    return s = !1, r = t, !l && void 0 !== window.performance && "getEntries" in performance && "addEventListener" in performance && (l = (0, tj.q)(r, performance, "resourcetimingbufferfull", () => {
                        performance.clearResourceTimings()
                    })), e_(m.FIRST_INPUT) || e.type !== m.FIRST_INPUT || ({
                        stop: a
                    } = function(t, e) {
                        let n = (0, A.x3)(),
                            r = !1,
                            {
                                stop: i
                            } = (0, tj.l)(t, window, ["click", "mousedown", "keydown", "touchstart", "pointerdown"], e => {
                                var n, r;
                                if (!e.cancelable) return;
                                let i = {
                                    entryType: "first-input",
                                    processingStart: (0, A.$S)(),
                                    processingEnd: (0, A.$S)(),
                                    startTime: e.timeStamp,
                                    duration: 0,
                                    name: "",
                                    cancelable: !1,
                                    target: null,
                                    toJSON: () => ({})
                                };
                                "pointerdown" === e.type ? (n = t, r = i, (0, tj.l)(n, window, ["pointerup", "pointercancel"], t => {
                                    "pointerup" === t.type && a(r)
                                }, {
                                    once: !0
                                })) : a(i)
                            }, {
                                passive: !0,
                                capture: !0
                            });
                        return {
                            stop: i
                        };

                        function a(t) {
                            if (!r) {
                                r = !0, i();
                                let a = t.processingStart - t.startTime;
                                a >= 0 && a < (0, A.x3)() - n && e(t)
                            }
                        }
                    }(t, t => {
                        o([t])
                    })), () => {
                        u.disconnect(), a && a(), (0, K.DJ)(i)
                    }
                })
            }

            function e_(t) {
                return window.PerformanceObserver && void 0 !== PerformanceObserver.supportedEntryTypes && PerformanceObserver.supportedEntryTypes.includes(t)
            }! function(t) {
                t.EVENT = "event", t.FIRST_INPUT = "first-input", t.LARGEST_CONTENTFUL_PAINT = "largest-contentful-paint", t.LAYOUT_SHIFT = "layout-shift", t.LONG_TASK = "longtask", t.LONG_ANIMATION_FRAME = "long-animation-frame", t.NAVIGATION = "navigation", t.PAINT = "paint", t.RESOURCE = "resource", t.VISIBILITY_STATE = "visibility-state"
            }(m || (m = {}));

            function eb(t, e, n) {
                let r, i = !1,
                    a = (0, K.wg)((0, b.dm)(() => l({
                        hadActivity: !1
                    })), 100),
                    o = void 0 !== n ? (0, K.wg)((0, b.dm)(() => l({
                        hadActivity: !0,
                        end: (0, A.nx)()
                    })), n) : void 0,
                    s = t.subscribe(({
                        isBusy: t
                    }) => {
                        (0, K.DJ)(a), (0, K.DJ)(r);
                        let e = (0, A.nx)();
                        t || (r = (0, K.wg)((0, b.dm)(() => l({
                            hadActivity: !0,
                            end: e
                        })), 100))
                    }),
                    u = () => {
                        i = !0, (0, K.DJ)(a), (0, K.DJ)(r), (0, K.DJ)(o), s.unsubscribe()
                    };

                function l(t) {
                    i || (u(), e(t))
                }
                return {
                    stop: u
                }
            }

            function ew(t, e, n, r) {
                return new g.c(i => {
                    let a, o = [],
                        s = 0;
                    return o.push(e.subscribe(u), n.subscribe(u), ev(r, {
                        type: m.RESOURCE
                    }).subscribe(t => {
                        t.some(t => !eS(r, t.name)) && u()
                    }), t.subscribe(7, t => {
                        eS(r, t.url) || (void 0 === a && (a = t.requestIndex), s += 1, u())
                    }), t.subscribe(8, t => {
                        eS(r, t.url) || void 0 === a || t.requestIndex < a || (s -= 1, u())
                    })), () => {
                        o.forEach(t => t.unsubscribe())
                    };

                    function u() {
                        i.notify({
                            isBusy: s > 0
                        })
                    }
                })
            }

            function eS(t, e) {
                return tN(t.excludedActivityUrls, e)
            }

            function ex(t) {
                return t.nodeType === Node.TEXT_NODE
            }

            function ek(t) {
                return t.nodeType === Node.ELEMENT_NODE
            }

            function eC(t) {
                return ek(t) && !!t.shadowRoot
            }

            function eA(t) {
                return !!t.host && t.nodeType === Node.DOCUMENT_FRAGMENT_NODE && ek(t.host)
            }

            function eT(t) {
                return t.childNodes.length > 0 || eC(t)
            }

            function eE(t, e) {
                let n = t.firstChild;
                for (; n;) e(n), n = n.nextSibling;
                eC(t) && e(t.shadowRoot)
            }

            function eR(t) {
                return eA(t) ? t.host : t.parentNode
            }
            let eI = {
                    IGNORE: "ignore",
                    HIDDEN: "hidden",
                    ALLOW: tT.ALLOW,
                    MASK: tT.MASK,
                    MASK_USER_INPUT: tT.MASK_USER_INPUT
                },
                eO = "data-dd-privacy",
                eP = "hidden",
                eN = "***",
                eM = "data:image/gif;base64,R0lGODlhAQABAIAAAMLCwgAAACH5BAAAAAAALAAAAAABAAEAAAICRAEAOw==",
                eL = {
                    INPUT: !0,
                    OUTPUT: !0,
                    TEXTAREA: !0,
                    SELECT: !0,
                    OPTION: !0,
                    DATALIST: !0,
                    OPTGROUP: !0
                };

            function eD(t, e, n) {
                if (n && n.has(t)) return n.get(t);
                let r = eR(t),
                    i = r ? eD(r, e, n) : e,
                    a = e$(eU(t), i);
                return n && n.set(t, a), a
            }

            function e$(t, e) {
                switch (e) {
                    case eI.HIDDEN:
                    case eI.IGNORE:
                        return e
                }
                switch (t) {
                    case eI.ALLOW:
                    case eI.MASK:
                    case eI.MASK_USER_INPUT:
                    case eI.HIDDEN:
                    case eI.IGNORE:
                        return t;
                    default:
                        return e
                }
            }

            function eU(t) {
                if (ek(t)) {
                    if ("BASE" === t.tagName) return eI.ALLOW;
                    if ("INPUT" === t.tagName) {
                        if ("password" === t.type || "email" === t.type || "tel" === t.type || "hidden" === t.type) return eI.MASK;
                        let e = t.getAttribute("autocomplete");
                        if (e && (e.startsWith("cc-") || e.endsWith("-password"))) return eI.MASK
                    }
                    if (t.matches(eF(eI.HIDDEN))) return eI.HIDDEN;
                    if (t.matches(eF(eI.MASK))) return eI.MASK;
                    if (t.matches(eF(eI.MASK_USER_INPUT))) return eI.MASK_USER_INPUT;
                    if (t.matches(eF(eI.ALLOW))) return eI.ALLOW;
                    if (function(t) {
                            if ("SCRIPT" === t.nodeName) return !0;
                            if ("LINK" === t.nodeName) {
                                let t = e("rel");
                                return /preload|prefetch/i.test(t) && "script" === e("as") || "shortcut icon" === t || "icon" === t
                            }
                            if ("META" === t.nodeName) {
                                let n = e("name"),
                                    r = e("rel"),
                                    i = e("property");
                                return /^msapplication-tile(image|color)$/.test(n) || "application-name" === n || "icon" === r || "apple-touch-icon" === r || "shortcut icon" === r || "keywords" === n || "description" === n || /^(og|twitter|fb):/.test(i) || /^(og|twitter):/.test(n) || "pinterest" === n || "robots" === n || "googlebot" === n || "bingbot" === n || t.hasAttribute("http-equiv") || "author" === n || "generator" === n || "framework" === n || "publisher" === n || "progid" === n || /^article:/.test(i) || /^product:/.test(i) || "google-site-verification" === n || "yandex-verification" === n || "csrf-token" === n || "p:domain_verify" === n || "verify-v1" === n || "verification" === n || "shopify-checkout-api-token" === n
                            }

                            function e(e) {
                                return (t.getAttribute(e) || "").toLowerCase()
                            }
                            return !1
                        }(t)) return eI.IGNORE
                }
            }

            function ej(t, e) {
                switch (e) {
                    case eI.MASK:
                    case eI.HIDDEN:
                    case eI.IGNORE:
                        return !0;
                    case eI.MASK_USER_INPUT:
                        return ex(t) ? eq(t.parentNode) : eq(t);
                    default:
                        return !1
                }
            }

            function eq(t) {
                if (!t || t.nodeType !== t.ELEMENT_NODE) return !1;
                if ("INPUT" === t.tagName) switch (t.type) {
                    case "button":
                    case "color":
                    case "reset":
                    case "submit":
                        return !1
                }
                return !!eL[t.tagName]
            }
            let eV = t => t.replace(/\S/g, "x");

            function ez(t, e, n) {
                var r;
                let i = null == (r = t.parentElement) ? void 0 : r.tagName,
                    a = t.textContent || "";
                if (!e || a.trim()) {
                    if ("SCRIPT" === i) a = eN;
                    else if (n === eI.HIDDEN) a = eN;
                    else if (ej(t, n))
                        if ("DATALIST" === i || "SELECT" === i || "OPTGROUP" === i) {
                            if (!a.trim()) return
                        } else a = "OPTION" === i ? eN : eV(a);
                    return a
                }
            }

            function eF(t) {
                return `[${eO}="${t}"], .dd-privacy-${t}`
            }
            let eB = "data-dd-action-name";

            function eG(t, e) {
                let n = t.closest(`[${e}]`);
                if (n) return eJ(eQ(n.getAttribute(e).trim()))
            }
            let eH = [(t, e) => {
                    if ("labels" in t && t.labels && t.labels.length > 0) return eK(t.labels[0], e)
                }, t => {
                    if ("INPUT" === t.nodeName) {
                        let e = t.getAttribute("type");
                        if ("button" === e || "submit" === e || "reset" === e) return {
                            name: t.value,
                            nameSource: "text_content"
                        }
                    }
                }, (t, e, n) => {
                    if ("BUTTON" === t.nodeName || "LABEL" === t.nodeName || "button" === t.getAttribute("role")) return eK(t, e, n)
                }, t => eY(t, "aria-label"), (t, e, n) => {
                    let r = t.getAttribute("aria-labelledby");
                    if (r) return {
                        name: r.split(/\s+/).map(e => (function(t, e) {
                            return t.ownerDocument ? t.ownerDocument.getElementById(e) : null
                        })(t, e)).filter(t => !!t).map(t => eX(t, e, n)).join(" "),
                        nameSource: "text_content"
                    }
                }, t => eY(t, "alt"), t => eY(t, "name"), t => eY(t, "title"), t => eY(t, "placeholder"), (t, e) => {
                    if ("options" in t && t.options.length > 0) return eK(t.options[0], e)
                }],
                eZ = [(t, e, n) => eK(t, e, n)];

            function eW(t, e, n, r) {
                let i = t,
                    a = 0;
                for (; a <= 10 && i && "BODY" !== i.nodeName && "HTML" !== i.nodeName && "HEAD" !== i.nodeName;) {
                    for (let t of n) {
                        let n = t(i, e, r);
                        if (n) {
                            let {
                                name: t,
                                nameSource: e
                            } = n, r = t && t.trim();
                            if (r) return {
                                name: eJ(eQ(r)),
                                nameSource: e
                            }
                        }
                    }
                    if ("FORM" === i.nodeName) break;
                    i = i.parentElement, a += 1
                }
            }

            function eQ(t) {
                return t.replace(/\s+/g, " ")
            }

            function eJ(t) {
                return t.length > 100 ? `${M(t,100)} [...]` : t
            }

            function eY(t, e) {
                return {
                    name: t.getAttribute(e) || "",
                    nameSource: "standard_attribute"
                }
            }

            function eK(t, e, n) {
                return {
                    name: eX(t, e, n) || "",
                    nameSource: "text_content"
                }
            }

            function eX(t, e, n) {
                if (!t.isContentEditable) {
                    if ("innerText" in t) {
                        let r = t.innerText,
                            i = e => {
                                let n = t.querySelectorAll(e);
                                for (let t = 0; t < n.length; t += 1) {
                                    let e = n[t];
                                    if ("innerText" in e) {
                                        let t = e.innerText;
                                        t && t.trim().length > 0 && (r = r.replace(t, ""))
                                    }
                                }
                            };
                        return i(`[${eB}]`), e && i(`[${e}]`), n && i(`${eF(eI.HIDDEN)}, ${eF(eI.MASK)}`), r
                    }
                    return t.textContent
                }
            }
            let e0 = [eB, "data-testid", "data-test", "data-qa", "data-cy", "data-test-id", "data-qa-id", "data-testing", "data-component", "data-element", "data-source-file"],
                e1 = [e6, function(t) {
                    if (t.id && !e3(t.id)) return `#${CSS.escape(t.id)}`
                }],
                e2 = [e6, function(t) {
                    if ("BODY" === t.tagName) return;
                    let e = t.classList;
                    for (let n = 0; n < e.length; n += 1) {
                        let r = e[n];
                        if (!e3(r)) return `${CSS.escape(t.tagName)}.${CSS.escape(r)}`
                    }
                }, function(t) {
                    return CSS.escape(t.tagName)
                }];

            function e5(t, e) {
                let n;
                if (!t.isConnected) return;
                let r = t;
                for (; r && "HTML" !== r.nodeName;) {
                    let t = e4(r, e1, e8, e, n);
                    if (t) return t;
                    n = e4(r, e2, e9, e, n) || e7(function(t) {
                        let e = t.parentElement.firstElementChild,
                            n = 1;
                        for (; e && e !== t;) e.tagName === t.tagName && (n += 1), e = e.nextElementSibling;
                        return `${CSS.escape(t.tagName)}:nth-of-type(${n})`
                    }(r), n), r = r.parentElement
                }
                return n
            }

            function e3(t) {
                return /[0-9]/.test(t)
            }

            function e6(t, e) {
                if (e) {
                    let t = n(e);
                    if (t) return t
                }
                for (let t of e0) {
                    let e = n(t);
                    if (e) return e
                }

                function n(e) {
                    if (t.hasAttribute(e)) return `${CSS.escape(t.tagName)}[${e}="${CSS.escape(t.getAttribute(e))}"]`
                }
            }

            function e4(t, e, n, r, i) {
                for (let a of e) {
                    let e = a(t, r);
                    if (e && n(t, e, i)) return e7(e, i)
                }
            }

            function e8(t, e, n) {
                return 1 === t.ownerDocument.querySelectorAll(e7(e, n)).length
            }

            function e9(t, e, n) {
                let r;
                if (void 0 === n) r = t => t.matches(e);
                else {
                    let t = e7(`${e}:scope`, n);
                    r = e => null !== e.querySelector(t)
                }
                let i = t.parentElement.firstElementChild;
                for (; i;) {
                    if (i !== t && r(i)) return !1;
                    i = i.nextElementSibling
                }
                return !0
            }

            function e7(t, e) {
                return e ? `${t}>${e}` : t
            }
            let nt = A.OY;

            function ne() {
                let t = window.getSelection();
                return !t || t.isCollapsed
            }

            function nn(t) {
                return t.target instanceof Element && !1 !== t.isPrimary
            }

            function nr(t) {
                return !t.hasPageActivity && !t.getUserActivity().input && !t.getUserActivity().scroll && !t.event.target.matches('input:not([type="checkbox"]):not([type="radio"]):not([type="button"]):not([type="submit"]):not([type="reset"]):not([type="range"]),textarea,select,[contenteditable],[contenteditable] *,canvas,a[href],a[href] *')
            }
            let ni = 10 * A.OY,
                na = new Map;

            function no(t, e) {
                na.set(t, e), na.forEach((t, e) => {
                    (0, A.vk)(e, (0, A.$S)()) > ni && na.delete(e)
                })
            }
            let ns = 5 * A.iW;

            function nu(t) {
                let e = nl(t) ? {
                        action: {
                            id: t.id,
                            loading_time: eg((0, A.Zj)(t.duration)),
                            frustration: {
                                type: t.frustrationTypes
                            },
                            error: {
                                count: t.counts.errorCount
                            },
                            long_task: {
                                count: t.counts.longTaskCount
                            },
                            resource: {
                                count: t.counts.resourceCount
                            }
                        },
                        _dd: {
                            action: {
                                target: t.target,
                                position: t.position,
                                name_source: t.nameSource
                            }
                        }
                    } : void 0,
                    n = (0, x.kg)({
                        action: {
                            id: O(),
                            target: {
                                name: t.name
                            },
                            type: t.type
                        },
                        date: t.startClocks.timeStamp,
                        type: "action"
                    }, e),
                    r = nl(t) ? t.duration : void 0,
                    i = nl(t) ? void 0 : t.context,
                    a = nl(t) ? {
                        events: t.events
                    } : {
                        handlingStack: t.handlingStack
                    };
                return {
                    customerContext: i,
                    rawRumEvent: n,
                    duration: r,
                    startTime: t.startClocks.relative,
                    domainContext: a
                }
            }

            function nl(t) {
                return "custom" !== t.type
            }
            var nc = n(46866),
                nd = n(46532),
                nf = n(81135),
                np = n(58961);
            let nh = {},
                nm = {
                    intervention: "intervention",
                    cspViolation: "csp_violation"
                };

            function ng(t) {
                return {
                    startClocks: (0, A.M8)(),
                    source: nf.g.REPORT,
                    handling: "unhandled",
                    ...t
                }
            }

            function ny(t, e, n, r, i) {
                return n ? (0, k.Yn)({
                    name: t,
                    message: e,
                    stack: [{
                        func: "?",
                        url: n,
                        line: null != r ? r : void 0,
                        column: null != i ? i : void 0
                    }]
                }) : void 0
            }
            var nv = n(98020);
            let n_ = A.OY,
                nb = new WeakSet;

            function nw(t) {
                return (0, A.Gw)(t.startTime, t.duration)
            }
            var nS = n(32563);
            let nx = 2 * A.iW;

            function nk(t, e) {
                let n = e && Number(e);
                if (t && n) return {
                    traceId: t,
                    traceTime: n
                }
            }

            function nC(t) {
                if (t && t.nodeType === Node.COMMENT_NODE) {
                    let e = /^\s*DATADOG;(.*?)\s*$/.exec(t.data);
                    if (e) return e[1]
                }
            }

            function nA() {
                if (e_(m.NAVIGATION)) {
                    let t = performance.getEntriesByType(m.NAVIGATION)[0];
                    if (t) return t
                }
                let t = function() {
                        let t = {},
                            e = performance.timing;
                        for (let n in e)
                            if ((0, J.Et)(e[n])) {
                                let r = e[n];
                                t[n] = 0 === r ? 0 : (0, A.gs)(r)
                            }
                        return t
                    }(),
                    e = {
                        entryType: m.NAVIGATION,
                        initiatorType: "navigation",
                        name: window.location.href,
                        startTime: 0,
                        duration: t.loadEventEnd,
                        decodedBodySize: 0,
                        encodedBodySize: 0,
                        transferSize: 0,
                        workerStart: 0,
                        toJSON: () => ({ ...e,
                            toJSON: void 0
                        }),
                        ...t
                    };
                return e
            }

            function nT(t, e) {
                var n;
                let r = (0, A.FR)(t.startTime),
                    i = function(t, e) {
                        if (t.traceId) return {
                            _dd: {
                                trace_id: t.traceId,
                                span_id: tM(63).toString(),
                                rule_psr: e.rulePsr
                            }
                        }
                    }(t, e);
                if (!e.trackResources && !i) return;
                let a = function(t) {
                        let e = t.name;
                        if (!(0, z.AY)(e)) return (0, w.A2)(`Failed to construct URL for "${t.name}"`), "other";
                        let n = (0, z.L2)(e);
                        for (let [e, r] of en)
                            if (r(t.initiatorType, n)) return e;
                        return "other"
                    }(t),
                    o = nE(t),
                    s = ei(t),
                    u = (0, x.kg)({
                        date: r.timeStamp,
                        resource: {
                            id: O(),
                            type: a,
                            duration: (0, A.Zj)(s),
                            url: t.name,
                            status_code: 0 === (n = t.responseStatus) ? void 0 : n,
                            protocol: eu(t),
                            delivery_type: el(t)
                        },
                        type: "resource",
                        _dd: {
                            discarded: !e.trackResources
                        }
                    }, i, o);
                return {
                    startTime: r.relative,
                    duration: s,
                    rawRumEvent: u,
                    domainContext: {
                        performanceEntry: t
                    }
                }
            }

            function nE(t) {
                let {
                    renderBlockingStatus: e
                } = t;
                return {
                    resource: {
                        render_blocking_status: e,
                        ... function(t) {
                            if (t.startTime < t.responseStart) {
                                let {
                                    encodedBodySize: e,
                                    decodedBodySize: n,
                                    transferSize: r
                                } = t;
                                return {
                                    size: n,
                                    encoded_body_size: e,
                                    decoded_body_size: n,
                                    transfer_size: r
                                }
                            }
                            return {
                                size: void 0,
                                encoded_body_size: void 0,
                                decoded_body_size: void 0,
                                transfer_size: void 0
                            }
                        }(t),
                        ... function(t) {
                            if (!eo(t)) return;
                            let {
                                startTime: e,
                                fetchStart: n,
                                workerStart: r,
                                redirectStart: i,
                                redirectEnd: a,
                                domainLookupStart: o,
                                domainLookupEnd: s,
                                connectStart: u,
                                secureConnectionStart: l,
                                connectEnd: c,
                                requestStart: d,
                                responseStart: f,
                                responseEnd: p
                            } = t, h = {
                                download: es(e, f, p),
                                first_byte: es(e, d, f)
                            };
                            return 0 < r && r < n && (h.worker = es(e, r, n)), n < c && (h.connect = es(e, u, c), u <= l && l <= c && (h.ssl = es(e, l, c))), n < s && (h.dns = es(e, o, s)), e < a && (h.redirect = es(e, i, a)), h
                        }(t)
                    }
                }
            }
            let nR = 10 * A.iW,
                nI = 10 * A.iW;

            function nO(t, e = window) {
                if ("hidden" === document.visibilityState) return {
                    timeStamp: 0,
                    stop: q.l
                };
                if (e_(m.VISIBILITY_STATE)) {
                    let t = performance.getEntriesByType(m.VISIBILITY_STATE).find(t => "hidden" === t.name);
                    if (t) return {
                        timeStamp: t.startTime,
                        stop: q.l
                    }
                }
                let n = 1 / 0,
                    {
                        stop: r
                    } = (0, tj.l)(t, e, ["pagehide", "visibilitychange"], t => {
                        ("pagehide" === t.type || "hidden" === document.visibilityState) && (n = t.timeStamp, r())
                    }, {
                        capture: !0
                    });
                return {
                    get timeStamp() {
                        return n
                    },
                    stop: r
                }
            }

            function nP({
                x: t,
                y: e,
                width: n,
                height: r
            }) {
                return {
                    x: t,
                    y: e,
                    width: n,
                    height: r
                }
            }
            let nN = 5 * A.OY,
                nM = A.OY,
                nL = 0,
                nD = 1 / 0,
                n$ = 0,
                nU = () => c ? nL : window.performance.interactionCount || 0,
                nj = +A.iW;

            function nq() {
                let t, e = window.visualViewport;
                return Math.round(e ? e.pageLeft - e.offsetLeft : void 0 !== window.scrollX ? window.scrollX : window.pageXOffset || 0)
            }

            function nV() {
                let t, e = window.visualViewport;
                return Math.round(e ? e.pageTop - e.offsetTop : void 0 !== window.scrollY ? window.scrollY : window.pageYOffset || 0)
            }

            function nz(t) {
                var e;
                return d || (e = t, d = new g.c(t => {
                    let {
                        throttled: n
                    } = (0, q.n)(() => {
                        t.notify(nF())
                    }, 200);
                    return (0, tj.q)(e, window, "resize", n, {
                        capture: !0,
                        passive: !0
                    }).stop
                })), d
            }

            function nF() {
                let t = window.visualViewport;
                return t ? {
                    width: Number(t.width * t.scale),
                    height: Number(t.height * t.scale)
                } : {
                    width: Number(window.innerWidth || 0),
                    height: Number(window.innerHeight || 0)
                }
            }
            let nB = A.OY,
                nG = 5 * A.iW,
                nH = 5 * A.iW;

            function nZ(t) {
                let e = t.indexOf("?");
                return e < 0 ? t : t.slice(0, e)
            }
            let nW = A.iW,
                nQ = [];

            function nJ(t) {
                return "2" === t || "1" === t
            }

            function nY(t) {
                let e;
                return {
                    data: "string" == typeof t.output ? t.output : new Blob([t.output], {
                        type: "text/plain"
                    }),
                    bytesCount: t.outputBytesCount,
                    encoding: t.encoding
                }
            }
            var nK = n(85520);

            function nX(t) {
                return Object.prototype.hasOwnProperty.call(history, t) ? history : History.prototype
            }
            let n0 = 10 * A.OY;

            function n1() {
                0 !== f.batchCount && ((0, w.A2)("Customer data measures", f), n3())
            }

            function n2() {
                return {
                    min: 1 / 0,
                    max: 0,
                    sum: 0
                }
            }

            function n5(t, e) {
                t.sum += e, t.min = Math.min(t.min, e), t.max = Math.max(t.max, e)
            }

            function n3() {
                f = {
                    batchCount: 0,
                    batchBytesCount: n2(),
                    batchMessagesCount: n2()
                }
            }

            function n6() {
                return "hidden" === document.visibilityState ? "hidden" : document.hasFocus() ? "active" : "passive"
            }
            let n4 = A.OY,
                n8 = "datadog-ci-visibility-test-execution-id";

            function n9(t, e, n) {
                let r = 0,
                    i = !1;
                return {
                    isLimitReached() {
                        if (0 === r && (0, K.wg)(() => {
                                r = 0
                            }, A.iW), (r += 1) <= e || i) return i = !1, !1;
                        if (r === e + 1) {
                            i = !0;
                            try {
                                n({
                                    message: `Reached max number of ${t}s by minute: ${e}`,
                                    source: nf.g.AGENT,
                                    startClocks: (0, A.M8)()
                                })
                            } finally {
                                i = !1
                            }
                        }
                        return !0
                    }
                }
            }
            var n7 = n(94404);

            function rt(t) {
                return "object" === (0, tO.P)(t)
            }
            let re = {
                    "view.name": "string",
                    "view.url": "string",
                    "view.referrer": "string"
                },
                rn = {
                    context: "object"
                },
                rr = {
                    service: "string",
                    version: "string"
                };

            function ri(t, e, n, r, i, a, o) {
                var s, l, d, y, _, S, T, E;
                let I, P = [],
                    $ = new t0,
                    U = function() {
                        let t = {};
                        return {
                            register: (e, n) => (t[e] || (t[e] = []), t[e].push(n), {
                                unregister: () => {
                                    t[e] = t[e].filter(t => t !== n)
                                }
                            }),
                            triggerHook(e, n) {
                                let r = (t[e] || []).map(t => t(n));
                                return (0, x.kg)(...r)
                            }
                        }
                    }();
                $.subscribe(13, t => (0, tJ.b)("rum", t));
                let z = function(t) {
                    let e = (0, w.a5)("browser-rum-sdk", t);
                    if ((0, j.d0)()) {
                        let t = (0, j.Y9)();
                        e.observable.subscribe(e => t.send("internal_telemetry", e))
                    }
                    return e
                }(t);
                z.setContextProvider(() => {
                    var e, n;
                    return {
                        application: {
                            id: t.applicationId
                        },
                        session: {
                            id: null == (e = tf.findTrackedSession()) ? void 0 : e.id
                        },
                        view: {
                            id: null == (n = tb.findView()) ? void 0 : n.id
                        },
                        action: {
                            id: tI.findActionId()
                        }
                    }
                });
                let H = t => {
                        $.notify(14, {
                            error: t
                        }), (0, w.A2)("Error reported to customer", {
                            "error.message": t.message
                        })
                    },
                    Q = (0, tY._T)(t),
                    to = Q.subscribe(t => {
                        $.notify(11, t)
                    });
                P.push(() => to.unsubscribe());
                let tf = (0, j.d0)() ? function() {
                    let t = {
                        id: "00000000-aaaa-0000-aaaa-000000000000",
                        sessionReplay: +!!(0, j.Ww)("records")
                    };
                    return {
                        findTrackedSession: () => t,
                        expire: q.l,
                        expireObservable: new g.c,
                        setForcedReplay: q.l
                    }
                }() : function(t, e, n) {
                    let r = function(t, e, n, r) {
                        let i = new g.c,
                            a = new g.c,
                            o = function(t, e, n, r) {
                                let i, a = new g.c,
                                    o = new g.c,
                                    s = new g.c,
                                    u = t.type === ta.COOKIE ? function(t, e) {
                                        var n;
                                        let r = {
                                            isLockEnabled: (0, X.F2)(),
                                            persistSession: (n = e, t => {
                                                G(tt, td(t), tr, n)
                                            }),
                                            retrieveSession: th,
                                            expireSession: n => {
                                                var r, i;
                                                return r = e, void G(tt, td(ts(n, i = t)), i.trackAnonymousUser ? ti : tn, r)
                                            }
                                        };
                                        if (!Z(tt)) {
                                            let t = Z("_dd"),
                                                e = Z("_dd_r"),
                                                n = Z("_dd_l"),
                                                i = {};
                                            t && (i.id = t), n && /^[01]$/.test(n) && (i.logs = n), e && /^[012]$/.test(e) && (i.rum = e), tu(i) || (tc(i), r.persistSession(i))
                                        }
                                        return r
                                    }(e, t.cookieOptions) : {
                                        isLockEnabled: !1,
                                        persistSession: tg,
                                        retrieveSession: ty,
                                        expireSession: t => {
                                            tg(ts(t, e))
                                        }
                                    },
                                    {
                                        expireSession: l
                                    } = u,
                                    c = (0, K.yb)(function() {
                                        t_({
                                            process: t => tl(t) ? ts(t, e) : void 0,
                                            after: p
                                        }, u)
                                    }, tS);
                                h();
                                let {
                                    throttled: d,
                                    cancel: f
                                } = (0, q.n)(() => {
                                    t_({
                                        process: t => {
                                            if (tu(t)) return;
                                            let e = p(t);
                                            return function(t) {
                                                if (tu(t)) return;
                                                let {
                                                    trackingType: e,
                                                    isTracked: i
                                                } = r(t.rum);
                                                t[n] = e, delete t.isExpired, i && !t.id && (t.id = O(), t.created = String((0, A.x3)()))
                                            }(e), e
                                        },
                                        after: t => {
                                            tu(t) || m() || (i = t, a.notify()), i = t
                                        }
                                    }, u)
                                }, tS);

                                function p(t) {
                                    var r;
                                    return tl(t) && (t = ts(t, e)), m() && ((r = t, i.id !== r.id || i[n] !== r[n]) ? (i = ts(i, e), o.notify()) : (s.notify({
                                        previousState: i,
                                        newState: t
                                    }), i = t)), t
                                }

                                function h() {
                                    t_({
                                        process: t => {
                                            if (tu(t)) return ts(t, e)
                                        },
                                        after: t => {
                                            i = t
                                        }
                                    }, u)
                                }

                                function m() {
                                    return void 0 !== i[n]
                                }
                                return {
                                    expandOrRenewSession: d,
                                    expandSession: function() {
                                        t_({
                                            process: t => m() ? p(t) : void 0
                                        }, u)
                                    },
                                    getSession: () => i,
                                    renewObservable: a,
                                    expireObservable: o,
                                    sessionStateUpdateObservable: s,
                                    restartSession: h,
                                    expire: () => {
                                        f(), l(i), p(ts(i, e))
                                    },
                                    stop: () => {
                                        (0, K.vG)(c)
                                    },
                                    updateSessionState: function(t) {
                                        t_({
                                            process: e => ({ ...e,
                                                ...t
                                            }),
                                            after: p
                                        }, u)
                                    }
                                }
                            }(t.sessionStoreStrategyType, t, "rum", n);
                        nQ.push(() => o.stop());
                        let s = t4({
                            expireDelay: tn
                        });

                        function u() {
                            return {
                                id: o.getSession().id,
                                trackingType: o.getSession().rum,
                                isReplayForced: !!o.getSession().forcedReplay,
                                anonymousId: o.getSession().anonymousId
                            }
                        }
                        return nQ.push(() => s.stop()), o.renewObservable.subscribe(() => {
                                s.add(u(), (0, A.$S)()), i.notify()
                            }), o.expireObservable.subscribe(() => {
                                a.notify(), s.closeActive((0, A.$S)())
                            }), o.expandOrRenewSession(), s.add(u(), (0, A.Oc)().relative), r.observable.subscribe(() => {
                                r.isGranted() ? o.expandOrRenewSession() : o.expire()
                            }),
                            function(t, e) {
                                let {
                                    stop: n
                                } = (0, tj.l)(t, window, ["click", "touchstart", "keydown", "scroll"], e, {
                                    capture: !0,
                                    passive: !0
                                });
                                nQ.push(n)
                            }(t, () => {
                                r.isGranted() && o.expandOrRenewSession()
                            }),
                            function(t, e) {
                                let n = () => {
                                        "visible" === document.visibilityState && e()
                                    },
                                    {
                                        stop: r
                                    } = (0, tj.q)(t, document, "visibilitychange", n);
                                nQ.push(r);
                                let i = (0, K.yb)(n, nW);
                                nQ.push(() => {
                                    (0, K.vG)(i)
                                })
                            }(t, () => o.expandSession()),
                            function(t, e) {
                                let {
                                    stop: n
                                } = (0, tj.q)(t, window, "resume", e, {
                                    capture: !0
                                });
                                nQ.push(n)
                            }(t, () => o.restartSession()), {
                                findSession: (t, e) => s.find(t, e),
                                renewObservable: i,
                                expireObservable: a,
                                sessionStateUpdateObservable: o.sessionStateUpdateObservable,
                                expire: o.expire,
                                updateSessionState: o.updateSessionState
                            }
                    }(t, "rum", e => {
                        var n, r, i;
                        let a;
                        return n = t, {
                            trackingType: a = "0" === (i = r = e) || "1" === i || "2" === i ? r : (0, J.ic)(n.sessionSampleRate) ? (0, J.ic)(n.sessionReplaySampleRate) ? "1" : "2" : "0",
                            isTracked: nJ(a)
                        }
                    }, n);
                    return r.expireObservable.subscribe(() => {
                        e.notify(9)
                    }), r.renewObservable.subscribe(() => {
                        e.notify(10)
                    }), r.sessionStateUpdateObservable.subscribe(({
                        previousState: t,
                        newState: e
                    }) => {
                        if (!t.forcedReplay && e.forcedReplay) {
                            let t = r.findSession();
                            t && (t.isReplayForced = !0)
                        }
                    }), {
                        findTrackedSession: t => {
                            let e = r.findSession(t);
                            if (e && nJ(e.trackingType)) return {
                                id: e.id,
                                sessionReplay: "1" === e.trackingType ? 1 : 2 * !!e.isReplayForced,
                                anonymousId: e.anonymousId
                            }
                        },
                        expire: r.expire,
                        expireObservable: r.expireObservable,
                        setForcedReplay: () => r.updateSessionState({
                            forcedReplay: "1"
                        })
                    }
                }(t, $, a);
                if ((0, j.d0)()) {
                    let t = (0, j.Y9)();
                    $.subscribe(13, e => {
                        t.send("rum", e)
                    })
                } else {
                    let e = function(t, e, n, r, i, a, o) {
                        let s = t.replica,
                            u = function(t, e, n, r, i, a, o = function({
                                encoder: t,
                                request: e,
                                flushController: n,
                                messageBytesLimit: r
                            }) {
                                let i = {},
                                    a = n.flushObservable.subscribe(n => (function(n) {
                                        let r = (0, te.KQ)(i).join("\n");
                                        i = {};
                                        let a = (0, tY.Kp)(n.reason),
                                            o = a ? e.sendOnExit : e.send;
                                        if (a && t.isAsync) {
                                            let e = t.finishSync();
                                            e.outputBytesCount && o(nY(e));
                                            let n = [e.pendingData, r].filter(Boolean).join("\n");
                                            n && o({
                                                data: n,
                                                bytesCount: (0, v.WW)(n)
                                            })
                                        } else r && t.write(t.isEmpty ? r : `
${r}`), t.finish(t => {
                                            o(nY(t))
                                        })
                                    })(n));

                                function o(e, a) {
                                    let o = (0, np.s)(e),
                                        s = t.estimateEncodedBytesCount(o);
                                    if (s >= r) return void R.Vy.warn(`Discarded a message whose size was bigger than the maximum allowed size ${r}KB. ${R.xG} ${R.Xs}/#technical-limitations`);
                                    void 0 !== a && void 0 !== i[a] && function(e) {
                                        let r = i[e];
                                        delete i[e];
                                        let a = t.estimateEncodedBytesCount(r);
                                        n.notifyAfterRemoveMessage(a)
                                    }(a), n.notifyBeforeAddMessage(s), void 0 !== a ? (i[a] = o, n.notifyAfterAddMessage()) : t.write(t.isEmpty ? o : `
${o}`, t => {
                                        n.notifyAfterAddMessage(t - s)
                                    })
                                }
                                return {
                                    flushController: n,
                                    add: o,
                                    upsert: o,
                                    stop: a.unsubscribe
                                }
                            }) {
                                let s = l(t, e),
                                    u = n && l(t, n);

                                function l(t, {
                                    endpoint: e,
                                    encoder: n
                                }) {
                                    return o({
                                        encoder: n,
                                        request: (0, nK.sA)(e, t.batchBytesLimit, r),
                                        flushController: function({
                                            messagesLimit: t,
                                            bytesLimit: e,
                                            durationLimit: n,
                                            pageMayExitObservable: r,
                                            sessionExpireObservable: i
                                        }) {
                                            let a, o = r.subscribe(t => d(t.reason)),
                                                s = i.subscribe(() => d("session_expire")),
                                                u = new g.c(() => () => {
                                                    o.unsubscribe(), s.unsubscribe()
                                                }),
                                                l = 0,
                                                c = 0;

                                            function d(t) {
                                                if (0 === c) return;
                                                let e = c,
                                                    n = l;
                                                c = 0, l = 0, f(), u.notify({
                                                    reason: t,
                                                    messagesCount: e,
                                                    bytesCount: n
                                                })
                                            }

                                            function f() {
                                                (0, K.DJ)(a), a = void 0
                                            }
                                            return {
                                                flushObservable: u,
                                                get messagesCount() {
                                                    return c
                                                },
                                                notifyBeforeAddMessage(t) {
                                                    l + t >= e && d("bytes_limit"), c += 1, l += t, void 0 === a && (a = (0, K.wg)(() => {
                                                        d("duration_limit")
                                                    }, n))
                                                },
                                                notifyAfterAddMessage(n = 0) {
                                                    l += n, c >= t ? d("messages_limit") : l >= e && d("bytes_limit")
                                                },
                                                notifyAfterRemoveMessage(t) {
                                                    l -= t, 0 == (c -= 1) && f()
                                                }
                                            }
                                        }({
                                            messagesLimit: t.batchMessagesLimit,
                                            bytesLimit: t.batchBytesLimit,
                                            durationLimit: t.flushTimeout,
                                            pageMayExitObservable: i,
                                            sessionExpireObservable: a
                                        }),
                                        messageBytesLimit: t.messageBytesLimit
                                    })
                                }
                                return {
                                    flushObservable: s.flushController.flushObservable,
                                    add(t, e = !0) {
                                        s.add(t), u && e && u.add(n.transformMessage ? n.transformMessage(t) : t)
                                    },
                                    upsert: (t, e) => {
                                        s.upsert(t, e), u && u.upsert(n.transformMessage ? n.transformMessage(t) : t, e)
                                    },
                                    stop: () => {
                                        s.stop(), u && u.stop()
                                    }
                                }
                            }(t, {
                                endpoint: t.rumEndpointBuilder,
                                encoder: o(2)
                            }, s && {
                                endpoint: s.rumEndpointBuilder,
                                transformMessage: t => (0, x.kg)(t, {
                                    application: {
                                        id: s.applicationId
                                    }
                                }),
                                encoder: o(3)
                            }, r, i, a);
                        return e.subscribe(13, t => {
                            "view" === t.type ? u.upsert(t, t.view.id) : u.add(t)
                        }), n.subscribe(e => u.add(e, (0, w.Wb)(t))), u
                    }(t, $, z.observable, H, Q, tf.expireObservable, i);
                    P.push(() => e.stop()), s = e.flushObservable, z.enabled && (0, J.ic)(t.customerDataTelemetrySampleRate) && (n3(), p = !1, $.subscribe(13, () => {
                        p = !0
                    }), s.subscribe(({
                        bytesCount: t,
                        messagesCount: e
                    }) => {
                        p && (f.batchCount += 1, n5(f.batchBytesCount, t), n5(f.batchMessagesCount, e))
                    }), (0, K.yb)(n1, n0))
                }
                let tp = function() {
                        let t = tX();
                        return new g.c(e => {
                            if (!t) return;
                            let n = new t((0, b.dm)(() => e.notify()));
                            return n.observe(document, {
                                attributes: !0,
                                characterData: !0,
                                childList: !0,
                                subtree: !0
                            }), () => n.disconnect()
                        })
                    }(),
                    tm = (l = location, I = (0, Y.yG)(l), new g.c(e => {
                        var n, r;
                        let {
                            stop: i
                        } = function(t, e) {
                            let {
                                stop: n
                            } = (0, V.H)(nX("pushState"), "pushState", ({
                                onPostCall: t
                            }) => {
                                t(e)
                            }), {
                                stop: r
                            } = (0, V.H)(nX("replaceState"), "replaceState", ({
                                onPostCall: t
                            }) => {
                                t(e)
                            }), {
                                stop: i
                            } = (0, tj.q)(t, window, "popstate", e);
                            return {
                                stop: () => {
                                    n(), r(), i()
                                }
                            }
                        }(t, o), {
                            stop: a
                        } = (n = t, r = o, (0, tj.q)(n, window, "hashchange", r));

                        function o() {
                            if (I.href === l.href) return;
                            let t = (0, Y.yG)(l);
                            e.notify({
                                newLocation: t,
                                oldLocation: I
                            }), I = t
                        }
                        return () => {
                            i(), a()
                        }
                    })),
                    tv = function(t, e, n = 500) {
                        let r, i = t4({
                            expireDelay: tn,
                            maxEntries: 4e3
                        });
                        o(n6(), (0, A.$S)());
                        let {
                            stop: a
                        } = (0, tj.l)(e, window, ["pageshow", "focus", "blur", "visibilitychange", "resume", "freeze", "pagehide"], t => {
                            var e;
                            o("freeze" === (e = t).type ? "frozen" : "pagehide" === e.type ? e.persisted ? "frozen" : "terminated" : n6(), t.timeStamp)
                        }, {
                            capture: !0
                        });

                        function o(t, e = (0, A.$S)()) {
                            t !== r && (r = t, i.closeActive(e), i.add({
                                state: r,
                                startTime: e
                            }, e))
                        }

                        function s(t, e, n) {
                            return i.findAll(e, n).some(e => e.state === t)
                        }
                        return t.register(0, ({
                            startTime: t,
                            duration: e = 0,
                            eventType: r
                        }) => "view" === r ? {
                            type: r,
                            _dd: {
                                page_states: function(t, e, n) {
                                    if (0 !== t.length) return t.slice(-n).reverse().map(({
                                        state: t,
                                        startTime: n
                                    }) => ({
                                        state: t,
                                        start: (0, A.Zj)((0, A.vk)(e, n))
                                    }))
                                }(i.findAll(t, e), t, n)
                            }
                        } : "action" === r || "error" === r ? {
                            type: r,
                            view: {
                                in_foreground: s("active", t, 0)
                            }
                        } : void 0), {
                            wasInPageStateDuringPeriod: s,
                            addPageState: o,
                            stop: () => {
                                a(), i.stop()
                            }
                        }
                    }(U, t),
                    tb = function(t) {
                        let e = t4({
                            expireDelay: tn
                        });
                        return t.subscribe(1, t => {
                            var n;
                            e.add({
                                service: (n = t).service,
                                version: n.version,
                                context: n.context,
                                id: n.id,
                                name: n.name,
                                startClocks: n.startClocks
                            }, t.startClocks.relative)
                        }), t.subscribe(6, ({
                            endClocks: t
                        }) => {
                            e.closeActive(t.relative)
                        }), t.subscribe(3, t => {
                            let n = e.find(t.startClocks.relative);
                            n && t.name && (n.name = t.name), n && t.context && (n.context = t.context)
                        }), t.subscribe(10, () => {
                            e.reset()
                        }), {
                            findView: t => e.find(t),
                            getAllEntries: () => e.getAllEntries(),
                            getDeletedEntries: () => e.getDeletedEntries(),
                            stop: () => {
                                e.stop()
                            }
                        }
                    }($),
                    tw = function(t, e, n, r) {
                        let i, a = t4({
                            expireDelay: tn
                        });
                        t.subscribe(1, ({
                            startClocks: t
                        }) => {
                            let e = r.href;
                            a.add(s({
                                url: e,
                                referrer: i || document.referrer
                            }), t.relative), i = e
                        }), t.subscribe(6, ({
                            endClocks: t
                        }) => {
                            a.closeActive(t.relative)
                        });
                        let o = n.subscribe(({
                            newLocation: t
                        }) => {
                            let e = a.find();
                            if (e) {
                                let n = (0, A.$S)();
                                a.closeActive(n), a.add(s({
                                    url: t.href,
                                    referrer: e.referrer
                                }), n)
                            }
                        });

                        function s({
                            url: t,
                            referrer: e
                        }) {
                            return {
                                url: t,
                                referrer: e
                            }
                        }
                        return e.register(0, ({
                            startTime: t,
                            eventType: e
                        }) => {
                            let {
                                url: n,
                                referrer: r
                            } = a.find(t);
                            return {
                                type: e,
                                view: {
                                    url: n,
                                    referrer: r
                                }
                            }
                        }), {
                            findUrl: t => a.find(t),
                            getAllEntries: () => a.getAllEntries(),
                            getDeletedEntries: () => a.getDeletedEntries(),
                            stop: () => {
                                o.unsubscribe(), a.stop()
                            }
                        }
                    }($, U, tm, location),
                    tx = function(t, e, n) {
                        let r = t4({
                            expireDelay: tn
                        });
                        return t.subscribe(1, ({
                            startClocks: t
                        }) => {
                            r.add({}, t.relative)
                        }), t.subscribe(6, ({
                            endClocks: t
                        }) => {
                            r.closeActive(t.relative)
                        }), e.register(0, ({
                            startTime: t,
                            eventType: e
                        }) => {
                            if (!n.trackFeatureFlagsForEvents.concat(["view", "error"]).includes(e)) return;
                            let i = r.find(t);
                            if (!(!i || (0, Y.RI)(i))) return {
                                type: e,
                                feature_flags: i
                            }
                        }), {
                            addFeatureFlagEvaluation: (t, e) => {
                                let n = r.find();
                                n && (n[t] = e)
                            }
                        }
                    }($, U, t),
                    {
                        observable: tk,
                        stop: tC
                    } = function() {
                        let t = new g.c,
                            {
                                stop: e
                            } = (0, V.H)(window, "open", () => t.notify());
                        return {
                            observable: t,
                            stop: e
                        }
                    }();
                P.push(tC);
                let tA = function(t) {
                        let e = tG();
                        return t.storeContextsAcrossPages && tz(t, e, "rum", 2), e
                    }(t),
                    tT = function(t) {
                        let e = tH();
                        return t.storeContextsAcrossPages && tz(t, e, "rum", 1), e
                    }(t),
                    tE = function(t) {
                        let e = tZ();
                        return t.storeContextsAcrossPages && tz(t, e, "rum", 4), e
                    }(t),
                    tR = () => ({
                        context: tA.getContext(),
                        user: tT.getContext(),
                        account: tE.getContext(),
                        hasReplay: !!e.isRecording() || void 0
                    }),
                    {
                        actionContexts: tI,
                        addAction: tP,
                        stop: tN
                    } = function(t, e, n, r, i, a, o, s, u, l, c) {
                        let d, f, p = (t.subscribe(0, e => t.notify(12, nu(e))), e.register(0, ({
                                startTime: t,
                                eventType: e
                            }) => {
                                if ("error" !== e && "resource" !== e && "long_task" !== e) return;
                                let n = d.findActionId(t);
                                if (n) return {
                                    type: e,
                                    action: {
                                        id: n
                                    }
                                }
                            }), d = {
                                findActionId: q.l
                            }, f = q.l, n.trackUserInteractions && ({
                                actionContexts: d,
                                stop: f
                            } = function(t, e, n, r) {
                                let i, a = t4({
                                        expireDelay: ns
                                    }),
                                    o = new g.c;
                                t.subscribe(10, () => {
                                    a.reset()
                                }), t.subscribe(5, l), t.subscribe(11, t => {
                                    t.reason === tY.y5.UNLOADING && l()
                                });
                                let {
                                    stop: s
                                } = function(t, {
                                    onPointerDown: e,
                                    onPointerUp: n
                                }) {
                                    let r, i, a = {
                                            selection: !1,
                                            input: !1,
                                            scroll: !1
                                        },
                                        o = [(0, tj.q)(t, window, "pointerdown", t => {
                                            nn(t) && (r = ne(), a = {
                                                selection: !1,
                                                input: !1,
                                                scroll: !1
                                            }, i = e(t))
                                        }, {
                                            capture: !0
                                        }), (0, tj.q)(t, window, "selectionchange", () => {
                                            r && ne() || (a.selection = !0)
                                        }, {
                                            capture: !0
                                        }), (0, tj.q)(t, window, "scroll", () => {
                                            a.scroll = !0
                                        }, {
                                            capture: !0,
                                            passive: !0
                                        }), (0, tj.q)(t, window, "pointerup", t => {
                                            if (nn(t) && i) {
                                                let e = a;
                                                n(i, t, () => e), i = void 0
                                            }
                                        }, {
                                            capture: !0
                                        }), (0, tj.q)(t, window, "input", () => {
                                            a.input = !0
                                        }, {
                                            capture: !0
                                        })];
                                    return {
                                        stop: () => {
                                            o.forEach(t => t.stop())
                                        }
                                    }
                                }(r, {
                                    onPointerDown: i => (function(t, e, n, r, i) {
                                        var a;
                                        let o = t.enablePrivacyForActionName ? eD(r.target, t.defaultPrivacyLevel) : eI.ALLOW;
                                        if (o === eI.HIDDEN) return;
                                        let s = function(t, e, n) {
                                                let r = t.target.getBoundingClientRect(),
                                                    i = e5(t.target, n.actionNameAttribute);
                                                i && no(t.timeStamp, i);
                                                let a = function(t, {
                                                    enablePrivacyForActionName: e,
                                                    actionNameAttribute: n
                                                }, r) {
                                                    let i = eG(t, eB) || n && eG(t, n);
                                                    return i ? {
                                                        name: i,
                                                        nameSource: "custom_attribute"
                                                    } : r === eI.MASK ? {
                                                        name: "Masked Element",
                                                        nameSource: "mask_placeholder"
                                                    } : eW(t, n, eH, e) || eW(t, n, eZ, e) || {
                                                        name: "",
                                                        nameSource: "blank"
                                                    }
                                                }(t.target, n, e);
                                                return {
                                                    type: "click",
                                                    target: {
                                                        width: Math.round(r.width),
                                                        height: Math.round(r.height),
                                                        selector: i
                                                    },
                                                    position: {
                                                        x: Math.round(t.clientX - r.left),
                                                        y: Math.round(t.clientY - r.top)
                                                    },
                                                    name: a.name,
                                                    nameSource: a.nameSource
                                                }
                                            }(r, o, t),
                                            u = !1;
                                        return a = t => {
                                            u = t.hadActivity
                                        }, eb(ew(e, n, i, t), a, 100), {
                                            clickActionBase: s,
                                            hadActivityOnPointerDown: () => u
                                        }
                                    })(r, t, e, i, n),
                                    onPointerUp: ({
                                        clickActionBase: i,
                                        hadActivityOnPointerDown: s
                                    }, l, c) => {
                                        ! function(t, e, n, r, i, a, o, s, u, l, c) {
                                            var d, f;
                                            let p = function t(e, n, r, i, a) {
                                                let o, s = O(),
                                                    u = (0, A.M8)(),
                                                    l = n.add(s, u.relative),
                                                    c = ey({
                                                        lifeCycle: e,
                                                        isChildEvent: t => void 0 !== t.action && (Array.isArray(t.action.id) ? t.action.id.includes(s) : t.action.id === s)
                                                    }),
                                                    d = 0,
                                                    f = [],
                                                    p = new g.c;

                                                function h(t) {
                                                    0 === d && (d = 1, (o = t) ? l.close((0, A.gs)(o)) : l.remove(), c.stop(), p.notify())
                                                }
                                                return {
                                                    event: a,
                                                    stop: h,
                                                    stopObservable: p,
                                                    get hasError() {
                                                        return c.eventCounts.errorCount > 0
                                                    },
                                                    get hasPageActivity() {
                                                        return void 0 !== o
                                                    },
                                                    getUserActivity: r,
                                                    addFrustration: t => {
                                                        f.push(t)
                                                    },
                                                    startClocks: u,
                                                    isStopped: () => 1 === d || 2 === d,
                                                    clone: () => t(e, n, r, i, a),
                                                    validate: t => {
                                                        if (h(), 1 !== d) return;
                                                        let {
                                                            resourceCount: n,
                                                            errorCount: r,
                                                            longTaskCount: l
                                                        } = c.eventCounts, p = {
                                                            duration: o && (0, A.vk)(u.timeStamp, o),
                                                            startClocks: u,
                                                            id: s,
                                                            frustrationTypes: f,
                                                            counts: {
                                                                resourceCount: n,
                                                                errorCount: r,
                                                                longTaskCount: l
                                                            },
                                                            events: null != t ? t : [a],
                                                            event: a,
                                                            ...i
                                                        };
                                                        e.notify(0, p), d = 2
                                                    },
                                                    discard: () => {
                                                        h(), d = 2
                                                    }
                                                }
                                            }(e, i, l, s, u);
                                            o(p);
                                            let h = null == (d = null == s ? void 0 : s.target) ? void 0 : d.selector;
                                            h && no(u.timeStamp, h);
                                            let {
                                                stop: m
                                            } = (f = t => {
                                                t.hadActivity && t.end < p.startClocks.timeStamp ? p.discard() : t.hadActivity ? p.stop(t.end) : c() ? p.stop(p.startClocks.timeStamp) : p.stop()
                                            }, eb(ew(e, n, r, t), f, ni)), y = e.subscribe(5, ({
                                                endClocks: t
                                            }) => {
                                                p.stop(t.timeStamp)
                                            }), v = a.subscribe(() => {
                                                p.stop()
                                            });
                                            p.stopObservable.subscribe(() => {
                                                y.unsubscribe(), m(), v.unsubscribe()
                                            })
                                        }(r, t, e, n, a, o, u, i, l, c, s)
                                    }
                                });
                                return {
                                    stop: () => {
                                        l(), o.notify(), s()
                                    },
                                    actionContexts: {
                                        findActionId: t => a.findAll(t)
                                    }
                                };

                                function u(t) {
                                    if (!i || !i.tryAppend(t)) {
                                        let e = t.clone();
                                        i = function(t, e) {
                                            let n, r = [],
                                                i = 0;

                                            function a(t) {
                                                t.stopObservable.subscribe(o), r.push(t), (0, K.DJ)(n), n = (0, K.wg)(s, nt)
                                            }

                                            function o() {
                                                1 === i && r.every(t => t.isStopped()) && (i = 2, e(r))
                                            }

                                            function s() {
                                                (0, K.DJ)(n), 0 === i && (i = 1, o())
                                            }
                                            return a(t), {
                                                tryAppend: t => {
                                                    var e, n, o, u;
                                                    return 0 === i && (!(r.length > 0) || (e = r[r.length - 1].event, n = t.event, e.target === n.target && 100 >= (o = e, u = n, Math.sqrt(Math.pow(o.clientX - u.clientX, 2) + Math.pow(o.clientY - u.clientY, 2))) && e.timeStamp - n.timeStamp <= nt) ? (a(t), !0) : (s(), !1))
                                                },
                                                stop: () => {
                                                    s()
                                                }
                                            }
                                        }(t, t => {
                                            var n = t,
                                                r = e;
                                            let {
                                                isRage: i
                                            } = function(t, e) {
                                                if (function(t) {
                                                        if (t.some(t => t.getUserActivity().selection || t.getUserActivity().scroll)) return !1;
                                                        for (let e = 0; e < t.length - 2; e += 1)
                                                            if (t[e + 3 - 1].event.timeStamp - t[e].event.timeStamp <= A.OY) return !0;
                                                        return !1
                                                    }(t)) return e.addFrustration("rage_click"), t.some(nr) && e.addFrustration("dead_click"), e.hasError && e.addFrustration("error_click"), {
                                                    isRage: !0
                                                };
                                                let n = t.some(t => t.getUserActivity().selection);
                                                return t.forEach(t => {
                                                    t.hasError && t.addFrustration("error_click"), nr(t) && !n && t.addFrustration("dead_click")
                                                }), {
                                                    isRage: !1
                                                }
                                            }(n, r);
                                            i ? (n.forEach(t => t.discard()), r.stop((0, A.nx)()), r.validate(n.map(t => t.event))) : (r.discard(), n.forEach(t => t.validate()))
                                        })
                                    }
                                }

                                function l() {
                                    i && i.stop()
                                }
                            }(t, a, o, n)), {
                                addAction: e => {
                                    t.notify(12, nu(e))
                                },
                                actionContexts: d,
                                stop: f
                            }),
                            m = function(t) {
                                let e, n = requestAnimationFrame((0, b.dm)(() => {
                                        e = nF()
                                    })),
                                    r = nz(t).subscribe(t => {
                                        e = t
                                    }).unsubscribe;
                                return {
                                    get: () => e ? {
                                        viewport: e
                                    } : void 0,
                                    stop: () => {
                                        r(), n && cancelAnimationFrame(n)
                                    }
                                }
                            }(n),
                            y = function(t, e = function(t) {
                                return new g.c(e => (function(t, e) {
                                    let n = N(document.cookie, t),
                                        r = (0, K.yb)(() => {
                                            let r = N(document.cookie, t);
                                            r !== n && e(r)
                                        }, n4);
                                    return () => (0, K.vG)(r)
                                })(t, t => e.notify(t)))
                            }(n8)) {
                                var n;
                                let r = Z(n8) || (null == (n = window.Cypress) ? void 0 : n.env("traceId")),
                                    i = e.subscribe(t => {
                                        r = t
                                    });
                                return t.register(0, ({
                                    eventType: t
                                }) => {
                                    if ("string" == typeof r) return {
                                        type: t,
                                        session: {
                                            type: "ci_test"
                                        },
                                        ci_test: {
                                            test_execution_id: r
                                        }
                                    }
                                }), {
                                    stop: () => {
                                        i.unsubscribe()
                                    }
                                }
                            }(e);
                        e.register(0, ({
                            eventType: t
                        }) => {
                            let e = function() {
                                    let t = window._DATADOG_SYNTHETICS_PUBLIC_ID || Z("datadog-synthetics-public-id");
                                    return "string" == typeof t ? t : void 0
                                }(),
                                n = function() {
                                    let t = window._DATADOG_SYNTHETICS_RESULT_ID || Z("datadog-synthetics-result-id");
                                    return "string" == typeof t ? t : void 0
                                }();
                            if (e && n) return {
                                type: t,
                                session: {
                                    type: "synthetics"
                                },
                                synthetics: {
                                    test_id: e,
                                    result_id: n,
                                    injected: W()
                                }
                            }
                        }), h = {
                            view: {
                                "view.performance.lcp.resource_url": "string",
                                ...rn,
                                ...re
                            },
                            error: {
                                "error.message": "string",
                                "error.stack": "string",
                                "error.resource.url": "string",
                                "error.fingerprint": "string",
                                ...rn,
                                ...re,
                                ...rr
                            },
                            resource: {
                                "resource.url": "string",
                                ...(0, B.sr)(B.R9.WRITABLE_RESOURCE_GRAPHQL) ? {
                                    "resource.graphql": "object"
                                } : {},
                                ...rn,
                                ...re,
                                ...rr
                            },
                            action: {
                                "action.target.name": "string",
                                ...rn,
                                ...re,
                                ...rr
                            },
                            long_task: {
                                "long_task.scripts[].source_url": "string",
                                "long_task.scripts[].invoker": "string",
                                ...rn,
                                ...re
                            },
                            vital: { ...rn,
                                ...re
                            }
                        };
                        let v = {
                            error: n9("error", n.eventRateLimiterThreshold, c),
                            action: n9("action", n.eventRateLimiterThreshold, c),
                            vital: n9("vital", n.eventRateLimiterThreshold, c)
                        };
                        return t.subscribe(12, ({
                            startTime: i,
                            duration: a,
                            rawRumEvent: o,
                            domainContext: c,
                            customerContext: d
                        }) => {
                            let f = u.findView(i),
                                p = s.findUrl(i),
                                g = r.findTrackedSession(i);
                            if (g && f && !p && (0, B.sr)(B.R9.MISSING_URL_CONTEXT_TELEMETRY) && (0, w.A2)("Missing URL entry", {
                                    debug: {
                                        eventType: o.type,
                                        startTime: i,
                                        urlEntries: s.getAllEntries(),
                                        urlDeletedEntries: s.getDeletedEntries(),
                                        viewEntries: u.getAllEntries(),
                                        viewDeletedEntries: u.getDeletedEntries()
                                    }
                                }), g && f && p) {
                                let r = l(),
                                    s = {
                                        _dd: {
                                            format_version: 2,
                                            drift: (0, A.TP)(),
                                            configuration: {
                                                session_sample_rate: (0, J.LI)(n.sessionSampleRate, 3),
                                                session_replay_sample_rate: (0, J.LI)(n.sessionReplaySampleRate, 3)
                                            },
                                            browser_sdk_version: (0, j.d0)() ? "6.6.3" : void 0
                                        },
                                        application: {
                                            id: n.applicationId
                                        },
                                        date: (0, A.nx)(),
                                        source: "browser",
                                        session: {
                                            id: g.id,
                                            type: "user"
                                        },
                                        display: m.get(),
                                        connectivity: (0, n7.q)(),
                                        context: r.context
                                    },
                                    u = (0, x.kg)(s, e.triggerHook(0, {
                                        eventType: o.type,
                                        startTime: i,
                                        duration: a
                                    }), {
                                        context: d
                                    }, o);
                                "has_replay" in u.session || (u.session.has_replay = r.hasReplay), "view" === u.type && (u.session.sampled_for_replay = 1 === g.sessionReplay), g.anonymousId && !r.user.anonymous_id && n.trackAnonymousUser && (r.user.anonymous_id = g.anonymousId), (0, Y.RI)(r.user) || (u.usr = r.user), !(0, Y.RI)(r.account) && r.account.id && (u.account = r.account),
                                    function(t, e, n, r) {
                                        var i;
                                        if (e) {
                                            let r = function(t, e, n) {
                                                let r = (0, x.Go)(t),
                                                    i = n(r);
                                                return (0, te.WP)(e).forEach(([e, n]) => (function t(e, n, r, i) {
                                                    let [a, ...o] = r;
                                                    if ("[]" === a) {
                                                        Array.isArray(e) && Array.isArray(n) && e.forEach((e, r) => t(e, n[r], o, i));
                                                        return
                                                    }
                                                    if (rt(e) && rt(n)) {
                                                        if (o.length > 0) return t(e[a], n[a], o, i);
                                                        var s = e,
                                                            u = a,
                                                            l = n[a],
                                                            c = i;
                                                        let r = (0, tO.P)(l);
                                                        r === c ? s[u] = (0, C.a)(l) : "object" === c && ("undefined" === r || "null" === r) && (s[u] = {})
                                                    }
                                                })(t, r, e.split(/\.|(?=\[\])/), n)), i
                                            }(t, h[t.type], t => e(t, n));
                                            if (!1 === r && "view" !== t.type) return !1;
                                            !1 === r && R.Vy.warn("Can't dismiss view events using beforeSend!")
                                        }
                                        return !(null == (i = r[t.type]) ? void 0 : i.isLimitReached())
                                    }(u, n.beforeSend, c, v) && ((0, Y.RI)(u.context) && delete u.context, t.notify(13, u))
                            }
                        }), {
                            pageStateHistory: i,
                            addAction: p.addAction,
                            actionContexts: p.actionContexts,
                            stop: () => {
                                p.stop(), y.stop(), m.stop(), u.stop(), i.stop(), s.stop()
                            }
                        }
                    }($, U, t, tf, tv, tp, tk, tw, tb, tR, H);
                P.push(tN), (0, w.JK)();
                let {
                    addTiming: tM,
                    startView: tL,
                    setViewName: tU,
                    setViewContext: tq,
                    setViewContextProperty: tV,
                    getViewContext: tF,
                    stop: tW
                } = (d = location, $.subscribe(4, n => $.notify(12, function(t, e, n) {
                    var r, i, a, o, s, u, l, c, d, f, p, h, m, g, y, v, _, b;
                    let w = n.getReplayStats(t.id),
                        S = null == (i = null == (r = t.commonViewMetrics) ? void 0 : r.cumulativeLayoutShift) ? void 0 : i.devicePixelRatio,
                        x = {
                            _dd: {
                                document_version: t.documentVersion,
                                replay_stats: w,
                                cls: S ? {
                                    device_pixel_ratio: S
                                } : void 0,
                                configuration: {
                                    start_session_replay_recording_manually: e.startSessionReplayRecordingManually
                                }
                            },
                            date: t.startClocks.timeStamp,
                            type: "view",
                            view: {
                                action: {
                                    count: t.eventCounts.actionCount
                                },
                                frustration: {
                                    count: t.eventCounts.frustrationCount
                                },
                                cumulative_layout_shift: null == (a = t.commonViewMetrics.cumulativeLayoutShift) ? void 0 : a.value,
                                cumulative_layout_shift_time: (0, A.Zj)(null == (o = t.commonViewMetrics.cumulativeLayoutShift) ? void 0 : o.time),
                                cumulative_layout_shift_target_selector: null == (s = t.commonViewMetrics.cumulativeLayoutShift) ? void 0 : s.targetSelector,
                                first_byte: (0, A.Zj)(null == (u = t.initialViewMetrics.navigationTimings) ? void 0 : u.firstByte),
                                dom_complete: (0, A.Zj)(null == (l = t.initialViewMetrics.navigationTimings) ? void 0 : l.domComplete),
                                dom_content_loaded: (0, A.Zj)(null == (c = t.initialViewMetrics.navigationTimings) ? void 0 : c.domContentLoaded),
                                dom_interactive: (0, A.Zj)(null == (d = t.initialViewMetrics.navigationTimings) ? void 0 : d.domInteractive),
                                error: {
                                    count: t.eventCounts.errorCount
                                },
                                first_contentful_paint: (0, A.Zj)(t.initialViewMetrics.firstContentfulPaint),
                                first_input_delay: (0, A.Zj)(null == (f = t.initialViewMetrics.firstInput) ? void 0 : f.delay),
                                first_input_time: (0, A.Zj)(null == (p = t.initialViewMetrics.firstInput) ? void 0 : p.time),
                                first_input_target_selector: null == (h = t.initialViewMetrics.firstInput) ? void 0 : h.targetSelector,
                                interaction_to_next_paint: (0, A.Zj)(null == (m = t.commonViewMetrics.interactionToNextPaint) ? void 0 : m.value),
                                interaction_to_next_paint_time: (0, A.Zj)(null == (g = t.commonViewMetrics.interactionToNextPaint) ? void 0 : g.time),
                                interaction_to_next_paint_target_selector: null == (y = t.commonViewMetrics.interactionToNextPaint) ? void 0 : y.targetSelector,
                                is_active: t.isActive,
                                name: t.name,
                                largest_contentful_paint: (0, A.Zj)(null == (v = t.initialViewMetrics.largestContentfulPaint) ? void 0 : v.value),
                                largest_contentful_paint_target_selector: null == (_ = t.initialViewMetrics.largestContentfulPaint) ? void 0 : _.targetSelector,
                                load_event: (0, A.Zj)(null == (b = t.initialViewMetrics.navigationTimings) ? void 0 : b.loadEvent),
                                loading_time: eg((0, A.Zj)(t.commonViewMetrics.loadingTime)),
                                loading_type: t.loadingType,
                                long_task: {
                                    count: t.eventCounts.longTaskCount
                                },
                                performance: function({
                                    cumulativeLayoutShift: t,
                                    interactionToNextPaint: e
                                }, {
                                    firstContentfulPaint: n,
                                    firstInput: r,
                                    largestContentfulPaint: i
                                }) {
                                    return {
                                        cls: t && {
                                            score: t.value,
                                            timestamp: (0, A.Zj)(t.time),
                                            target_selector: t.targetSelector,
                                            previous_rect: t.previousRect,
                                            current_rect: t.currentRect
                                        },
                                        fcp: n && {
                                            timestamp: (0, A.Zj)(n)
                                        },
                                        fid: r && {
                                            duration: (0, A.Zj)(r.delay),
                                            timestamp: (0, A.Zj)(r.time),
                                            target_selector: r.targetSelector
                                        },
                                        inp: e && {
                                            duration: (0, A.Zj)(e.value),
                                            timestamp: (0, A.Zj)(e.time),
                                            target_selector: e.targetSelector
                                        },
                                        lcp: i && {
                                            timestamp: (0, A.Zj)(i.value),
                                            target_selector: i.targetSelector,
                                            resource_url: i.resourceUrl
                                        }
                                    }
                                }(t.commonViewMetrics, t.initialViewMetrics),
                                resource: {
                                    count: t.eventCounts.resourceCount
                                },
                                time_spent: (0, A.Zj)(t.duration)
                            },
                            display: t.commonViewMetrics.scroll ? {
                                scroll: {
                                    max_depth: t.commonViewMetrics.scroll.maxDepth,
                                    max_depth_scroll_top: t.commonViewMetrics.scroll.maxDepthScrollTop,
                                    max_scroll_height: t.commonViewMetrics.scroll.maxScrollHeight,
                                    max_scroll_height_time: (0, A.Zj)(t.commonViewMetrics.scroll.maxScrollHeightTime)
                                }
                            } : void 0,
                            session: {
                                has_replay: !!w || void 0,
                                is_active: !!t.sessionIsActive && void 0
                            },
                            privacy: {
                                replay_level: e.defaultPrivacyLevel
                            }
                        };
                    return (0, Y.RI)(t.customTimings) || (x.view.custom_timings = (0, Y.LG)(t.customTimings, A.Zj)), {
                        rawRumEvent: x,
                        startTime: t.startClocks.relative,
                        duration: t.duration,
                        domainContext: {
                            location: t.location
                        }
                    }
                }(n, t, e))), U.register(0, ({
                    startTime: t,
                    eventType: e
                }) => {
                    let {
                        service: n,
                        version: r,
                        id: i,
                        name: a,
                        context: o
                    } = tb.findView(t);
                    return {
                        type: e,
                        service: n,
                        version: r,
                        context: o,
                        view: {
                            id: i,
                            name: a
                        }
                    }
                }), function(t, e, n, r, i, a, o, s) {
                    let u, l = new Set,
                        d = f("initial_load", (0, A.Oc)(), s);

                    function f(a, o, s) {
                        let u = function(t, e, n, r, i, a, o = (0, A.M8)(), s) {
                            let u, l = O(),
                                d = new g.c,
                                f = {},
                                p = 0,
                                h = (0, Y.yG)(i),
                                y = tB(),
                                v = !0,
                                _ = null == s ? void 0 : s.name,
                                w = (null == s ? void 0 : s.service) || r.service,
                                S = (null == s ? void 0 : s.version) || r.version,
                                x = null == s ? void 0 : s.context;
                            x && y.setContext(x);
                            let k = {
                                id: l,
                                name: _,
                                startClocks: o,
                                service: w,
                                version: S,
                                context: x
                            };
                            t.notify(1, k), t.notify(2, k);
                            let {
                                throttled: C,
                                cancel: T
                            } = (0, q.n)(B, 3e3, {
                                leading: !1
                            }), {
                                setLoadEvent: E,
                                setViewEnd: I,
                                stop: P,
                                stopINPTracking: N,
                                getCommonViewMetrics: M
                            } = function(t, e, n, r, i, a, o) {
                                let s = {},
                                    {
                                        stop: u,
                                        setLoadEvent: l
                                    } = function(t, e, n, r, i, a, o) {
                                        var s;
                                        let u = "initial_load" === i,
                                            l = !0,
                                            c = [],
                                            d = nO(r);

                                        function f() {
                                            if (!l && !u && c.length > 0) {
                                                let t = Math.max(...c);
                                                t < d.timeStamp && o(t)
                                            }
                                        }
                                        let {
                                            stop: p
                                        } = (s = t => {
                                            l && (l = !1, t.hadActivity && c.push((0, A.vk)(a.timeStamp, t.end)), f())
                                        }, eb(ew(t, e, n, r), s, void 0));
                                        return {
                                            stop: () => {
                                                p(), d.stop()
                                            },
                                            setLoadEvent: t => {
                                                u && (u = !1, c.push(t), f())
                                            }
                                        }
                                    }(t, e, n, r, a, o, t => {
                                        s.loadingTime = t, i()
                                    }),
                                    {
                                        stop: d
                                    } = function(t, e, n, r = function(t, e = nB) {
                                        return new g.c(n => {
                                            if (window.ResizeObserver) {
                                                let r = (0, q.n)(function() {
                                                        n.notify(function() {
                                                            let t = nV(),
                                                                {
                                                                    height: e
                                                                } = nF();
                                                            return {
                                                                scrollHeight: Math.round((document.scrollingElement || document.documentElement).scrollHeight),
                                                                scrollDepth: Math.round(e + t),
                                                                scrollTop: t
                                                            }
                                                        }())
                                                    }, e, {
                                                        leading: !1,
                                                        trailing: !0
                                                    }),
                                                    i = document.scrollingElement || document.documentElement,
                                                    a = new ResizeObserver((0, b.dm)(r.throttled));
                                                i && a.observe(i);
                                                let o = (0, tj.q)(t, window, "scroll", r.throttled, {
                                                    passive: !0
                                                });
                                                return () => {
                                                    r.cancel(), a.disconnect(), o.stop()
                                                }
                                            }
                                        })
                                    }(t)) {
                                        let i = 0,
                                            a = 0,
                                            o = 0,
                                            s = r.subscribe(({
                                                scrollDepth: t,
                                                scrollTop: r,
                                                scrollHeight: s
                                            }) => {
                                                let u = !1;
                                                if (t > i && (i = t, u = !0), s > a) {
                                                    a = s;
                                                    let t = (0, A.$S)();
                                                    o = (0, A.vk)(e.relative, t), u = !0
                                                }
                                                u && n({
                                                    maxDepth: Math.min(i, a),
                                                    maxDepthScrollTop: r,
                                                    maxScrollHeight: a,
                                                    maxScrollHeightTime: o
                                                })
                                            });
                                        return {
                                            stop: () => s.unsubscribe()
                                        }
                                    }(r, o, t => {
                                        s.scroll = t
                                    }),
                                    {
                                        stop: f
                                    } = function(t, e, n) {
                                        let r, i, a, o, s;
                                        if (!(e_(m.LAYOUT_SHIFT) && "WeakRef" in window)) return {
                                            stop: q.l
                                        };
                                        let u = 0;
                                        n({
                                            value: 0
                                        });
                                        let l = (o = 0, s = 0, {
                                                update: t => {
                                                    let e;
                                                    return void 0 === i || t.startTime - a >= nM || t.startTime - i >= nN ? (i = a = t.startTime, s = o = t.value, e = !0) : (o += t.value, a = t.startTime, (e = t.value > s) && (s = t.value)), {
                                                        cumulatedValue: o,
                                                        isMaxValue: e
                                                    }
                                                }
                                            }),
                                            c = ev(t, {
                                                type: m.LAYOUT_SHIFT,
                                                buffered: !0
                                            }).subscribe(i => {
                                                var a;
                                                for (let o of i) {
                                                    if (o.hadRecentInput || o.startTime < e) continue;
                                                    let {
                                                        cumulatedValue: i,
                                                        isMaxValue: s
                                                    } = l.update(o);
                                                    if (s) {
                                                        let t = o.sources.find(t => !!t.node && ek(t.node));
                                                        r = {
                                                            target: (null == t ? void 0 : t.node) ? new WeakRef(t.node) : void 0,
                                                            time: (0, A.vk)(e, o.startTime),
                                                            previousRect: null == t ? void 0 : t.previousRect,
                                                            currentRect: null == t ? void 0 : t.currentRect,
                                                            devicePixelRatio: window.devicePixelRatio
                                                        }
                                                    }
                                                    if (i > u) {
                                                        u = i;
                                                        let e = null == (a = null == r ? void 0 : r.target) ? void 0 : a.deref();
                                                        n({
                                                            value: (0, J.LI)(u, 4),
                                                            targetSelector: e && e5(e, t.actionNameAttribute),
                                                            time: null == r ? void 0 : r.time,
                                                            previousRect: (null == r ? void 0 : r.previousRect) ? nP(r.previousRect) : void 0,
                                                            currentRect: (null == r ? void 0 : r.currentRect) ? nP(r.currentRect) : void 0,
                                                            devicePixelRatio: null == r ? void 0 : r.devicePixelRatio
                                                        })
                                                    }
                                                }
                                            });
                                        return {
                                            stop: () => {
                                                c.unsubscribe()
                                            }
                                        }
                                    }(r, o.relative, t => {
                                        s.cumulativeLayoutShift = t, i()
                                    }),
                                    {
                                        stop: p,
                                        getInteractionToNextPaint: h,
                                        setViewEnd: y
                                    } = function(t, e, n) {
                                        let r, i;
                                        if (!(e_(m.EVENT) && window.PerformanceEventTiming && "interactionId" in PerformanceEventTiming.prototype)) return {
                                            getInteractionToNextPaint: () => void 0,
                                            setViewEnd: q.l,
                                            stop: q.l
                                        };
                                        let {
                                            getViewInteractionCount: a,
                                            stopViewInteractionCount: o
                                        } = function(t) {
                                            "interactionCount" in performance || c || (c = new window.PerformanceObserver((0, b.dm)(t => {
                                                t.getEntries().forEach(t => {
                                                    t.interactionId && (nD = Math.min(nD, t.interactionId), nL = ((n$ = Math.max(n$, t.interactionId)) - nD) / 7 + 1)
                                                })
                                            }))).observe({
                                                type: "event",
                                                buffered: !0,
                                                durationThreshold: 0
                                            });
                                            let e = "initial_load" === t ? 0 : nU(),
                                                n = {
                                                    stopped: !1
                                                };
                                            return {
                                                getViewInteractionCount: () => n.stopped ? n.interactionCount : nU() - e,
                                                stopViewInteractionCount: () => {
                                                    n = {
                                                        stopped: !0,
                                                        interactionCount: nU() - e
                                                    }
                                                }
                                            }
                                        }(n), s = 1 / 0, u = function(t) {
                                            let e = [];

                                            function n() {
                                                e.sort((t, e) => e.duration - t.duration).splice(10)
                                            }
                                            return {
                                                process(t) {
                                                    let r = e.findIndex(e => t.interactionId === e.interactionId),
                                                        i = e[e.length - 1]; - 1 !== r ? t.duration > e[r].duration && (e[r] = t, n()) : (e.length < 10 || t.duration > i.duration) && (e.push(t), n())
                                                },
                                                estimateP98Interaction() {
                                                    let n = Math.min(e.length - 1, Math.floor(t() / 50));
                                                    return e[n]
                                                }
                                            }
                                        }(a), l = -1;

                                        function d(n) {
                                            for (let t of n) t.interactionId && t.startTime >= e && t.startTime <= s && u.process(t);
                                            let a = u.estimateP98Interaction();
                                            a && a.duration !== l && (l = a.duration, i = (0, A.vk)(e, a.startTime), !(r = function(t) {
                                                let e = na.get(t);
                                                return na.delete(t), e
                                            }(a.startTime)) && a.target && ek(a.target) && (r = e5(a.target, t.actionNameAttribute)))
                                        }
                                        let f = ev(t, {
                                                type: m.FIRST_INPUT,
                                                buffered: !0
                                            }).subscribe(d),
                                            p = ev(t, {
                                                type: m.EVENT,
                                                durationThreshold: 40,
                                                buffered: !0
                                            }).subscribe(d);
                                        return {
                                            getInteractionToNextPaint: () => l >= 0 ? {
                                                value: Math.min(l, nj),
                                                targetSelector: r,
                                                time: i
                                            } : a() ? {
                                                value: 0
                                            } : void 0,
                                            setViewEnd: t => {
                                                s = t, o()
                                            },
                                            stop: () => {
                                                p.unsubscribe(), f.unsubscribe()
                                            }
                                        }
                                    }(r, o.relative, a);
                                return {
                                    stop: () => {
                                        u(), f(), d()
                                    },
                                    stopINPTracking: p,
                                    setLoadEvent: l,
                                    setViewEnd: y,
                                    getCommonViewMetrics: () => (s.interactionToNextPaint = h(), s)
                                }
                            }(t, e, n, r, F, a, o), {
                                stop: L,
                                initialViewMetrics: D
                            } = "initial_load" === a ? function(t, e, n) {
                                var r;
                                let i = {},
                                    {
                                        stop: a
                                    } = function(t, e, n = nA) {
                                        let r;
                                        var i = t,
                                            a = () => {
                                                var t;
                                                let r = n();
                                                r.loadEventEnd <= 0 || e({
                                                    domComplete: (t = r).domComplete,
                                                    domContentLoaded: t.domContentLoadedEventEnd,
                                                    domInteractive: t.domInteractive,
                                                    loadEvent: t.loadEventEnd,
                                                    firstByte: t.responseStart >= 0 && t.responseStart <= (0, A.$S)() ? t.responseStart : void 0
                                                })
                                            };
                                        let {
                                            stop: o
                                        } = (0, nS.H)(i, "complete", () => {
                                            r = (0, K.wg)(() => a())
                                        });
                                        return {
                                            stop: () => {
                                                o(), (0, K.DJ)(r)
                                            }
                                        }
                                    }(t, t => {
                                        e(t.loadEvent), i.navigationTimings = t, n()
                                    }),
                                    o = nO(t),
                                    {
                                        stop: s
                                    } = (r = t => {
                                        i.firstContentfulPaint = t, n()
                                    }, {
                                        stop: ev(t, {
                                            type: m.PAINT,
                                            buffered: !0
                                        }).subscribe(t => {
                                            let e = t.find(t => "first-contentful-paint" === t.name && t.startTime < o.timeStamp && t.startTime < nR);
                                            e && r(e.startTime)
                                        }).unsubscribe
                                    }),
                                    {
                                        stop: u
                                    } = function(t, e, n, r) {
                                        let i = 1 / 0,
                                            {
                                                stop: a
                                            } = (0, tj.l)(t, n, ["pointerdown", "keydown"], t => {
                                                i = t.timeStamp
                                            }, {
                                                capture: !0,
                                                once: !0
                                            }),
                                            o = 0,
                                            s = ev(t, {
                                                type: m.LARGEST_CONTENTFUL_PAINT,
                                                buffered: !0
                                            }).subscribe(n => {
                                                let a = (0, te.Uk)(n, t => t.entryType === m.LARGEST_CONTENTFUL_PAINT && t.startTime < i && t.startTime < e.timeStamp && t.startTime < nI && t.size > o);
                                                if (a) {
                                                    var s;
                                                    let e;
                                                    a.element && (e = e5(a.element, t.actionNameAttribute)), r({
                                                        value: a.startTime,
                                                        targetSelector: e,
                                                        resourceUrl: "" === (s = a).url ? void 0 : s.url
                                                    }), o = a.size
                                                }
                                            });
                                        return {
                                            stop: () => {
                                                a(), s.unsubscribe()
                                            }
                                        }
                                    }(t, o, window, t => {
                                        i.largestContentfulPaint = t, n()
                                    }),
                                    {
                                        stop: l
                                    } = function(t, e, n) {
                                        let r = ev(t, {
                                            type: m.FIRST_INPUT,
                                            buffered: !0
                                        }).subscribe(r => {
                                            let i = r.find(t => t.startTime < e.timeStamp);
                                            if (i) {
                                                let e, r = (0, A.vk)(i.startTime, i.processingStart);
                                                i.target && ek(i.target) && (e = e5(i.target, t.actionNameAttribute)), n({
                                                    delay: r >= 0 ? r : 0,
                                                    time: i.startTime,
                                                    targetSelector: e
                                                })
                                            }
                                        });
                                        return {
                                            stop: () => {
                                                r.unsubscribe()
                                            }
                                        }
                                    }(t, o, t => {
                                        i.firstInput = t, n()
                                    });
                                return {
                                    stop: function() {
                                        a(), s(), u(), l(), o.stop()
                                    },
                                    initialViewMetrics: i
                                }
                            }(r, E, F) : {
                                stop: q.l,
                                initialViewMetrics: {}
                            }, {
                                stop: $,
                                eventCounts: U
                            } = function(t, e, n) {
                                let {
                                    stop: r,
                                    eventCounts: i
                                } = ey({
                                    lifeCycle: t,
                                    isChildEvent: t => t.view.id === e,
                                    onChange: n
                                });
                                return {
                                    stop: r,
                                    eventCounts: i
                                }
                            }(t, l, F), j = (0, K.yb)(B, nG), V = t.subscribe(11, t => {
                                t.reason === tY.y5.UNLOADING && B()
                            });

                            function z() {
                                t.notify(3, {
                                    id: l,
                                    name: _,
                                    context: y.getContext(),
                                    startClocks: o
                                })
                            }

                            function F() {
                                z(), C()
                            }

                            function B() {
                                T(), z(), p += 1;
                                let e = void 0 === u ? (0, A.nx)() : u.timeStamp;
                                t.notify(4, {
                                    customTimings: f,
                                    documentVersion: p,
                                    id: l,
                                    name: _,
                                    service: w,
                                    version: S,
                                    context: y.getContext(),
                                    loadingType: a,
                                    location: h,
                                    startClocks: o,
                                    commonViewMetrics: M(),
                                    initialViewMetrics: D,
                                    duration: (0, A.vk)(o.timeStamp, e),
                                    isActive: void 0 === u,
                                    sessionIsActive: v,
                                    eventCounts: U
                                })
                            }
                            return B(), y.changeObservable.subscribe(F), {
                                get name() {
                                    return _
                                },
                                service: w,
                                version: S,
                                contextManager: y,
                                stopObservable: d,
                                end(e = {}) {
                                    var n, r;
                                    u || (u = null != (n = e.endClocks) ? n : (0, A.M8)(), v = null == (r = e.sessionIsActive) || r, t.notify(5, {
                                        endClocks: u
                                    }), t.notify(6, {
                                        endClocks: u
                                    }), (0, K.vG)(j), I(u.relative), P(), V.unsubscribe(), B(), (0, K.wg)(() => {
                                        this.stop()
                                    }, nH))
                                },
                                stop() {
                                    L(), $(), N(), d.notify()
                                },
                                addTiming(t, e) {
                                    if (u) return;
                                    let n = (0, A.pu)(e) ? e : (0, A.vk)(o.timeStamp, e);
                                    f[function(t) {
                                        let e = t.replace(/[^a-zA-Z0-9-_.@$]/g, "_");
                                        return e !== t && R.Vy.warn(`Invalid timing name: ${t}, sanitized to: ${e}`), e
                                    }(t)] = n, F()
                                },
                                setViewName(t) {
                                    _ = t, B()
                                }
                            }
                        }(e, n, r, i, t, a, o, s);
                        return l.add(u), u.stopObservable.subscribe(() => {
                            l.delete(u)
                        }), u
                    }
                    return e.subscribe(10, () => {
                        d = f("route_change", void 0, {
                            name: d.name,
                            service: d.service,
                            version: d.version,
                            context: d.contextManager.getContext()
                        })
                    }), e.subscribe(9, () => {
                        d.end({
                            sessionIsActive: !1
                        })
                    }), o && (u = a.subscribe(({
                        oldLocation: t,
                        newLocation: e
                    }) => {
                        var n, r;
                        n = t, r = e, (n.pathname !== r.pathname || ! function(t) {
                            let e = t.substring(1);
                            return "" !== e && !!document.getElementById(e)
                        }(r.hash) && nZ(r.hash) !== nZ(n.hash)) && (d.end(), d = f("route_change"))
                    })), {
                        addTiming: (t, e = (0, A.nx)()) => {
                            d.addTiming(t, e)
                        },
                        startView: (t, e) => {
                            d.end({
                                endClocks: e
                            }), d = f("route_change", e, t)
                        },
                        setViewContext: t => {
                            d.contextManager.setContext(t)
                        },
                        setViewContextProperty: (t, e) => {
                            d.contextManager.setContextProperty(t, e)
                        },
                        setViewName: t => {
                            d.setViewName(t)
                        },
                        getViewContext: () => d.contextManager.getContext(),
                        stop: () => {
                            u && u.unsubscribe(), d.end(), l.forEach(t => t.stop())
                        }
                    }
                }(d, $, tp, tk, t, tm, !t.trackViewsManually, r));
                P.push(tW);
                let {
                    stop: tQ
                } = function(t, e, n, r = function() {
                    let t = [];

                    function e(e) {
                        let r;
                        if (e.didTimeout) {
                            let t = performance.now();
                            r = () => 30 - (performance.now() - t)
                        } else r = e.timeRemaining.bind(e);
                        for (; r() > 0 && t.length;) t.shift()();
                        t.length && n()
                    }

                    function n() {
                        (0, nv.BB)(e, {
                            timeout: n_
                        })
                    }
                    return {
                        push(e) {
                            1 === t.push(e) && n()
                        }
                    }
                }(), i = function(t, e, n = nA) {
                    (0, nS.H)(t, "interactive", () => {
                        let t = n(),
                            r = Object.assign(t.toJSON(), {
                                entryType: m.RESOURCE,
                                initiatorType: ee,
                                duration: t.responseEnd,
                                traceId: function(t) {
                                    let e = function(t) {
                                        let e = t.querySelector("meta[name=dd-trace-id]"),
                                            n = t.querySelector("meta[name=dd-trace-time]");
                                        return nk(e && e.content, n && n.content)
                                    }(t) || function(t) {
                                        let e = function(t) {
                                            for (let e = 0; e < t.childNodes.length; e += 1) {
                                                let n = nC(t.childNodes[e]);
                                                if (n) return n
                                            }
                                            if (t.body)
                                                for (let e = t.body.childNodes.length - 1; e >= 0; e -= 1) {
                                                    let n = t.body.childNodes[e],
                                                        r = nC(n);
                                                    if (r) return r;
                                                    if (!ex(n)) break
                                                }
                                        }(t);
                                        if (e) return nk(N(e, "trace-id"), N(e, "trace-time"))
                                    }(t);
                                    if (!(!e || e.traceTime <= (0, A.x3)() - nx)) return e.traceId
                                }(document),
                                toJSON: () => ({ ...r,
                                    toJSON: void 0
                                })
                            });
                        e(r)
                    })
                }) {
                    t.subscribe(8, t => {
                        o(() => (function(t, e, n) {
                            var r, i, a;
                            let o = function(t) {
                                    if (!performance || !("getEntriesByName" in performance)) return;
                                    let e = performance.getEntriesByName(t.url, "resource");
                                    if (!e.length || !("toJSON" in e[0])) return;
                                    let n = e.filter(t => !nb.has(t)).filter(t => ea(t) && eo(t)).filter(e => {
                                        var n, r, i;
                                        return n = e, r = t.startClocks.relative, i = nw({
                                            startTime: t.startClocks.relative,
                                            duration: t.duration
                                        }), n.startTime >= r - 1 && nw(n) <= (0, A.Gw)(i, 1)
                                    });
                                    if (1 === n.length) return nb.add(n[0]), n[0].toJSON()
                                }(t),
                                s = o ? (0, A.FR)(o.startTime) : t.startClocks,
                                u = function(t, e) {
                                    if (t.traceSampled && t.traceId && t.spanId) return {
                                        _dd: {
                                            span_id: t.spanId.toString(),
                                            trace_id: t.traceId.toString(),
                                            rule_psr: e.rulePsr
                                        }
                                    }
                                }(t, e);
                            if (!e.trackResources && !u) return;
                            let l = "xhr" === t.type ? "xhr" : "fetch",
                                c = o ? nE(o) : void 0,
                                d = o ? ei(o) : (r = n, i = s, a = t.duration, r.wasInPageStateDuringPeriod("frozen", i.relative, a) ? void 0 : a),
                                f = (0, x.kg)({
                                    date: s.timeStamp,
                                    resource: {
                                        id: O(),
                                        type: l,
                                        duration: (0, A.Zj)(d),
                                        method: t.method,
                                        status_code: t.status,
                                        protocol: o && eu(o),
                                        url: ef(t.url) ? ep(t.url) : t.url,
                                        delivery_type: o && el(o)
                                    },
                                    type: "resource",
                                    _dd: {
                                        discarded: !e.trackResources
                                    }
                                }, u, c);
                            return {
                                startTime: s.relative,
                                duration: d,
                                rawRumEvent: f,
                                domainContext: {
                                    performanceEntry: o,
                                    xhr: t.xhr,
                                    response: t.response,
                                    requestInput: t.input,
                                    requestInit: t.init,
                                    error: t.error,
                                    isAborted: t.isAborted,
                                    handlingStack: t.handlingStack
                                }
                            }
                        })(t, e, n))
                    });
                    let a = ev(e, {
                        type: m.RESOURCE,
                        buffered: !0
                    }).subscribe(t => {
                        for (let n of t) "xmlhttprequest" !== n.initiatorType && "fetch" !== n.initiatorType && o(() => nT(n, e))
                    });

                    function o(e) {
                        r.push(() => {
                            let n = e();
                            n && t.notify(12, n)
                        })
                    }
                    return i(e, t => {
                        o(() => nT(t, e))
                    }), {
                        stop: () => {
                            a.unsubscribe()
                        }
                    }
                }($, t, tv);
                if (P.push(tQ), t.trackLongTasks)
                    if (e_(m.LONG_ANIMATION_FRAME)) {
                        let {
                            stop: e
                        } = function(t, e) {
                            let n = ev(e, {
                                type: m.LONG_ANIMATION_FRAME,
                                buffered: !0
                            }).subscribe(e => {
                                for (let n of e) {
                                    let e = (0, A.FR)(n.startTime),
                                        r = {
                                            date: e.timeStamp,
                                            long_task: {
                                                id: O(),
                                                entry_type: "long-animation-frame",
                                                duration: (0, A.Zj)(n.duration),
                                                blocking_duration: (0, A.Zj)(n.blockingDuration),
                                                first_ui_event_timestamp: (0, A.Zj)(n.firstUIEventTimestamp),
                                                render_start: (0, A.Zj)(n.renderStart),
                                                style_and_layout_start: (0, A.Zj)(n.styleAndLayoutStart),
                                                start_time: (0, A.Zj)(n.startTime),
                                                scripts: n.scripts.map(t => ({
                                                    duration: (0, A.Zj)(t.duration),
                                                    pause_duration: (0, A.Zj)(t.pauseDuration),
                                                    forced_style_and_layout_duration: (0, A.Zj)(t.forcedStyleAndLayoutDuration),
                                                    start_time: (0, A.Zj)(t.startTime),
                                                    execution_start: (0, A.Zj)(t.executionStart),
                                                    source_url: t.sourceURL,
                                                    source_function_name: t.sourceFunctionName,
                                                    source_char_position: t.sourceCharPosition,
                                                    invoker: t.invoker,
                                                    invoker_type: t.invokerType,
                                                    window_attribution: t.windowAttribution
                                                }))
                                            },
                                            type: "long_task",
                                            _dd: {
                                                discarded: !1
                                            }
                                        };
                                    t.notify(12, {
                                        rawRumEvent: r,
                                        startTime: e.relative,
                                        duration: n.duration,
                                        domainContext: {
                                            performanceEntry: n
                                        }
                                    })
                                }
                            });
                            return {
                                stop: () => n.unsubscribe()
                            }
                        }($, t);
                        P.push(e)
                    } else {
                        _ = $, ev(S = t, {
                            type: m.LONG_TASK,
                            buffered: !0
                        }).subscribe(t => {
                            for (let e of t) {
                                if (e.entryType !== m.LONG_TASK || !S.trackLongTasks) break;
                                let t = (0, A.FR)(e.startTime),
                                    n = {
                                        date: t.timeStamp,
                                        long_task: {
                                            id: O(),
                                            entry_type: "long-task",
                                            duration: (0, A.Zj)(e.duration)
                                        },
                                        type: "long_task",
                                        _dd: {
                                            discarded: !1
                                        }
                                    };
                                _.notify(12, {
                                    rawRumEvent: n,
                                    startTime: t.relative,
                                    duration: e.duration,
                                    domainContext: {
                                        performanceEntry: e
                                    }
                                })
                            }
                        })
                    }
                let {
                    addError: tK
                } = function(t, e) {
                    var n, r, i, a;
                    let o = new g.c;
                    return n = o, (function(t) {
                        let e = t.map(t => {
                            var e;
                            return nh[t] || (nh[t] = (e = t, new g.c(t => {
                                let n = R.JZ[e];
                                return R.JZ[e] = (...r) => {
                                    n.apply(console, r);
                                    let i = (0, k.uC)("console error");
                                    (0, b.um)(() => {
                                        t.notify(function(t, e, n) {
                                            let r, i = t.map(t => {
                                                var e;
                                                return "string" == typeof(e = t) ? (0, C.a)(e) : (0, nd.bJ)(e) ? (0, k.NR)((0, nc.T)(e)) : (0, np.s)((0, C.a)(e), void 0, 2)
                                            }).join(" ");
                                            if (e === R.bP.error) {
                                                let e = t.find(nd.bJ);
                                                r = {
                                                    stack: e ? (0, k.Yn)((0, nc.T)(e)) : void 0,
                                                    fingerprint: (0, nd.Nt)(e),
                                                    causes: e ? (0, nd.Dr)(e, "console") : void 0,
                                                    startClocks: (0, A.M8)(),
                                                    message: i,
                                                    source: nf.g.CONSOLE,
                                                    handling: "handled",
                                                    handlingStack: n,
                                                    context: (0, nd.Qb)(e),
                                                    originalError: e
                                                }
                                            }
                                            return {
                                                api: e,
                                                message: i,
                                                error: r,
                                                handlingStack: n
                                            }
                                        }(r, e, i))
                                    })
                                }, () => {
                                    R.JZ[e] = n
                                }
                            }))), nh[t]
                        });
                        return (0, g.F)(...e)
                    })([R.bP.error]).subscribe(t => n.notify(t.error)), ! function(t) {
                        var e, n;
                        let r = (e, n) => {
                                let r = (0, nd.As)({
                                    stackTrace: e,
                                    originalError: n,
                                    startClocks: (0, A.M8)(),
                                    nonErrorPrefix: "Uncaught",
                                    source: nf.g.SOURCE,
                                    handling: "unhandled"
                                });
                                t.notify(r)
                            },
                            {
                                stop: i
                            } = (e = r, (0, V.H)(window, "onerror", ({
                                parameters: [t, n, r, i, a]
                            }) => {
                                let o;
                                e((0, nd.bJ)(a) ? (0, nc.T)(a) : (0, nc.h)(t, n, r, i), null != a ? a : t)
                            })),
                            {
                                stop: a
                            } = (n = r, (0, V.H)(window, "onunhandledrejection", ({
                                parameters: [t]
                            }) => {
                                let e = t.reason || "Empty reason";
                                n((0, nc.T)(e), e)
                            }))
                    }(o), r = e, i = o, (function(t, e) {
                        var n, r;
                        let i = [];
                        e.includes(nm.cspViolation) && i.push((n = t, new g.c(t => {
                            let {
                                stop: e
                            } = (0, tj.q)(n, document, "securitypolicyviolation", e => {
                                t.notify(function(t) {
                                    let e = `'${t.blockedURI}' blocked by '${t.effectiveDirective}' directive`;
                                    return ng({
                                        type: t.effectiveDirective,
                                        message: `${nm.cspViolation}: ${e}`,
                                        originalError: t,
                                        csp: {
                                            disposition: t.disposition
                                        },
                                        stack: ny(t.effectiveDirective, t.originalPolicy ? `${e} of the policy "${M(t.originalPolicy,100,"...")}"` : "no policy", t.sourceFile, t.lineNumber, t.columnNumber)
                                    })
                                }(e))
                            });
                            return e
                        })));
                        let a = e.filter(t => t !== nm.cspViolation);
                        return a.length && i.push((r = a, new g.c(t => {
                            if (!window.ReportingObserver) return;
                            let e = (0, b.dm)((e, n) => e.forEach(e => t.notify(function(t) {
                                    let {
                                        type: e,
                                        body: n
                                    } = t;
                                    return ng({
                                        type: n.id,
                                        message: `${e}: ${n.message}`,
                                        originalError: t,
                                        stack: ny(n.id, n.message, n.sourceFile, n.lineNumber, n.columnNumber)
                                    })
                                }(e)))),
                                n = new window.ReportingObserver(e, {
                                    types: r,
                                    buffered: !0
                                });
                            return n.observe(), () => {
                                n.disconnect()
                            }
                        }))), (0, g.F)(...i)
                    })(r, [nm.cspViolation, nm.intervention]).subscribe(t => i.notify(t)), o.subscribe(e => t.notify(14, {
                        error: e
                    })), (a = t).subscribe(14, ({
                        error: t,
                        customerContext: e
                    }) => {
                        e = (0, x.kg)(t.context, e), a.notify(12, {
                            customerContext: e,
                            ... function(t) {
                                let e = {
                                        date: t.startClocks.timeStamp,
                                        error: {
                                            id: O(),
                                            message: t.message,
                                            source: t.source,
                                            stack: t.stack,
                                            handling_stack: t.handlingStack,
                                            component_stack: t.componentStack,
                                            type: t.type,
                                            handling: t.handling,
                                            causes: t.causes,
                                            source_type: "browser",
                                            fingerprint: t.fingerprint,
                                            csp: t.csp
                                        },
                                        type: "error"
                                    },
                                    n = {
                                        error: t.originalError,
                                        handlingStack: t.handlingStack
                                    };
                                return {
                                    rawRumEvent: e,
                                    startTime: t.startClocks.relative,
                                    domainContext: n
                                }
                            }(t)
                        })
                    }), {
                        addError: ({
                            error: t,
                            handlingStack: e,
                            componentStack: n,
                            startClocks: r,
                            context: i
                        }) => {
                            let o = (0, nd.bJ)(t) ? (0, nc.T)(t) : void 0,
                                s = (0, nd.As)({
                                    stackTrace: o,
                                    originalError: t,
                                    handlingStack: e,
                                    componentStack: n,
                                    startClocks: r,
                                    nonErrorPrefix: "Provided",
                                    source: nf.g.CUSTOM,
                                    handling: "handled"
                                });
                            a.notify(14, {
                                customerContext: i,
                                error: s
                            })
                        }
                    }
                }($, t), t1 = {
                    clearTracingIfNeeded: tD,
                    traceFetch: e => t$(t, e, tf, tR, t => {
                        var n;
                        if (e.input instanceof Request && !(null == (n = e.init) ? void 0 : n.headers)) e.input = new Request(e.input), Object.keys(t).forEach(n => {
                            e.input.headers.append(n, t[n])
                        });
                        else {
                            e.init = (0, Y.yG)(e.init);
                            let n = [];
                            e.init.headers instanceof Headers ? e.init.headers.forEach((t, e) => {
                                n.push([e, t])
                            }) : Array.isArray(e.init.headers) ? e.init.headers.forEach(t => {
                                n.push(t)
                            }) : e.init.headers && Object.keys(e.init.headers).forEach(t => {
                                n.push([t, e.init.headers[t]])
                            }), e.init.headers = n.concat((0, te.WP)(t))
                        }
                    }),
                    traceXhr: (e, n) => t$(t, e, tf, tR, t => {
                        Object.keys(t).forEach(e => {
                            n.setRequestHeader(e, t[e])
                        })
                    })
                };
                (function(t, e, n) {
                    var r;
                    (!u && (r = e, u = new g.c(t => {
                        let {
                            stop: e
                        } = (0, V.H)(XMLHttpRequest.prototype, "open", t9), {
                            stop: n
                        } = (0, V.H)(XMLHttpRequest.prototype, "send", e => {
                            ! function({
                                target: t,
                                handlingStack: e
                            }, n, r) {
                                let i = t8.get(t);
                                if (!i) return;
                                i.state = "start", i.startClocks = (0, A.M8)(), i.isAborted = !1, i.xhr = t, i.handlingStack = e;
                                let a = !1,
                                    {
                                        stop: o
                                    } = (0, V.H)(t, "onreadystatechange", () => {
                                        t.readyState === XMLHttpRequest.DONE && s()
                                    }),
                                    s = () => {
                                        u(), o(), a || (a = !0, i.state = "complete", i.duration = (0, A.vk)(i.startClocks.timeStamp, (0, A.nx)()), i.status = t.status, r.notify((0, Y.yG)(i)))
                                    },
                                    {
                                        stop: u
                                    } = (0, tj.q)(n, t, "loadend", s);
                                r.notify(i)
                            }(e, r, t)
                        }, {
                            computeHandlingStack: !0
                        }), {
                            stop: i
                        } = (0, V.H)(XMLHttpRequest.prototype, "abort", t7);
                        return () => {
                            e(), n(), i()
                        }
                    })), u).subscribe(e => {
                        if (ec(e.url)) switch (e.state) {
                            case "start":
                                n.traceXhr(e, e.xhr), e.requestIndex = em(), t.notify(7, {
                                    requestIndex: e.requestIndex,
                                    url: e.url
                                });
                                break;
                            case "complete":
                                n.clearTracingIfNeeded(e), t.notify(8, {
                                    duration: e.duration,
                                    method: e.method,
                                    requestIndex: e.requestIndex,
                                    spanId: e.spanId,
                                    startClocks: e.startClocks,
                                    status: e.status,
                                    traceId: e.traceId,
                                    traceSampled: e.traceSampled,
                                    type: "xhr",
                                    url: e.url,
                                    xhr: e.xhr,
                                    isAborted: e.isAborted,
                                    handlingStack: e.handlingStack
                                })
                        }
                    })
                })($, t, t1), T = $, E = t1, F().subscribe(t => {
                    if (ec(t.url)) switch (t.state) {
                        case "start":
                            E.traceFetch(t), t.requestIndex = em(), T.notify(7, {
                                requestIndex: t.requestIndex,
                                url: t.url
                            });
                            break;
                        case "resolve":
                            var e = t,
                                n = e => {
                                    E.clearTracingIfNeeded(t), T.notify(8, {
                                        duration: e,
                                        method: t.method,
                                        requestIndex: t.requestIndex,
                                        responseType: t.responseType,
                                        spanId: t.spanId,
                                        startClocks: t.startClocks,
                                        status: t.status,
                                        traceId: t.traceId,
                                        traceSampled: t.traceSampled,
                                        type: "fetch",
                                        url: t.url,
                                        response: t.response,
                                        init: t.init,
                                        input: t.input,
                                        isAborted: t.isAborted,
                                        handlingStack: t.handlingStack
                                    })
                                };
                            let r = e.response && (0, et.i)(e.response);
                            r && r.body ? function(t, e, n) {
                                let r = t.getReader(),
                                    i = [],
                                    a = 0;

                                function o() {
                                    let t, o;
                                    if (r.cancel().catch(q.l), n.collectStreamBody) {
                                        let e;
                                        if (1 === i.length) e = i[0];
                                        else {
                                            e = new Uint8Array(a);
                                            let t = 0;
                                            i.forEach(n => {
                                                e.set(n, t), t += n.length
                                            })
                                        }
                                        t = e.slice(0, n.bytesLimit), o = e.length > n.bytesLimit
                                    }
                                    e(void 0, t, o)
                                }! function t() {
                                    r.read().then((0, b.dm)(e => {
                                        if (e.done) return void o();
                                        n.collectStreamBody && i.push(e.value), (a += e.value.length) > n.bytesLimit ? o() : t()
                                    }), (0, b.dm)(t => e(t)))
                                }()
                            }(r.body, () => {
                                n((0, A.vk)(e.startClocks.timeStamp, (0, A.nx)()))
                            }, {
                                bytesLimit: Number.POSITIVE_INFINITY,
                                collectStreamBody: !1
                            }) : n((0, A.vk)(e.startClocks.timeStamp, (0, A.nx)()))
                    }
                });
                let t2 = function(t, e, n) {
                        function r(n) {
                            e.wasInPageStateDuringPeriod("frozen", n.startClocks.relative, n.duration) || t.notify(12, function(t, e) {
                                let n = {
                                    date: t.startClocks.timeStamp,
                                    vital: {
                                        id: O(),
                                        type: t.type,
                                        name: t.name,
                                        duration: (0, A.Zj)(t.duration),
                                        description: t.description
                                    },
                                    type: "vital"
                                };
                                return e && (n._dd = {
                                    vital: {
                                        computed_value: !0
                                    }
                                }), {
                                    rawRumEvent: n,
                                    startTime: t.startClocks.relative,
                                    duration: t.duration,
                                    customerContext: t.context,
                                    domainContext: {}
                                }
                            }(n, !0))
                        }
                        return {
                            addDurationVital: r,
                            startDurationVital: (t, e = {}) => L(n, t, e),
                            stopDurationVital: (t, e = {}) => {
                                D(r, n, t, e)
                            }
                        }
                    }($, tv, o),
                    t5 = (y = t.applicationId, {
                        get: t => {
                            let e = tb.findView(t),
                                n = tw.findUrl(t),
                                r = tf.findTrackedSession(t);
                            if (r && e && n) {
                                let i = tI.findActionId(t);
                                return {
                                    application_id: y,
                                    session_id: r.id,
                                    user_action: i ? {
                                        id: i
                                    } : void 0,
                                    view: {
                                        id: e.id,
                                        name: e.name,
                                        referrer: n.referrer,
                                        url: n.url
                                    }
                                }
                            }
                        }
                    });
                return P.push(() => n.stop()), {
                    addAction: tP,
                    addError: tK,
                    addTiming: tM,
                    addFeatureFlagEvaluation: tx.addFeatureFlagEvaluation,
                    startView: tL,
                    setViewContext: tq,
                    setViewContextProperty: tV,
                    getViewContext: tF,
                    setViewName: tU,
                    lifeCycle: $,
                    viewHistory: tb,
                    session: tf,
                    stopSession: () => tf.expire(),
                    getInternalContext: t5.get,
                    startDurationVital: t2.startDurationVital,
                    stopDurationVital: t2.stopDurationVital,
                    addDurationVital: t2.addDurationVital,
                    globalContext: tA,
                    userContext: tT,
                    accountContext: tE,
                    stop: () => {
                        P.forEach(t => t())
                    }
                }
            }

            function ra(t, {
                session: e,
                viewContext: n,
                errorType: r
            }) {
                let i = e ? e.id : "no-session-id",
                    a = [];
                void 0 !== r && a.push(`error-type=${r}`), n && (a.push(`seed=${n.id}`), a.push(`from=${n.startClocks.timeStamp}`));
                let o = function(t) {
                        let e = t.site,
                            n = t.subdomain || function(t) {
                                switch (t.site) {
                                    case tx.NW:
                                    case tx.dV:
                                        return "app";
                                    case tx.Bb:
                                        return "dd";
                                    default:
                                        return
                                }
                            }(t);
                        return `https://${n?`${n}.`:""}${e}`
                    }(t),
                    s = `/rum/replay/sessions/${i}`;
                return `${o}${s}?${a.join("&")}`
            }
        },
        94357: (t, e, n) => {
            "use strict";
            n.d(e, {
                DJ: () => s,
                vG: () => l,
                wg: () => o,
                yb: () => u
            });
            var r = n(14531),
                i = n(85590),
                a = n(10676);

            function o(t, e) {
                return (0, r.W)((0, a.V)(), "setTimeout")((0, i.dm)(t), e)
            }

            function s(t) {
                (0, r.W)((0, a.V)(), "clearTimeout")(t)
            }

            function u(t, e) {
                return (0, r.W)((0, a.V)(), "setInterval")((0, i.dm)(t), e)
            }

            function l(t) {
                (0, r.W)((0, a.V)(), "clearInterval")(t)
            }
        },
        94404: (t, e, n) => {
            "use strict";

            function r() {
                var t;
                let e = window.navigator;
                return {
                    status: e.onLine ? "connected" : "not_connected",
                    interfaces: e.connection && e.connection.type ? [e.connection.type] : void 0,
                    effective_type: null == (t = e.connection) ? void 0 : t.effectiveType
                }
            }
            n.d(e, {
                q: () => r
            })
        },
        94727: (t, e, n) => {
            "use strict";
            n.d(e, {
                O: () => i
            });
            var r = n(61540);

            function i() {
                let t = [];
                return {
                    add: e => {
                        t.push(e) > 500 && t.splice(0, 1)
                    },
                    remove: e => {
                        (0, r.A)(t, e)
                    },
                    drain: e => {
                        t.forEach(t => t(e)), t.length = 0
                    }
                }
            }
        },
        96605: (t, e, n) => {
            "use strict";
            n.d(e, {
                NR: () => s,
                Yn: () => o,
                uC: () => a
            });
            var r = n(85590),
                i = n(46866);

            function a(t) {
                let e, n = Error(t);
                return n.name = "HandlingStack", (0, r.um)(() => {
                    let t = (0, i.T)(n);
                    t.stack = t.stack.slice(2), e = o(t)
                }), e
            }

            function o(t) {
                let e = s(t);
                return t.stack.forEach(t => {
                    let n = "?" === t.func ? "<anonymous>" : t.func,
                        r = t.args && t.args.length > 0 ? `(${t.args.join(", ")})` : "",
                        i = t.line ? `:${t.line}` : "",
                        a = t.line && t.column ? `:${t.column}` : "";
                    e += `
  at ${n}${r} @ ${t.url}${i}${a}`
                }), e
            }

            function s(t) {
                return `${t.name||"Error"}: ${t.message}`
            }
        },
        97617: (t, e, n) => {
            "use strict";
            n.d(e, {
                WW: () => o,
                _m: () => r,
                iH: () => i,
                wh: () => s
            });
            let r = 1024,
                i = 1048576,
                a = /[^\u0000-\u007F]/;

            function o(t) {
                return a.test(t) ? void 0 !== window.TextEncoder ? new TextEncoder().encode(t).length : new Blob([t]).size : t.length
            }

            function s(t) {
                let e = new Uint8Array(t.reduce((t, e) => t + e.length, 0)),
                    n = 0;
                for (let r of t) e.set(r, n), n += r.length;
                return e
            }
        },
        98020: (t, e, n) => {
            "use strict";
            n.d(e, {
                BB: () => o
            });
            var r = n(94357),
                i = n(85590),
                a = n(26664);

            function o(t, e) {
                if (window.requestIdleCallback && window.cancelIdleCallback) {
                    let n = window.requestIdleCallback((0, i.dm)(t), e);
                    return () => window.cancelIdleCallback(n)
                }
                var n = t;
                let o = (0, a.x3)(),
                    s = (0, r.wg)(() => {
                        n({
                            didTimeout: !1,
                            timeRemaining: () => Math.max(0, 50 - ((0, a.x3)() - o))
                        })
                    }, 0);
                return () => (0, r.DJ)(s)
            }
        },
        98202: (t, e, n) => {
            "use strict";
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.sendGTMEvent = void 0, e.GoogleTagManager = function(t) {
                let {
                    gtmId: e,
                    gtmScriptUrl: n = "https://www.googletagmanager.com/gtm.js",
                    dataLayerName: s = "dataLayer",
                    auth: u,
                    preview: l,
                    dataLayer: c,
                    nonce: d
                } = t;
                o = s;
                let f = "dataLayer" !== s ? "&l=".concat(s) : "";
                return (0, i.useEffect)(() => {
                    performance.mark("mark_feature_usage", {
                        detail: {
                            feature: "next-third-parties-gtm"
                        }
                    })
                }, []), (0, r.jsxs)(r.Fragment, {
                    children: [(0, r.jsx)(a.default, {
                        id: "_next-gtm-init",
                        dangerouslySetInnerHTML: {
                            __html: "\n      (function(w,l){\n        w[l]=w[l]||[];\n        w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});\n        ".concat(c ? "w[l].push(".concat(JSON.stringify(c), ")") : "", "\n      })(window,'").concat(s, "');")
                        },
                        nonce: d
                    }), (0, r.jsx)(a.default, {
                        id: "_next-gtm",
                        "data-ntpc": "GTM",
                        src: "".concat(n, "?id=").concat(e).concat(f).concat(u ? "&gtm_auth=".concat(u) : "").concat(l ? "&gtm_preview=".concat(l, "&gtm_cookies_win=x") : ""),
                        nonce: d
                    })]
                })
            };
            let r = n(95155),
                i = n(12115),
                a = function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }(n(68321)),
                o = "dataLayer";
            e.sendGTMEvent = (t, e) => {
                let n = e || o;
                window[n] = window[n] || [], window[n].push(t)
            }
        },
        98595: (t, e, n) => {
            "use strict";
            n.d(e, {
                l: () => a,
                n: () => i
            });
            var r = n(94357);

            function i(t, e, n) {
                let i, a, o = !n || void 0 === n.leading || n.leading,
                    s = !n || void 0 === n.trailing || n.trailing,
                    u = !1;
                return {
                    throttled: (...n) => {
                        if (u) {
                            i = n;
                            return
                        }
                        o ? t(...n) : i = n, u = !0, a = (0, r.wg)(() => {
                            s && i && t(...i), u = !1, i = void 0
                        }, e)
                    },
                    cancel: () => {
                        (0, r.DJ)(a), u = !1, i = void 0
                    }
                }
            }

            function a() {}
        }
    }
]);