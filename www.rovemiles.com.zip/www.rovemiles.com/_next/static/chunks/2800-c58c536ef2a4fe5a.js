! function() {
    try {
        var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "a17b4db9-3c1a-4836-8dc6-f409b182683d", t._sentryDebugIdIdentifier = "sentry-dbid-a17b4db9-3c1a-4836-8dc6-f409b182683d")
    } catch (t) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2800], {
        47605: (t, e, n) => {
            n.d(e, {
                Ay: () => tw
            });
            var r, i, o, s, a, l, c, p = n(2761),
                u = {},
                f = 180 / Math.PI,
                d = Math.PI / 180,
                h = Math.atan2,
                g = /([A-Z])/g,
                x = /(left|right|width|margin|padding|x)/i,
                m = /[\s,\(]\S/,
                y = {
                    autoAlpha: "opacity,visibility",
                    scale: "scaleX,scaleY",
                    alpha: "opacity"
                },
                v = function(t, e) {
                    return e.set(e.t, e.p, Math.round((e.s + e.c * t) * 1e4) / 1e4 + e.u, e)
                },
                w = function(t, e) {
                    return e.set(e.t, e.p, 1 === t ? e.e : Math.round((e.s + e.c * t) * 1e4) / 1e4 + e.u, e)
                },
                b = function(t, e) {
                    return e.set(e.t, e.p, t ? Math.round((e.s + e.c * t) * 1e4) / 1e4 + e.u : e.b, e)
                },
                _ = function(t, e) {
                    var n = e.s + e.c * t;
                    e.set(e.t, e.p, ~~(n + (n < 0 ? -.5 : .5)) + e.u, e)
                },
                M = function(t, e) {
                    return e.set(e.t, e.p, t ? e.e : e.b, e)
                },
                T = function(t, e) {
                    return e.set(e.t, e.p, 1 !== t ? e.b : e.e, e)
                },
                E = function(t, e, n) {
                    return t.style[e] = n
                },
                O = function(t, e, n) {
                    return t.style.setProperty(e, n)
                },
                Y = function(t, e, n) {
                    return t._gsap[e] = n
                },
                C = function(t, e, n) {
                    return t._gsap.scaleX = t._gsap.scaleY = n
                },
                P = function(t, e, n, r, i) {
                    var o = t._gsap;
                    o.scaleX = o.scaleY = n, o.renderTransform(i, o)
                },
                S = function(t, e, n, r, i) {
                    var o = t._gsap;
                    o[e] = n, o.renderTransform(i, o)
                },
                X = "transform",
                k = X + "Origin",
                D = function t(e, n) {
                    var r = this,
                        i = this.target,
                        o = i.style,
                        s = i._gsap;
                    if (e in u && o) {
                        if (this.tfm = this.tfm || {}, "transform" === e) return y.transform.split(",").forEach(function(e) {
                            return t.call(r, e, n)
                        });
                        if (~(e = y[e] || e).indexOf(",") ? e.split(",").forEach(function(t) {
                                return r.tfm[t] = Z(i, t)
                            }) : this.tfm[e] = s.x ? s[e] : Z(i, e), e === k && (this.tfm.zOrigin = s.zOrigin), this.props.indexOf(X) >= 0) return;
                        s.svg && (this.svgo = i.getAttribute("data-svg-origin"), this.props.push(k, n, "")), e = X
                    }(o || n) && this.props.push(e, n, o[e])
                },
                A = function(t) {
                    t.translate && (t.removeProperty("translate"), t.removeProperty("scale"), t.removeProperty("rotate"))
                },
                N = function() {
                    var t, e, n = this.props,
                        r = this.target,
                        i = r.style,
                        o = r._gsap;
                    for (t = 0; t < n.length; t += 3) n[t + 1] ? r[n[t]] = n[t + 2] : n[t + 2] ? i[n[t]] = n[t + 2] : i.removeProperty("--" === n[t].substr(0, 2) ? n[t] : n[t].replace(g, "-$1").toLowerCase());
                    if (this.tfm) {
                        for (e in this.tfm) o[e] = this.tfm[e];
                        o.svg && (o.renderTransform(), r.setAttribute("data-svg-origin", this.svgo || "")), (t = l()) && t.isStart || i[X] || (A(i), o.zOrigin && i[k] && (i[k] += " " + o.zOrigin + "px", o.zOrigin = 0, o.renderTransform()), o.uncache = 1)
                    }
                },
                L = function(t, e) {
                    var n = {
                        target: t,
                        props: [],
                        revert: N,
                        save: D
                    };
                    return t._gsap || p.os.core.getCache(t), e && e.split(",").forEach(function(t) {
                        return n.save(t)
                    }), n
                },
                B = function(t, e) {
                    var n = r.createElementNS ? r.createElementNS((e || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), t) : r.createElement(t);
                    return n && n.style ? n : r.createElement(t)
                },
                F = function t(e, n, r) {
                    var i = getComputedStyle(e);
                    return i[n] || i.getPropertyValue(n.replace(g, "-$1").toLowerCase()) || i.getPropertyValue(n) || !r && t(e, R(n) || n, 1) || ""
                },
                I = "O,Moz,ms,Ms,Webkit".split(","),
                R = function(t, e, n) {
                    var r = (e || s).style,
                        i = 5;
                    if (t in r && !n) return t;
                    for (t = t.charAt(0).toUpperCase() + t.substr(1); i-- && !(I[i] + t in r););
                    return i < 0 ? null : (3 === i ? "ms" : i >= 0 ? I[i] : "") + t
                },
                z = function() {
                    "undefined" != typeof window && window.document && (i = (r = window.document).documentElement, s = B("div") || {
                        style: {}
                    }, B("div"), k = (X = R(X)) + "Origin", s.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0", c = !!R("perspective"), l = p.os.core.reverting, o = 1)
                },
                H = function t(e) {
                    var n, r = B("svg", this.ownerSVGElement && this.ownerSVGElement.getAttribute("xmlns") || "http://www.w3.org/2000/svg"),
                        o = this.parentNode,
                        s = this.nextSibling,
                        a = this.style.cssText;
                    if (i.appendChild(r), r.appendChild(this), this.style.display = "block", e) try {
                        n = this.getBBox(), this._gsapBBox = this.getBBox, this.getBBox = t
                    } catch (t) {} else this._gsapBBox && (n = this._gsapBBox());
                    return o && (s ? o.insertBefore(this, s) : o.appendChild(this)), i.removeChild(r), this.style.cssText = a, n
                },
                W = function(t, e) {
                    for (var n = e.length; n--;)
                        if (t.hasAttribute(e[n])) return t.getAttribute(e[n])
                },
                V = function(t) {
                    var e;
                    try {
                        e = t.getBBox()
                    } catch (n) {
                        e = H.call(t, !0)
                    }
                    return e && (e.width || e.height) || t.getBBox === H || (e = H.call(t, !0)), !e || e.width || e.x || e.y ? e : {
                        x: +W(t, ["x", "cx", "x1"]) || 0,
                        y: +W(t, ["y", "cy", "y1"]) || 0,
                        width: 0,
                        height: 0
                    }
                },
                q = function(t) {
                    return !!(t.getCTM && (!t.parentNode || t.ownerSVGElement) && V(t))
                },
                G = function(t, e) {
                    if (e) {
                        var n, r = t.style;
                        e in u && e !== k && (e = X), r.removeProperty ? (("ms" === (n = e.substr(0, 2)) || "webkit" === e.substr(0, 6)) && (e = "-" + e), r.removeProperty("--" === n ? e : e.replace(g, "-$1").toLowerCase())) : r.removeAttribute(e)
                    }
                },
                j = function(t, e, n, r, i, o) {
                    var s = new p.J7(t._pt, e, n, 0, 1, o ? T : M);
                    return t._pt = s, s.b = r, s.e = i, t._props.push(n), s
                },
                J = {
                    deg: 1,
                    rad: 1,
                    turn: 1
                },
                K = {
                    grid: 1,
                    flex: 1
                },
                U = function t(e, n, i, o) {
                    var a, l, c, f, d = parseFloat(i) || 0,
                        h = (i + "").trim().substr((d + "").length) || "px",
                        g = s.style,
                        m = x.test(n),
                        y = "svg" === e.tagName.toLowerCase(),
                        v = (y ? "client" : "offset") + (m ? "Width" : "Height"),
                        w = "px" === o,
                        b = "%" === o;
                    if (o === h || !d || J[o] || J[h]) return d;
                    if ("px" === h || w || (d = t(e, n, i, "px")), f = e.getCTM && q(e), (b || "%" === h) && (u[n] || ~n.indexOf("adius"))) return a = f ? e.getBBox()[m ? "width" : "height"] : e[v], (0, p.E_)(b ? d / a * 100 : d / 100 * a);
                    if (g[m ? "width" : "height"] = 100 + (w ? h : o), l = ~n.indexOf("adius") || "em" === o && e.appendChild && !y ? e : e.parentNode, f && (l = (e.ownerSVGElement || {}).parentNode), l && l !== r && l.appendChild || (l = r.body), (c = l._gsap) && b && c.width && m && c.time === p.au.time && !c.uncache) return (0, p.E_)(d / c.width * 100);
                    if (b && ("height" === n || "width" === n)) {
                        var _ = e.style[n];
                        e.style[n] = 100 + o, a = e[v], _ ? e.style[n] = _ : G(e, n)
                    } else(b || "%" === h) && !K[F(l, "display")] && (g.position = F(e, "position")), l === e && (g.position = "static"), l.appendChild(s), a = s[v], l.removeChild(s), g.position = "absolute";
                    return m && b && ((c = (0, p.a0)(l)).time = p.au.time, c.width = l[v]), (0, p.E_)(w ? a * d / 100 : a && d ? 100 / a * d : 0)
                },
                Z = function(t, e, n, r) {
                    var i;
                    return o || z(), e in y && "transform" !== e && ~(e = y[e]).indexOf(",") && (e = e.split(",")[0]), u[e] && "transform" !== e ? (i = tc(t, r), i = "transformOrigin" !== e ? i[e] : i.svg ? i.origin : tp(F(t, k)) + " " + i.zOrigin + "px") : (!(i = t.style[e]) || "auto" === i || r || ~(i + "").indexOf("calc(")) && (i = tn[e] && tn[e](t, e, n) || F(t, e) || (0, p.n)(t, e) || +("opacity" === e)), n && !~(i + "").trim().indexOf(" ") ? U(t, e, i, n) + n : i
                },
                $ = function(t, e, n, r) {
                    if (!n || "none" === n) {
                        var i = R(e, t, 1),
                            o = i && F(t, i, 1);
                        o && o !== n ? (e = i, n = o) : "borderColor" === e && (n = F(t, "borderTopColor"))
                    }
                    var s, a, l, c, u, f, d, h, g, x, m, y = new p.J7(this._pt, t.style, e, 0, 1, p.l1),
                        v = 0,
                        w = 0;
                    if (y.b = n, y.e = r, n += "", "auto" == (r += "") && (f = t.style[e], t.style[e] = r, r = F(t, e) || r, f ? t.style[e] = f : G(t, e)), s = [n, r], (0, p.Uc)(s), n = s[0], r = s[1], l = n.match(p.vM) || [], (r.match(p.vM) || []).length) {
                        for (; a = p.vM.exec(r);) d = a[0], g = r.substring(v, a.index), u ? u = (u + 1) % 5 : ("rgba(" === g.substr(-5) || "hsla(" === g.substr(-5)) && (u = 1), d !== (f = l[w++] || "") && (c = parseFloat(f) || 0, m = f.substr((c + "").length), "=" === d.charAt(1) && (d = (0, p.B0)(c, d) + m), h = parseFloat(d), x = d.substr((h + "").length), v = p.vM.lastIndex - x.length, x || (x = x || p.Yz.units[e] || m, v === r.length && (r += x, y.e += x)), m !== x && (c = U(t, e, f, x) || 0), y._pt = {
                            _next: y._pt,
                            p: g || 1 === w ? g : ",",
                            s: c,
                            c: h - c,
                            m: u && u < 4 || "zIndex" === e ? Math.round : 0
                        });
                        y.c = v < r.length ? r.substring(v, r.length) : ""
                    } else y.r = "display" === e && "none" === r ? T : M;
                    return p.Ks.test(r) && (y.e = 0), this._pt = y, y
                },
                Q = {
                    top: "0%",
                    bottom: "100%",
                    left: "0%",
                    right: "100%",
                    center: "50%"
                },
                tt = function(t) {
                    var e = t.split(" "),
                        n = e[0],
                        r = e[1] || "50%";
                    return ("top" === n || "bottom" === n || "left" === r || "right" === r) && (t = n, n = r, r = t), e[0] = Q[n] || n, e[1] = Q[r] || r, e.join(" ")
                },
                te = function(t, e) {
                    if (e.tween && e.tween._time === e.tween._dur) {
                        var n, r, i, o = e.t,
                            s = o.style,
                            a = e.u,
                            l = o._gsap;
                        if ("all" === a || !0 === a) s.cssText = "", r = 1;
                        else
                            for (i = (a = a.split(",")).length; --i > -1;) u[n = a[i]] && (r = 1, n = "transformOrigin" === n ? k : X), G(o, n);
                        r && (G(o, X), l && (l.svg && o.removeAttribute("transform"), tc(o, 1), l.uncache = 1, A(s)))
                    }
                },
                tn = {
                    clearProps: function(t, e, n, r, i) {
                        if ("isFromStart" !== i.data) {
                            var o = t._pt = new p.J7(t._pt, e, n, 0, 0, te);
                            return o.u = r, o.pr = -10, o.tween = i, t._props.push(n), 1
                        }
                    }
                },
                tr = [1, 0, 0, 1, 0, 0],
                ti = {},
                to = function(t) {
                    return "matrix(1, 0, 0, 1, 0, 0)" === t || "none" === t || !t
                },
                ts = function(t) {
                    var e = F(t, X);
                    return to(e) ? tr : e.substr(7).match(p.vX).map(p.E_)
                },
                ta = function(t, e) {
                    var n, r, o, s, a = t._gsap || (0, p.a0)(t),
                        l = t.style,
                        c = ts(t);
                    return a.svg && t.getAttribute("transform") ? "1,0,0,1,0,0" === (c = [(o = t.transform.baseVal.consolidate().matrix).a, o.b, o.c, o.d, o.e, o.f]).join(",") ? tr : c : (c !== tr || t.offsetParent || t === i || a.svg || (o = l.display, l.display = "block", (n = t.parentNode) && t.offsetParent || (s = 1, r = t.nextElementSibling, i.appendChild(t)), c = ts(t), o ? l.display = o : G(t, "display"), s && (r ? n.insertBefore(t, r) : n ? n.appendChild(t) : i.removeChild(t))), e && c.length > 6 ? [c[0], c[1], c[4], c[5], c[12], c[13]] : c)
                },
                tl = function(t, e, n, r, i, o) {
                    var s, a, l, c, p = t._gsap,
                        u = i || ta(t, !0),
                        f = p.xOrigin || 0,
                        d = p.yOrigin || 0,
                        h = p.xOffset || 0,
                        g = p.yOffset || 0,
                        x = u[0],
                        m = u[1],
                        y = u[2],
                        v = u[3],
                        w = u[4],
                        b = u[5],
                        _ = e.split(" "),
                        M = parseFloat(_[0]) || 0,
                        T = parseFloat(_[1]) || 0;
                    n ? u !== tr && (a = x * v - m * y) && (l = v / a * M + -y / a * T + (y * b - v * w) / a, c = -m / a * M + x / a * T - (x * b - m * w) / a, M = l, T = c) : (M = (s = V(t)).x + (~_[0].indexOf("%") ? M / 100 * s.width : M), T = s.y + (~(_[1] || _[0]).indexOf("%") ? T / 100 * s.height : T)), r || !1 !== r && p.smooth ? (p.xOffset = h + ((w = M - f) * x + (b = T - d) * y) - w, p.yOffset = g + (w * m + b * v) - b) : p.xOffset = p.yOffset = 0, p.xOrigin = M, p.yOrigin = T, p.smooth = !!r, p.origin = e, p.originIsAbsolute = !!n, t.style[k] = "0px 0px", o && (j(o, p, "xOrigin", f, M), j(o, p, "yOrigin", d, T), j(o, p, "xOffset", h, p.xOffset), j(o, p, "yOffset", g, p.yOffset)), t.setAttribute("data-svg-origin", M + " " + T)
                },
                tc = function(t, e) {
                    var n = t._gsap || new p.n6(t);
                    if ("x" in n && !e && !n.uncache) return n;
                    var r, i, o, s, a, l, u, g, x, m, y, v, w, b, _, M, T, E, O, Y, C, P, S, D, A, N, L, B, I, R, z, H, W = t.style,
                        V = n.scaleX < 0,
                        G = getComputedStyle(t),
                        j = F(t, k) || "0";
                    return r = i = o = l = u = g = x = m = y = 0, s = a = 1, n.svg = !!(t.getCTM && q(t)), G.translate && (("none" !== G.translate || "none" !== G.scale || "none" !== G.rotate) && (W[X] = ("none" !== G.translate ? "translate3d(" + (G.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + ("none" !== G.rotate ? "rotate(" + G.rotate + ") " : "") + ("none" !== G.scale ? "scale(" + G.scale.split(" ").join(",") + ") " : "") + ("none" !== G[X] ? G[X] : "")), W.scale = W.rotate = W.translate = "none"), b = ta(t, n.svg), n.svg && (n.uncache ? (A = t.getBBox(), j = n.xOrigin - A.x + "px " + (n.yOrigin - A.y) + "px", D = "") : D = !e && t.getAttribute("data-svg-origin"), tl(t, D || j, !!D || n.originIsAbsolute, !1 !== n.smooth, b)), v = n.xOrigin || 0, w = n.yOrigin || 0, b !== tr && (E = b[0], O = b[1], Y = b[2], C = b[3], r = P = b[4], i = S = b[5], 6 === b.length ? (s = Math.sqrt(E * E + O * O), a = Math.sqrt(C * C + Y * Y), l = E || O ? h(O, E) * f : 0, (x = Y || C ? h(Y, C) * f + l : 0) && (a *= Math.abs(Math.cos(x * d))), n.svg && (r -= v - (v * E + w * Y), i -= w - (v * O + w * C))) : (H = b[6], R = b[7], L = b[8], B = b[9], I = b[10], z = b[11], r = b[12], i = b[13], o = b[14], u = (_ = h(H, I)) * f, _ && (D = P * (M = Math.cos(-_)) + L * (T = Math.sin(-_)), A = S * M + B * T, N = H * M + I * T, L = -(P * T) + L * M, B = -(S * T) + B * M, I = -(H * T) + I * M, z = -(R * T) + z * M, P = D, S = A, H = N), g = (_ = h(-Y, I)) * f, _ && (D = E * (M = Math.cos(-_)) - L * (T = Math.sin(-_)), A = O * M - B * T, N = Y * M - I * T, z = C * T + z * M, E = D, O = A, Y = N), l = (_ = h(O, E)) * f, _ && (D = E * (M = Math.cos(_)) + O * (T = Math.sin(_)), A = P * M + S * T, O = O * M - E * T, S = S * M - P * T, E = D, P = A), u && Math.abs(u) + Math.abs(l) > 359.9 && (u = l = 0, g = 180 - g), s = (0, p.E_)(Math.sqrt(E * E + O * O + Y * Y)), a = (0, p.E_)(Math.sqrt(S * S + H * H)), x = Math.abs(_ = h(P, S)) > 2e-4 ? _ * f : 0, y = z ? 1 / (z < 0 ? -z : z) : 0), n.svg && (D = t.getAttribute("transform"), n.forceCSS = t.setAttribute("transform", "") || !to(F(t, X)), D && t.setAttribute("transform", D))), Math.abs(x) > 90 && 270 > Math.abs(x) && (V ? (s *= -1, x += l <= 0 ? 180 : -180, l += l <= 0 ? 180 : -180) : (a *= -1, x += x <= 0 ? 180 : -180)), e = e || n.uncache, n.x = r - ((n.xPercent = r && (!e && n.xPercent || (Math.round(t.offsetWidth / 2) === Math.round(-r) ? -50 : 0))) ? t.offsetWidth * n.xPercent / 100 : 0) + "px", n.y = i - ((n.yPercent = i && (!e && n.yPercent || (Math.round(t.offsetHeight / 2) === Math.round(-i) ? -50 : 0))) ? t.offsetHeight * n.yPercent / 100 : 0) + "px", n.z = o + "px", n.scaleX = (0, p.E_)(s), n.scaleY = (0, p.E_)(a), n.rotation = (0, p.E_)(l) + "deg", n.rotationX = (0, p.E_)(u) + "deg", n.rotationY = (0, p.E_)(g) + "deg", n.skewX = x + "deg", n.skewY = m + "deg", n.transformPerspective = y + "px", (n.zOrigin = parseFloat(j.split(" ")[2]) || !e && n.zOrigin || 0) && (W[k] = tp(j)), n.xOffset = n.yOffset = 0, n.force3D = p.Yz.force3D, n.renderTransform = n.svg ? tg : c ? th : tf, n.uncache = 0, n
                },
                tp = function(t) {
                    return (t = t.split(" "))[0] + " " + t[1]
                },
                tu = function(t, e, n) {
                    var r = (0, p.l_)(e);
                    return (0, p.E_)(parseFloat(e) + parseFloat(U(t, "x", n + "px", r))) + r
                },
                tf = function(t, e) {
                    e.z = "0px", e.rotationY = e.rotationX = "0deg", e.force3D = 0, th(t, e)
                },
                td = "0deg",
                th = function(t, e) {
                    var n = e || this,
                        r = n.xPercent,
                        i = n.yPercent,
                        o = n.x,
                        s = n.y,
                        a = n.z,
                        l = n.rotation,
                        c = n.rotationY,
                        p = n.rotationX,
                        u = n.skewX,
                        f = n.skewY,
                        h = n.scaleX,
                        g = n.scaleY,
                        x = n.transformPerspective,
                        m = n.force3D,
                        y = n.target,
                        v = n.zOrigin,
                        w = "",
                        b = "auto" === m && t && 1 !== t || !0 === m;
                    if (v && (p !== td || c !== td)) {
                        var _, M = parseFloat(c) * d,
                            T = Math.sin(M),
                            E = Math.cos(M);
                        o = tu(y, o, -(T * (_ = Math.cos(M = parseFloat(p) * d)) * v)), s = tu(y, s, -(-Math.sin(M) * v)), a = tu(y, a, -(E * _ * v) + v)
                    }
                    "0px" !== x && (w += "perspective(" + x + ") "), (r || i) && (w += "translate(" + r + "%, " + i + "%) "), (b || "0px" !== o || "0px" !== s || "0px" !== a) && (w += "0px" !== a || b ? "translate3d(" + o + ", " + s + ", " + a + ") " : "translate(" + o + ", " + s + ") "), l !== td && (w += "rotate(" + l + ") "), c !== td && (w += "rotateY(" + c + ") "), p !== td && (w += "rotateX(" + p + ") "), (u !== td || f !== td) && (w += "skew(" + u + ", " + f + ") "), (1 !== h || 1 !== g) && (w += "scale(" + h + ", " + g + ") "), y.style[X] = w || "translate(0, 0)"
                },
                tg = function(t, e) {
                    var n, r, i, o, s, a = e || this,
                        l = a.xPercent,
                        c = a.yPercent,
                        u = a.x,
                        f = a.y,
                        h = a.rotation,
                        g = a.skewX,
                        x = a.skewY,
                        m = a.scaleX,
                        y = a.scaleY,
                        v = a.target,
                        w = a.xOrigin,
                        b = a.yOrigin,
                        _ = a.xOffset,
                        M = a.yOffset,
                        T = a.forceCSS,
                        E = parseFloat(u),
                        O = parseFloat(f);
                    h = parseFloat(h), g = parseFloat(g), (x = parseFloat(x)) && (g += x = parseFloat(x), h += x), h || g ? (h *= d, g *= d, n = Math.cos(h) * m, r = Math.sin(h) * m, i = -(Math.sin(h - g) * y), o = Math.cos(h - g) * y, g && (x *= d, i *= s = Math.sqrt(1 + (s = Math.tan(g - x)) * s), o *= s, x && (n *= s = Math.sqrt(1 + (s = Math.tan(x)) * s), r *= s)), n = (0, p.E_)(n), r = (0, p.E_)(r), i = (0, p.E_)(i), o = (0, p.E_)(o)) : (n = m, o = y, r = i = 0), (E && !~(u + "").indexOf("px") || O && !~(f + "").indexOf("px")) && (E = U(v, "x", u, "px"), O = U(v, "y", f, "px")), (w || b || _ || M) && (E = (0, p.E_)(E + w - (w * n + b * i) + _), O = (0, p.E_)(O + b - (w * r + b * o) + M)), (l || c) && (s = v.getBBox(), E = (0, p.E_)(E + l / 100 * s.width), O = (0, p.E_)(O + c / 100 * s.height)), s = "matrix(" + n + "," + r + "," + i + "," + o + "," + E + "," + O + ")", v.setAttribute("transform", s), T && (v.style[X] = s)
                },
                tx = function(t, e, n, r, i) {
                    var o, s, a = (0, p.vQ)(i),
                        l = parseFloat(i) * (a && ~i.indexOf("rad") ? f : 1) - r,
                        c = r + l + "deg";
                    return a && ("short" === (o = i.split("_")[1]) && (l %= 360) != l % 180 && (l += l < 0 ? 360 : -360), "cw" === o && l < 0 ? l = (l + 36e9) % 360 - 360 * ~~(l / 360) : "ccw" === o && l > 0 && (l = (l - 36e9) % 360 - 360 * ~~(l / 360))), t._pt = s = new p.J7(t._pt, e, n, r, l, w), s.e = c, s.u = "deg", t._props.push(n), s
                },
                tm = function(t, e) {
                    for (var n in e) t[n] = e[n];
                    return t
                },
                ty = function(t, e, n) {
                    var r, i, o, s, a, l, c, f = tm({}, n._gsap),
                        d = n.style;
                    for (i in f.svg ? (o = n.getAttribute("transform"), n.setAttribute("transform", ""), d[X] = e, r = tc(n, 1), G(n, X), n.setAttribute("transform", o)) : (o = getComputedStyle(n)[X], d[X] = e, r = tc(n, 1), d[X] = o), u)(o = f[i]) !== (s = r[i]) && 0 > "perspective,force3D,transformOrigin,svgOrigin".indexOf(i) && (a = (0, p.l_)(o) !== (c = (0, p.l_)(s)) ? U(n, i, o, c) : parseFloat(o), l = parseFloat(s), t._pt = new p.J7(t._pt, r, i, a, l - a, v), t._pt.u = c || 0, t._props.push(i));
                    tm(r, f)
                };
            (0, p.fA)("padding,margin,Width,Radius", function(t, e) {
                var n = "Right",
                    r = "Bottom",
                    i = "Left",
                    o = (e < 3 ? ["Top", n, r, i] : ["Top" + i, "Top" + n, r + n, r + i]).map(function(n) {
                        return e < 2 ? t + n : "border" + n + t
                    });
                tn[e > 1 ? "border" + t : t] = function(t, e, n, r, i) {
                    var s, a;
                    if (arguments.length < 4) return 5 === (a = (s = o.map(function(e) {
                        return Z(t, e, n)
                    })).join(" ")).split(s[0]).length ? s[0] : a;
                    s = (r + "").split(" "), a = {}, o.forEach(function(t, e) {
                        return a[t] = s[e] = s[e] || s[(e - 1) / 2 | 0]
                    }), t.init(e, a, i)
                }
            });
            var tv = {
                name: "css",
                register: z,
                targetTest: function(t) {
                    return t.style && t.nodeType
                },
                init: function(t, e, n, r, i) {
                    var s, a, l, c, f, d, h, g, x, w, M, T, E, O, Y, C, P = this._props,
                        S = t.style,
                        D = n.vars.startAt;
                    for (h in o || z(), this.styles = this.styles || L(t), C = this.styles.props, this.tween = n, e)
                        if ("autoRound" !== h && (a = e[h], !(p.wU[h] && (0, p.Zm)(h, e, n, r, t, i)))) {
                            if (f = typeof a, d = tn[h], "function" === f && (f = typeof(a = a.call(n, r, t, i))), "string" === f && ~a.indexOf("random(") && (a = (0, p.Vy)(a)), d) d(this, t, h, a, n) && (Y = 1);
                            else if ("--" === h.substr(0, 2)) s = (getComputedStyle(t).getPropertyValue(h) + "").trim(), a += "", p.qA.lastIndex = 0, p.qA.test(s) || (g = (0, p.l_)(s), x = (0, p.l_)(a)), x ? g !== x && (s = U(t, h, s, x) + x) : g && (a += g), this.add(S, "setProperty", s, a, r, i, 0, 0, h), P.push(h), C.push(h, 0, S[h]);
                            else if ("undefined" !== f) {
                                if (D && h in D ? (s = "function" == typeof D[h] ? D[h].call(n, r, t, i) : D[h], (0, p.vQ)(s) && ~s.indexOf("random(") && (s = (0, p.Vy)(s)), (0, p.l_)(s + "") || "auto" === s || (s += p.Yz.units[h] || (0, p.l_)(Z(t, h)) || ""), "=" === (s + "").charAt(1) && (s = Z(t, h))) : s = Z(t, h), c = parseFloat(s), (w = "string" === f && "=" === a.charAt(1) && a.substr(0, 2)) && (a = a.substr(2)), l = parseFloat(a), h in y && ("autoAlpha" === h && (1 === c && "hidden" === Z(t, "visibility") && l && (c = 0), C.push("visibility", 0, S.visibility), j(this, S, "visibility", c ? "inherit" : "hidden", l ? "inherit" : "hidden", !l)), "scale" !== h && "transform" !== h && ~(h = y[h]).indexOf(",") && (h = h.split(",")[0])), M = h in u) {
                                    if (this.styles.save(h), T || ((E = t._gsap).renderTransform && !e.parseTransform || tc(t, e.parseTransform), O = !1 !== e.smoothOrigin && E.smooth, (T = this._pt = new p.J7(this._pt, S, X, 0, 1, E.renderTransform, E, 0, -1)).dep = 1), "scale" === h) this._pt = new p.J7(this._pt, E, "scaleY", E.scaleY, (w ? (0, p.B0)(E.scaleY, w + l) : l) - E.scaleY || 0, v), this._pt.u = 0, P.push("scaleY", h), h += "X";
                                    else if ("transformOrigin" === h) {
                                        C.push(k, 0, S[k]), a = tt(a), E.svg ? tl(t, a, 0, O, 0, this) : ((x = parseFloat(a.split(" ")[2]) || 0) !== E.zOrigin && j(this, E, "zOrigin", E.zOrigin, x), j(this, S, h, tp(s), tp(a)));
                                        continue
                                    } else if ("svgOrigin" === h) {
                                        tl(t, a, 1, O, 0, this);
                                        continue
                                    } else if (h in ti) {
                                        tx(this, E, h, c, w ? (0, p.B0)(c, w + a) : a);
                                        continue
                                    } else if ("smoothOrigin" === h) {
                                        j(this, E, "smooth", E.smooth, a);
                                        continue
                                    } else if ("force3D" === h) {
                                        E[h] = a;
                                        continue
                                    } else if ("transform" === h) {
                                        ty(this, a, t);
                                        continue
                                    }
                                } else h in S || (h = R(h) || h);
                                if (M || (l || 0 === l) && (c || 0 === c) && !m.test(a) && h in S) g = (s + "").substr((c + "").length), l || (l = 0), x = (0, p.l_)(a) || (h in p.Yz.units ? p.Yz.units[h] : g), g !== x && (c = U(t, h, s, x)), this._pt = new p.J7(this._pt, M ? E : S, h, c, (w ? (0, p.B0)(c, w + l) : l) - c, !M && ("px" === x || "zIndex" === h) && !1 !== e.autoRound ? _ : v), this._pt.u = x || 0, g !== x && "%" !== x && (this._pt.b = s, this._pt.r = b);
                                else if (h in S) $.call(this, t, h, s, w ? w + a : a);
                                else if (h in t) this.add(t, h, s || t[h], w ? w + a : a, r, i);
                                else if ("parseTransform" !== h) {
                                    (0, p.dg)(h, a);
                                    continue
                                }
                                M || (h in S ? C.push(h, 0, S[h]) : C.push(h, 1, s || t[h])), P.push(h)
                            }
                        }
                    Y && (0, p.St)(this)
                },
                render: function(t, e) {
                    if (e.tween._time || !l())
                        for (var n = e._pt; n;) n.r(t, n.d), n = n._next;
                    else e.styles.revert()
                },
                get: Z,
                aliases: y,
                getSetter: function(t, e, n) {
                    var r = y[e];
                    return r && 0 > r.indexOf(",") && (e = r), e in u && e !== k && (t._gsap.x || Z(t, "x")) ? n && a === n ? "scale" === e ? C : Y : (a = n || {}, "scale" === e ? P : S) : t.style && !(0, p.OF)(t.style[e]) ? E : ~e.indexOf("-") ? O : (0, p.Dx)(t, e)
                },
                core: {
                    _removeProperty: G,
                    _getMatrix: ta
                }
            };
            p.os.utils.checkPrefix = R, p.os.core.getStyleSaver = L,
                function(t, e, n, r) {
                    var i = (0, p.fA)(t + "," + e + "," + n, function(t) {
                        u[t] = 1
                    });
                    (0, p.fA)(e, function(t) {
                        p.Yz.units[t] = "deg", ti[t] = 1
                    }), y[i[13]] = t + "," + e, (0, p.fA)(r, function(t) {
                        var e = t.split(":");
                        y[e[1]] = i[e[0]]
                    })
                }("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY"), (0, p.fA)("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(t) {
                    p.Yz.units[t] = "px"
                }), p.os.registerPlugin(tv);
            var tw = p.os.registerPlugin(tv) || p.os;
            tw.core.Tween
        },
        53902: (t, e, n) => {
            n.d(e, {
                s: () => tU
            });
            var r, i, o, s, a, l, c, p, u, f = "transform",
                d = f + "Origin",
                h = function(t) {
                    var e = t.ownerDocument || t;
                    for (!(f in t.style) && ("msTransform" in t.style) && (d = (f = "msTransform") + "Origin"); e.parentNode && (e = e.parentNode););
                    if (i = window, c = new T, e) {
                        r = e, o = e.documentElement, s = e.body, (p = r.createElementNS("http://www.w3.org/2000/svg", "g")).style.transform = "none";
                        var n = e.createElement("div"),
                            a = e.createElement("div"),
                            l = e && (e.body || e.firstElementChild);
                        l && l.appendChild && (l.appendChild(n), n.appendChild(a), n.setAttribute("style", "position:static;transform:translate3d(0,0,1px)"), u = a.offsetParent !== n, l.removeChild(n))
                    }
                    return e
                },
                g = function(t) {
                    for (var e, n; t && t !== s;)(n = t._gsap) && n.uncache && n.get(t, "x"), n && !n.scaleX && !n.scaleY && n.renderTransform && (n.scaleX = n.scaleY = 1e-4, n.renderTransform(1, n), e ? e.push(n) : e = [n]), t = t.parentNode;
                    return e
                },
                x = [],
                m = [],
                y = function(t) {
                    return t.ownerSVGElement || ("svg" === (t.tagName + "").toLowerCase() ? t : null)
                },
                v = function t(e, n) {
                    if (e.parentNode && (r || h(e))) {
                        var i = y(e),
                            o = i ? i.getAttribute("xmlns") || "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml",
                            s = i ? n ? "rect" : "g" : "div",
                            c = 100 * (2 === n),
                            p = 100 * (3 === n),
                            u = "position:absolute;display:block;pointer-events:none;margin:0;padding:0;",
                            f = r.createElementNS ? r.createElementNS(o.replace(/^https/, "http"), s) : r.createElement(s);
                        return n && (i ? (l || (l = t(e)), f.setAttribute("width", .01), f.setAttribute("height", .01), f.setAttribute("transform", "translate(" + c + "," + p + ")"), l.appendChild(f)) : (a || ((a = t(e)).style.cssText = u), f.style.cssText = u + "width:0.1px;height:0.1px;top:" + p + "px;left:" + c + "px", a.appendChild(f))), f
                    }
                    throw "Need document and parent."
                },
                w = function(t) {
                    for (var e = new T, n = 0; n < t.numberOfItems; n++) e.multiply(t.getItem(n).matrix);
                    return e
                },
                b = function(t) {
                    var e, n = t.getCTM();
                    return n || (e = t.style[f], t.style[f] = "none", t.appendChild(p), n = p.getCTM(), t.removeChild(p), e ? t.style[f] = e : t.style.removeProperty(f.replace(/([A-Z])/g, "-$1").toLowerCase())), n || c.clone()
                },
                _ = function(t, e) {
                    var n, r, o, s, p, h, g = y(t),
                        _ = t === g,
                        M = g ? x : m,
                        E = t.parentNode;
                    if (t === i) return t;
                    if (M.length || M.push(v(t, 1), v(t, 2), v(t, 3)), n = g ? l : a, g) _ ? (s = -(o = b(t)).e / o.a, p = -o.f / o.d, r = c) : t.getBBox ? (o = t.getBBox(), s = (r = (r = t.transform ? t.transform.baseVal : {}).numberOfItems ? r.numberOfItems > 1 ? w(r) : r.getItem(0).matrix : c).a * o.x + r.c * o.y, p = r.b * o.x + r.d * o.y) : (r = new T, s = p = 0), e && "g" === t.tagName.toLowerCase() && (s = p = 0), (_ ? g : E).appendChild(n), n.setAttribute("transform", "matrix(" + r.a + "," + r.b + "," + r.c + "," + r.d + "," + (r.e + s) + "," + (r.f + p) + ")");
                    else {
                        if (s = p = 0, u)
                            for (r = t.offsetParent, o = t; o && (o = o.parentNode) && o !== r && o.parentNode;)(i.getComputedStyle(o)[f] + "").length > 4 && (s = o.offsetLeft, p = o.offsetTop, o = 0);
                        if ("absolute" !== (h = i.getComputedStyle(t)).position && "fixed" !== h.position)
                            for (r = t.offsetParent; E && E !== r;) s += E.scrollLeft || 0, p += E.scrollTop || 0, E = E.parentNode;
                        (o = n.style).top = t.offsetTop - p + "px", o.left = t.offsetLeft - s + "px", o[f] = h[f], o[d] = h[d], o.position = "fixed" === h.position ? "fixed" : "absolute", t.parentNode.appendChild(n)
                    }
                    return n
                },
                M = function(t, e, n, r, i, o, s) {
                    return t.a = e, t.b = n, t.c = r, t.d = i, t.e = o, t.f = s, t
                },
                T = function() {
                    function t(t, e, n, r, i, o) {
                        void 0 === t && (t = 1), void 0 === e && (e = 0), void 0 === n && (n = 0), void 0 === r && (r = 1), void 0 === i && (i = 0), void 0 === o && (o = 0), M(this, t, e, n, r, i, o)
                    }
                    var e = t.prototype;
                    return e.inverse = function() {
                        var t = this.a,
                            e = this.b,
                            n = this.c,
                            r = this.d,
                            i = this.e,
                            o = this.f,
                            s = t * r - e * n || 1e-10;
                        return M(this, r / s, -e / s, -n / s, t / s, (n * o - r * i) / s, -(t * o - e * i) / s)
                    }, e.multiply = function(t) {
                        var e = this.a,
                            n = this.b,
                            r = this.c,
                            i = this.d,
                            o = this.e,
                            s = this.f,
                            a = t.a,
                            l = t.c,
                            c = t.b,
                            p = t.d,
                            u = t.e,
                            f = t.f;
                        return M(this, a * e + c * r, a * n + c * i, l * e + p * r, l * n + p * i, o + u * e + f * r, s + u * n + f * i)
                    }, e.clone = function() {
                        return new t(this.a, this.b, this.c, this.d, this.e, this.f)
                    }, e.equals = function(t) {
                        var e = this.a,
                            n = this.b,
                            r = this.c,
                            i = this.d,
                            o = this.e,
                            s = this.f;
                        return e === t.a && n === t.b && r === t.c && i === t.d && o === t.e && s === t.f
                    }, e.apply = function(t, e) {
                        void 0 === e && (e = {});
                        var n = t.x,
                            r = t.y,
                            i = this.a,
                            o = this.b,
                            s = this.c,
                            a = this.d,
                            l = this.e,
                            c = this.f;
                        return e.x = n * i + r * s + l || 0, e.y = n * o + r * a + c || 0, e
                    }, t
                }();

            function E(t, e, n, a) {
                if (!t || !t.parentNode || (r || h(t)).documentElement === t) return new T;
                var l = g(t),
                    c = y(t) ? x : m,
                    p = _(t, n),
                    u = c[0].getBoundingClientRect(),
                    f = c[1].getBoundingClientRect(),
                    d = c[2].getBoundingClientRect(),
                    v = p.parentNode,
                    w = !a && function t(e) {
                        return "fixed" === i.getComputedStyle(e).position || ((e = e.parentNode) && 1 === e.nodeType ? t(e) : void 0)
                    }(t),
                    b = new T((f.left - u.left) / 100, (f.top - u.top) / 100, (d.left - u.left) / 100, (d.top - u.top) / 100, u.left + (w ? 0 : i.pageXOffset || r.scrollLeft || o.scrollLeft || s.scrollLeft || 0), u.top + (w ? 0 : i.pageYOffset || r.scrollTop || o.scrollTop || s.scrollTop || 0));
                if (v.removeChild(p), l)
                    for (u = l.length; u--;)(f = l[u]).scaleX = f.scaleY = 0, f.renderTransform(1, f);
                return e ? b.inverse() : b
            }

            function O(t) {
                if (void 0 === t) throw ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t
            }
            var Y, C, P, S, X, k, D, A, N, L, B, F, I, R, z, H, W, V, q, G, j, J, K = 0,
                U = function() {
                    return "undefined" != typeof window
                },
                Z = function() {
                    return Y || U() && (Y = window.gsap) && Y.registerPlugin && Y
                },
                $ = function(t) {
                    return "function" == typeof t
                },
                Q = function(t) {
                    return "object" == typeof t
                },
                tt = function(t) {
                    return void 0 === t
                },
                te = function() {
                    return !1
                },
                tn = "transform",
                tr = "transformOrigin",
                ti = function(t) {
                    return Math.round(1e4 * t) / 1e4
                },
                to = Array.isArray,
                ts = function(t, e) {
                    var n = P.createElementNS ? P.createElementNS((e || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), t) : P.createElement(t);
                    return n.style ? n : P.createElement(t)
                },
                ta = 180 / Math.PI,
                tl = new T,
                tc = Date.now || function() {
                    return new Date().getTime()
                },
                tp = [],
                tu = {},
                tf = 0,
                td = /^(?:a|input|textarea|button|select)$/i,
                th = 0,
                tg = {},
                tx = {},
                tm = function(t, e) {
                    var n, r = {};
                    for (n in t) r[n] = e ? t[n] * e : t[n];
                    return r
                },
                ty = function(t, e) {
                    for (var n in e) n in t || (t[n] = e[n]);
                    return t
                },
                tv = function t(e, n) {
                    for (var r, i = e.length; i--;) n ? e[i].style.touchAction = n : e[i].style.removeProperty("touch-action"), (r = e[i].children) && r.length && t(r, n)
                },
                tw = function() {
                    return tp.forEach(function(t) {
                        return t()
                    })
                },
                tb = function(t) {
                    tp.push(t), 1 === tp.length && Y.ticker.add(tw)
                },
                t_ = function() {
                    return !tp.length && Y.ticker.remove(tw)
                },
                tM = function(t) {
                    for (var e = tp.length; e--;) tp[e] === t && tp.splice(e, 1);
                    Y.to(t_, {
                        overwrite: !0,
                        delay: 15,
                        duration: 0,
                        onComplete: t_,
                        data: "_draggable"
                    })
                },
                tT = function(t, e, n, r) {
                    if (t.addEventListener) {
                        var i = I[e];
                        r = r || (B ? {
                            passive: !1
                        } : null), t.addEventListener(i || e, n, r), i && e !== i && t.addEventListener(e, n, r)
                    }
                },
                tE = function(t, e, n, r) {
                    if (t.removeEventListener) {
                        var i = I[e];
                        t.removeEventListener(i || e, n, r), i && e !== i && t.removeEventListener(e, n, r)
                    }
                },
                tO = function(t) {
                    t.preventDefault && t.preventDefault(), t.preventManipulation && t.preventManipulation()
                },
                tY = function(t, e) {
                    for (var n = t.length; n--;)
                        if (t[n].identifier === e) return !0
                },
                tC = function t(e) {
                    R = e.touches && K < e.touches.length, tE(e.target, "touchend", t)
                },
                tP = function(t) {
                    R = t.touches && K < t.touches.length, tT(t.target, "touchend", tC)
                },
                tS = function(t) {
                    return C.pageYOffset || t.scrollTop || t.documentElement.scrollTop || t.body.scrollTop || 0
                },
                tX = function(t) {
                    return C.pageXOffset || t.scrollLeft || t.documentElement.scrollLeft || t.body.scrollLeft || 0
                },
                tk = function t(e, n) {
                    tT(e, "scroll", n), tA(e.parentNode) || t(e.parentNode, n)
                },
                tD = function t(e, n) {
                    tE(e, "scroll", n), tA(e.parentNode) || t(e.parentNode, n)
                },
                tA = function(t) {
                    return !!(!t || t === S || 9 === t.nodeType || t === P.body || t === C || !t.nodeType || !t.parentNode)
                },
                tN = function(t, e) {
                    var n = "x" === e ? "Width" : "Height",
                        r = "scroll" + n,
                        i = "client" + n;
                    return Math.max(0, tA(t) ? Math.max(S[r], X[r]) - (C["inner" + n] || S[i] || X[i]) : t[r] - t[i])
                },
                tL = function t(e, n) {
                    var r = tN(e, "x"),
                        i = tN(e, "y");
                    tA(e) ? e = tx : t(e.parentNode, n), e._gsMaxScrollX = r, e._gsMaxScrollY = i, n || (e._gsScrollX = e.scrollLeft || 0, e._gsScrollY = e.scrollTop || 0)
                },
                tB = function(t, e, n) {
                    var r = t.style;
                    r && (tt(r[e]) && (e = N(e, t) || e), null == n ? r.removeProperty && r.removeProperty(e.replace(/([A-Z])/g, "-$1").toLowerCase()) : r[e] = n)
                },
                tF = function(t) {
                    return C.getComputedStyle(t instanceof Element ? t : t.host || (t.parentNode || {}).host || t)
                },
                tI = {},
                tR = function(t) {
                    if (t === C) return tI.left = tI.top = 0, tI.width = tI.right = S.clientWidth || t.innerWidth || X.clientWidth || 0, tI.height = tI.bottom = (t.innerHeight || 0) - 20 < S.clientHeight ? S.clientHeight : t.innerHeight || X.clientHeight || 0, tI;
                    var e = t.ownerDocument || P,
                        n = tt(t.pageX) ? t.nodeType || tt(t.left) || tt(t.top) ? L(t)[0].getBoundingClientRect() : t : {
                            left: t.pageX - tX(e),
                            top: t.pageY - tS(e),
                            right: t.pageX - tX(e) + 1,
                            bottom: t.pageY - tS(e) + 1
                        };
                    return tt(n.right) && !tt(n.width) ? (n.right = n.left + n.width, n.bottom = n.top + n.height) : tt(n.width) && (n = {
                        width: n.right - n.left,
                        height: n.bottom - n.top,
                        right: n.right,
                        left: n.left,
                        bottom: n.bottom,
                        top: n.top
                    }), n
                },
                tz = function(t, e, n) {
                    var r, i = t.vars,
                        o = i[n],
                        s = t._listeners[e];
                    return $(o) && (r = o.apply(i.callbackScope || t, i[n + "Params"] || [t.pointerEvent])), s && !1 === t.dispatchEvent(e) && (r = !1), r
                },
                tH = function(t, e) {
                    var n, r, i, o = L(t)[0];
                    return o.nodeType || o === C ? tV(o, e) : tt(t.left) ? {
                        left: r = t.min || t.minX || t.minRotation || 0,
                        top: n = t.min || t.minY || 0,
                        width: (t.max || t.maxX || t.maxRotation || 0) - r,
                        height: (t.max || t.maxY || 0) - n
                    } : (i = {
                        x: 0,
                        y: 0
                    }, {
                        left: t.left - i.x,
                        top: t.top - i.y,
                        width: t.width,
                        height: t.height
                    })
                },
                tW = {},
                tV = function(t, e) {
                    e = L(e)[0];
                    var n, r, i, o, s, a, l, c, p, u, f, d, h, g = t.getBBox && t.ownerSVGElement,
                        x = t.ownerDocument || P;
                    if (t === C) i = tS(x), r = (n = tX(x)) + (x.documentElement.clientWidth || t.innerWidth || x.body.clientWidth || 0), o = i + ((t.innerHeight || 0) - 20 < x.documentElement.clientHeight ? x.documentElement.clientHeight : t.innerHeight || x.body.clientHeight || 0);
                    else {
                        if (e === C || tt(e)) return t.getBoundingClientRect();
                        n = i = 0, g ? (f = (u = t.getBBox()).width, d = u.height) : (t.viewBox && (u = t.viewBox.baseVal) && (n = u.x || 0, i = u.y || 0, f = u.width, d = u.height), f || (u = "border-box" === (h = tF(t)).boxSizing, f = (parseFloat(h.width) || t.clientWidth || 0) + (u ? 0 : parseFloat(h.borderLeftWidth) + parseFloat(h.borderRightWidth)), d = (parseFloat(h.height) || t.clientHeight || 0) + (u ? 0 : parseFloat(h.borderTopWidth) + parseFloat(h.borderBottomWidth)))), r = f, o = d
                    }
                    return t === e ? {
                        left: n,
                        top: i,
                        width: r - n,
                        height: o - i
                    } : (a = (s = E(e, !0).multiply(E(t))).apply({
                        x: n,
                        y: i
                    }), l = s.apply({
                        x: r,
                        y: i
                    }), c = s.apply({
                        x: r,
                        y: o
                    }), p = s.apply({
                        x: n,
                        y: o
                    }), {
                        left: n = Math.min(a.x, l.x, c.x, p.x),
                        top: i = Math.min(a.y, l.y, c.y, p.y),
                        width: Math.max(a.x, l.x, c.x, p.x) - n,
                        height: Math.max(a.y, l.y, c.y, p.y) - i
                    })
                },
                tq = function(t, e, n, r, i, o) {
                    var s, a, l, c = {};
                    if (e)
                        if (1 !== i && e instanceof Array) {
                            if (c.end = s = [], l = e.length, Q(e[0]))
                                for (a = 0; a < l; a++) s[a] = tm(e[a], i);
                            else
                                for (a = 0; a < l; a++) s[a] = e[a] * i;
                            n += 1.1, r -= 1.1
                        } else $(e) ? c.end = function(n) {
                            var r, o, s = e.call(t, n);
                            if (1 !== i)
                                if (Q(s)) {
                                    for (o in r = {}, s) r[o] = s[o] * i;
                                    s = r
                                } else s *= i;
                            return s
                        } : c.end = e;
                    return (n || 0 === n) && (c.max = n), (r || 0 === r) && (c.min = r), o && (c.velocity = 0), c
                },
                tG = function t(e) {
                    var n;
                    return !!e && !!e.getAttribute && e !== X && (!!("true" === (n = e.getAttribute("data-clickable")) || "false" !== n && (td.test(e.nodeName + "") || "true" === e.getAttribute("contentEditable"))) || t(e.parentNode))
                },
                tj = function(t, e) {
                    for (var n, r = t.length; r--;)(n = t[r]).ondragstart = n.onselectstart = e ? null : te, Y.set(n, {
                        lazy: !0,
                        userSelect: e ? "text" : "none"
                    })
                },
                tJ = function(t, e) {
                    t = Y.utils.toArray(t)[0], e = e || {};
                    var n, r, i, o, s, a, l = document.createElement("div"),
                        c = l.style,
                        p = t.firstChild,
                        u = 0,
                        f = 0,
                        d = t.scrollTop,
                        h = t.scrollLeft,
                        g = t.scrollWidth,
                        x = t.scrollHeight,
                        m = 0,
                        y = 0,
                        v = 0;
                    j && !1 !== e.force3D ? (s = "translate3d(", a = "px,0px)") : tn && (s = "translate(", a = "px)"), this.scrollTop = function(t, e) {
                        if (!arguments.length) return -this.top();
                        this.top(-t, e)
                    }, this.scrollLeft = function(t, e) {
                        if (!arguments.length) return -this.left();
                        this.left(-t, e)
                    }, this.left = function(n, r) {
                        if (!arguments.length) return -(t.scrollLeft + f);
                        var i = t.scrollLeft - h,
                            o = f;
                        if ((i > 2 || i < -2) && !r) {
                            h = t.scrollLeft, Y.killTweensOf(this, {
                                left: 1,
                                scrollLeft: 1
                            }), this.left(-h), e.onKill && e.onKill();
                            return
                        }(n = -n) < 0 ? (f = n - .5 | 0, n = 0) : n > y ? (f = n - y | 0, n = y) : f = 0, (f || o) && (this._skip || (c[tn] = s + -f + "px," + -u + a), f + m >= 0 && (c.paddingRight = f + m + "px")), t.scrollLeft = 0 | n, h = t.scrollLeft
                    }, this.top = function(n, r) {
                        if (!arguments.length) return -(t.scrollTop + u);
                        var i = t.scrollTop - d,
                            o = u;
                        if ((i > 2 || i < -2) && !r) {
                            d = t.scrollTop, Y.killTweensOf(this, {
                                top: 1,
                                scrollTop: 1
                            }), this.top(-d), e.onKill && e.onKill();
                            return
                        }(n = -n) < 0 ? (u = n - .5 | 0, n = 0) : n > v ? (u = n - v | 0, n = v) : u = 0, (u || o) && !this._skip && (c[tn] = s + -f + "px," + -u + a), t.scrollTop = 0 | n, d = t.scrollTop
                    }, this.maxScrollTop = function() {
                        return v
                    }, this.maxScrollLeft = function() {
                        return y
                    }, this.disable = function() {
                        for (p = l.firstChild; p;) o = p.nextSibling, t.appendChild(p), p = o;
                        t === l.parentNode && t.removeChild(l)
                    }, this.enable = function() {
                        if ((p = t.firstChild) !== l) {
                            for (; p;) o = p.nextSibling, l.appendChild(p), p = o;
                            t.appendChild(l), this.calibrate()
                        }
                    }, this.calibrate = function(e) {
                        var o, s, a, p = t.clientWidth === n;
                        d = t.scrollTop, h = t.scrollLeft, (!p || t.clientHeight !== r || l.offsetHeight !== i || g !== t.scrollWidth || x !== t.scrollHeight || e) && ((u || f) && (s = this.left(), a = this.top(), this.left(-t.scrollLeft), this.top(-t.scrollTop)), o = tF(t), (!p || e) && (c.display = "block", c.width = "auto", c.paddingRight = "0px", (m = Math.max(0, t.scrollWidth - t.clientWidth)) && (m += parseFloat(o.paddingLeft) + (J ? parseFloat(o.paddingRight) : 0))), c.display = "inline-block", c.position = "relative", c.overflow = "visible", c.verticalAlign = "top", c.boxSizing = "content-box", c.width = "100%", c.paddingRight = m + "px", J && (c.paddingBottom = o.paddingBottom), n = t.clientWidth, r = t.clientHeight, g = t.scrollWidth, x = t.scrollHeight, y = t.scrollWidth - n, v = t.scrollHeight - r, i = l.offsetHeight, c.display = "block", (s || a) && (this.left(s), this.top(a)))
                    }, this.content = l, this.element = t, this._skip = !1, this.enable()
                },
                tK = function(t) {
                    if (U() && document.body) {
                        var e, n, r, i, o, s = window && window.navigator;
                        C = window, S = (P = document).documentElement, X = P.body, k = ts("div"), V = !!window.PointerEvent, (D = ts("div")).style.cssText = "visibility:hidden;height:1px;top:-1px;pointer-events:none;position:relative;clear:both;cursor:grab", W = "grab" === D.style.cursor ? "grab" : "move", z = s && -1 !== s.userAgent.toLowerCase().indexOf("android"), F = "ontouchstart" in S && "orientation" in C || s && (s.MaxTouchPoints > 0 || s.msMaxTouchPoints > 0), n = ts("div"), i = (r = ts("div")).style, o = X, i.display = "inline-block", i.position = "relative", n.style.cssText = "width:90px;height:40px;padding:10px;overflow:auto;visibility:hidden", n.appendChild(r), o.appendChild(n), e = r.offsetHeight + 18 > n.scrollHeight, o.removeChild(n), J = e, I = function(t) {
                            for (var e = t.split(","), n = (("onpointerdown" in k) ? "pointerdown,pointermove,pointerup,pointercancel" : ("onmspointerdown" in k) ? "MSPointerDown,MSPointerMove,MSPointerUp,MSPointerCancel" : t).split(","), r = {}, i = 4; --i > -1;) r[e[i]] = n[i], r[n[i]] = e[i];
                            try {
                                S.addEventListener("test", null, Object.defineProperty({}, "passive", {
                                    get: function() {
                                        B = 1
                                    }
                                }))
                            } catch (t) {}
                            return r
                        }("touchstart,touchmove,touchend,touchcancel"), tT(P, "touchcancel", te), tT(C, "touchmove", te), X && X.addEventListener("touchstart", te), tT(P, "contextmenu", function() {
                            for (var t in tu) tu[t].isPressed && tu[t].endDrag()
                        }), Y = A = Z()
                    }
                    Y ? (H = Y.plugins.inertia, q = Y.core.context || function() {}, tn = (N = Y.utils.checkPrefix)(tn), tr = N(tr), L = Y.utils.toArray, G = Y.core.getStyleSaver, j = !!N("perspective")) : t && console.warn("Please gsap.registerPlugin(Draggable)")
                },
                tU = function(t) {
                    function e(n, r) {
                        i = t.call(this) || this, A || tK(1), n = L(n)[0], i.styles = G && G(n, "transform,left,top"), H || (H = Y.plugins.inertia), i.vars = r = tm(r || {}), i.target = n, i.x = i.y = i.rotation = 0, i.dragResistance = parseFloat(r.dragResistance) || 0, i.edgeResistance = isNaN(r.edgeResistance) ? 1 : parseFloat(r.edgeResistance) || 0, i.lockAxis = r.lockAxis, i.autoScroll = r.autoScroll || 0, i.lockedAxis = null, i.allowEventDefault = !!r.allowEventDefault, Y.getProperty(n, "x");
                        var i, o, s, a, l, c, p, u, f, d, h, g, x, m, y, v, w, b, _, M, X, k, N, B, j, J, U, Z, te, tn, ts, tp, td, tw, t_ = (r.type || "x,y").toLowerCase(),
                            tC = ~t_.indexOf("x") || ~t_.indexOf("y"),
                            tN = -1 !== t_.indexOf("rotation"),
                            tI = tN ? "rotation" : tC ? "x" : "left",
                            tV = tC ? "y" : "top",
                            tU = !!(~t_.indexOf("x") || ~t_.indexOf("left") || "scroll" === t_),
                            tZ = !!(~t_.indexOf("y") || ~t_.indexOf("top") || "scroll" === t_),
                            t$ = r.minimumMovement || 2,
                            tQ = O(i),
                            t0 = L(r.trigger || r.handle || n),
                            t1 = {},
                            t2 = 0,
                            t3 = !1,
                            t4 = r.autoScrollMarginTop || 40,
                            t8 = r.autoScrollMarginRight || 40,
                            t6 = r.autoScrollMarginBottom || 40,
                            t5 = r.autoScrollMarginLeft || 40,
                            t9 = r.clickableTest || tG,
                            t7 = 0,
                            et = n._gsap || Y.core.getCache(n),
                            ee = function t(e) {
                                return "fixed" === tF(e).position || ((e = e.parentNode) && 1 === e.nodeType ? t(e) : void 0)
                            }(n),
                            en = function(t, e) {
                                return parseFloat(et.get(n, t, e))
                            },
                            er = n.ownerDocument || P,
                            ei = function(t) {
                                return tO(t), t.stopImmediatePropagation && t.stopImmediatePropagation(), !1
                            },
                            eo = function t(e) {
                                if (tQ.autoScroll && tQ.isDragging && (t3 || b)) {
                                    var r, i, o, a, l, c, p, u, d = n,
                                        h = 15 * tQ.autoScroll;
                                    for (t3 = !1, tx.scrollTop = null != C.pageYOffset ? C.pageYOffset : null != er.documentElement.scrollTop ? er.documentElement.scrollTop : er.body.scrollTop, tx.scrollLeft = null != C.pageXOffset ? C.pageXOffset : null != er.documentElement.scrollLeft ? er.documentElement.scrollLeft : er.body.scrollLeft, a = tQ.pointerX - tx.scrollLeft, l = tQ.pointerY - tx.scrollTop; d && !i;) r = (i = tA(d.parentNode)) ? tx : d.parentNode, o = i ? {
                                        bottom: Math.max(S.clientHeight, C.innerHeight || 0),
                                        right: Math.max(S.clientWidth, C.innerWidth || 0),
                                        left: 0,
                                        top: 0
                                    } : r.getBoundingClientRect(), c = p = 0, tZ && ((u = r._gsMaxScrollY - r.scrollTop) < 0 ? p = u : l > o.bottom - t6 && u ? (t3 = !0, p = Math.min(u, h * (1 - Math.max(0, o.bottom - l) / t6) | 0)) : l < o.top + t4 && r.scrollTop && (t3 = !0, p = -Math.min(r.scrollTop, h * (1 - Math.max(0, l - o.top) / t4) | 0)), p && (r.scrollTop += p)), tU && ((u = r._gsMaxScrollX - r.scrollLeft) < 0 ? c = u : a > o.right - t8 && u ? (t3 = !0, c = Math.min(u, h * (1 - Math.max(0, o.right - a) / t8) | 0)) : a < o.left + t5 && r.scrollLeft && (t3 = !0, c = -Math.min(r.scrollLeft, h * (1 - Math.max(0, a - o.left) / t5) | 0)), c && (r.scrollLeft += c)), i && (c || p) && (C.scrollTo(r.scrollLeft, r.scrollTop), ey(tQ.pointerX + c, tQ.pointerY + p)), d = r
                                }
                                if (b) {
                                    var g = tQ.x,
                                        x = tQ.y;
                                    tN ? (tQ.deltaX = g - parseFloat(et.rotation), tQ.rotation = g, et.rotation = g + "deg", et.renderTransform(1, et)) : s ? (tZ && (tQ.deltaY = x - s.top(), s.top(x)), tU && (tQ.deltaX = g - s.left(), s.left(g))) : tC ? (tZ && (tQ.deltaY = x - parseFloat(et.y), et.y = x + "px"), tU && (tQ.deltaX = g - parseFloat(et.x), et.x = g + "px"), et.renderTransform(1, et)) : (tZ && (tQ.deltaY = x - parseFloat(n.style.top || 0), n.style.top = x + "px"), tU && (tQ.deltaX = g - parseFloat(n.style.left || 0), n.style.left = g + "px")), !f || e || te || (te = !0, !1 === tz(tQ, "drag", "onDrag") && (tU && (tQ.x -= tQ.deltaX), tZ && (tQ.y -= tQ.deltaY), t(!0)), te = !1)
                                }
                                b = !1
                            },
                            es = function(t, e) {
                                var r, i, o = tQ.x,
                                    a = tQ.y;
                                n._gsap || (et = Y.core.getCache(n)), et.uncache && Y.getProperty(n, "x"), tC ? (tQ.x = parseFloat(et.x), tQ.y = parseFloat(et.y)) : tN ? tQ.x = tQ.rotation = parseFloat(et.rotation) : s ? (tQ.y = s.top(), tQ.x = s.left()) : (tQ.y = parseFloat(n.style.top || (i = tF(n)) && i.top) || 0, tQ.x = parseFloat(n.style.left || (i || {}).left) || 0), (M || X || k) && !e && (tQ.isDragging || tQ.isThrowing) && (k && (tg.x = tQ.x, tg.y = tQ.y, (r = k(tg)).x !== tQ.x && (tQ.x = r.x, b = !0), r.y !== tQ.y && (tQ.y = r.y, b = !0)), M && (r = M(tQ.x)) !== tQ.x && (tQ.x = r, tN && (tQ.rotation = r), b = !0), X && ((r = X(tQ.y)) !== tQ.y && (tQ.y = r), b = !0)), b && eo(!0), t || (tQ.deltaX = tQ.x - o, tQ.deltaY = tQ.y - a, tz(tQ, "throwupdate", "onThrowUpdate"))
                            },
                            ea = function(t, e, n, r) {
                                return (null == e && (e = -1e20), null == n && (n = 1e20), $(t)) ? function(i) {
                                    var o = tQ.isPressed ? 1 - tQ.edgeResistance : 1;
                                    return t.call(tQ, (i > n ? n + (i - n) * o : i < e ? e + (i - e) * o : i) * r) * r
                                } : to(t) ? function(r) {
                                    for (var i, o, s = t.length, a = 0, l = 1e20; --s > -1;)(o = (i = t[s]) - r) < 0 && (o = -o), o < l && i >= e && i <= n && (a = s, l = o);
                                    return t[a]
                                } : isNaN(t) ? function(t) {
                                    return t
                                } : function() {
                                    return t * r
                                }
                            },
                            el = function() {
                                var t, e, i, o, a, l, c, p, f, d, y;
                                u = !1, s ? (s.calibrate(), tQ.minX = g = -s.maxScrollLeft(), tQ.minY = m = -s.maxScrollTop(), tQ.maxX = h = tQ.maxY = x = 0, u = !0) : r.bounds && (t = tH(r.bounds, n.parentNode), tN ? (tQ.minX = g = t.left, tQ.maxX = h = t.left + t.width, tQ.minY = m = tQ.maxY = x = 0) : tt(r.bounds.maxX) && tt(r.bounds.maxY) ? (e = tH(n, n.parentNode), tQ.minX = g = Math.round(en(tI, "px") + t.left - e.left), tQ.minY = m = Math.round(en(tV, "px") + t.top - e.top), tQ.maxX = h = Math.round(g + (t.width - e.width)), tQ.maxY = x = Math.round(m + (t.height - e.height))) : (tQ.minX = g = (t = r.bounds).minX, tQ.minY = m = t.minY, tQ.maxX = h = t.maxX, tQ.maxY = x = t.maxY), g > h && (tQ.minX = h, tQ.maxX = h = g, g = tQ.minX), m > x && (tQ.minY = x, tQ.maxY = x = m, m = tQ.minY), tN && (tQ.minRotation = g, tQ.maxRotation = h), u = !0), r.liveSnap && ((o = to(i = !0 === r.liveSnap ? r.snap || {} : r.liveSnap) || $(i), tN) ? (M = ea(o ? i : i.rotation, g, h, 1), X = null) : i.points ? (a = o ? i : i.points, l = g, c = h, p = m, f = x, d = i.radius, y = s ? -1 : 1, d = d && d < 1e20 ? d * d : 1e20, k = $(a) ? function(t) {
                                    var e, n, r, i = tQ.isPressed ? 1 - tQ.edgeResistance : 1,
                                        o = t.x,
                                        s = t.y;
                                    return t.x = o = o > c ? c + (o - c) * i : o < l ? l + (o - l) * i : o, t.y = s = s > f ? f + (s - f) * i : s < p ? p + (s - p) * i : s, (e = a.call(tQ, t)) !== t && (t.x = e.x, t.y = e.y), 1 !== y && (t.x *= y, t.y *= y), d < 1e20 && (n = t.x - o) * n + (r = t.y - s) * r > d && (t.x = o, t.y = s), t
                                } : to(a) ? function(t) {
                                    for (var e, n, r, i, o = a.length, s = 0, l = 1e20; --o > -1;)(i = (e = (r = a[o]).x - t.x) * e + (n = r.y - t.y) * n) < l && (s = o, l = i);
                                    return l <= d ? a[s] : t
                                } : function(t) {
                                    return t
                                }) : (tU && (M = ea(o ? i : i.x || i.left || i.scrollLeft, g, h, s ? -1 : 1)), tZ && (X = ea(o ? i : i.y || i.top || i.scrollTop, m, x, s ? -1 : 1))))
                            },
                            ec = function() {
                                tQ.isThrowing = !1, tz(tQ, "throwcomplete", "onThrowComplete")
                            },
                            ep = function() {
                                tQ.isThrowing = !1
                            },
                            eu = function(t, e) {
                                var i, o, a, l;
                                t && H ? (!0 === t && (o = to(i = r.snap || r.liveSnap || {}) || $(i), t = {
                                    resistance: (r.throwResistance || r.resistance || 1e3) / (tN ? 10 : 1)
                                }, tN ? t.rotation = tq(tQ, o ? i : i.rotation, h, g, 1, e) : (tU && (t[tI] = tq(tQ, o ? i : i.points || i.x || i.left, h, g, s ? -1 : 1, e || "x" === tQ.lockedAxis)), tZ && (t[tV] = tq(tQ, o ? i : i.points || i.y || i.top, x, m, s ? -1 : 1, e || "y" === tQ.lockedAxis)), (i.points || to(i) && Q(i[0])) && (t.linkedProps = tI + "," + tV, t.radius = i.radius))), tQ.isThrowing = !0, l = isNaN(r.overshootTolerance) ? 1 === r.edgeResistance ? 0 : 1 - tQ.edgeResistance + .2 : r.overshootTolerance, t.duration || (t.duration = {
                                    max: Math.max(r.minDuration || 0, "maxDuration" in r ? r.maxDuration : 2),
                                    min: isNaN(r.minDuration) ? 0 === l || Q(t) && t.resistance > 1e3 ? 0 : .5 : r.minDuration,
                                    overshoot: l
                                }), tQ.tween = a = Y.to(s || n, {
                                    inertia: t,
                                    data: "_draggable",
                                    inherit: !1,
                                    onComplete: ec,
                                    onInterrupt: ep,
                                    onUpdate: r.fastMode ? tz : es,
                                    onUpdateParams: r.fastMode ? [tQ, "onthrowupdate", "onThrowUpdate"] : i && i.radius ? [!1, !0] : []
                                }), !r.fastMode && (s && (s._skip = !0), a.render(1e9, !0, !0), es(!0, !0), tQ.endX = tQ.x, tQ.endY = tQ.y, tN && (tQ.endRotation = tQ.x), a.play(0), es(!0, !0), s && (s._skip = !1))) : u && tQ.applyBounds()
                            },
                            ef = function(t) {
                                var e, r = j;
                                j = E(n.parentNode, !0), t && tQ.isPressed && !j.equals(r || new T) && (e = r.inverse().apply({
                                    x: a,
                                    y: l
                                }), j.apply(e, e), a = e.x, l = e.y), j.equals(tl) && (j = null)
                            },
                            ed = function() {
                                var t, e, r, i = 1 - tQ.edgeResistance,
                                    o = ee ? tX(er) : 0,
                                    f = ee ? tS(er) : 0;
                                tC && (et.x = en(tI, "px") + "px", et.y = en(tV, "px") + "px", et.renderTransform()), ef(!1), tW.x = tQ.pointerX - o, tW.y = tQ.pointerY - f, j && j.apply(tW, tW), a = tW.x, l = tW.y, b && (ey(tQ.pointerX, tQ.pointerY), eo(!0)), td = E(n), s ? (el(), p = s.top(), c = s.left()) : (eh() ? (es(!0, !0), el()) : tQ.applyBounds(), tN ? (t = n.ownerSVGElement ? [et.xOrigin - n.getBBox().x, et.yOrigin - n.getBBox().y] : (tF(n)[tr] || "0 0").split(" "), w = tQ.rotationOrigin = E(n).apply({
                                    x: parseFloat(t[0]) || 0,
                                    y: parseFloat(t[1]) || 0
                                }), es(!0, !0), e = tQ.pointerX - w.x - o, r = w.y - tQ.pointerY + f, c = tQ.x, p = tQ.y = Math.atan2(r, e) * ta) : (p = en(tV, "px"), c = en(tI, "px"))), u && i && (c > h ? c = h + (c - h) / i : c < g && (c = g - (g - c) / i), !tN && (p > x ? p = x + (p - x) / i : p < m && (p = m - (m - p) / i))), tQ.startX = c = ti(c), tQ.startY = p = ti(p)
                            },
                            eh = function() {
                                return tQ.tween && tQ.tween.isActive()
                            },
                            eg = function() {
                                !D.parentNode || eh() || tQ.isDragging || D.parentNode.removeChild(D)
                            },
                            ex = function(t, i) {
                                var c;
                                if (!o || tQ.isPressed || !t || ("mousedown" === t.type || "pointerdown" === t.type) && !i && tc() - t7 < 30 && I[tQ.pointerEvent.type]) {
                                    tp && t && o && tO(t);
                                    return
                                }
                                if (J = eh(), tw = !1, tQ.pointerEvent = t, I[t.type] ? (tT(B = ~t.type.indexOf("touch") ? t.currentTarget || t.target : er, "touchend", ev), tT(B, "touchmove", em), tT(B, "touchcancel", ev), tT(er, "touchstart", tP)) : (B = null, tT(er, "mousemove", em)), Z = null, (!V || !B) && (tT(er, "mouseup", ev), t && t.target && tT(t.target, "mouseup", ev)), N = t9.call(tQ, t.target) && !1 === r.dragClickables && !i) {
                                    tT(t.target, "change", ev), tz(tQ, "pressInit", "onPressInit"), tz(tQ, "press", "onPress"), tj(t0, !0), tp = !1;
                                    return
                                }
                                if ((tp = !(U = !!B && tU !== tZ && !1 !== tQ.vars.allowNativeTouchScrolling && (!tQ.vars.allowContextMenu || !t || !t.ctrlKey && !(t.which > 2)) && (tU ? "y" : "x")) && !tQ.allowEventDefault) && (tO(t), tT(C, "touchforcechange", tO)), t.changedTouches ? v = (t = y = t.changedTouches[0]).identifier : t.pointerId ? v = t.pointerId : y = v = null, K++, tb(eo), l = tQ.pointerY = t.pageY, a = tQ.pointerX = t.pageX, tz(tQ, "pressInit", "onPressInit"), (U || tQ.autoScroll) && tL(n.parentNode), !n.parentNode || !tQ.autoScroll || s || tN || !n.parentNode._gsMaxScrollX || D.parentNode || n.getBBox || (D.style.width = n.parentNode.scrollWidth + "px", n.parentNode.appendChild(D)), ed(), tQ.tween && tQ.tween.kill(), tQ.isThrowing = !1, Y.killTweensOf(s || n, t1, !0), s && Y.killTweensOf(n, {
                                        scrollTo: 1
                                    }, !0), tQ.tween = tQ.lockedAxis = null, !r.zIndexBoost && (tN || s || !1 === r.zIndexBoost) || (n.style.zIndex = e.zIndex++), tQ.isPressed = !0, f = !!(r.onDrag || tQ._listeners.drag), d = !!(r.onMove || tQ._listeners.move), !1 !== r.cursor || r.activeCursor)
                                    for (c = t0.length; --c > -1;) Y.set(t0[c], {
                                        cursor: r.activeCursor || r.cursor || ("grab" === W ? "grabbing" : W)
                                    });
                                tz(tQ, "press", "onPress")
                            },
                            em = function(t) {
                                var e, r, i, s, c, p, u = t;
                                if (!o || R || !tQ.isPressed || !t) {
                                    tp && t && o && tO(t);
                                    return
                                }
                                if (tQ.pointerEvent = t, e = t.changedTouches) {
                                    if ((t = e[0]) !== y && t.identifier !== v) {
                                        for (s = e.length; --s > -1 && (t = e[s]).identifier !== v && t.target !== n;);
                                        if (s < 0) return
                                    }
                                } else if (t.pointerId && v && t.pointerId !== v) return;
                                if (B && U && !Z && (tW.x = t.pageX - (ee ? tX(er) : 0), tW.y = t.pageY - (ee ? tS(er) : 0), j && j.apply(tW, tW), r = tW.x, i = tW.y, (c = Math.abs(r - a)) !== (p = Math.abs(i - l)) && (c > t$ || p > t$) || z && U === Z) && (Z = c > p && tU ? "x" : "y", U && Z !== U && tT(C, "touchforcechange", tO), !1 !== tQ.vars.lockAxisOnTouchScroll && tU && tZ && (tQ.lockedAxis = "x" === Z ? "y" : "x", $(tQ.vars.onLockAxis) && tQ.vars.onLockAxis.call(tQ, u)), z && U === Z)) return void ev(u);
                                tQ.allowEventDefault || U && (!Z || U === Z) || !1 === u.cancelable ? tp && (tp = !1) : (tO(u), tp = !0), tQ.autoScroll && (t3 = !0), ey(t.pageX, t.pageY, d)
                            },
                            ey = function(t, e, n) {
                                var r, i, o, s, f, d, y = 1 - tQ.dragResistance,
                                    v = 1 - tQ.edgeResistance,
                                    _ = tQ.pointerX,
                                    T = tQ.pointerY,
                                    E = p,
                                    O = tQ.x,
                                    Y = tQ.y,
                                    C = tQ.endX,
                                    P = tQ.endY,
                                    S = tQ.endRotation,
                                    D = b;
                                tQ.pointerX = t, tQ.pointerY = e, ee && (t -= tX(er), e -= tS(er)), tN ? (s = Math.atan2(w.y - e, t - w.x) * ta, (f = tQ.y - s) > 180 ? (p -= 360, tQ.y = s) : f < -180 && (p += 360, tQ.y = s), tQ.x !== c || Math.abs(p - s) > t$ ? (tQ.y = s, o = c + (p - s) * y) : o = c) : (j && (d = t * j.a + e * j.c + j.e, e = t * j.b + e * j.d + j.f, t = d), (i = e - l) < t$ && i > -t$ && (i = 0), (r = t - a) < t$ && r > -t$ && (r = 0), (tQ.lockAxis || tQ.lockedAxis) && (r || i) && (!(d = tQ.lockedAxis) && (tQ.lockedAxis = d = tU && Math.abs(r) > Math.abs(i) ? "y" : tZ ? "x" : null, d && $(tQ.vars.onLockAxis) && tQ.vars.onLockAxis.call(tQ, tQ.pointerEvent)), "y" === d ? i = 0 : "x" === d && (r = 0)), o = ti(c + r * y), s = ti(p + i * y)), (M || X || k) && (tQ.x !== o || tQ.y !== s && !tN) && (k && (tg.x = o, tg.y = s, o = ti((d = k(tg)).x), s = ti(d.y)), M && (o = ti(M(o))), X && (s = ti(X(s)))), u && (o > h ? o = h + Math.round((o - h) * v) : o < g && (o = g + Math.round((o - g) * v)), !tN && (s > x ? s = Math.round(x + (s - x) * v) : s < m && (s = Math.round(m + (s - m) * v)))), tQ.x === o && (tQ.y === s || tN) || (tN ? (tQ.endRotation = tQ.x = tQ.endX = o, b = !0) : (tZ && (tQ.y = tQ.endY = s, b = !0), tU && (tQ.x = tQ.endX = o, b = !0)), n && !1 === tz(tQ, "move", "onMove") ? (tQ.pointerX = _, tQ.pointerY = T, p = E, tQ.x = O, tQ.y = Y, tQ.endX = C, tQ.endY = P, tQ.endRotation = S, b = D) : !tQ.isDragging && tQ.isPressed && (tQ.isDragging = tw = !0, tz(tQ, "dragstart", "onDragStart")))
                            },
                            ev = function t(e, i) {
                                if (!o || !tQ.isPressed || e && null != v && !i && (e.pointerId && e.pointerId !== v && e.target !== n || e.changedTouches && !tY(e.changedTouches, v))) {
                                    tp && e && o && tO(e);
                                    return
                                }
                                tQ.isPressed = !1;
                                var s, a, l, c, p = e,
                                    u = tQ.isDragging,
                                    f = tQ.vars.allowContextMenu && e && (e.ctrlKey || e.which > 2),
                                    d = Y.delayedCall(.001, eg);
                                if (B ? (tE(B, "touchend", t), tE(B, "touchmove", em), tE(B, "touchcancel", t), tE(er, "touchstart", tP)) : tE(er, "mousemove", em), tE(C, "touchforcechange", tO), (!V || !B) && (tE(er, "mouseup", t), e && e.target && tE(e.target, "mouseup", t)), b = !1, u && (t2 = th = tc(), tQ.isDragging = !1), tM(eo), N && !f) {
                                    e && (tE(e.target, "change", t), tQ.pointerEvent = p), tj(t0, !1), tz(tQ, "release", "onRelease"), tz(tQ, "click", "onClick"), N = !1;
                                    return
                                }
                                for (a = t0.length; --a > -1;) tB(t0[a], "cursor", r.cursor || (!1 !== r.cursor ? W : null));
                                if (K--, e) {
                                    if ((s = e.changedTouches) && (e = s[0]) !== y && e.identifier !== v) {
                                        for (a = s.length; --a > -1 && (e = s[a]).identifier !== v && e.target !== n;);
                                        if (a < 0 && !i) return
                                    }
                                    tQ.pointerEvent = p, tQ.pointerX = e.pageX, tQ.pointerY = e.pageY
                                }
                                return f && p ? (tO(p), tp = !0, tz(tQ, "release", "onRelease")) : p && !u ? (tp = !1, J && (r.snap || r.bounds) && eu(r.inertia || r.throwProps), tz(tQ, "release", "onRelease"), (!z || "touchmove" !== p.type) && -1 === p.type.indexOf("cancel") && (tz(tQ, "click", "onClick"), tc() - t7 < 300 && tz(tQ, "doubleclick", "onDoubleClick"), c = p.target || n, t7 = tc(), z || p.defaultPrevented || Y.delayedCall(.05, function() {
                                    t7 !== tn && tQ.enabled() && !tQ.isPressed && !p.defaultPrevented && (c.click ? c.click() : er.createEvent && ((l = er.createEvent("MouseEvents")).initMouseEvent("click", !0, !0, C, 1, tQ.pointerEvent.screenX, tQ.pointerEvent.screenY, tQ.pointerX, tQ.pointerY, !1, !1, !1, !1, 0, null), c.dispatchEvent(l)))
                                }))) : (eu(r.inertia || r.throwProps), !tQ.allowEventDefault && p && (!1 !== r.dragClickables || !t9.call(tQ, p.target)) && u && (!U || Z && U === Z) && !1 !== p.cancelable ? (tp = !0, tO(p)) : tp = !1, tz(tQ, "release", "onRelease")), eh() && d.duration(tQ.tween.duration()), u && tz(tQ, "dragend", "onDragEnd"), !0
                            },
                            ew = function(t) {
                                if (t && tQ.isDragging && !s) {
                                    var e = t.target || n.parentNode,
                                        r = e.scrollLeft - e._gsScrollX,
                                        i = e.scrollTop - e._gsScrollY;
                                    (r || i) && (j ? (a -= r * j.a + i * j.c, l -= i * j.d + r * j.b) : (a -= r, l -= i), e._gsScrollX += r, e._gsScrollY += i, ey(tQ.pointerX, tQ.pointerY))
                                }
                            },
                            eb = function(t) {
                                var e = tc(),
                                    n = e - t7 < 100,
                                    r = e - t2 < 50,
                                    i = n && tn === t7,
                                    o = tQ.pointerEvent && tQ.pointerEvent.defaultPrevented,
                                    s = n && ts === t7,
                                    a = t.isTrusted || null == t.isTrusted && n && i;
                                if ((i || r && !1 !== tQ.vars.suppressClickOnDrag) && t.stopImmediatePropagation && t.stopImmediatePropagation(), n && !(tQ.pointerEvent && tQ.pointerEvent.defaultPrevented) && (!i || a && !s)) {
                                    a && i && (ts = t7), tn = t7;
                                    return
                                }(tQ.isPressed || r || n) && (!a || !t.detail || !n || o) && tO(t), n || r || tw || (t && t.target && (tQ.pointerEvent = t), tz(tQ, "click", "onClick"))
                            },
                            e_ = function(t) {
                                return j ? {
                                    x: t.x * j.a + t.y * j.c + j.e,
                                    y: t.x * j.b + t.y * j.d + j.f
                                } : {
                                    x: t.x,
                                    y: t.y
                                }
                            };
                        return (_ = e.get(n)) && _.kill(), i.startDrag = function(t, e) {
                            var r, i, o, s;
                            ex(t || tQ.pointerEvent, !0), e && !tQ.hitTest(t || tQ.pointerEvent) && (r = tR(t || tQ.pointerEvent), i = tR(n), o = e_({
                                x: r.left + r.width / 2,
                                y: r.top + r.height / 2
                            }), s = e_({
                                x: i.left + i.width / 2,
                                y: i.top + i.height / 2
                            }), a -= o.x - s.x, l -= o.y - s.y), tQ.isDragging || (tQ.isDragging = tw = !0, tz(tQ, "dragstart", "onDragStart"))
                        }, i.drag = em, i.endDrag = function(t) {
                            return ev(t || tQ.pointerEvent, !0)
                        }, i.timeSinceDrag = function() {
                            return tQ.isDragging ? 0 : (tc() - t2) / 1e3
                        }, i.timeSinceClick = function() {
                            return (tc() - t7) / 1e3
                        }, i.hitTest = function(t, n) {
                            return e.hitTest(tQ.target, t, n)
                        }, i.getDirection = function(t, e) {
                            var r, i, o, s, a, l, u = "velocity" === t && H ? t : Q(t) && !tN ? "element" : "start";
                            return ("element" === u && (a = tR(tQ.target), l = tR(t)), r = "start" === u ? tQ.x - c : "velocity" === u ? H.getVelocity(n, tI) : a.left + a.width / 2 - (l.left + l.width / 2), tN) ? r < 0 ? "counter-clockwise" : "clockwise" : (e = e || 2, s = (o = Math.abs(r / (i = "start" === u ? tQ.y - p : "velocity" === u ? H.getVelocity(n, tV) : a.top + a.height / 2 - (l.top + l.height / 2)))) < 1 / e ? "" : r < 0 ? "left" : "right", o < e && ("" !== s && (s += "-"), s += i < 0 ? "up" : "down"), s)
                        }, i.applyBounds = function(t, e) {
                            var i, o, s, a, l, c;
                            if (t && r.bounds !== t) return r.bounds = t, tQ.update(!0, e);
                            if (es(!0), el(), u && !eh()) {
                                if (i = tQ.x, o = tQ.y, i > h ? i = h : i < g && (i = g), o > x ? o = x : o < m && (o = m), (tQ.x !== i || tQ.y !== o) && (s = !0, tQ.x = tQ.endX = i, tN ? tQ.endRotation = i : tQ.y = tQ.endY = o, b = !0, eo(!0), tQ.autoScroll && !tQ.isDragging))
                                    for (tL(n.parentNode), a = n, tx.scrollTop = null != C.pageYOffset ? C.pageYOffset : null != er.documentElement.scrollTop ? er.documentElement.scrollTop : er.body.scrollTop, tx.scrollLeft = null != C.pageXOffset ? C.pageXOffset : null != er.documentElement.scrollLeft ? er.documentElement.scrollLeft : er.body.scrollLeft; a && !c;) l = (c = tA(a.parentNode)) ? tx : a.parentNode, tZ && l.scrollTop > l._gsMaxScrollY && (l.scrollTop = l._gsMaxScrollY), tU && l.scrollLeft > l._gsMaxScrollX && (l.scrollLeft = l._gsMaxScrollX), a = l;
                                tQ.isThrowing && (s || tQ.endX > h || tQ.endX < g || tQ.endY > x || tQ.endY < m) && eu(r.inertia || r.throwProps, s)
                            }
                            return tQ
                        }, i.update = function(t, e, r) {
                            if (e && tQ.isPressed) {
                                var i = E(n),
                                    o = td.apply({
                                        x: tQ.x - c,
                                        y: tQ.y - p
                                    }),
                                    s = E(n.parentNode, !0);
                                s.apply({
                                    x: i.e - o.x,
                                    y: i.f - o.y
                                }, o), tQ.x -= o.x - s.e, tQ.y -= o.y - s.f, eo(!0), ed()
                            }
                            var a = tQ.x,
                                l = tQ.y;
                            return ef(!e), t ? tQ.applyBounds() : (b && r && eo(!0), es(!0)), e && (ey(tQ.pointerX, tQ.pointerY), b && eo(!0)), tQ.isPressed && !e && (tU && Math.abs(a - tQ.x) > .01 || tZ && Math.abs(l - tQ.y) > .01 && !tN) && ed(), tQ.autoScroll && (tL(n.parentNode, tQ.isDragging), t3 = tQ.isDragging, eo(!0), tD(n, ew), tk(n, ew)), tQ
                        }, i.enable = function(t) {
                            var e, i, a, l = {
                                lazy: !0
                            };
                            if (!1 !== r.cursor && (l.cursor = r.cursor || W), Y.utils.checkPrefix("touchCallout") && (l.touchCallout = "none"), "soft" !== t) {
                                for (tv(t0, tU === tZ ? "none" : r.allowNativeTouchScrolling && n.scrollHeight === n.clientHeight == (n.scrollWidth === n.clientHeight) || r.allowEventDefault ? "manipulation" : tU ? "pan-y" : "pan-x"), i = t0.length; --i > -1;) a = t0[i], V || tT(a, "mousedown", ex), tT(a, "touchstart", ex), tT(a, "click", eb, !0), Y.set(a, l), a.getBBox && a.ownerSVGElement && tU !== tZ && Y.set(a.ownerSVGElement, {
                                    touchAction: r.allowNativeTouchScrolling || r.allowEventDefault ? "manipulation" : tU ? "pan-y" : "pan-x"
                                }), r.allowContextMenu || tT(a, "contextmenu", ei);
                                tj(t0, !1)
                            }
                            return tk(n, ew), o = !0, H && "soft" !== t && H.track(s || n, tC ? "x,y" : tN ? "rotation" : "top,left"), n._gsDragID = e = "d" + tf++, tu[e] = tQ, s && (s.enable(), s.element._gsDragID = e), (r.bounds || tN) && ed(), r.bounds && tQ.applyBounds(), tQ
                        }, i.disable = function(t) {
                            for (var e, r = tQ.isDragging, i = t0.length; --i > -1;) tB(t0[i], "cursor", null);
                            if ("soft" !== t) {
                                for (tv(t0, null), i = t0.length; --i > -1;) tB(e = t0[i], "touchCallout", null), tE(e, "mousedown", ex), tE(e, "touchstart", ex), tE(e, "click", eb, !0), tE(e, "contextmenu", ei);
                                tj(t0, !0), B && (tE(B, "touchcancel", ev), tE(B, "touchend", ev), tE(B, "touchmove", em)), tE(er, "mouseup", ev), tE(er, "mousemove", em)
                            }
                            return tD(n, ew), o = !1, H && "soft" !== t && (H.untrack(s || n, tC ? "x,y" : tN ? "rotation" : "top,left"), tQ.tween && tQ.tween.kill()), s && s.disable(), tM(eo), tQ.isDragging = tQ.isPressed = N = !1, r && tz(tQ, "dragend", "onDragEnd"), tQ
                        }, i.enabled = function(t, e) {
                            return arguments.length ? t ? tQ.enable(e) : tQ.disable(e) : o
                        }, i.kill = function() {
                            return tQ.isThrowing = !1, tQ.tween && tQ.tween.kill(), tQ.disable(), Y.set(t0, {
                                clearProps: "userSelect"
                            }), delete tu[n._gsDragID], tQ
                        }, i.revert = function() {
                            this.kill(), this.styles && this.styles.revert()
                        }, ~t_.indexOf("scroll") && (s = i.scrollProxy = new tJ(n, ty({
                            onKill: function() {
                                tQ.isPressed && ev(null)
                            }
                        }, r)), n.style.overflowY = tZ && !F ? "auto" : "hidden", n.style.overflowX = tU && !F ? "auto" : "hidden", n = s.content), tN ? t1.rotation = 1 : (tU && (t1[tI] = 1), tZ && (t1[tV] = 1)), et.force3D = !("force3D" in r) || r.force3D, q(O(i)), i.enable(), i
                    }
                    return e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t, e.register = function(t) {
                        Y = t, tK()
                    }, e.create = function(t, n) {
                        return A || tK(!0), L(t).map(function(t) {
                            return new e(t, n)
                        })
                    }, e.get = function(t) {
                        return tu[(L(t)[0] || {})._gsDragID]
                    }, e.timeSinceDrag = function() {
                        return (tc() - th) / 1e3
                    }, e.hitTest = function(t, e, n) {
                        if (t === e) return !1;
                        var r, i, o, s = tR(t),
                            a = tR(e),
                            l = s.top,
                            c = s.left,
                            p = s.right,
                            u = s.bottom,
                            f = s.width,
                            d = s.height,
                            h = a.left > p || a.right < c || a.top > u || a.bottom < l;
                        return h || !n ? !h : (o = -1 !== (n + "").indexOf("%"), n = parseFloat(n) || 0, (r = {
                            left: Math.max(c, a.left),
                            top: Math.max(l, a.top)
                        }).width = Math.min(p, a.right) - r.left, r.height = Math.min(u, a.bottom) - r.top, !(r.width < 0) && !(r.height < 0) && (o ? (n *= .01, (i = r.width * r.height) >= f * d * n || i >= a.width * a.height * n) : r.width > n && r.height > n))
                    }, e
                }(function() {
                    function t(t) {
                        this._listeners = {}, this.target = t || this
                    }
                    var e = t.prototype;
                    return e.addEventListener = function(t, e) {
                        var n = this._listeners[t] || (this._listeners[t] = []);
                        ~n.indexOf(e) || n.push(e)
                    }, e.removeEventListener = function(t, e) {
                        var n = this._listeners[t],
                            r = n && n.indexOf(e);
                        r >= 0 && n.splice(r, 1)
                    }, e.dispatchEvent = function(t) {
                        var e, n = this;
                        return (this._listeners[t] || []).forEach(function(r) {
                            return !1 === r.call(n, {
                                type: t,
                                target: n.target
                            }) && (e = !1)
                        }), e
                    }, t
                }());
            ! function(t, e) {
                for (var n in e) n in t || (t[n] = e[n])
            }(tU.prototype, {
                pointerX: 0,
                pointerY: 0,
                startX: 0,
                startY: 0,
                deltaX: 0,
                deltaY: 0,
                isDragging: !1,
                isPressed: !1
            }), tU.zIndex = 1e3, tU.version = "3.12.5", Z() && Y.registerPlugin(tU)
        }
    }
]);