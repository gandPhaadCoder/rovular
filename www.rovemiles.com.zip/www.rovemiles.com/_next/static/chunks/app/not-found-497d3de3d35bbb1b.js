! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "b245efc8-e9c2-4233-8e8f-ea7c4779a3d5", e._sentryDebugIdIdentifier = "sentry-dbid-b245efc8-e9c2-4233-8e8f-ea7c4779a3d5")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4345], {
        2981: (e, t, r) => {
            "use strict";
            r.d(t, {
                F: () => s
            });
            let s = "search-bar-expanded";
            new Event(s)
        },
        43229: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 27497)), Promise.resolve().then(r.bind(r, 57739)), Promise.resolve().then(r.bind(r, 80285)), Promise.resolve().then(r.bind(r, 54009)), Promise.resolve().then(r.bind(r, 20342)), Promise.resolve().then(r.bind(r, 9514)), Promise.resolve().then(r.bind(r, 8772)), Promise.resolve().then(r.bind(r, 49474))
        },
        54009: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => x
            });
            var s = r(95155),
                n = r(12115),
                l = r(64269),
                a = r(49474),
                i = r(56297),
                o = r(87708),
                d = r(42878),
                c = r(15239);
            let u = {
                src: "/_next/static/media/map.428e453d.svg",
                height: 821,
                width: 1440,
                blurWidth: 0,
                blurHeight: 0
            };
            var f = r(20063);

            function x(e) {
                let {
                    content: t
                } = e, [r] = (0, n.useState)(""), [x, h] = (0, n.useState)(!1), p = (0, n.useRef)(null), {
                    currentCity: m
                } = (0, o.CD)({
                    pause: !x || !!r
                }), {
                    isMobile: b
                } = (0, a.l)(), v = (0, f.useRouter)();
                return (0, n.useEffect)(() => {
                    if (!p.current) return;
                    let e = new IntersectionObserver(e => {
                        let [t] = e;
                        h(t.isIntersecting)
                    }, {
                        threshold: .5
                    });
                    return e.observe(p.current), () => e.disconnect()
                }, [p]), (0, n.useEffect)(() => {
                    let e = () => {
                        if (!b) return
                    };
                    return window.addEventListener("scroll", e), () => window.removeEventListener("scroll", e)
                }, [b]), (0, s.jsx)("div", {
                    className: "relative flex flex-col h-screen overflow-hidden bg-[#0D0D0D]",
                    "data-sentry-component": "ErrorLayout",
                    "data-sentry-source-file": "ErrorLayout.tsx",
                    children: (0, s.jsx)("div", {
                        className: "w-full flex flex-col items-center px-4 relative flex-1",
                        ref: p,
                        children: (0, s.jsxs)("div", {
                            className: "z-10 flex flex-col items-center text-center space-y-6 max-w-lg mt-10",
                            children: [(0, s.jsx)("h1", {
                                className: "text-white font-normal text-[20px] leading-[100%] tracking-[-0.03em] text-center pt-10 min-w-[320px]",
                                children: t
                            }), (0, s.jsxs)("div", {
                                className: "relative w-full flex justify-center",
                                children: [(0, s.jsx)("div", {
                                    className: "absolute top-[20px] w-[406px] h-[30px] rounded-[9px] pointer-events-none",
                                    style: {
                                        background: "linear-gradient(90deg, #000 0%, #333 28%, #C3C3C3 66%, #000 80%)",
                                        filter: "blur(50px)",
                                        zIndex: 0,
                                        opacity: .9
                                    }
                                }), (0, s.jsx)("div", {
                                    className: "p-[0.78px] rounded-[9px] w-full max-w-md min-h-[72px]",
                                    children: (0, s.jsx)(i.A, {
                                        placeholder: "Travel to ".concat(m),
                                        value: "",
                                        onChange: () => {},
                                        as: "div",
                                        onClick: () => v.push("/explore"),
                                        className: (0, l.cn)("text-[20px] font-normal", "w-full h-[64.2px]", "rounded-[9px]", "flex items-center justify-between", "pl-[22.83px] pr-[22.83px]", "border-[#3E3A4B] bg-[#1A1A1A]", "cursor-default border", "sm:w-[406px]"),
                                        "data-sentry-element": "LandingSearchInput",
                                        "data-sentry-source-file": "ErrorLayout.tsx",
                                        children: (0, s.jsx)("button", {
                                            className: "absolute right-2 top-1/2 -translate-y-1/2 bg-[#3E3A4B] text-white h-8 w-8 rounded-full flex justify-center items-center shadow-sm",
                                            children: (0, s.jsx)(d.pn2, {
                                                className: "text-lg",
                                                "data-sentry-element": "IoSearchSharp",
                                                "data-sentry-source-file": "ErrorLayout.tsx"
                                            })
                                        })
                                    })
                                })]
                            }), (0, s.jsx)("div", {
                                className: "absolute inset-0 w-full h-full -z-10",
                                children: (0, s.jsx)(c.default, {
                                    src: u,
                                    alt: "Map illustration",
                                    fill: !0,
                                    priority: !0,
                                    style: {
                                        objectFit: "cover",
                                        objectPosition: "center bottom"
                                    },
                                    "data-sentry-element": "Image",
                                    "data-sentry-source-file": "ErrorLayout.tsx"
                                })
                            })]
                        })
                    })
                })
            }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [4206, 9933, 2150, 2202, 5592, 512, 760, 1356, 5653, 9312, 6410, 1029, 6743, 4342, 4299, 4585, 4718, 9719, 1158, 8234, 2800, 3566, 1443, 7708, 4537, 4850, 8441, 8329, 7358], () => t(43229)), _N_E = e.O()
    }
]);