! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "9d9024b9-9408-4164-b907-e26470fbbb8e", e._sentryDebugIdIdentifier = "sentry-dbid-9d9024b9-9408-4164-b907-e26470fbbb8e")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5219], {
        980: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => l,
                s: () => i
            });
            var a = s(12115),
                n = s(14679),
                r = s(75329);
            let i = () => ({
                    trackMixPanelEvent: (0, a.useCallback)((e, t) => {
                        n.A.track(e, { ...t,
                            platform: "web"
                        })
                    }, [])
                }),
                l = e => {
                    (0, a.useEffect)(() => {
                        var t, s;
                        if (n.A.init(r.A.NEXT_PUBLIC_MIXPANEL_TOKEN || "", {
                                debug: "production" !== r.A.NEXT_PUBLIC_ENV
                            }), !e) return void n.A.reset();
                        n.A.identify(e.id), n.A.people.set({
                            $email: e.email,
                            $name: "".concat((null == (t = e.user_metadata) ? void 0 : t.first_name) || "", " ").concat((null == (s = e.user_metadata) ? void 0 : s.last_name) || "").trim()
                        })
                    }, [e])
                }
        },
        8155: (e, t, s) => {
            "use strict";
            s.d(t, {
                b: () => a,
                s: () => n
            });
            let a = {
                    SIGN_IN_CLICK: "sign_in_click",
                    FLIGHT_SEARCH_CLICK: "flight_search_click",
                    HOTEL_SEARCH_CLICK: "hotel_search_click",
                    EXPLORE_DEAL_CLICK: "deal_click",
                    HOTEL_CARD_CLICK: "hotel_card_click",
                    FLIGHT_MENU_CLICK: "flight_menu_click",
                    HOTELS_MENU_CLICK: "hotels_menu_click",
                    SELECT_FLIGHT_CLICK: "select_flight_click",
                    CONFIRM_FLIGHT_CLICK: "confirm_flight_click",
                    SELECT_HOTEL_CLICK: "select_hotel_click",
                    COMPLETE_HOTEL_BOOKING_CLICK: "complete_hotel_booking_click",
                    HOMEPAGE_DEAL_CLICK: "homepage_deal_click",
                    REFER_BUTTON_CLICK: "refer_button_click",
                    EXPLORE_TOP_DEALS_CLICK: "explore_top_deals_click",
                    EARN_TAB_CLICK: "earn_tab_click",
                    EARN_SHOPPING_CARD_CLICK: "earn_shopping_card_click",
                    ADD_TO_CHROME_CLICK: "add_to_chrome_click ",
                    SIGN_UP_SUCCESS: "sign_up_success"
                },
                n = function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    window.dataLayer = window.dataLayer || [], window.dataLayer.push({
                        event: e,
                        ...t
                    })
                }
        },
        38728: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => d,
                O: () => _
            });
            var a = s(95155),
                n = s(12115),
                r = s(99776),
                i = s(53455),
                l = s(20063),
                o = s(77650);
            let c = (0, n.createContext)({
                    user: null,
                    isAuthenticated: !1,
                    isLoading: !0,
                    authRef: {
                        current: null
                    },
                    signOut: async () => {}
                }),
                _ = e => {
                    let {
                        children: t
                    } = e, s = (0, o.U)(), _ = (0, l.useRouter)(), d = (0, r.jE)(), u = (0, n.useRef)(null), {
                        data: E,
                        isLoading: C
                    } = (0, i.I)({
                        queryKey: ["auth", "user"],
                        queryFn: async () => {
                            let {
                                data: e,
                                error: t
                            } = await s.auth.getUser();
                            if (t) throw t;
                            return u.current = e.user, e.user
                        },
                        staleTime: 3e5,
                        gcTime: 6e5
                    });
                    (0, n.useEffect)(() => {
                        let {
                            data: {
                                subscription: e
                            }
                        } = s.auth.onAuthStateChange(() => {
                            d.invalidateQueries({
                                queryKey: ["auth", "user"]
                            })
                        });
                        return () => e.unsubscribe()
                    }, [d, s]);
                    let I = (0, n.useCallback)(async () => {
                        try {
                            let {
                                error: e
                            } = await s.auth.signOut();
                            if (e) throw e;
                            d.setQueryData(["auth", "user"], null), u.current = null, setTimeout(() => {
                                _.push("/"), _.refresh()
                            }, 100)
                        } catch (e) {
                            console.error("Error during sign out:", e), _.push("/")
                        }
                    }, [s, d, _]);
                    return (0, a.jsx)(c.Provider, {
                        value: {
                            user: E || null,
                            isAuthenticated: !!E,
                            isLoading: C,
                            authRef: u,
                            signOut: I
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "AuthProvider",
                        "data-sentry-source-file": "AuthContext.tsx",
                        children: t
                    })
                },
                d = () => (0, n.useContext)(c)
        },
        51849: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => d
            });
            var a = s(95155),
                n = s(12710);
            s(12115);
            var r = s(92033),
                i = s(64269);
            let l = (0, n.tv)({
                    base: "relative",
                    variants: {
                        fullWidth: {
                            true: "w-full"
                        },
                        size: {
                            sm: "",
                            md: ""
                        }
                    }
                }),
                o = (0, n.tv)({
                    base: "bg-[#0D0D0D] rounded-full w-full h-full",
                    variants: {
                        size: {
                            sm: "px-3 py-[2px]",
                            md: "px-4 py-[9px]"
                        }
                    }
                }),
                c = (0, n.tv)({
                    base: "text-base text-[#FFFFFF] opacity-80",
                    variants: {
                        size: {
                            sm: "text-sm",
                            md: "text-base"
                        },
                        xPadding: {
                            single: "",
                            double: ""
                        },
                        disabled: {
                            true: "text-gray-400",
                            false: ""
                        }
                    },
                    compoundVariants: [{
                        xPadding: "double",
                        size: "sm",
                        class: "px-3"
                    }, {
                        xPadding: "double",
                        size: "md",
                        class: "px-4"
                    }]
                }),
                _ = e => {
                    let {
                        size: t = "md",
                        xPadding: s = "single",
                        innerClassName: n,
                        children: _,
                        onClick: d,
                        style: u,
                        className: E,
                        fullWidth: C = !1,
                        isLoading: I = !1,
                        disabled: N = !1,
                        innerBgColor: L = "#0D0D0D",
                        borderVariant: g = "default",
                        ...p
                    } = e;
                    return (0, a.jsx)("button", {
                        className: l({
                            fullWidth: C,
                            className: E
                        }),
                        onClick: d,
                        style: {
                            background: N ? "linear-gradient(90deg, #333333 0%, #333333 28%, #555555 66%, #333333 100%)" : "default" === g ? "linear-gradient(90deg, #464646 0%, #333333 28%, #9C9C9C 66%, #464646 100%)" : "linear-gradient(90deg, #00000000 0%, #FFFFFF 42%, #9C9C9C 66%, #00000000 100%)",
                            borderRadius: "40px",
                            padding: "1px",
                            ...u
                        },
                        disabled: N || I,
                        ...p,
                        "data-sentry-component": "ButtonCapsule",
                        "data-sentry-source-file": "ButtonCapsule.tsx",
                        children: (0, a.jsx)("div", {
                            className: (0, i.cn)(o({
                                size: t
                            }), n),
                            style: {
                                background: L
                            },
                            children: (0, a.jsx)("span", {
                                className: c({
                                    size: t,
                                    xPadding: s,
                                    disabled: N
                                }),
                                children: I ? (0, a.jsx)(r.A, {
                                    className: "h-6 animate-spin w-full"
                                }) : _
                            })
                        })
                    })
                };
            _.displayName = "ButtonCapsule";
            let d = _
        },
        64269: (e, t, s) => {
            "use strict";
            s.d(t, {
                cn: () => r
            });
            var a = s(2821),
                n = s(75889);

            function r() {
                for (var e = arguments.length, t = Array(e), s = 0; s < e; s++) t[s] = arguments[s];
                return (0, n.QP)((0, a.$)(t))
            }
        },
        66560: (e, t, s) => {
            Promise.resolve().then(s.bind(s, 5835)), Promise.resolve().then(s.bind(s, 90778))
        },
        75329: (e, t, s) => {
            "use strict";
            s.d(t, {
                A: () => r
            });
            var a = s(15653);
            let n = a.z.object({
                    NEXT_PUBLIC_SUPABASE_URL: a.z.string(),
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: a.z.string(),
                    NEXT_PUBLIC_ENV: a.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_MIXPANEL_TOKEN: a.z.string(),
                    NEXT_PUBLIC_SENTRY_DSN: a.z.string(),
                    NEXT_PUBLIC_SENTRY_ORG: a.z.string(),
                    NEXT_PUBLIC_SENTRY_PROJECT: a.z.string(),
                    NEXT_PUBLIC_SENTRY_ENV: a.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_ENABLE_BANNER: a.z.coerce.boolean().default(!1),
                    NEXT_PUBLIC_FACEBOOK_PIXEL_ID: a.z.string(),
                    NEXT_PUBLIC_TIKTOK_PIXEL_ID: a.z.string(),
                    NEXT_PUBLIC_REDDIT_PIXEL_ID: a.z.string()
                }),
                r = (() => {
                    try {
                        return n.parse({
                            NEXT_PUBLIC_SUPABASE_URL: "https://api.rovemiles.com",
                            NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4d3BpcWh3cmtxYXl6a3BkZXJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkwMjM5MDMsImV4cCI6MjA0NDU5OTkwM30.9bm_de4Zwm8gM1tILRZyYvuBe7ymJxycP4dYYxzo8Kw",
                            NEXT_PUBLIC_ENV: "production",
                            NEXT_PUBLIC_MIXPANEL_TOKEN: "9da7db12d48488485c9d6cfac54831b3",
                            NEXT_PUBLIC_SENTRY_DSN: "https://d2b1818c4d1059a71206cf1a19342e14@o4508490297638912.ingest.us.sentry.io/4508490311532544",
                            NEXT_PUBLIC_SENTRY_ORG: "rove-22",
                            NEXT_PUBLIC_SENTRY_PROJECT: "rove-miles-portal",
                            NEXT_PUBLIC_SENTRY_ENV: "production",
                            NEXT_PUBLIC_ENABLE_BANNER: "true",
                            NEXT_PUBLIC_FACEBOOK_PIXEL_ID: "1877255199716926",
                            NEXT_PUBLIC_TIKTOK_PIXEL_ID: "D0R4033C77UBLRIEQ98G",
                            NEXT_PUBLIC_REDDIT_PIXEL_ID: "a2_gw72ldodzgpx"
                        })
                    } catch (e) {
                        throw e instanceof a.z.ZodError && console.error("❌ Invalid environment variables:", e.errors.map(e => "".concat(e.path, ": ").concat(e.message))), e
                    }
                })()
        },
        77650: (e, t, s) => {
            "use strict";
            s.d(t, {
                U: () => r
            });
            var a = s(62471),
                n = s(75329);

            function r(e) {
                return (0, a.createBrowserClient)(n.A.NEXT_PUBLIC_SUPABASE_URL, n.A.NEXT_PUBLIC_SUPABASE_ANON_KEY, {
                    db: {
                        schema: e
                    }
                })
            }
        },
        81264: (e, t, s) => {
            "use strict";
            s.d(t, {
                Toaster: () => c,
                o: () => _
            });
            var a = s(95155),
                n = s(12115),
                r = s(22663),
                i = s(74233),
                l = s(26615);
            let o = "rgba(255, 255, 255, 0.11)",
                c = () => {
                    let {
                        toasts: e
                    } = (0, r.Nk)();
                    return (0, n.useEffect)(() => {
                        e.filter(e => e.visible).filter((e, t) => t >= 6).forEach(e => _.dismiss(e.id))
                    }, [e]), (0, a.jsx)(r.l$, {
                        position: "top-center",
                        toastOptions: {
                            style: {
                                background: o,
                                color: "white",
                                fontFamily: "var(--font-untitled-sans), sans-serif",
                                fontWeight: "400",
                                backdropFilter: "blur(12px)",
                                borderRadius: "8px",
                                padding: "12px 14px"
                            }
                        },
                        "data-sentry-element": "ReactHotToaster",
                        "data-sentry-component": "Toaster",
                        "data-sentry-source-file": "Toaster.tsx",
                        children: e => (0, a.jsx)(r.bv, {
                            toast: e,
                            children: t => {
                                let {
                                    icon: s,
                                    message: n
                                } = t;
                                return (0, a.jsxs)(a.Fragment, {
                                    children: [(0, a.jsx)("span", {
                                        className: "opacity-90 text-sm",
                                        children: s
                                    }), (0, a.jsx)("span", {
                                        className: "pl-1 opacity-90 text-[13px] leading-[20px]",
                                        children: n
                                    }), "loading" !== e.type && e.closeButton && (0, a.jsx)("button", {
                                        onClick: () => _.dismiss(e.id),
                                        children: (0, a.jsx)(l.A, {
                                            className: "text-[12px] opacity-90"
                                        })
                                    })]
                                })
                            }
                        })
                    })
                },
                _ = { ...r.oR,
                    plain: (e, t) => (0, r.oR)(e, { ...t
                    }),
                    info: (e, t) => (0, r.oR)(e, {
                        icon: (0, a.jsx)(i.Izb, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(59, 130, 246, 0.11)" : o,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    success: (e, t) => (0, r.oR)(e, {
                        icon: (0, a.jsx)(i.v_8, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(34, 197, 94, 0.11)" : o,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    warn: (e, t) => (0, r.oR)(e, {
                        icon: (0, a.jsx)(i.qVL, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(234, 179, 8, 0.11)" : o,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    error: (e, t) => (0, r.oR)(e, {
                        icon: (0, a.jsx)(i.Edw, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(239, 68, 68, 0.11)" : o,
                            ...null == t ? void 0 : t.style
                        },
                        duration: 1e4,
                        ...t
                    }),
                    loading: (e, t) => r.oR.loading(e, { ...t,
                        icon: (0, a.jsx)(r.hz, {
                            style: {
                                width: "24px",
                                height: "24px"
                            }
                        })
                    }),
                    promise: async function(e, t, s) {
                        let a = { ...s
                        };
                        try {
                            a.id = _.loading(t.loading, a);
                            let s = await e;
                            return _.success(t.success, a), s
                        } catch (e) {
                            _.error(t.error, a)
                        }
                    }
                }
        },
        85163: (e, t, s) => {
            "use strict";
            s.d(t, {
                $: () => a
            });
            let a = {
                FLIGHT_SEARCH_PERFORMED: "FlightSearchPerformed",
                FLIGHT_SELECTED: "FlightSelected",
                FLIGHT_BOOKED: "FlightBooked",
                MILES_TRANSFERRED: "MilesTransferred",
                HOTEL_SEARCH_PERFORMED: "HotelSearchPerformed",
                HOTEL_ROOM_SELECTED: "HotelRoomSelected",
                HOTEL_BOOKED: "HotelBooked",
                USER_LOGGED_IN: "UserLoggedIn",
                BOOKING_STARTED: "BookingStarted",
                BOOKING_ABANDONED: "BookingAbandoned",
                ONBOARDING_COMPLETED: "OnboardingCompleted",
                FIRST_BOOKING_COMPLETED: "FirstBookingCompleted",
                USER_RETURNED: "UserReturned",
                REFERRAL_USED: "ReferralUsed",
                MILES_REDEEMED: "MilesRedeemed",
                MILES_EARNED: "MilesEarned"
            }
        },
        90778: (e, t, s) => {
            "use strict";
            s.d(t, {
                default: () => E
            });
            var a = s(95155),
                n = s(20063),
                r = s(12115),
                i = s(73788),
                l = s(78718),
                o = s(7417),
                c = s(42953),
                _ = s(60077),
                d = s(21297),
                u = s(6924);

            function E() {
                let [e, t] = (0, r.useState)((0, i.Q6)()), [s, E] = (0, r.useState)(!1), {
                    values: C,
                    loading: I
                } = (0, u.v)();
                (0, r.useEffect)(() => {
                    C && t({ ...e,
                        origin: C
                    })
                }, [C]);
                let N = (0, n.useRouter)(),
                    L = async e => {
                        let t = (0, l.mp)(e);
                        t && N.push(t)
                    },
                    g = (0, c.A)(),
                    [p, T] = (0, r.useState)("Best");
                return (0, _.B)({
                    className: "p-0 sm:px-4 sm:py-6",
                    containerClassName: "z-50 sm:z-[1010]",
                    content: (0, a.jsx)(d.u, {
                        isSearchExpanded: s,
                        onExpandChange: E,
                        onSearch: L,
                        initialValues: e,
                        activeTab: p,
                        onSetActiveTab: T,
                        loading: I,
                        onLandingScrolled: g
                    }),
                    cleanupOnUnmount: !0
                }), (0, a.jsx)(a.Fragment, {
                    children: (0, a.jsx)(o.k, {
                        "data-sentry-element": "HotelSection",
                        "data-sentry-source-file": "hotel.tsx"
                    })
                })
            }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [4206, 9933, 2150, 2202, 3873, 760, 1356, 5653, 9312, 6410, 1029, 6743, 4342, 4299, 4585, 219, 9719, 6692, 682, 5511, 734, 4915, 3366, 4850, 8441, 8329, 7358], () => t(66560)), _N_E = e.O()
    }
]);