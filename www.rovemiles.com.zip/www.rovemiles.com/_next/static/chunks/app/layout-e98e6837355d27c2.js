! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "1fa91fe3-019d-470c-8ce7-e8d1e467620a", e._sentryDebugIdIdentifier = "sentry-dbid-1fa91fe3-019d-470c-8ce7-e8d1e467620a")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7177], {
        7237: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => o
            });
            var s = r(29259),
                a = r(45460),
                n = r(75329);

            function o() {
                return null
            }
            "production" === n.A.NEXT_PUBLIC_ENV && s.L.init({
                applicationId: "c61d2556-4683-483a-a0b7-3f316a2a4a74",
                clientToken: "pub44c855584c39de15e631b9530bc83a8b",
                site: "us5.datadoghq.com",
                service: "rove-miles",
                env: n.A.NEXT_PUBLIC_ENV,
                sessionSampleRate: 100,
                sessionReplaySampleRate: 100,
                defaultPrivacyLevel: "mask-user-input",
                plugins: [(0, a.tx)({
                    router: !1
                })],
                allowedTracingUrls: [e => e.includes("rovemiles.vercel.app") || e.includes("localhost") || e.includes("rovemiles.com") || e.includes("rove-miles.vercel.app")]
            })
        },
        11093: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => i
            });
            var s = r(95155),
                a = r(31461),
                n = r(99776),
                o = r(12115);

            function i(e) {
                let {
                    children: t
                } = e, [r] = (0, o.useState)(() => new a.E);
                return (0, s.jsx)(n.Ht, {
                    client: r,
                    "data-sentry-element": "QueryClientProvider",
                    "data-sentry-component": "ReactQueryProvider",
                    "data-sentry-source-file": "ReactQueryProvider.tsx",
                    children: t
                })
            }
        },
        13673: () => {},
        39698: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => i
            });
            var s = r(95155),
                a = r(12115),
                n = r(68321),
                o = r(20063);

            function i(e) {
                let {
                    type: t,
                    data: r
                } = e, i = (0, o.usePathname)(), [l, d] = (0, a.useState)(null), [c, u] = (0, a.useState)(null);
                return ((0, a.useEffect)(() => {
                    (async () => {
                        try {
                            let e;
                            if (r) return void d(r);
                            let s = "/" === i ? "homepage" : i.replace(/^\/|\/$/g, "").replace(/\//g, "-"),
                                a = await fetch("/structured-data/index.json");
                            if (!a.ok) throw Error("Failed to load structured data index");
                            let n = await a.json();
                            e = t ? "/structured-data/".concat(t, ".json") : n.pages[s] ? n.pages[s] : n.global.website;
                            let o = await fetch(e);
                            if (!o.ok) {
                                let e = await fetch(n.global.website);
                                if (!e.ok) throw Error("Failed to load structured data");
                                let t = await e.json();
                                d(t);
                                return
                            }
                            let l = await o.json();
                            d(l)
                        } catch (e) {
                            console.error("Error loading structured data:", e), u(e.message)
                        }
                    })()
                }, [i, t, r]), c || !l) ? null : (0, s.jsx)(n.default, {
                    id: "structured-data",
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: {
                        __html: JSON.stringify(l)
                    },
                    strategy: "afterInteractive",
                    "data-sentry-element": "Script",
                    "data-sentry-component": "StructuredData",
                    "data-sentry-source-file": "StructuredData.tsx"
                })
            }
        },
        52707: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 68332)), Promise.resolve().then(r.bind(r, 98202)), Promise.resolve().then(r.bind(r, 57445)), Promise.resolve().then(r.t.bind(r, 41402, 23)), Promise.resolve().then(r.t.bind(r, 52331, 23)), Promise.resolve().then(r.bind(r, 7237)), Promise.resolve().then(r.t.bind(r, 13673, 23)), Promise.resolve().then(r.bind(r, 11093)), Promise.resolve().then(r.bind(r, 39698)), Promise.resolve().then(r.bind(r, 81264))
        },
        75329: (e, t, r) => {
            "use strict";
            r.d(t, {
                A: () => n
            });
            var s = r(15653);
            let a = s.z.object({
                    NEXT_PUBLIC_SUPABASE_URL: s.z.string(),
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: s.z.string(),
                    NEXT_PUBLIC_ENV: s.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_MIXPANEL_TOKEN: s.z.string(),
                    NEXT_PUBLIC_SENTRY_DSN: s.z.string(),
                    NEXT_PUBLIC_SENTRY_ORG: s.z.string(),
                    NEXT_PUBLIC_SENTRY_PROJECT: s.z.string(),
                    NEXT_PUBLIC_SENTRY_ENV: s.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_ENABLE_BANNER: s.z.coerce.boolean().default(!1),
                    NEXT_PUBLIC_FACEBOOK_PIXEL_ID: s.z.string(),
                    NEXT_PUBLIC_TIKTOK_PIXEL_ID: s.z.string(),
                    NEXT_PUBLIC_REDDIT_PIXEL_ID: s.z.string()
                }),
                n = (() => {
                    try {
                        return a.parse({
                            NEXT_PUBLIC_SUPABASE_URL: "https://api.rovemiles.com",
                            NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4d3BpcWh3cmtxYXl6a3BkZXJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkwMjM5MDMsImV4cCI6MjA0NDU5OTkwM30.9bm_de4Zwm8gM1tILRZyYvuBe7ymJxycP4dYYxzo8Kw",
                            NEXT_PUBLIC_ENV: "production",
                            NEXT_PUBLIC_MIXPANEL_TOKEN: "9da7db12d48488485c9d6cfac54831b3",
                            NEXT_PUBLIC_SENTRY_DSN: "https://d2b1818c4d1059a71206cf1a19342e14@o4508490297638912.ingest.us.sentry.io/4508490311532544",
                            NEXT_PUBLIC_SENTRY_ORG: "rove-22",
                            NEXT_PUBLIC_SENTRY_PROJECT: "rove-miles-portal",
                            NEXT_PUBLIC_SENTRY_ENV: "production",
                            NEXT_PUBLIC_ENABLE_BANNER: "true",
                            NEXT_PUBLIC_FACEBOOK_PIXEL_ID: "1877255199716926",
                            NEXT_PUBLIC_TIKTOK_PIXEL_ID: "D0R4033C77UBLRIEQ98G",
                            NEXT_PUBLIC_REDDIT_PIXEL_ID: "a2_gw72ldodzgpx"
                        })
                    } catch (e) {
                        throw e instanceof s.z.ZodError && console.error("❌ Invalid environment variables:", e.errors.map(e => "".concat(e.path, ": ").concat(e.message))), e
                    }
                })()
        },
        81264: (e, t, r) => {
            "use strict";
            r.d(t, {
                Toaster: () => d,
                o: () => c
            });
            var s = r(95155),
                a = r(12115),
                n = r(22663),
                o = r(74233),
                i = r(26615);
            let l = "rgba(255, 255, 255, 0.11)",
                d = () => {
                    let {
                        toasts: e
                    } = (0, n.Nk)();
                    return (0, a.useEffect)(() => {
                        e.filter(e => e.visible).filter((e, t) => t >= 6).forEach(e => c.dismiss(e.id))
                    }, [e]), (0, s.jsx)(n.l$, {
                        position: "top-center",
                        toastOptions: {
                            style: {
                                background: l,
                                color: "white",
                                fontFamily: "var(--font-untitled-sans), sans-serif",
                                fontWeight: "400",
                                backdropFilter: "blur(12px)",
                                borderRadius: "8px",
                                padding: "12px 14px"
                            }
                        },
                        "data-sentry-element": "ReactHotToaster",
                        "data-sentry-component": "Toaster",
                        "data-sentry-source-file": "Toaster.tsx",
                        children: e => (0, s.jsx)(n.bv, {
                            toast: e,
                            children: t => {
                                let {
                                    icon: r,
                                    message: a
                                } = t;
                                return (0, s.jsxs)(s.Fragment, {
                                    children: [(0, s.jsx)("span", {
                                        className: "opacity-90 text-sm",
                                        children: r
                                    }), (0, s.jsx)("span", {
                                        className: "pl-1 opacity-90 text-[13px] leading-[20px]",
                                        children: a
                                    }), "loading" !== e.type && e.closeButton && (0, s.jsx)("button", {
                                        onClick: () => c.dismiss(e.id),
                                        children: (0, s.jsx)(i.A, {
                                            className: "text-[12px] opacity-90"
                                        })
                                    })]
                                })
                            }
                        })
                    })
                },
                c = { ...n.oR,
                    plain: (e, t) => (0, n.oR)(e, { ...t
                    }),
                    info: (e, t) => (0, n.oR)(e, {
                        icon: (0, s.jsx)(o.Izb, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(59, 130, 246, 0.11)" : l,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    success: (e, t) => (0, n.oR)(e, {
                        icon: (0, s.jsx)(o.v_8, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(34, 197, 94, 0.11)" : l,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    warn: (e, t) => (0, n.oR)(e, {
                        icon: (0, s.jsx)(o.qVL, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(234, 179, 8, 0.11)" : l,
                            ...null == t ? void 0 : t.style
                        },
                        ...t
                    }),
                    error: (e, t) => (0, n.oR)(e, {
                        icon: (0, s.jsx)(o.Edw, {
                            className: "text-[24px]"
                        }),
                        style: {
                            background: (null == t ? void 0 : t.colorful) ? "rgba(239, 68, 68, 0.11)" : l,
                            ...null == t ? void 0 : t.style
                        },
                        duration: 1e4,
                        ...t
                    }),
                    loading: (e, t) => n.oR.loading(e, { ...t,
                        icon: (0, s.jsx)(n.hz, {
                            style: {
                                width: "24px",
                                height: "24px"
                            }
                        })
                    }),
                    promise: async function(e, t, r) {
                        let s = { ...r
                        };
                        try {
                            s.id = c.loading(t.loading, s);
                            let r = await e;
                            return c.success(t.success, s), r
                        } catch (e) {
                            c.error(t.error, s)
                        }
                    }
                }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [154, 2978, 4206, 5653, 9312, 6743, 6655, 4850, 8441, 8329, 7358], () => t(52707)), _N_E = e.O()
    }
]);