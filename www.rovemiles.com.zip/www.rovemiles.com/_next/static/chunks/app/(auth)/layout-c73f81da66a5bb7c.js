! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "952c0713-c8f2-4a23-b3c1-615ecbb89204", e._sentryDebugIdIdentifier = "sentry-dbid-952c0713-c8f2-4a23-b3c1-615ecbb89204")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9097], {
        980: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => s,
                s: () => o
            });
            var r = n(12115),
                a = n(14679),
                i = n(75329);
            let o = () => ({
                    trackMixPanelEvent: (0, r.useCallback)((e, t) => {
                        a.A.track(e, { ...t,
                            platform: "web"
                        })
                    }, [])
                }),
                s = e => {
                    (0, r.useEffect)(() => {
                        var t, n;
                        if (a.A.init(i.A.NEXT_PUBLIC_MIXPANEL_TOKEN || "", {
                                debug: "production" !== i.A.NEXT_PUBLIC_ENV
                            }), !e) return void a.A.reset();
                        a.A.identify(e.id), a.A.people.set({
                            $email: e.email,
                            $name: "".concat((null == (t = e.user_metadata) ? void 0 : t.first_name) || "", " ").concat((null == (n = e.user_metadata) ? void 0 : n.last_name) || "").trim()
                        })
                    }, [e])
                }
        },
        17045: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "errorOnce", {
                enumerable: !0,
                get: function() {
                    return n
                }
            });
            let n = e => {}
        },
        27497: (e, t, n) => {
            "use strict";
            n.d(t, {
                ClientRoot: () => E
            });
            var r = n(95155),
                a = n(77979),
                i = n(53350),
                o = n(6410),
                s = n(71408),
                l = n(56468),
                u = n(20063);
            let c = e => {
                let {
                    children: t
                } = e, n = (0, u.usePathname)(), {
                    onLandingPage: c
                } = (0, l.A)(), d = (0, i.d)("hidden");
                return (0, r.jsx)(o.P.div, {
                    className: (0, a.cn)("flex-grow relative", c && "absolute top-0 left-0 w-full h-full translate-x-0"),
                    style: {
                        overflow: d
                    },
                    "data-sentry-element": "unknown",
                    "data-sentry-component": "PageTransition",
                    "data-sentry-source-file": "PageTransition.tsx",
                    children: (0, r.jsx)(s.N, {
                        mode: "wait",
                        "data-sentry-element": "AnimatePresence",
                        "data-sentry-source-file": "PageTransition.tsx",
                        children: (0, r.jsx)(o.P.main, {
                            initial: {
                                opacity: 0,
                                y: 20
                            },
                            animate: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: .5
                            },
                            onAnimationStart: () => d.set("hidden"),
                            onAnimationComplete: () => d.set("unset"),
                            className: "relative z-10",
                            "data-sentry-element": "unknown",
                            "data-sentry-source-file": "PageTransition.tsx",
                            children: t
                        }, n)
                    })
                })
            };
            var d = n(12115),
                f = n(27122);
            let p = e => {
                (0, d.useEffect)(() => {
                    var t, n;
                    if (!e) return void f.gV(null);
                    f.gV({
                        userId: e.id,
                        name: (null == (t = e.user_metadata) ? void 0 : t.first_name) ? "".concat(e.user_metadata.first_name, " ").concat((null == (n = e.user_metadata) ? void 0 : n.last_name) || "") : e.email
                    })
                }, [e])
            };
            var _ = n(980),
                m = n(75329);

            function E(e) {
                let {
                    user: t,
                    children: n
                } = e;
                return (0, d.useEffect)(() => {
                    var e, n, r, a;
                    t && window.Atlas && window.Atlas.call("identify", {
                        userId: t.id,
                        name: (null == (e = t.user_metadata) ? void 0 : e.first_name) ? "".concat(t.user_metadata.first_name, " ").concat((null == (n = t.user_metadata) ? void 0 : n.last_name) || "") : t.email,
                        email: t.email ? t.email : null == (r = t.user_metadata) ? void 0 : r.email,
                        phone: t.phone ? t.phone : null == (a = t.user_metadata) ? void 0 : a.phone
                    })
                }, [t]), p(t), (0, _.A)(t), (0, d.useEffect)(() => {
                    var e, n;
                    t && window.ttq && window.ttq.identify({
                        external_id: t.id,
                        email: t.email || (null == (e = t.user_metadata) ? void 0 : e.email) || "",
                        phone_number: t.phone || (null == (n = t.user_metadata) ? void 0 : n.phone) || ""
                    })
                }, [t]), (0, d.useEffect)(() => {
                    var e, n;
                    t && window.rdt && window.rdt("init", m.A.NEXT_PUBLIC_REDDIT_PIXEL_ID, {
                        email: t.email || (null == (e = t.user_metadata) ? void 0 : e.email) || "",
                        phoneNumber: t.phone || (null == (n = t.user_metadata) ? void 0 : n.phone) || "",
                        externalId: t.id
                    })
                }, [t]), (0, r.jsx)(c, {
                    "data-sentry-element": "PageTransition",
                    "data-sentry-component": "ClientRoot",
                    "data-sentry-source-file": "_clientRoot.tsx",
                    children: n
                })
            }
        },
        29445: (e, t, n) => {
            Promise.resolve().then(n.t.bind(n, 52619, 23)), Promise.resolve().then(n.t.bind(n, 81356, 23)), Promise.resolve().then(n.bind(n, 27497))
        },
        52619: (e, t, n) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var n in t) Object.defineProperty(e, n, {
                    enumerable: !0,
                    get: t[n]
                })
            }(t, {
                default: function() {
                    return E
                },
                useLinkStatus: function() {
                    return I
                }
            });
            let r = n(49417),
                a = n(95155),
                i = r._(n(12115)),
                o = n(47670),
                s = n(46752),
                l = n(86871),
                u = n(83011),
                c = n(62296),
                d = n(96058);
            n(94781);
            let f = n(63499),
                p = n(58607),
                _ = n(11807);

            function m(e) {
                return "string" == typeof e ? e : (0, o.formatUrl)(e)
            }

            function E(e) {
                let t, n, r, [o, E] = (0, i.useOptimistic)(f.IDLE_LINK_STATUS),
                    I = (0, i.useRef)(null),
                    {
                        href: P,
                        as: v,
                        children: N,
                        prefetch: g = null,
                        passHref: T,
                        replace: y,
                        shallow: C,
                        scroll: L,
                        onClick: b,
                        onMouseEnter: A,
                        onTouchStart: U,
                        legacyBehavior: B = !1,
                        onNavigate: X,
                        ref: x,
                        unstable_dynamicOnHover: w,
                        ...R
                    } = e;
                t = N, B && ("string" == typeof t || "number" == typeof t) && (t = (0, a.jsx)("a", {
                    children: t
                }));
                let S = i.default.useContext(s.AppRouterContext),
                    M = !1 !== g,
                    O = null === g ? l.PrefetchKind.AUTO : l.PrefetchKind.FULL,
                    {
                        href: D,
                        as: j
                    } = i.default.useMemo(() => {
                        let e = m(P);
                        return {
                            href: e,
                            as: v ? m(v) : e
                        }
                    }, [P, v]);
                B && (n = i.default.Children.only(t));
                let k = B ? n && "object" == typeof n && n.ref : x,
                    z = i.default.useCallback(e => (null !== S && (I.current = (0, f.mountLinkInstance)(e, D, S, O, M, E)), () => {
                        I.current && ((0, f.unmountLinkForCurrentNavigation)(I.current), I.current = null), (0, f.unmountPrefetchableInstance)(e)
                    }), [M, D, S, O, E]),
                    K = {
                        ref: (0, u.useMergedRef)(z, k),
                        onClick(e) {
                            B || "function" != typeof b || b(e), B && n.props && "function" == typeof n.props.onClick && n.props.onClick(e), S && (e.defaultPrevented || function(e, t, n, r, a, o, s) {
                                let {
                                    nodeName: l
                                } = e.currentTarget;
                                if (!("A" === l.toUpperCase() && function(e) {
                                        let t = e.currentTarget.getAttribute("target");
                                        return t && "_self" !== t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                                    }(e) || e.currentTarget.hasAttribute("download"))) {
                                    if (!(0, p.isLocalURL)(t)) {
                                        a && (e.preventDefault(), location.replace(t));
                                        return
                                    }
                                    e.preventDefault(), i.default.startTransition(() => {
                                        if (s) {
                                            let e = !1;
                                            if (s({
                                                    preventDefault: () => {
                                                        e = !0
                                                    }
                                                }), e) return
                                        }(0, _.dispatchNavigateAction)(n || t, a ? "replace" : "push", null == o || o, r.current)
                                    })
                                }
                            }(e, D, j, I, y, L, X))
                        },
                        onMouseEnter(e) {
                            B || "function" != typeof A || A(e), B && n.props && "function" == typeof n.props.onMouseEnter && n.props.onMouseEnter(e), S && M && (0, f.onNavigationIntent)(e.currentTarget, !0 === w)
                        },
                        onTouchStart: function(e) {
                            B || "function" != typeof U || U(e), B && n.props && "function" == typeof n.props.onTouchStart && n.props.onTouchStart(e), S && M && (0, f.onNavigationIntent)(e.currentTarget, !0 === w)
                        }
                    };
                return (0, c.isAbsoluteUrl)(j) ? K.href = j : B && !T && ("a" !== n.type || "href" in n.props) || (K.href = (0, d.addBasePath)(j)), r = B ? i.default.cloneElement(n, K) : (0, a.jsx)("a", { ...R,
                    ...K,
                    children: t
                }), (0, a.jsx)(h.Provider, {
                    value: o,
                    children: r
                })
            }
            n(17045);
            let h = (0, i.createContext)(f.IDLE_LINK_STATUS),
                I = () => (0, i.useContext)(h);
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        53350: (e, t, n) => {
            "use strict";
            n.d(t, {
                d: () => s
            });
            var r = n(12115),
                a = n(49568),
                i = n(53127),
                o = n(94416);

            function s(e) {
                let t = (0, o.M)(() => (0, a.OQ)(e)),
                    {
                        isStatic: n
                    } = (0, r.useContext)(i.Q);
                if (n) {
                    let [, n] = (0, r.useState)(e);
                    (0, r.useEffect)(() => t.on("change", n), [])
                }
                return t
            }
        },
        56468: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => a
            });
            var r = n(20063);
            let a = () => ({
                onLandingPage: "/" === (0, r.usePathname)()
            })
        },
        71408: (e, t, n) => {
            "use strict";
            n.d(t, {
                N: () => h
            });
            var r = n(95155),
                a = n(12115),
                i = n(60296),
                o = n(94416),
                s = n(59686),
                l = n(53127);
            class u extends a.Component {
                getSnapshotBeforeUpdate(e) {
                    let t = this.props.childRef.current;
                    if (t && e.isPresent && !this.props.isPresent) {
                        let e = this.props.sizeRef.current;
                        e.height = t.offsetHeight || 0, e.width = t.offsetWidth || 0, e.top = t.offsetTop, e.left = t.offsetLeft
                    }
                    return null
                }
                componentDidUpdate() {}
                render() {
                    return this.props.children
                }
            }

            function c(e) {
                let {
                    children: t,
                    isPresent: n
                } = e, i = (0, a.useId)(), o = (0, a.useRef)(null), s = (0, a.useRef)({
                    width: 0,
                    height: 0,
                    top: 0,
                    left: 0
                }), {
                    nonce: c
                } = (0, a.useContext)(l.Q);
                return (0, a.useInsertionEffect)(() => {
                    let {
                        width: e,
                        height: t,
                        top: r,
                        left: a
                    } = s.current;
                    if (n || !o.current || !e || !t) return;
                    o.current.dataset.motionPopId = i;
                    let l = document.createElement("style");
                    return c && (l.nonce = c), document.head.appendChild(l), l.sheet && l.sheet.insertRule('\n          [data-motion-pop-id="'.concat(i, '"] {\n            position: absolute !important;\n            width: ').concat(e, "px !important;\n            height: ").concat(t, "px !important;\n            top: ").concat(r, "px !important;\n            left: ").concat(a, "px !important;\n          }\n        ")), () => {
                        document.head.removeChild(l)
                    }
                }, [n]), (0, r.jsx)(u, {
                    isPresent: n,
                    childRef: o,
                    sizeRef: s,
                    children: a.cloneElement(t, {
                        ref: o
                    })
                })
            }
            let d = e => {
                let {
                    children: t,
                    initial: n,
                    isPresent: i,
                    onExitComplete: l,
                    custom: u,
                    presenceAffectsLayout: d,
                    mode: p
                } = e, _ = (0, o.M)(f), m = (0, a.useId)(), E = (0, a.useCallback)(e => {
                    for (let t of (_.set(e, !0), _.values()))
                        if (!t) return;
                    l && l()
                }, [_, l]), h = (0, a.useMemo)(() => ({
                    id: m,
                    initial: n,
                    isPresent: i,
                    custom: u,
                    onExitComplete: E,
                    register: e => (_.set(e, !1), () => _.delete(e))
                }), d ? [Math.random(), E] : [i, E]);
                return (0, a.useMemo)(() => {
                    _.forEach((e, t) => _.set(t, !1))
                }, [i]), a.useEffect(() => {
                    i || _.size || !l || l()
                }, [i]), "popLayout" === p && (t = (0, r.jsx)(c, {
                    isPresent: i,
                    children: t
                })), (0, r.jsx)(s.t.Provider, {
                    value: h,
                    children: t
                })
            };

            function f() {
                return new Map
            }
            var p = n(75601);
            let _ = e => e.key || "";

            function m(e) {
                let t = [];
                return a.Children.forEach(e, e => {
                    (0, a.isValidElement)(e) && t.push(e)
                }), t
            }
            var E = n(86553);
            let h = e => {
                let {
                    children: t,
                    custom: n,
                    initial: s = !0,
                    onExitComplete: l,
                    presenceAffectsLayout: u = !0,
                    mode: c = "sync",
                    propagate: f = !1
                } = e, [h, I] = (0, p.xQ)(f), P = (0, a.useMemo)(() => m(t), [t]), v = f && !h ? [] : P.map(_), N = (0, a.useRef)(!0), g = (0, a.useRef)(P), T = (0, o.M)(() => new Map), [y, C] = (0, a.useState)(P), [L, b] = (0, a.useState)(P);
                (0, E.E)(() => {
                    N.current = !1, g.current = P;
                    for (let e = 0; e < L.length; e++) {
                        let t = _(L[e]);
                        v.includes(t) ? T.delete(t) : !0 !== T.get(t) && T.set(t, !1)
                    }
                }, [L, v.length, v.join("-")]);
                let A = [];
                if (P !== y) {
                    let e = [...P];
                    for (let t = 0; t < L.length; t++) {
                        let n = L[t],
                            r = _(n);
                        v.includes(r) || (e.splice(t, 0, n), A.push(n))
                    }
                    "wait" === c && A.length && (e = A), b(m(e)), C(P);
                    return
                }
                let {
                    forceRender: U
                } = (0, a.useContext)(i.L);
                return (0, r.jsx)(r.Fragment, {
                    children: L.map(e => {
                        let t = _(e),
                            a = (!f || !!h) && (P === L || v.includes(t));
                        return (0, r.jsx)(d, {
                            isPresent: a,
                            initial: (!N.current || !!s) && void 0,
                            custom: a ? void 0 : n,
                            presenceAffectsLayout: u,
                            mode: c,
                            onExitComplete: a ? void 0 : () => {
                                if (!T.has(t)) return;
                                T.set(t, !0);
                                let e = !0;
                                T.forEach(t => {
                                    t || (e = !1)
                                }), e && (null == U || U(), b(g.current), f && (null == I || I()), l && l())
                            },
                            children: e
                        }, t)
                    })
                })
            }
        },
        75329: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => i
            });
            var r = n(15653);
            let a = r.z.object({
                    NEXT_PUBLIC_SUPABASE_URL: r.z.string(),
                    NEXT_PUBLIC_SUPABASE_ANON_KEY: r.z.string(),
                    NEXT_PUBLIC_ENV: r.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_MIXPANEL_TOKEN: r.z.string(),
                    NEXT_PUBLIC_SENTRY_DSN: r.z.string(),
                    NEXT_PUBLIC_SENTRY_ORG: r.z.string(),
                    NEXT_PUBLIC_SENTRY_PROJECT: r.z.string(),
                    NEXT_PUBLIC_SENTRY_ENV: r.z.enum(["development", "staging", "production"]).default("staging"),
                    NEXT_PUBLIC_ENABLE_BANNER: r.z.coerce.boolean().default(!1),
                    NEXT_PUBLIC_FACEBOOK_PIXEL_ID: r.z.string(),
                    NEXT_PUBLIC_TIKTOK_PIXEL_ID: r.z.string(),
                    NEXT_PUBLIC_REDDIT_PIXEL_ID: r.z.string()
                }),
                i = (() => {
                    try {
                        return a.parse({
                            NEXT_PUBLIC_SUPABASE_URL: "https://api.rovemiles.com",
                            NEXT_PUBLIC_SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd4d3BpcWh3cmtxYXl6a3BkZXJjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjkwMjM5MDMsImV4cCI6MjA0NDU5OTkwM30.9bm_de4Zwm8gM1tILRZyYvuBe7ymJxycP4dYYxzo8Kw",
                            NEXT_PUBLIC_ENV: "production",
                            NEXT_PUBLIC_MIXPANEL_TOKEN: "9da7db12d48488485c9d6cfac54831b3",
                            NEXT_PUBLIC_SENTRY_DSN: "https://d2b1818c4d1059a71206cf1a19342e14@o4508490297638912.ingest.us.sentry.io/4508490311532544",
                            NEXT_PUBLIC_SENTRY_ORG: "rove-22",
                            NEXT_PUBLIC_SENTRY_PROJECT: "rove-miles-portal",
                            NEXT_PUBLIC_SENTRY_ENV: "production",
                            NEXT_PUBLIC_ENABLE_BANNER: "true",
                            NEXT_PUBLIC_FACEBOOK_PIXEL_ID: "1877255199716926",
                            NEXT_PUBLIC_TIKTOK_PIXEL_ID: "D0R4033C77UBLRIEQ98G",
                            NEXT_PUBLIC_REDDIT_PIXEL_ID: "a2_gw72ldodzgpx"
                        })
                    } catch (e) {
                        throw e instanceof r.z.ZodError && console.error("❌ Invalid environment variables:", e.errors.map(e => "".concat(e.path, ": ").concat(e.message))), e
                    }
                })()
        },
        77979: (e, t, n) => {
            "use strict";
            n.d(t, {
                cn: () => i
            });
            var r = n(75889),
                a = n(2821);

            function i() {
                for (var e = arguments.length, t = Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return (0, r.QP)((0, a.$)(t))
            }
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [9933, 760, 1356, 5653, 6410, 1029, 4850, 8441, 8329, 7358], () => t(29445)), _N_E = e.O()
    }
]);