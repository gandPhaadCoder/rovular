! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "b5f11e92-db69-40ff-bbcb-139ff95d59a8", e._sentryDebugIdIdentifier = "sentry-dbid-b5f11e92-db69-40ff-bbcb-139ff95d59a8")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4219], {
        1262: (e, t, n) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let r = n(12115),
                o = r.useLayoutEffect,
                l = r.useEffect;

            function s(e) {
                let {
                    headManager: t,
                    reduceComponentsToState: n
                } = e;

                function s() {
                    if (t && t.mountedInstances) {
                        let o = r.Children.toArray(Array.from(t.mountedInstances).filter(Boolean));
                        t.updateHead(n(o, e))
                    }
                }
                return o(() => {
                    var n;
                    return null == t || null == (n = t.mountedInstances) || n.add(e.children), () => {
                        var n;
                        null == t || null == (n = t.mountedInstances) || n.delete(e.children)
                    }
                }), o(() => (t && (t._pendingUpdate = s), () => {
                    t && (t._pendingUpdate = s)
                })), l(() => (t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null), () => {
                    t && t._pendingUpdate && (t._pendingUpdate(), t._pendingUpdate = null)
                })), null
            }
        },
        4283: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => a
            });
            var r = n(95155),
                o = n(27122),
                l = n(56696),
                s = n.n(l),
                d = n(12115);

            function a(e) {
                let {
                    error: t
                } = e;
                return (0, d.useEffect)(() => {
                    o.Cp(t)
                }, [t]), (0, r.jsx)("html", {
                    "data-sentry-component": "GlobalError",
                    "data-sentry-source-file": "global-error.tsx",
                    children: (0, r.jsx)("body", {
                        children: (0, r.jsx)(s(), {
                            statusCode: 0,
                            "data-sentry-element": "NextError",
                            "data-sentry-source-file": "global-error.tsx"
                        })
                    })
                })
            }
        },
        44755: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 4283))
        },
        55939: (e, t, n) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "default", {
                enumerable: !0,
                get: function() {
                    return u
                }
            });
            let r = n(28140),
                o = n(95155),
                l = r._(n(12115)),
                s = r._(n(74841)),
                d = {
                    400: "Bad Request",
                    404: "This page could not be found",
                    405: "Method Not Allowed",
                    500: "Internal Server Error"
                };

            function a(e) {
                let {
                    req: t,
                    res: n,
                    err: r
                } = e;
                return {
                    statusCode: n && n.statusCode ? n.statusCode : r ? r.statusCode : 404,
                    hostname: window.location.hostname
                }
            }
            let i = {
                error: {
                    fontFamily: 'system-ui,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji"',
                    height: "100vh",
                    textAlign: "center",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center"
                },
                desc: {
                    lineHeight: "48px"
                },
                h1: {
                    display: "inline-block",
                    margin: "0 20px 0 0",
                    paddingRight: 23,
                    fontSize: 24,
                    fontWeight: 500,
                    verticalAlign: "top"
                },
                h2: {
                    fontSize: 14,
                    fontWeight: 400,
                    lineHeight: "28px"
                },
                wrap: {
                    display: "inline-block"
                }
            };
            class u extends l.default.Component {
                render() {
                    let {
                        statusCode: e,
                        withDarkMode: t = !0
                    } = this.props, n = this.props.title || d[e] || "An unexpected error has occurred";
                    return (0, o.jsxs)("div", {
                        style: i.error,
                        children: [(0, o.jsx)(s.default, {
                            children: (0, o.jsx)("title", {
                                children: e ? e + ": " + n : "Application error: a client-side exception has occurred"
                            })
                        }), (0, o.jsxs)("div", {
                            style: i.desc,
                            children: [(0, o.jsx)("style", {
                                dangerouslySetInnerHTML: {
                                    __html: "body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}" + (t ? "@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}" : "")
                                }
                            }), e ? (0, o.jsx)("h1", {
                                className: "next-error-h1",
                                style: i.h1,
                                children: e
                            }) : null, (0, o.jsx)("div", {
                                style: i.wrap,
                                children: (0, o.jsxs)("h2", {
                                    style: i.h2,
                                    children: [this.props.title || e ? n : (0, o.jsxs)(o.Fragment, {
                                        children: ["Application error: a client-side exception has occurred", " ", !!this.props.hostname && (0, o.jsxs)(o.Fragment, {
                                            children: ["while loading ", this.props.hostname]
                                        }), " ", "(see the browser console for more information)"]
                                    }), "."]
                                })
                            })]
                        })]
                    })
                }
            }
            u.displayName = "ErrorPage", u.getInitialProps = a, u.origGetInitialProps = a, ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        56696: (e, t, n) => {
            e.exports = n(55939)
        },
        60861: (e, t) => {
            "use strict";

            function n(e) {
                let {
                    ampFirst: t = !1,
                    hybrid: n = !1,
                    hasQuery: r = !1
                } = void 0 === e ? {} : e;
                return t || n && r
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "isInAmpMode", {
                enumerable: !0,
                get: function() {
                    return n
                }
            })
        },
        74841: (e, t, n) => {
            "use strict";
            var r = n(95704);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var n in t) Object.defineProperty(e, n, {
                    enumerable: !0,
                    get: t[n]
                })
            }(t, {
                default: function() {
                    return b
                },
                defaultHead: function() {
                    return f
                }
            });
            let o = n(28140),
                l = n(49417),
                s = n(95155),
                d = l._(n(12115)),
                a = o._(n(1262)),
                i = n(90737),
                u = n(82073),
                c = n(60861);

            function f(e) {
                void 0 === e && (e = !1);
                let t = [(0, s.jsx)("meta", {
                    charSet: "utf-8"
                }, "charset")];
                return e || t.push((0, s.jsx)("meta", {
                    name: "viewport",
                    content: "width=device-width"
                }, "viewport")), t
            }

            function p(e, t) {
                return "string" == typeof t || "number" == typeof t ? e : t.type === d.default.Fragment ? e.concat(d.default.Children.toArray(t.props.children).reduce((e, t) => "string" == typeof t || "number" == typeof t ? e : e.concat(t), [])) : e.concat(t)
            }
            n(94781);
            let h = ["name", "httpEquiv", "charSet", "itemProp"];

            function y(e, t) {
                let {
                    inAmpMode: n
                } = t;
                return e.reduce(p, []).reverse().concat(f(n).reverse()).filter(function() {
                    let e = new Set,
                        t = new Set,
                        n = new Set,
                        r = {};
                    return o => {
                        let l = !0,
                            s = !1;
                        if (o.key && "number" != typeof o.key && o.key.indexOf("$") > 0) {
                            s = !0;
                            let t = o.key.slice(o.key.indexOf("$") + 1);
                            e.has(t) ? l = !1 : e.add(t)
                        }
                        switch (o.type) {
                            case "title":
                            case "base":
                                t.has(o.type) ? l = !1 : t.add(o.type);
                                break;
                            case "meta":
                                for (let e = 0, t = h.length; e < t; e++) {
                                    let t = h[e];
                                    if (o.props.hasOwnProperty(t))
                                        if ("charSet" === t) n.has(t) ? l = !1 : n.add(t);
                                        else {
                                            let e = o.props[t],
                                                n = r[t] || new Set;
                                            ("name" !== t || !s) && n.has(e) ? l = !1 : (n.add(e), r[t] = n)
                                        }
                                }
                        }
                        return l
                    }
                }()).reverse().map((e, t) => {
                    let o = e.key || t;
                    if (r.env.__NEXT_OPTIMIZE_FONTS && !n && "link" === e.type && e.props.href && ["https://fonts.googleapis.com/css", "https://use.typekit.net/"].some(t => e.props.href.startsWith(t))) {
                        let t = { ...e.props || {}
                        };
                        return t["data-href"] = t.href, t.href = void 0, t["data-optimized-fonts"] = !0, d.default.cloneElement(e, t)
                    }
                    return d.default.cloneElement(e, {
                        key: o
                    })
                })
            }
            let b = function(e) {
                let {
                    children: t
                } = e, n = (0, d.useContext)(i.AmpStateContext), r = (0, d.useContext)(u.HeadManagerContext);
                return (0, s.jsx)(a.default, {
                    reduceComponentsToState: y,
                    headManager: r,
                    inAmpMode: (0, c.isInAmpMode)(n),
                    children: t
                })
            };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        90737: (e, t, n) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "AmpStateContext", {
                enumerable: !0,
                get: function() {
                    return r
                }
            });
            let r = n(28140)._(n(12115)).default.createContext({})
        }
    },
    e => {
        var t = t => e(e.s = t);
        e.O(0, [4850, 8441, 8329, 7358], () => t(44755)), _N_E = e.O()
    }
]);