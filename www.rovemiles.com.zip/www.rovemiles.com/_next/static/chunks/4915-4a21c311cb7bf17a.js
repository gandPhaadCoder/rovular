! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "dd294c47-208a-4465-872a-995c022f1ca7", e._sentryDebugIdIdentifier = "sentry-dbid-dd294c47-208a-4465-872a-995c022f1ca7")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4915], {
        1690: (e, t, a) => {
            a.d(t, {
                A: () => g
            });
            var n = a(95155),
                l = a(12115),
                s = a(24509),
                r = a(15239);
            let i = (0, l.memo)(e => {
                let {
                    region: t,
                    onSelect: a
                } = e;
                return (0, n.jsxs)("button", {
                    onClick: e => {
                        e.stopPropagation(), a({
                            code: t.code,
                            name: t.name,
                            type: "region",
                            city: t.city,
                            svgPath: t.svgPath
                        })
                    },
                    className: "relative aspect-square rounded-lg overflow-hidden group",
                    children: [(0, n.jsx)(r.default, {
                        src: t.svgPath,
                        alt: t.name,
                        fill: !0,
                        sizes: "(max-width: 768px) 33vw, 150px",
                        priority: !1,
                        className: "object-cover group-hover:scale-110 transition-transform duration-300 will-change-transform"
                    }), (0, n.jsx)("div", {
                        className: "absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"
                    }), (0, n.jsx)("div", {
                        className: "absolute bottom-2 left-2 text-white text-left",
                        children: (0, n.jsx)("div", {
                            className: "text-sm font-medium",
                            children: t.name
                        })
                    })]
                })
            });
            i.displayName = "RegionOption";
            let o = e => {
                let {
                    item: t,
                    onSelect: a
                } = e;
                return (0, n.jsxs)("button", {
                    onClick: e => {
                        e.stopPropagation(), a(t)
                    },
                    className: "w-full text-left px-3 py-2 text-sm text-white/70 hover:bg-white/5",
                    "data-sentry-component": "LocationOption",
                    "data-sentry-source-file": "LocationOption.tsx",
                    children: [(0, n.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [(0, n.jsx)("span", {
                            children: t.name
                        }), (0, n.jsx)("span", {
                            className: "text-white/40",
                            children: t.code
                        })]
                    }), (0, n.jsxs)("div", {
                        className: "text-xs text-white/40",
                        children: [t.city, " (", "airport" === t.type ? "Airport" : "City", ")"]
                    })]
                })
            };
            var d = a(50742),
                c = a(53455),
                u = a(95125),
                h = a(64269);
            let g = (0, l.memo)(e => {
                let {
                    className: t,
                    size: a = "small",
                    isMinimized: r = !1,
                    label: g,
                    value: m,
                    onChange: p,
                    onFocus: x,
                    placeholder: f,
                    showRegions: y = !1,
                    variant: b = "default",
                    isExpanded: v = !0,
                    type: w,
                    focusableArea: N = "input",
                    initialLoading: j = !1
                } = e, [C, S] = (0, l.useState)({
                    query: (null == m ? void 0 : m.name) || "",
                    isOpen: !1
                }), D = (0, l.useRef)(null), A = C.query ? "Anywhere" === C.query ? "" : C.query : "", {
                    data: T,
                    isLoading: E
                } = function(e) {
                    return (0, c.I)({
                        queryKey: ["airports", e],
                        queryFn: async () => e && 0 !== e.size ? (await u.A.get("/api/airports", {
                            params: e
                        })).data.data : {
                            airports: [],
                            totalCount: 0,
                            page: 0
                        },
                        enabled: !!e,
                        staleTime: 864e5,
                        gcTime: 864e5
                    })
                }(A ? {
                    query: A,
                    size: 5
                } : null), {
                    data: F,
                    isLoading: z
                } = function(e) {
                    return (0, c.I)({
                        queryKey: ["airportGroups", e],
                        queryFn: async () => e && 0 !== e.size ? (await u.A.get("/api/airports/groups", {
                            params: e
                        })).data.data : {
                            groups: [],
                            totalCount: 0,
                            page: 0
                        },
                        enabled: !!e,
                        staleTime: 864e5,
                        gcTime: 864e5
                    })
                }({
                    query: A,
                    size: 50
                }), I = E || z;
                (0, l.useEffect)(() => {
                    S(e => ({ ...e,
                        query: (null == m ? void 0 : m.name) || ""
                    }))
                }, [null == m ? void 0 : m.name]);
                let k = (0, l.useMemo)(() => {
                        var e, t, a;
                        let n = null != (t = null == F ? void 0 : F.groups.filter(e => "region" === e.type)) ? t : [],
                            l = (null == F ? void 0 : F.groups.filter(e => "city" === e.type)) || [],
                            s = n.map(e => {
                                var t;
                                return { ...e,
                                    type: "region",
                                    svgPath: null != (t = e.image_url) ? t : "",
                                    city: e.name
                                }
                            }),
                            r = l.map(e => ({
                                id: e.id,
                                code: e.code,
                                name: e.name,
                                type: "city",
                                city: e.name,
                                svgPath: e.image_url || void 0
                            })),
                            i = null != (a = null == T || null == (e = T.airports) ? void 0 : e.map(e => ({
                                id: e.id,
                                code: e.iata_code,
                                name: e.name,
                                type: "airport",
                                city: e.municipality || void 0,
                                svgPath: e.image_url || void 0
                            }))) ? a : [],
                            o = y ? s : [],
                            d = r.concat(i),
                            c = d.sort((e, t) => A.length <= 3 ? e.code.toLowerCase().startsWith(A.toLowerCase()) ? -1 : +!!t.code.toLowerCase().startsWith(A.toLowerCase()) : e.name.toLowerCase().startsWith(A.toLowerCase()) && !t.name.toLowerCase().startsWith(A.toLowerCase()) ? -1 : t.name.toLowerCase().startsWith(A.toLowerCase()) && !e.name.toLowerCase().startsWith(A.toLowerCase()) ? 1 : 0);
                        return {
                            totalCount: d.length + o.length,
                            regions: o,
                            airports: c
                        }
                    }, [T, F, y, A]),
                    M = e => {
                        p(e), S(e => ({ ...e,
                            isOpen: !1
                        }))
                    };
                (0, l.useEffect)(() => {
                    v || S(e => ({ ...e,
                        isOpen: !1
                    }))
                }, [v]);
                let P = () => {
                    S({
                        query: (null == m ? void 0 : m.name) || "",
                        isOpen: !1
                    })
                };
                return (0, n.jsxs)("div", {
                    className: (0, h.cn)("flex-1 px-3 py-1.5", "bordered-mobile" === b && "px-4 border-white/10 flex items-center rounded-lg border-solid border", t),
                    onClick: () => {
                        if ("all" === N) {
                            var e;
                            S(e => ({ ...e,
                                isOpen: !0
                            })), null == (e = D.current) || e.focus()
                        }
                    },
                    "data-sentry-component": "LocationInput",
                    "data-sentry-source-file": "index.tsx",
                    children: [(!r || v) && (0, n.jsx)("div", {
                        className: (0, h.cn)("uppercase text-white/40 leading-none mb-0.5", "small" === a ? "text-[10px]" : "text-xs"),
                        children: g
                    }), (0, n.jsxs)("div", {
                        className: (0, h.cn)("relative flex items-center gap-2", "bordered-mobile" === b && "w-full"),
                        children: [(!r || v) && (0, n.jsxs)(n.Fragment, {
                            children: ["origin" === w && (0, n.jsx)(d.T7X, {
                                className: (0, h.cn)("text-white/40", "small" === a ? "w-3.5 h-3.5" : "w-6 h-6")
                            }), "destination" === w && (0, n.jsx)(d.Yu, {
                                className: (0, h.cn)("text-white/40", "small" === a ? "w-3.5 h-3.5" : "w-6 h-6")
                            })]
                        }), (0, n.jsx)("input", {
                            className: (0, h.cn)("w-full bg-transparent ".concat(!r || v ? "text-xs" : "text-sm", " focus:outline-none ").concat((null == m ? void 0 : m.code) ? "text-white" : "text-white/70 placeholder-white/40"), "large" === a ? "text-sm" : "", "bordered-mobile" === b && "py-2.5"),
                            placeholder: j ? "Loading..." : f,
                            value: C.query,
                            onChange: e => {
                                S({
                                    query: e.target.value,
                                    isOpen: !0
                                })
                            },
                            onFocus: e => {
                                x(), S(e => ({ ...e,
                                    isOpen: !0
                                })), e.target.select()
                            },
                            onBlur: P,
                            ref: D
                        }), (0, n.jsx)(s.A, {
                            isOpen: C.isOpen,
                            onClose: P,
                            className: "absolute top-full left-0 mt-1 -mx-4 w-[calc(100vw-2rem)] sm:w-[500px] max-h-[400px] overflow-y-auto bg-[#101010] backdrop-blur-xl border border-[#636363]/60 rounded-lg shadow-lg z-50",
                            "data-sentry-element": "OverlayContainer",
                            "data-sentry-source-file": "index.tsx",
                            children: (0, n.jsx)("div", {
                                className: "p-2",
                                children: (0, n.jsxs)(n.Fragment, {
                                    children: [y && k.regions.length > 0 && (0, n.jsxs)(n.Fragment, {
                                        children: [(0, n.jsx)("div", {
                                            className: "grid grid-cols-3 gap-2",
                                            children: k.regions.map(e => (0, n.jsx)(i, {
                                                region: e,
                                                onSelect: M
                                            }, "region-".concat(e.code)))
                                        }), k.airports.length > 0 && (0, n.jsx)("div", {
                                            className: "h-[1px] bg-white/10 my-2 -mx-2"
                                        })]
                                    }), k.airports.length > 0 && (0, n.jsx)("div", {
                                        children: k.airports.map(e => (0, n.jsx)(o, {
                                            item: { ...e,
                                                type: e.type || "airport",
                                                code: e.code
                                            },
                                            onSelect: M
                                        }, "airport-".concat(e.code, "-").concat(e.id)))
                                    }), 0 === k.totalCount && !I && (0, n.jsx)("div", {
                                        className: "text-xs text-white/40 text-center",
                                        children: "No results found"
                                    }), I && (0, n.jsx)("div", {
                                        className: "text-xs text-white/40 text-center",
                                        children: "Loading..."
                                    })]
                                })
                            })
                        })]
                    })]
                })
            })
        },
        2981: (e, t, a) => {
            a.d(t, {
                F: () => n
            });
            let n = "search-bar-expanded";
            new Event(n)
        },
        5673: (e, t, a) => {
            a.d(t, {
                A: () => M
            });
            var n = a(95155),
                l = a(12115),
                s = a(90109),
                r = a(83871),
                i = a(1690),
                o = a(37138),
                d = a(53380),
                c = a(46431),
                u = a(64269),
                h = a(34217),
                g = a(89568),
                m = a(76433),
                p = a(56468),
                x = a(42953);
            let f = e => {
                let {
                    initialValues: t,
                    isExpanded: a,
                    onFocus: l,
                    onSearch: f,
                    isLoading: y,
                    isMinimized: b = !1,
                    showRegions: v = !1
                } = e, {
                    mode: w,
                    passengers: N,
                    setPassengers: j,
                    selectedCabin: C,
                    handleCabinChange: S,
                    handleLocationChange: D,
                    handleSearch: A,
                    handleSwapLocations: T,
                    handleDepartDateChange: E,
                    values: F,
                    effectiveMode: z,
                    isDestinationRegion: I,
                    updateField: k,
                    handlePaymentTypeChange: M,
                    handleChangeMode: P
                } = (0, m.A)({
                    initialValues: t,
                    onSearch: f
                }), {
                    onLandingPage: O
                } = (0, p.A)(), L = (0, x.A)();
                return (0, n.jsxs)("div", {
                    className: (0, u.cn)("flex flex-col gap-1 relative transition-all duration-300 top-0", {
                        "py-1": b,
                        "md:mt-0": !a && "hotels" === t.tab
                    }, "mx-4", O && (L && !a ? "-top-8" : "-top-2")),
                    "data-sentry-component": "FlightSearchInput",
                    "data-sentry-source-file": "FlightSearchInput.tsx",
                    children: [(!b || a) && (0, n.jsx)(r.A, {
                        mode: w,
                        handleChangeMode: P,
                        passengers: N,
                        onPassengersChange: j,
                        selectedCabin: C,
                        onCabinChange: e => {
                            S(e)
                        },
                        isExpanded: a
                    }), (0, n.jsxs)("div", {
                        className: (0, u.cn)("relative rounded-lg max-w-3xl mx-auto p-[1px]", O && !a && "max-w-[470px]"),
                        children: [(0, n.jsx)("div", {
                            className: "absolute inset-0 rounded-lg",
                            style: {
                                background: O ? "transparent" : "linear-gradient(90deg, #313131 0%, #585858 28%, #333333 66%, #313131 100%)",
                                border: O ? "1px solid #313131" : ""
                            }
                        }), O && (0, n.jsxs)(n.Fragment, {
                            children: [(0, n.jsx)("div", {
                                className: "w-[calc(100%-10px)] h-[1px] absolute top-0 left-1/2 -translate-x-1/2",
                                style: {
                                    background: "linear-gradient(90deg, #313131 0%, #585858 28%, #333333 66%, #313131 100%)"
                                }
                            }), (0, n.jsx)("div", {
                                className: "w-[calc(100%-10px)] h-[1px] absolute bottom-0 left-1/2 -translate-x-1/2",
                                style: {
                                    background: "linear-gradient(90deg, #313131 0%, #585858 28%, #333333 66%, #313131 100%)"
                                }
                            })]
                        }), (0, n.jsxs)("div", {
                            className: (0, u.cn)("relative flex items-center bg-[#101010]/90 rounded-lg h-14", O && "bg-[#343434]/20"),
                            children: [(0, n.jsxs)("div", {
                                className: "flex-1 flex items-center p-2",
                                children: [(0, n.jsx)(i.A, {
                                    label: "From",
                                    value: F.origin,
                                    onChange: e => D("origin", e),
                                    onFocus: l,
                                    placeholder: b ? "From" : "Enter city or airport",
                                    showRegions: !1,
                                    isExpanded: a,
                                    type: "origin",
                                    isMinimized: b,
                                    initialLoading: !t.origin && "flights" === t.tab,
                                    "data-sentry-element": "LocationInput",
                                    "data-sentry-source-file": "FlightSearchInput.tsx"
                                }), (0, n.jsx)("button", {
                                    onClick: () => {
                                        T(), a || A({ ...F,
                                            origin: F.destination,
                                            destination: F.origin
                                        })
                                    },
                                    className: "px-2 py-1 hover:opacity-75 transition-opacity",
                                    children: (0, n.jsx)(d.CqI, {
                                        className: "w-4 h-4 text-white opacity-40",
                                        "data-sentry-element": "LuArrowLeftRight",
                                        "data-sentry-source-file": "FlightSearchInput.tsx"
                                    })
                                }), (0, n.jsx)(i.A, {
                                    label: "To",
                                    value: F.destination,
                                    onChange: e => D("destination", e),
                                    onFocus: l,
                                    placeholder: b ? "To" : "Enter city or airport",
                                    showRegions: "oneWay" === z && "miles" === F.paymentType && v,
                                    isExpanded: a,
                                    type: "destination",
                                    isMinimized: b,
                                    initialLoading: !t.destination && "flights" === t.tab,
                                    "data-sentry-element": "LocationInput",
                                    "data-sentry-source-file": "FlightSearchInput.tsx"
                                })]
                            }), (0, n.jsx)("div", {
                                className: "w-[1px] h-6 bg-white/10"
                            }), (0, n.jsx)(o.A, {
                                label: "Depart",
                                value: F.dates.startDate,
                                onChange: E,
                                onFocus: l,
                                placeholder: b ? "Depart" : "Add date",
                                isExpanded: a,
                                dateRange: F.dates,
                                isRangeMode: "oneWay" === z && I,
                                updateField: k,
                                isMinimized: b,
                                "data-sentry-element": "DateInput",
                                "data-sentry-source-file": "FlightSearchInput.tsx"
                            }), "roundTrip" === z && (0, n.jsxs)(n.Fragment, {
                                children: [!b || a ? (0, n.jsx)("div", {
                                    className: "w-[1px] h-6 bg-white/10"
                                }) : (0, n.jsx)("div", {
                                    children: "-"
                                }), (0, n.jsx)(o.A, {
                                    label: "Return",
                                    value: F.returnDate,
                                    onChange: e => k("returnDate", e),
                                    onFocus: l,
                                    placeholder: b ? "Return" : "Add date",
                                    isExpanded: a,
                                    isReturnDate: !0,
                                    dateRange: F.dates,
                                    isMinimized: b
                                })]
                            }), a && (0, n.jsxs)(n.Fragment, {
                                children: [(0, n.jsx)("div", {
                                    className: "w-[1px] h-6 bg-white/10"
                                }), (0, n.jsx)("div", {
                                    className: "flex items-center gap-1",
                                    children: (0, n.jsx)(g.A, {
                                        selected: F.paymentType,
                                        onSelect: M,
                                        onFocus: l
                                    })
                                })]
                            }), (!b || a) && (0, n.jsx)("div", {
                                className: "px-1.5",
                                children: (0, n.jsx)("button", {
                                    className: (0, u.cn)("w-8 h-8 rounded-full bg-[#3E3A4B] flex items-center justify-center hover:opacity-90 transition-opacity disabled:opacity-50", h.q.classes.flightSearchButton),
                                    onClick: () => A(),
                                    children: (0, n.jsx)(s.A, {
                                        className: "w-3.5 h-3.5 text-[#FFFFFF]"
                                    })
                                })
                            })]
                        }), (0, n.jsx)(c.b, {
                            isVisible: null != y && y,
                            "data-sentry-element": "LoadingProgressBar",
                            "data-sentry-source-file": "FlightSearchInput.tsx"
                        })]
                    })]
                })
            };
            var y = a(9087),
                b = a(17772),
                v = a(92381),
                w = a(8155),
                N = a(17031);
            let j = new Date,
                C = new Date(j);
            C.setDate(j.getDate() + 7);
            let S = new Date(C);
            S.setDate(C.getDate() + 1);
            let D = e => {
                var t, a;
                let {
                    initialValues: r,
                    onFocus: i,
                    isExpanded: d,
                    isMinimized: g = !1,
                    isLoading: m,
                    onSearch: p
                } = e, [x, f] = (0, l.useState)({
                    displayName: "Around your area",
                    placeId: "",
                    location: void 0,
                    checkIn: new Date,
                    checkOut: (0, v.f)(new Date, 1),
                    rooms: [{
                        adults: 2,
                        children: 0,
                        childrenAges: []
                    }],
                    guestNationality: "US",
                    currency: "USD",
                    formattedAddress: void 0
                }), [j, D] = (0, l.useState)(C), [A, T] = (0, l.useState)(S), [E, F] = (0, l.useState)([{
                    adults: 2,
                    children: 0,
                    childrenAges: []
                }]), z = (null == (t = r.hotelDestination) ? void 0 : t.currency) || "USD", I = (null == (a = r.hotelDestination) ? void 0 : a.guestNationality) || "US", k = (0, l.useRef)(null);
                return (0, N.Ij)(() => {
                    var e, t, a;
                    r.hotelDestination && (r.hotelDestination.placeId || (null == (e = r.hotelDestination.location) ? void 0 : e.latitude) || (null == (t = r.hotelDestination.location) ? void 0 : t.longitude) || (r.hotelDestination.displayName = "Around your area"), f(r.hotelDestination), D(r.hotelDestination.checkIn), T(r.hotelDestination.checkOut), (null == (a = r.hotelDestination) ? void 0 : a.rooms) && F(r.hotelDestination.rooms.map(e => ({
                        adults: e.adults,
                        children: e.children,
                        childrenAges: e.childrenAges
                    }))))
                }, [r]), (0, n.jsx)("div", {
                    className: (0, u.cn)("flex flex-col gap-1 mx-4", {
                        "py-1": g,
                        "lg:mt-0": d && "hotels" === r.tab
                    }),
                    "data-sentry-component": "HotelSearchInput",
                    "data-sentry-source-file": "HotelSearchInput.tsx",
                    children: (0, n.jsxs)("div", {
                        className: "relative p-[1px] rounded-lg max-w-4xl mx-auto",
                        children: [(0, n.jsx)("div", {
                            className: "absolute inset-0 rounded-lg",
                            style: {
                                background: "linear-gradient(90deg, #313131 0%, #585858 28%, #333333 66%, #313131 100%)"
                            }
                        }), (0, n.jsxs)("div", {
                            className: "relative flex items-center bg-[#101010]/90 rounded-lg h-14",
                            children: [(0, n.jsxs)("div", {
                                className: "flex-1 flex items-center p-2",
                                children: [(0, n.jsx)(y.A, {
                                    label: "Destination",
                                    value: x,
                                    onChange: f,
                                    onFocus: i,
                                    placeholder: g ? "Destination" : "Enter city or hotel name",
                                    isMinimized: g,
                                    "data-sentry-element": "HotelLocationInput",
                                    "data-sentry-source-file": "HotelSearchInput.tsx"
                                }), (0, n.jsx)("div", {
                                    className: "w-[1px] h-6 bg-white/10"
                                }), (0, n.jsx)(o.A, {
                                    label: "Check in",
                                    value: j,
                                    onChange: e => {
                                        D(e), e ? (T((0, v.f)(e, 1)), setTimeout(() => {
                                            k.current && k.current.click()
                                        }, 300)) : T(null)
                                    },
                                    onFocus: i,
                                    placeholder: g ? "Check in" : "Add date",
                                    isExpanded: !1,
                                    isMinimized: g,
                                    "data-sentry-element": "DateInput",
                                    "data-sentry-source-file": "HotelSearchInput.tsx"
                                }), (0, n.jsx)("div", {
                                    className: "w-[1px] h-6 bg-white/10"
                                }), (0, n.jsx)(o.A, {
                                    ref: k,
                                    label: "Check out",
                                    value: A,
                                    onChange: T,
                                    onFocus: i,
                                    placeholder: g ? "Check out" : "Add date",
                                    isExpanded: !1,
                                    isMinimized: g,
                                    isReturnDate: !0,
                                    dateRange: j ? {
                                        startDate: j,
                                        endDate: A
                                    } : void 0,
                                    "data-sentry-element": "DateInput",
                                    "data-sentry-source-file": "HotelSearchInput.tsx"
                                }), (0, n.jsx)("div", {
                                    className: "w-[1px] h-6 bg-white/10"
                                }), (0, n.jsx)(b.A, {
                                    value: E,
                                    onChange: F,
                                    isMinimized: g,
                                    "data-sentry-element": "HotelGuests",
                                    "data-sentry-source-file": "HotelSearchInput.tsx"
                                })]
                            }), (0, n.jsx)("div", {
                                className: "px-1.5",
                                children: (0, n.jsx)("button", {
                                    className: (0, u.cn)("w-8 h-8 rounded-full bg-[#3E3A4B] flex items-center justify-center hover:opacity-90 transition-opacity", h.q.classes.hotelSearchButton),
                                    onClick: () => {
                                        let e = { ...r
                                        };
                                        (0, w.s)(w.b.HOTEL_SEARCH_CLICK), p({ ...e,
                                            hotelDestination: {
                                                checkIn: j || C,
                                                checkOut: A || S,
                                                placeId: (null == x ? void 0 : x.placeId) || "",
                                                displayName: (null == x ? void 0 : x.displayName) || "",
                                                location: null == x ? void 0 : x.location,
                                                rooms: E.map(e => ({
                                                    adults: e.adults,
                                                    children: e.children,
                                                    childrenAges: e.childrenAges
                                                })),
                                                currency: z,
                                                guestNationality: I,
                                                filters: {
                                                    hotelName: "",
                                                    facilities: [],
                                                    guestRating: 0,
                                                    propertyRating: [],
                                                    types: [],
                                                    sorting: "1",
                                                    cancellation: "all",
                                                    meals: void 0
                                                }
                                            }
                                        })
                                    },
                                    children: (0, n.jsx)(s.A, {
                                        className: "w-3.5 h-3.5 text-[#FFFFFF]",
                                        "data-sentry-element": "Search",
                                        "data-sentry-source-file": "HotelSearchInput.tsx"
                                    })
                                })
                            })]
                        }), (0, n.jsx)(c.b, {
                            isVisible: null != m && m,
                            "data-sentry-element": "LoadingProgressBar",
                            "data-sentry-source-file": "HotelSearchInput.tsx"
                        })]
                    })
                })
            };
            var A = a(20063),
                T = a(78718);
            let E = (e, t) => {
                (0, l.useEffect)(() => {
                    let a = a => {
                        e.current && !e.current.contains(a.target) && t(a)
                    };
                    return document.addEventListener("mousedown", a), () => document.removeEventListener("mousedown", a)
                }, [e, t])
            };
            var F = a(2981),
                z = a(25950),
                I = a(5804),
                k = a(8772);
            let M = e => {
                let {
                    onSearch: t,
                    initialValues: a,
                    variant: s = "default",
                    loading: r,
                    onExpandChange: i,
                    isMinimized: o = !1,
                    isMinimizedTabsOverride: d,
                    showRegions: c = !1
                } = e, u = (0, A.usePathname)(), h = (0, A.useRouter)(), g = (0, l.useRef)(null), [m, p] = (0, l.useState)(!1), {
                    activeTab: x
                } = (0, z.F7)(), y = (0, k.Iz)();
                E(g, e => {
                    null === e.target.closest("[data-radix-popper-content-wrapper]") && (p(!1), null == i || i(!1), y({
                        type: "SET_IS_EXPANDED",
                        payload: !1
                    }))
                });
                let b = (0, l.useCallback)(() => {
                    "/shopping" !== u && (p(!0), null == i || i(!0), y({
                        type: "SET_IS_EXPANDED",
                        payload: !0
                    }))
                }, [i, u]);
                (0, l.useEffect)(() => {
                    let e = () => {
                        b()
                    };
                    return document.addEventListener(F.F, e), () => document.removeEventListener(F.F, e)
                }, [b]);
                let v = (0, l.useCallback)(e => {
                        if (p(!1), t) return void t({ ...e,
                            tab: x
                        });
                        let a = e.origin,
                            n = e.destination;
                        if (a && "airport" === a.type && (null == n ? void 0 : n.type) === "airport") {
                            let t = (0, T.mp)(e);
                            if (!t) return;
                            h.push(t)
                        }
                    }, [t, h, x]),
                    w = () => {
                        switch (x) {
                            case "flights":
                                return (0, n.jsx)(f, {
                                    initialValues: a,
                                    isExpanded: m,
                                    onFocus: b,
                                    onSearch: v,
                                    isLoading: r,
                                    isMinimized: o,
                                    showRegions: c
                                });
                            case "hotels":
                                return (0, n.jsx)(D, {
                                    initialValues: a,
                                    isLoading: r,
                                    onSearch: v,
                                    isExpanded: m,
                                    onFocus: b,
                                    isMinimized: o
                                });
                            default:
                                return null
                        }
                    };
                return "navbar" === s ? (0, n.jsxs)("div", {
                    ref: g,
                    className: "flex flex-col gap-3",
                    children: [(0, n.jsx)(I.g, {
                        isMinimized: void 0 !== d ? d : o,
                        isExpanded: m,
                        variant: s
                    }), w()]
                }) : (0, n.jsx)("div", {
                    className: "w-full max-w-4xl mx-auto",
                    "data-sentry-component": "SearchBarV2",
                    "data-sentry-source-file": "index.tsx",
                    children: (0, n.jsxs)("div", {
                        className: "bg-[#1E1D25] rounded-xl shadow-lg ".concat(o ? "p-2" : "p-4"),
                        children: [(0, n.jsx)(I.g, {
                            isMinimized: void 0 !== d ? d : o,
                            isExpanded: m,
                            variant: s,
                            "data-sentry-element": "SearchBarV2Tabs",
                            "data-sentry-source-file": "index.tsx"
                        }), w()]
                    })
                })
            }
        },
        5804: (e, t, a) => {
            a.d(t, {
                g: () => h,
                e: () => g
            });
            var n = a(95155),
                l = a(8155),
                s = a(64269),
                r = a(20063);
            a(12115);
            let i = e => {
                let {
                    active: t,
                    onClick: a,
                    variant: l = "large",
                    children: r,
                    disabled: i
                } = e;
                return (0, n.jsxs)("button", {
                    onClick: a,
                    disabled: i,
                    className: (0, s.cn)("relative px-3 py-1 transition-colors", "small" === l ? "text-xs" : "text-sm", t ? "text-white" : "text-white/70 hover:text-white/90", i && "opacity-50 cursor-not-allowed"),
                    "data-sentry-component": "TabButton",
                    "data-sentry-source-file": "TabButton.tsx",
                    children: [r, t && (0, n.jsx)("div", {
                        className: "absolute bottom-0 left-0 right-0 h-[1px]",
                        style: {
                            background: "linear-gradient(90deg, #464646 0%, #9C9C9C 66%, #464646 100%)"
                        }
                    })]
                })
            };
            var o = a(25950),
                d = a(87282),
                c = a.n(d),
                u = a(56468);
            let h = e => {
                    let {
                        isMinimized: t,
                        isExpanded: a,
                        variant: d
                    } = e, c = (0, r.useRouter)(), {
                        activeTab: h
                    } = (0, o.F7)(), {
                        onLandingPage: g
                    } = (0, u.A)(), m = e => {
                        (e.id !== h || g) && ((0, l.s)(e.trackingEvent), c.push(e.navigationTo))
                    };
                    return (0, n.jsx)("div", {
                        className: (0, s.cn)("flex justify-center gap-4 mb-4 transition-all duration-200 relative", g && "top-1 mb-2", t && (a ? "opacity-100 h-10" : "opacity-0 h-0 overflow-hidden")),
                        "data-sentry-component": "SearchBarV2Tabs",
                        "data-sentry-source-file": "tabs.tsx",
                        children: o.Ri.map(e => (0, n.jsx)(i, {
                            active: h === e.id && !g,
                            onClick: () => m(e),
                            variant: "navbar" !== d || g ? "large" : "small",
                            disabled: !1,
                            children: e.label
                        }, e.id))
                    })
                },
                g = () => {
                    let {
                        activeTab: e
                    } = (0, o.F7)(), t = (0, r.useRouter)(), a = a => {
                        a.id !== e && ((0, l.s)(a.trackingEvent), t.push(a.navigationTo))
                    };
                    return (0, n.jsx)("div", {
                        className: (0, s.cn)("flex justify-center gap-4 h-10"),
                        "data-sentry-component": "SearchBarV2TabsMobile",
                        "data-sentry-source-file": "tabs.tsx",
                        children: o.Ri.map(t => (0, n.jsx)(i, {
                            active: e === t.id,
                            onClick: () => a(t),
                            variant: "large",
                            children: c()(t.id)
                        }, t.id))
                    })
                }
        },
        8772: (e, t, a) => {
            a.d(t, {
                NavbarProvider: () => d,
                Iz: () => u,
                v8: () => c
            });
            var n = a(95155),
                l = a(12115);
            let s = {
                    headerContent: null,
                    className: void 0,
                    containerClassName: void 0,
                    isExpanded: !1
                },
                r = (e, t) => {
                    switch (t.type) {
                        case "SET_HEADER_CONTENT":
                            return { ...e,
                                headerContent: t.payload
                            };
                        case "SET_NAVBAR_CLASSNAME":
                            return { ...e,
                                className: t.payload
                            };
                        case "SET_CONTAINER_CLASSNAME":
                            return { ...e,
                                containerClassName: t.payload
                            };
                        case "SET_IS_EXPANDED":
                            return { ...e,
                                isExpanded: t.payload
                            };
                        default:
                            return e
                    }
                },
                i = (0, l.createContext)(s),
                o = (0, l.createContext)(() => {}),
                d = e => {
                    let {
                        children: t
                    } = e, [a, d] = (0, l.useReducer)(r, s);
                    return (0, n.jsx)(i.Provider, {
                        value: a,
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "NavbarProvider",
                        "data-sentry-source-file": "index.tsx",
                        children: (0, n.jsx)(o.Provider, {
                            value: d,
                            "data-sentry-element": "unknown",
                            "data-sentry-source-file": "index.tsx",
                            children: t
                        })
                    })
                },
                c = () => (0, l.useContext)(i),
                u = () => (0, l.useContext)(o)
        },
        9087: (e, t, a) => {
            a.d(t, {
                A: () => g
            });
            var n = a(95155),
                l = a(12115),
                s = a(50742),
                r = a(34357),
                i = a(64269),
                o = a(24509),
                d = a(53455),
                c = a(95125),
                u = a(16272);
            let h = (0, l.memo)(e => {
                let {
                    className: t,
                    isMinimized: a = !1,
                    label: h,
                    value: g,
                    onChange: m,
                    onFocus: p,
                    placeholder: x,
                    variant: f = "default"
                } = e, [y, b] = (0, l.useState)({
                    query: (null == g ? void 0 : g.displayName) || "",
                    isOpen: !1
                });
                (0, l.useEffect)(() => {
                    b(e => ({ ...e,
                        query: (null == g ? void 0 : g.displayName) || ""
                    }))
                }, [null == g ? void 0 : g.displayName]);
                let v = (0, l.useRef)(null),
                    [w] = (0, r.d7)(y.query, 300),
                    {
                        data: N,
                        isLoading: j
                    } = function(e) {
                        return (0, d.I)({
                            queryKey: ["hotelDestinations", e],
                            queryFn: async () => !e || e.length < 2 ? [] : (await c.A.get("/api/search/hotel-destinations", {
                                params: {
                                    query: e
                                }
                            })).data.data,
                            enabled: !!e && e.length >= 2,
                            staleTime: 864e5,
                            gcTime: 864e5
                        })
                    }(w),
                    C = (0, l.useMemo)(() => N && Array.isArray(N) ? N : [], [N]),
                    S = e => {
                        m(e), b(t => ({ ...t,
                            isOpen: !1,
                            query: e.displayName
                        }))
                    };
                return (0, n.jsxs)("div", {
                    className: (0, i.cn)("flex-1 px-3 py-1.5", "bordered-mobile" === f && "px-4 border-white/10 flex items-center rounded-lg border-solid border", t),
                    children: [!a && (0, n.jsx)("div", {
                        className: "text-[10px] uppercase text-white/40 mb-0.5",
                        children: h
                    }), (0, n.jsxs)("div", {
                        className: (0, i.cn)("relative flex items-center gap-2", "bordered-mobile" === f && "w-full"),
                        children: [!a && (0, n.jsx)(s.Ial, {
                            className: "w-4 h-4 text-white/40"
                        }), (0, n.jsx)("input", {
                            ref: v,
                            className: (0, i.cn)("w-full bg-transparent ".concat(a ? "text-sm" : "text-xs", " focus:outline-none placeholder:text-white/40 text-white"), "bordered-mobile" === f && "py-2.5 text-sm"),
                            placeholder: x,
                            value: y.query,
                            onChange: e => b({
                                query: e.target.value,
                                isOpen: !0
                            }),
                            onFocus: e => {
                                p(), b(e => ({ ...e,
                                    isOpen: !0
                                })), e.target.select()
                            }
                        }), (0, n.jsx)(o.A, {
                            isOpen: y.isOpen,
                            onClose: () => b(e => ({ ...e,
                                isOpen: !1
                            })),
                            className: "absolute top-full left-0 mt-1 bg-[#101010] border border-white/10 rounded-lg shadow-xl z-50 w-[calc(100vw-3.5rem)] sm:w-auto sm:min-w-[400px] overflow-hidden -mx-4 sm:-mx-0",
                            children: (0, n.jsxs)("div", {
                                className: "max-h-60 overflow-y-auto p-2 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]",
                                children: [0 === C.length && (0, n.jsx)("button", {
                                    onClick: () => S({
                                        displayName: "Around your area",
                                        placeId: ""
                                    }),
                                    className: "w-full px-4 py-3 text-left hover:bg-white/5 transition-colors group border-b border-white/5 last:border-0",
                                    children: (0, n.jsx)("div", {
                                        className: "flex items-center justify-between gap-4 w-full",
                                        children: (0, n.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, n.jsxs)("div", {
                                                className: "text-sm text-white/90 truncate flex items-center gap-2",
                                                children: [(0, n.jsx)(u.A, {
                                                    className: "w-4 h-4 text-white/40"
                                                }), " Around your area"]
                                            }), (0, n.jsx)("div", {
                                                className: "text-xs text-white/50 mt-1 truncate"
                                            })]
                                        })
                                    })
                                }), j && (0, n.jsx)("div", {
                                    className: "text-center text-white/50 py-2 text-sm",
                                    children: "Searching hotels..."
                                }), !j && C.map(e => (0, n.jsx)("button", {
                                    onClick: () => S(e),
                                    className: "w-full px-4 py-3 text-left hover:bg-white/5 transition-colors group border-b border-white/5 last:border-0",
                                    children: (0, n.jsx)("div", {
                                        className: "flex items-center justify-between gap-4 w-full",
                                        children: (0, n.jsxs)("div", {
                                            className: "flex-1 min-w-0",
                                            children: [(0, n.jsx)("div", {
                                                className: "text-sm text-white/90 truncate",
                                                children: e.displayName
                                            }), (0, n.jsx)("div", {
                                                className: "text-xs text-white/50 mt-1 truncate",
                                                children: e.formattedAddress
                                            })]
                                        })
                                    })
                                }, e.placeId)), !j && 0 === C.length && (0, n.jsx)("div", {
                                    className: "text-center text-white/50 py-2 text-sm",
                                    children: "" === y.query.trim() || "around your area" === y.query.trim().toLowerCase() ? "Enter a destination" : "No hotels found"
                                })]
                            })
                        })]
                    })]
                })
            });
            h.displayName = "HotelLocationInput";
            let g = h
        },
        11607: (e, t, a) => {
            a.d(t, {
                y: () => n
            });
            let n = a(75329).A.NEXT_PUBLIC_ENABLE_BANNER
        },
        15218: (e, t, a) => {
            a.d(t, {
                lZ: () => o
            });
            var n = a(95155),
                l = a(52619),
                s = a.n(l),
                r = a(12115),
                i = a(56041);
            let o = e => {
                let {
                    message: t,
                    linkText: a,
                    linkUrl: l,
                    onHeightChange: o,
                    trailingMessage: d
                } = e, c = (0, r.useRef)(null);
                return (0, r.useEffect)(() => {
                    let e = () => {
                        if (c.current) {
                            let e = c.current.offsetHeight;
                            document.documentElement.style.setProperty(i.J2, "".concat(e, "px")), null == o || o(e)
                        }
                    };
                    return e(), window.addEventListener("resize", e), () => window.removeEventListener("resize", e)
                }, [t, a, o]), (0, n.jsx)("div", {
                    ref: c,
                    className: "banner__container w-full flex items-center justify-center bg-[#292929] min-h-14 py-2 text-xs sm:text-sm text-[#ffffffcc] fixed top-0 left-0 right-0 z-[1000] px-1 sm:px-4",
                    "data-sentry-component": "Banner",
                    "data-sentry-source-file": "Banner.tsx",
                    children: (0, n.jsxs)("p", {
                        className: "text-center max-w-screen-lg",
                        children: [t, a && l && (0, n.jsx)("span", {
                            className: "inline-flex items-center",
                            children: (0, n.jsx)(s(), {
                                href: l,
                                className: "underline mr-1",
                                rel: "noopener noreferrer",
                                children: a
                            })
                        }), d && (0, n.jsx)("span", {
                            className: "inline-flex items-center",
                            children: d
                        })]
                    })
                })
            }
        },
        17772: (e, t, a) => {
            a.d(t, {
                A: () => u
            });
            var n = a(95155),
                l = a(12115),
                s = a(31475),
                r = a(67548),
                i = a(64269),
                o = a(6943),
                d = a(13630),
                c = a(51849);
            let u = e => {
                let {
                    value: t,
                    onChange: a,
                    isMinimized: u = !1,
                    size: h = "small"
                } = e, [g, m] = (0, l.useState)(!1), [p, x] = (0, l.useState)(t.length > 0 ? t : [{
                    adults: 2,
                    children: 0,
                    childrenAges: []
                }]), [f, y] = (0, l.useState)({});
                (0, l.useEffect)(() => {
                    t.length > 0 && (x(t), y(t.reduce((e, t, a) => (e["".concat(a)] = t.childrenAges, e), {})))
                }, [t]);
                let b = (e, t, a) => {
                        let n = [...p],
                            l = n[e][t];
                        if ("adults" === t) n[e][t] = Math.min(Math.max(l + a, 1), 6);
                        else {
                            let s = Math.min(Math.max(l + a, 0), 4);
                            n[e][t] = s;
                            let r = "".concat(e),
                                i = f[r] || [],
                                o = Array(s).fill(0).map((e, t) => i[t] || 0);
                            y(e => ({ ...e,
                                [r]: o
                            }))
                        }
                        x(n)
                    },
                    v = p.reduce((e, t) => e + t.adults + t.children, 0);
                return (0, n.jsxs)(s.AM, {
                    open: g,
                    onOpenChange: m,
                    "data-sentry-element": "Popover",
                    "data-sentry-component": "HotelGuests",
                    "data-sentry-source-file": "HotelGuests.tsx",
                    children: [(0, n.jsx)(s.Wv, {
                        asChild: !0,
                        "data-sentry-element": "PopoverTrigger",
                        "data-sentry-source-file": "HotelGuests.tsx",
                        children: (0, n.jsxs)("button", {
                            className: (0, i.cn)("flex-1 px-3 py-1.5 h-full flex items-center gap-2 hover:bg-white/5 transition-colors", g && "bg-white/5 rounded-lg"),
                            children: [!u && (0, n.jsx)(o.A, {
                                className: "w-4 h-4 text-white/40"
                            }), (0, n.jsxs)("div", {
                                className: "text-left",
                                children: [!u && (0, n.jsx)("div", {
                                    className: (0, i.cn)("text-[10px] uppercase text-white/40", "large" === h && "text-xs"),
                                    children: "Guests"
                                }), (0, n.jsxs)("div", {
                                    className: (0, i.cn)("text-xs text-white/90", "large" === h && "text-sm"),
                                    children: [p.length, " Room", p.length > 1 ? "s" : "", " • ", v, " Guests"]
                                })]
                            })]
                        })
                    }), (0, n.jsx)(s.hl, {
                        align: "start",
                        className: "w-64 bg-[#101010] border border-white/10 rounded-lg shadow-xl p-0 overflow-hidden",
                        "data-sentry-element": "PopoverContent",
                        "data-sentry-source-file": "HotelGuests.tsx",
                        children: (0, n.jsxs)("div", {
                            className: "max-h-[300px] md:max-h-[400px] flex flex-col relative",
                            children: [(0, n.jsx)("div", {
                                className: "overflow-y-auto p-4 space-y-6 relative  [&::-webkit-scrollbar]:w-2 [&::-webkit-scrollbar-track]:bg-transparent [&::-webkit-scrollbar-thumb]:bg-white/20 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-track]:rounded-full",
                                children: p.map((e, t) => (0, n.jsxs)("div", {
                                    className: "space-y-4",
                                    children: [(0, n.jsxs)("div", {
                                        className: "flex justify-between items-center",
                                        children: [(0, n.jsxs)("div", {
                                            className: "text-sm text-white/90",
                                            children: ["Room ", t + 1]
                                        }), p.length > 1 && (0, n.jsx)(r.A, {
                                            variant: "ghost",
                                            onClick: () => {
                                                x(p.filter((e, a) => a !== t))
                                            },
                                            className: "text-red-400/80 hover:text-red-400 hover:bg-red-400/10 px-2 py-1 text-xs gap-1",
                                            children: (0, n.jsxs)("span", {
                                                className: "flex items-center gap-1",
                                                children: [(0, n.jsx)(d.A, {
                                                    className: "w-3.5 h-3.5"
                                                }), " Remove"]
                                            })
                                        })]
                                    }), (0, n.jsxs)("div", {
                                        className: "flex justify-between items-center",
                                        children: [(0, n.jsx)("div", {
                                            className: "text-sm text-white/90",
                                            children: "Adults"
                                        }), (0, n.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, n.jsx)(r.A, {
                                                variant: "ghost",
                                                onClick: () => b(t, "adults", -1),
                                                className: "text-white/90 hover:bg-white/5",
                                                children: "-"
                                            }), (0, n.jsx)("span", {
                                                className: "text-sm text-white/90",
                                                children: e.adults
                                            }), (0, n.jsx)(r.A, {
                                                variant: "ghost",
                                                onClick: () => b(t, "adults", 1),
                                                className: "text-white/90 hover:bg-white/5",
                                                children: "+"
                                            })]
                                        })]
                                    }), (0, n.jsxs)("div", {
                                        className: "flex justify-between items-center",
                                        children: [(0, n.jsxs)("div", {
                                            className: "flex flex-col",
                                            children: [(0, n.jsx)("div", {
                                                className: "text-sm text-white/90",
                                                children: "Children"
                                            }), (0, n.jsx)("div", {
                                                className: "text-xs text-white/40",
                                                children: "Ages 0 to 17"
                                            })]
                                        }), (0, n.jsxs)("div", {
                                            className: "flex items-center gap-2",
                                            children: [(0, n.jsx)(r.A, {
                                                variant: "ghost",
                                                onClick: () => b(t, "children", -1),
                                                className: "text-white/90 hover:bg-white/5",
                                                children: "-"
                                            }), (0, n.jsx)("span", {
                                                className: "text-sm text-white/90",
                                                children: e.children
                                            }), (0, n.jsx)(r.A, {
                                                variant: "ghost",
                                                onClick: () => b(t, "children", 1),
                                                className: "text-white/90 hover:bg-white/5",
                                                children: "+"
                                            })]
                                        })]
                                    }), e.children > 0 && (0, n.jsx)("div", {
                                        className: "space-y-2",
                                        children: Array.from({
                                            length: e.children
                                        }).map((e, a) => {
                                            var l;
                                            return (0, n.jsxs)("div", {
                                                className: "flex items-center justify-between",
                                                children: [(0, n.jsxs)("div", {
                                                    className: "text-xs text-white/70",
                                                    children: ["Child ", a + 1]
                                                }), (0, n.jsx)("select", {
                                                    value: (null == (l = f["".concat(t)]) ? void 0 : l[a]) || 0,
                                                    onChange: e => {
                                                        let n = [...f["".concat(t)] || []];
                                                        n[a] = Number(e.target.value), y(e => ({ ...e,
                                                            ["".concat(t)]: n
                                                        }))
                                                    },
                                                    className: "bg-white/5 text-white/90 text-xs px-2 py-1 rounded",
                                                    children: Array.from({
                                                        length: 18
                                                    }).map((e, t) => (0, n.jsx)("option", {
                                                        value: -1 === t ? "" : t,
                                                        className: "bg-[#101010]",
                                                        children: -1 === t ? "Select age" : 0 === t ? "Under 1" : "".concat(t)
                                                    }, t))
                                                })]
                                            }, a)
                                        })
                                    }), t < p.length - 1 && (0, n.jsx)("div", {
                                        className: "border-t border-white/10"
                                    })]
                                }, t))
                            }), (0, n.jsx)("div", {
                                className: "sticky bottom-0 bg-[#101010] border-t border-white/10 p-4 z-10",
                                children: (0, n.jsxs)("div", {
                                    className: "flex gap-2",
                                    children: [(0, n.jsx)(r.A, {
                                        variant: "ghost",
                                        onClick: () => {
                                            p.length < 5 && x([...p, {
                                                adults: 2,
                                                children: 0,
                                                childrenAges: []
                                            }])
                                        },
                                        className: "flex-1 text-xs py-1.5 hover:bg-white/10",
                                        disabled: p.length >= 5,
                                        "data-sentry-element": "Button",
                                        "data-sentry-source-file": "HotelGuests.tsx",
                                        children: "Add Room"
                                    }), (0, n.jsx)(c.A, {
                                        onClick: () => {
                                            a(p.map((e, t) => ({ ...e,
                                                childrenAges: f["".concat(t)] || []
                                            }))), m(!1)
                                        },
                                        className: "flex-1 text-xs py-1.5 bg-white/10 hover:bg-white/20",
                                        "data-sentry-element": "ButtonCapsule",
                                        "data-sentry-source-file": "HotelGuests.tsx",
                                        children: "Apply"
                                    })]
                                })
                            })]
                        })
                    })]
                })
            }
        },
        24034: (e, t, a) => {
            a.d(t, {
                KI: () => p,
                bS: () => l,
                tE: () => s
            });
            var n = a(15653);
            let l = ["economy", "premium_economy", "business_first"],
                s = n.z.enum(l),
                r = n.z.enum(["flights", "hotels", "shopping"]);
            n.z.enum(["oneWay", "roundTrip"]);
            let i = n.z.enum(["miles", "cash"]),
                o = n.z.enum(["airport", "region", "city"]),
                d = n.z.object({
                    code: n.z.string(),
                    name: n.z.string(),
                    type: o,
                    city: n.z.string().optional(),
                    svgPath: n.z.string().optional()
                }),
                c = n.z.object({
                    startDate: n.z.date().nullable(),
                    endDate: n.z.date().nullable()
                }),
                u = n.z.object({
                    adults: n.z.number().min(1),
                    children: n.z.number().min(0),
                    infants: n.z.number().min(0)
                }),
                h = n.z.object({
                    cancellation: n.z.enum(["all", "free"]).optional(),
                    meals: n.z.enum(["RO", "HB", "FB", "AI", "BI"]).optional(),
                    sorting: n.z.string().optional(),
                    priceRange: n.z.object({
                        start: n.z.number().min(0),
                        end: n.z.number().min(0),
                        currency: n.z.enum(["miles", "cash"])
                    }).refine(e => e.end > e.start, {
                        message: "Maximum price must be greater than minimum price"
                    }).nullish()
                }),
                g = n.z.object({
                    hotelName: n.z.string().optional(),
                    facilities: n.z.array(n.z.string()).optional(),
                    guestRating: n.z.number().optional(),
                    propertyRating: n.z.array(n.z.string()).optional(),
                    types: n.z.array(n.z.string()).optional(),
                    sorting: n.z.string().optional()
                }).merge(h),
                m = n.z.object({
                    placeId: n.z.string(),
                    displayName: n.z.string(),
                    checkIn: n.z.date().nullable(),
                    checkOut: n.z.date().nullable(),
                    location: n.z.object({
                        latitude: n.z.number(),
                        longitude: n.z.number()
                    }).optional(),
                    rooms: n.z.array(n.z.object({
                        adults: n.z.number(),
                        children: n.z.number(),
                        childrenAges: n.z.array(n.z.number())
                    })),
                    guestNationality: n.z.string().length(2).optional(),
                    currency: n.z.string().length(3).optional(),
                    formattedAddress: n.z.string().optional(),
                    filters: g.optional()
                }),
                p = n.z.object({
                    tab: r,
                    origin: d.nullable(),
                    destination: d.nullable(),
                    dates: c,
                    returnDate: n.z.date().nullish(),
                    passengers: u,
                    cabin: s.optional(),
                    paymentType: i,
                    departingFlightId: n.z.string().nullish(),
                    returningFlightId: n.z.string().nullish(),
                    hotelDestination: m.nullish()
                })
        },
        24509: (e, t, a) => {
            a.d(t, {
                A: () => o
            });
            var n = a(95155),
                l = a(12115),
                s = a(71408),
                r = a(6410),
                i = a(64269);
            let o = e => {
                let {
                    isOpen: t,
                    onClose: a,
                    children: o,
                    className: d = "",
                    position: c = "bottom"
                } = e, u = (0, l.useRef)(null);
                return (0, l.useEffect)(() => {
                    let e = e => {
                            u.current && !u.current.contains(e.target) && a()
                        },
                        n = e => {
                            "Escape" === e.key && a()
                        };
                    return t && (document.addEventListener("mousedown", e), document.addEventListener("keydown", n)), () => {
                        document.removeEventListener("mousedown", e), document.removeEventListener("keydown", n)
                    }
                }, [t, a]), (0, n.jsx)(s.N, {
                    "data-sentry-element": "AnimatePresence",
                    "data-sentry-component": "OverlayContainer",
                    "data-sentry-source-file": "OverlayContainer.tsx",
                    children: t && (0, n.jsx)(r.P.div, {
                        ref: u,
                        initial: {
                            opacity: 0,
                            scale: .95
                        },
                        animate: {
                            opacity: 1,
                            scale: 1
                        },
                        exit: {
                            opacity: 0,
                            scale: .95
                        },
                        transition: {
                            duration: .2
                        },
                        className: (0, i.cn)("top" === c ? "bottom-full" : "top-full", d),
                        children: o
                    })
                })
            }
        },
        25950: (e, t, a) => {
            a.d(t, {
                F7: () => c,
                Ri: () => o,
                jT: () => d
            });
            var n = a(95155),
                l = a(8155),
                s = a(20063),
                r = a(12115);
            let i = (0, r.createContext)(void 0),
                o = [{
                    id: "flights",
                    label: "FLIGHTS",
                    paths: {
                        exact: ["/explore", "/flights"],
                        startsWith: ["/search/flights"]
                    },
                    trackingEvent: l.b.FLIGHT_MENU_CLICK,
                    navigationTo: "/explore"
                }, {
                    id: "hotels",
                    label: "HOTELS",
                    paths: {
                        exact: ["/explore/hotels"],
                        startsWith: ["/search/hotels"]
                    },
                    trackingEvent: l.b.HOTELS_MENU_CLICK,
                    navigationTo: "/explore/hotels"
                }, {
                    id: "shopping",
                    label: "SHOPPING",
                    paths: {
                        exact: [],
                        startsWith: ["/shopping"]
                    },
                    trackingEvent: l.b.FLIGHT_MENU_CLICK,
                    navigationTo: "/shopping"
                }],
                d = e => {
                    let {
                        children: t
                    } = e, a = (0, s.usePathname)(), l = (0, r.useMemo)(() => {
                        for (let e of o)
                            if (e.paths.exact.includes(a) || e.paths.startsWith.some(e => a.startsWith(e))) return e.id;
                        return "flights"
                    }, [a]);
                    return (0, n.jsx)(i.Provider, {
                        value: {
                            activeTab: l
                        },
                        "data-sentry-element": "unknown",
                        "data-sentry-component": "TabSearchProvider",
                        "data-sentry-source-file": "TabSearchContext.tsx",
                        children: t
                    })
                },
                c = () => {
                    let e = (0, r.useContext)(i);
                    if (!e) throw Error("useTabSearch must be used within a TabSearchProvider");
                    return e
                }
        },
        31475: (e, t, a) => {
            a.d(t, {
                AM: () => d,
                Wv: () => c,
                hl: () => u
            });
            var n = a(95155),
                l = a(12115),
                s = a(505),
                r = a(71408),
                i = a(6410),
                o = a(64269);
            let d = s.bL,
                c = s.l9;
            s.Mz;
            let u = l.forwardRef((e, t) => {
                let {
                    className: a,
                    align: l = "center",
                    sideOffset: d = 4,
                    ...c
                } = e;
                return (0, n.jsx)(s.ZL, {
                    children: (0, n.jsx)(r.N, {
                        children: (0, n.jsx)(s.UC, {
                            ref: t,
                            align: l,
                            sideOffset: d,
                            asChild: !0,
                            ...c,
                            children: (0, n.jsx)(i.P.div, {
                                initial: {
                                    opacity: 0,
                                    scale: .95
                                },
                                animate: {
                                    opacity: 1,
                                    scale: 1
                                },
                                exit: {
                                    opacity: 0,
                                    scale: .95
                                },
                                transition: {
                                    duration: .2,
                                    ease: "easeOut"
                                },
                                className: (0, o.cn)("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none", a),
                                children: c.children
                            })
                        })
                    })
                })
            });
            u.displayName = s.UC.displayName
        },
        34217: (e, t, a) => {
            a.d(t, {
                q: () => n
            });
            let n = {
                classes: {
                    signIn: "sign-in",
                    hotelSearchButton: "hotel-search-button",
                    flightSearchButton: "flight-search-button"
                },
                "data-sentry": {
                    hotelSearchCard: "HotelSearchCard",
                    flightDealCard: "FlightDealCard",
                    earnShoppingCard: "EarnShoppingCard"
                }
            }
        },
        35918: (e, t, a) => {
            a.d(t, {
                SF: () => i,
                z4: () => r
            });
            var n = a(15653),
                l = a(37171);
            let s = n.z.object({
                adults: n.z.number().int().min(1).max(6),
                children: n.z.number().int().min(0).max(4).default(0),
                childrenAges: n.z.array(n.z.number().int().min(0).max(17)).default([])
            });
            n.z.object({
                checkin: n.z.string().regex(l.s7),
                checkout: n.z.string().regex(l.s7),
                rooms: n.z.array(s).default([{
                    adults: 2,
                    children: 0,
                    childrenAges: []
                }]),
                currency: n.z.string().length(3).default("USD"),
                nationality: n.z.string().length(2).default("US")
            });
            let r = e => encodeURIComponent(JSON.stringify(e)),
                i = e => encodeURIComponent("".concat(e.latitude, ",").concat(e.longitude))
        },
        37138: (e, t, a) => {
            a.d(t, {
                A: () => T
            });
            var n = a(95155),
                l = a(12115),
                s = a(28127),
                r = a(64269),
                i = a(93366),
                o = a(78674),
                d = a(88901),
                c = a(75513),
                u = a(87205),
                h = a(59281),
                g = a(58576),
                m = a(14187),
                p = a(39557),
                x = a(30661),
                f = a(99228),
                y = a(72473),
                b = a(51190),
                v = a(63263),
                w = a(15653);
            let N = w.z.object({
                startDate: w.z.date().nullable(),
                endDate: w.z.date().nullable()
            });
            w.z.object({
                selected: w.z.date().nullish(),
                onChange: w.z.function().args(w.z.date()),
                isReturnDate: w.z.boolean().optional(),
                isRangeStart: w.z.boolean().optional(),
                dateRange: N.optional(),
                updateField: w.z.function().args(w.z.literal("dates"), N).optional()
            });
            let j = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
                C = (0, l.memo)(e => {
                    let {
                        selected: t,
                        onChange: a,
                        isReturnDate: s,
                        isRangeStart: r,
                        dateRange: w,
                        updateField: N
                    } = e, C = (0, i.o)(new Date), [S, D] = (0, l.useState)(t || (null == w ? void 0 : w.startDate) || C), A = (0, l.useRef)(0), T = (0, o.w)(S), E = (0, d.p)(S), F = (0, d.p)((0, c.P)(C, 12)), z = (0, u.k)({
                        start: T,
                        end: E
                    }), I = (0, h.P)(T), k = e => !!((0, g.Y)(e, C) || (0, m.d)(e, F)) || !!s && null != w && !!w.startDate && (0, g.Y)(e, w.startDate), M = e => {
                        if (!e) return !1;
                        let a = (0, i.o)(e);
                        return r ? (null == w ? void 0 : w.startDate) && !w.endDate ? (0, p.n)(a, (0, i.o)(w.startDate)) : null != w && !!w.startDate && null != w && !!w.endDate && (0, x.v)(a, {
                            start: (0, i.o)(w.startDate),
                            end: (0, i.o)(w.endDate)
                        }) : t && (0, p.n)(a, (0, i.o)(t))
                    }, P = e => {
                        if (!r || !(null == w ? void 0 : w.startDate) || !(null == w ? void 0 : w.endDate)) return !1;
                        let t = (0, i.o)(e);
                        return (0, p.n)(t, (0, i.o)(w.startDate)) || (0, p.n)(t, (0, i.o)(w.endDate))
                    }, O = (0, l.useCallback)(() => {
                        D(e => {
                            let t = (0, c.P)(e, 1);
                            return (0, g.Y)(t, F) ? t : e
                        })
                    }, [F]), L = (0, l.useCallback)(() => {
                        D(e => {
                            let t = (0, f.a)(e, 1);
                            return (0, g.Y)((0, d.p)(t), C) ? e : t
                        })
                    }, [C]), R = (0, l.useCallback)(e => {
                        let t = (0, i.o)(e);
                        if (!r) return void a(t);
                        if (!(null == w ? void 0 : w.startDate) || w.endDate) {
                            null == N || N("dates", {
                                startDate: t,
                                endDate: null
                            });
                            return
                        }
                        let n = w.startDate;
                        null == N || N("dates", {
                            startDate: (0, m.d)(t, n) ? n : t,
                            endDate: (0, m.d)(t, n) ? t : n
                        })
                    }, [r, a, w, N]), _ = e => {
                        if (!r || !(null == w ? void 0 : w.startDate) || !(null == w ? void 0 : w.endDate)) return !1;
                        let t = (0, i.o)(e),
                            a = (0, i.o)(w.startDate),
                            n = (0, i.o)(w.endDate);
                        return (0, x.v)(t, {
                            start: a,
                            end: n
                        }) && !(0, p.n)(t, a) && !(0, p.n)(t, n)
                    }, B = (0, l.useCallback)(e => {
                        let t = Date.now();
                        t - A.current > 250 && (A.current = t, e())
                    }, []);
                    return (0, n.jsxs)("div", {
                        className: "p-4 w-[280px]",
                        "data-sentry-component": "DatePicker",
                        "data-sentry-source-file": "DatePicker.tsx",
                        children: [(0, n.jsxs)("div", {
                            className: "flex items-center justify-between mb-4",
                            children: [(0, n.jsx)("button", {
                                onClick: () => B(L),
                                className: "p-1 hover:bg-white/5 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                                disabled: (0, g.Y)((0, d.p)((0, f.a)(S, 1)), C),
                                "aria-label": "Previous month",
                                children: (0, n.jsx)(b.A, {
                                    className: "h-4 w-4 text-white/70",
                                    "data-sentry-element": "ChevronLeft",
                                    "data-sentry-source-file": "DatePicker.tsx"
                                })
                            }), (0, n.jsx)("div", {
                                className: "flex flex-col items-center",
                                children: (0, n.jsx)("div", {
                                    className: "text-sm font-medium text-white",
                                    children: (0, y.GP)(S, "MMMM yyyy")
                                })
                            }), (0, n.jsx)("button", {
                                onClick: () => B(O),
                                className: "p-1 hover:bg-white/5 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed",
                                disabled: !(0, g.Y)((0, o.w)((0, c.P)(S, 1)), F),
                                "aria-label": "Next month",
                                children: (0, n.jsx)(v.A, {
                                    className: "h-4 w-4 text-white/70",
                                    "data-sentry-element": "ChevronRight",
                                    "data-sentry-source-file": "DatePicker.tsx"
                                })
                            })]
                        }), (0, n.jsx)("div", {
                            className: "grid grid-cols-7 mb-2",
                            children: j.map(e => (0, n.jsx)("div", {
                                className: "text-center text-[10px] font-medium text-white/50 uppercase",
                                children: e
                            }, e))
                        }), (0, n.jsxs)("div", {
                            className: "grid grid-cols-7 gap-1",
                            children: [Array.from({
                                length: I
                            }).map((e, t) => (0, n.jsx)("div", {}, "empty-".concat(t))), z.map((e, t) => (0, n.jsx)("button", {
                                onClick: () => B(() => R(e)),
                                disabled: k(e),
                                className: "\n              h-8 w-8 text-xs rounded-full flex items-center justify-center transition-colors\n              ".concat(k(e) ? "text-white/20 cursor-not-allowed" : "text-white/70 hover:bg-white/10", "\n              ").concat(M(e) ? "bg-white/20 text-white hover:bg-white/20" : "", "\n              ").concat(P(e) ? "bg-white/30 text-white" : "", "\n              ").concat(_(e) ? "bg-white/10 text-white" : "", "\n              ").concat((0, p.n)(e, C) ? "font-bold text-white" : "", "\n            "),
                                "aria-label": (0, y.GP)(e, "MMMM d, yyyy"),
                                children: (0, y.GP)(e, "d")
                            }, t))]
                        })]
                    })
                });
            var S = a(31475),
                D = a(56317),
                A = a(49474);
            let T = (0, l.memo)(e => {
                let {
                    ref: t,
                    label: a,
                    size: i = "small",
                    value: o,
                    onChange: d,
                    onFocus: c,
                    placeholder: u,
                    isReturnDate: h = !1,
                    dateRange: g,
                    isRangeMode: m = !1,
                    updateField: p,
                    isMinimized: x = !1,
                    isExpanded: f = !1
                } = e, [y, b] = (0, l.useState)(!1), {
                    windowSize: v,
                    isMobile: w
                } = (0, A.l)(), N = (0, l.useCallback)(() => {
                    b(!1)
                }, []), j = 480 >= (v.height || 0) ? "top" : "bottom";
                return (0, n.jsxs)("div", {
                    className: "px-3 py-1.5",
                    "data-sentry-component": "DateInput",
                    "data-sentry-source-file": "index.tsx",
                    children: [(!x || f) && (0, n.jsx)("div", {
                        className: (0, r.cn)("text-[10px] uppercase text-white/40 leading-none mb-0.5", "small" === i ? "text-[10px]" : "text-xs"),
                        children: m ? "Date Range" : a
                    }), (0, n.jsxs)("div", {
                        className: "relative flex items-center gap-2",
                        children: [(!x || f) && (0, n.jsx)(s.A, {
                            className: "w-3.5 h-3.5 text-white/40"
                        }), (0, n.jsxs)(S.AM, {
                            open: y,
                            onOpenChange: b,
                            "data-sentry-element": "Popover",
                            "data-sentry-source-file": "index.tsx",
                            children: [(0, n.jsx)(S.Wv, {
                                "data-sentry-element": "PopoverTrigger",
                                "data-sentry-source-file": "index.tsx",
                                children: (0, n.jsx)("input", {
                                    className: (0, r.cn)("bg-transparent focus:outline-none", !x || f ? "text-xs" : "text-sm text-center w-24", o ? "text-white" : "text-white/70 placeholder-white/40", "large" === i ? "text-sm" : ""),
                                    ref: t,
                                    placeholder: m ? "Select dates" : u,
                                    value: o ? m ? (null == g ? void 0 : g.endDate) ? "".concat((0, D.Yq)(o), " - ").concat((0, D.Yq)(g.endDate)) : (0, D.Yq)(o) : (0, D.wN)(o) : "",
                                    readOnly: !0,
                                    onClick: () => {
                                        c()
                                    }
                                })
                            }), (0, n.jsx)(S.hl, {
                                className: "bg-[#101010] backdrop-blur-xl border border-[#636363]/60 rounded-lg shadow-lg relative p-0 w-[280px]",
                                side: w ? j : void 0,
                                align: "start",
                                avoidCollisions: !1,
                                sideOffset: -8,
                                "data-sentry-element": "PopoverContent",
                                "data-sentry-source-file": "index.tsx",
                                children: (0, n.jsx)(C, {
                                    selected: o,
                                    onChange: e => {
                                        d(e), m || N()
                                    },
                                    isReturnDate: h,
                                    dateRange: g,
                                    isRangeStart: m,
                                    updateField: p,
                                    "data-sentry-element": "DatePicker",
                                    "data-sentry-source-file": "index.tsx"
                                })
                            })]
                        })]
                    })]
                })
            })
        },
        37171: (e, t, a) => {
            a.d(t, {
                Fw: () => g,
                L$: () => p,
                Q6: () => u,
                X3: () => o,
                XT: () => i,
                YE: () => d,
                f7: () => m,
                j2: () => c,
                s7: () => h
            });
            var n = a(72473),
                l = a(26467),
                s = a(86835),
                r = a(15653);
            let i = () => {
                    let e = new Date,
                        t = new Date(e.getFullYear(), e.getMonth() + 5, 1),
                        a = new Date(t.getFullYear(), t.getMonth() + 1, 0);
                    return {
                        startDate: t,
                        endDate: a
                    }
                },
                o = e => e ? new Date(e + "T00:00:00Z").toLocaleDateString("en-US", {
                    month: "short",
                    day: "numeric",
                    timeZone: "UTC"
                }) : "",
                d = e => (0, n.GP)(e, "MMMM d, yyyy"),
                c = e => (0, n.GP)(e, "yyyy-MM-dd"),
                u = e => (0, n.GP)(e, "MM-dd-yyyy"),
                h = /^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/,
                g = e => {
                    let [t, a, n] = e.split("-").map(Number);
                    return new Date(t, a - 1, n)
                },
                m = e => {
                    let [t, a] = e.split("T"), n = a.split(":")[0];
                    return "".concat(t, " ").concat(n, ":00")
                },
                p = r.z.string().transform(e => {
                    let t = (0, l.H)(e);
                    if (!(0, s.f)(t)) throw Error("Invalid UTC date string");
                    return t.toISOString()
                })
        },
        42953: (e, t, a) => {
            a.d(t, {
                A: () => r
            });
            var n = a(49474),
                l = a(20063),
                s = a(12115);
            let r = () => {
                let [e, t] = (0, s.useState)(!1), {
                    isMobile: a
                } = (0, n.l)(), r = (0, l.usePathname)();
                return (0, s.useEffect)(() => {
                    let e = () => {
                        if (a || "/shopping" === r) return;
                        let e = window.scrollY,
                            n = .85 * window.innerHeight,
                            l = .95 * window.innerHeight;
                        e > n && e < l || t(e > .9 * window.innerHeight)
                    };
                    return window.addEventListener("scroll", e), e(), () => window.removeEventListener("scroll", e)
                }, [a, r]), e
            }
        },
        45718: (e, t, a) => {
            a.d(t, {
                C2: () => s,
                NY: () => l,
                pP: () => n
            });
            let n = 75,
                l = 250,
                s = 25
        },
        46431: (e, t, a) => {
            a.d(t, {
                b: () => i
            });
            var n = a(95155),
                l = a(88661),
                s = a.n(l),
                r = a(64269);
            a(12115);
            let i = e => {
                let {
                    isVisible: t,
                    className: a
                } = e;
                return t ? (0, n.jsxs)("div", {
                    "data-sentry-component": "LoadingProgressBar",
                    "data-sentry-source-file": "LoadingProgressBar.tsx",
                    className: "jsx-396c9faf22048943 " + ((0, r.cn)("relative w-full h-[2px] bg-white/5 overflow-hidden", a) || ""),
                    children: [(0, n.jsx)(s(), {
                        id: "396c9faf22048943",
                        children: "@-webkit-keyframes progressBar{0%{-webkit-transform:translatex(-100%);transform:translatex(-100%)}100%{-webkit-transform:translatex(200%);transform:translatex(200%)}}@-moz-keyframes progressBar{0%{-moz-transform:translatex(-100%);transform:translatex(-100%)}100%{-moz-transform:translatex(200%);transform:translatex(200%)}}@-o-keyframes progressBar{0%{-o-transform:translatex(-100%);transform:translatex(-100%)}100%{-o-transform:translatex(200%);transform:translatex(200%)}}@keyframes progressBar{0%{-webkit-transform:translatex(-100%);-moz-transform:translatex(-100%);-o-transform:translatex(-100%);transform:translatex(-100%)}100%{-webkit-transform:translatex(200%);-moz-transform:translatex(200%);-o-transform:translatex(200%);transform:translatex(200%)}}.progress-bar.jsx-396c9faf22048943{-webkit-animation:progressBar.6s linear infinite;-moz-animation:progressBar.6s linear infinite;-o-animation:progressBar.6s linear infinite;animation:progressBar.6s linear infinite;background:-webkit-linear-gradient(left,transparent 0%,rgba(255,255,255,.3)20%,rgba(255,255,255,.5)50%,rgba(255,255,255,.3)80%,transparent 100%);background:-moz-linear-gradient(left,transparent 0%,rgba(255,255,255,.3)20%,rgba(255,255,255,.5)50%,rgba(255,255,255,.3)80%,transparent 100%);background:-o-linear-gradient(left,transparent 0%,rgba(255,255,255,.3)20%,rgba(255,255,255,.5)50%,rgba(255,255,255,.3)80%,transparent 100%);background:linear-gradient(90deg,transparent 0%,rgba(255,255,255,.3)20%,rgba(255,255,255,.5)50%,rgba(255,255,255,.3)80%,transparent 100%)}"
                    }), (0, n.jsx)("div", {
                        className: "jsx-396c9faf22048943 progress-bar absolute top-0 left-0 h-full w-2/3 opacity-90"
                    })]
                }) : null
            }
        },
        49474: (e, t, a) => {
            a.d(t, {
                WindowSizeProvider: () => i,
                l: () => o
            });
            var n = a(95155),
                l = a(12115);
            let s = (e, t) => {
                    let a, n, l = !1;
                    return function() {
                        for (var s = arguments.length, r = Array(s), i = 0; i < s; i++) r[i] = arguments[i];
                        l ? (clearTimeout(a), a = setTimeout(() => {
                            Date.now() - n >= t && (e.apply(this, r), n = Date.now())
                        }, t - (Date.now() - n))) : (e.apply(this, r), n = Date.now(), l = !0, setTimeout(() => {
                            l = !1
                        }, t))
                    }
                },
                r = (0, l.createContext)(void 0);

            function i(e) {
                let {
                    children: t
                } = e, [a, i] = (0, l.useState)({
                    width: void 0,
                    height: void 0
                }), o = !!(a.width && a.width < 640), d = !!(a.width && a.width < 768), c = (0, l.useCallback)(() => {
                    i({
                        width: window.innerWidth,
                        height: window.innerHeight
                    })
                }, []);
                return (0, l.useEffect)(() => {
                    let e = s(c, 100);
                    return window.addEventListener("resize", e, {
                        passive: !0
                    }), c(), () => window.removeEventListener("resize", e)
                }, [c]), (0, n.jsx)(r.Provider, {
                    value: {
                        windowSize: a,
                        isMobile: o,
                        isMedium: d
                    },
                    "data-sentry-element": "unknown",
                    "data-sentry-component": "WindowSizeProvider",
                    "data-sentry-source-file": "useWindowSize.tsx",
                    children: t
                })
            }

            function o() {
                let e = (0, l.useContext)(r);
                if (void 0 === e) throw Error("useWindowSize must be used within a WindowSizeProvider");
                return e
            }
        },
        51452: (e, t, a) => {
            a.d(t, {
                b2: () => r
            }), a(95155), a(15218), a(11607), a(56041);
            var n = a(20063),
                l = a(38728);
            let s = new Set(["/", "/about", "/explore", "/profile", "/shopping", "/transfer-miles"]),
                r = () => {
                    let e = (0, n.usePathname)(),
                        {
                            user: t,
                            isLoading: a
                        } = (0, l.A)();
                    return s.has(e) && !a && t
                }
        },
        51515: (e, t, a) => {
            a.d(t, {
                A: () => B
            });
            var n = a(95155),
                l = a(12115),
                s = a(20063),
                r = a(78718),
                i = a(64269),
                o = a(53483),
                d = a(26615),
                c = a(83871),
                u = a(1690),
                h = a(37138),
                g = a(51849),
                m = a(34217),
                p = a(76433),
                x = a(89568);
            let f = e => {
                let {
                    isExpanded: t,
                    initialValues: a,
                    onFocus: l,
                    onSearch: s,
                    isMinimized: r = !1,
                    showRegions: d = !1
                } = e, {
                    mode: f,
                    passengers: y,
                    setPassengers: b,
                    selectedCabin: v,
                    handleCabinChange: w,
                    handleLocationChange: N,
                    handleSearch: j,
                    handleDepartDateChange: C,
                    values: S,
                    effectiveMode: D,
                    isDestinationRegion: A,
                    updateField: T,
                    handleChangeMode: E,
                    handlePaymentTypeChange: F
                } = (0, p.A)({
                    initialValues: a,
                    onSearch: s
                });
                return (0, n.jsx)("div", {
                    className: (0, i.cn)("flex flex-col gap-4 pt-6 h-full justify-between"),
                    "data-sentry-component": "FlightSearchInputMobile",
                    "data-sentry-source-file": "FlightSearchInputMobile.tsx",
                    children: (0, n.jsxs)("div", {
                        className: "flex flex-col gap-4 px-7",
                        children: [(0, n.jsx)(c.A, {
                            size: "large",
                            mode: f,
                            handleChangeMode: E,
                            passengers: y,
                            onPassengersChange: b,
                            selectedCabin: v,
                            onCabinChange: e => {
                                w(e)
                            },
                            isExpanded: t,
                            "data-sentry-element": "TripOptionsBar",
                            "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                        }), (0, n.jsxs)("div", {
                            className: "flex flex-col gap-3",
                            children: [(0, n.jsx)(u.A, {
                                label: "",
                                size: "large",
                                value: S.origin,
                                onChange: e => N("origin", e),
                                onFocus: l,
                                placeholder: r ? "From" : "Enter city or airport",
                                showRegions: !1,
                                isExpanded: t,
                                type: "origin",
                                focusableArea: "all",
                                isMinimized: r,
                                variant: "bordered-mobile",
                                initialLoading: !a.origin,
                                "data-sentry-element": "LocationInput",
                                "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                            }), (0, n.jsx)(u.A, {
                                label: "",
                                size: "large",
                                value: S.destination,
                                onChange: e => N("destination", e),
                                onFocus: l,
                                placeholder: r ? "To" : "Enter city or airport",
                                showRegions: "oneWay" === D && d,
                                isExpanded: t,
                                type: "destination",
                                isMinimized: r,
                                focusableArea: "all",
                                variant: "bordered-mobile",
                                initialLoading: !a.destination,
                                "data-sentry-element": "LocationInput",
                                "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                            })]
                        }), (0, n.jsx)("div", {
                            className: "flex border border-white/10 rounded-lg border-solid p-2",
                            children: (0, n.jsx)(h.A, {
                                label: "Depart",
                                size: "large",
                                value: S.dates.startDate,
                                onChange: C,
                                onFocus: l,
                                placeholder: r ? "Depart" : "Add date",
                                isExpanded: t,
                                dateRange: S.dates,
                                isRangeMode: "oneWay" === D && A,
                                updateField: T,
                                isMinimized: r,
                                "data-sentry-element": "DateInput",
                                "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                            })
                        }), "roundTrip" === D && (0, n.jsx)("div", {
                            className: "flex border border-white/10 rounded-lg border-solid p-2",
                            children: (0, n.jsx)(h.A, {
                                label: "Return",
                                size: "large",
                                value: S.returnDate,
                                onChange: e => T("returnDate", e),
                                onFocus: l,
                                placeholder: r ? "Return" : "Add date",
                                isExpanded: t,
                                isReturnDate: !0,
                                dateRange: S.dates,
                                isMinimized: r
                            })
                        }), (0, n.jsx)(x.A, {
                            variant: "mobile",
                            selected: S.paymentType,
                            onSelect: F,
                            onFocus: l,
                            "data-sentry-element": "PaymentSelector",
                            "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                        }), (0, n.jsx)("div", {
                            className: "flex justify-start w-full pt-3 pb-[calc(1.5rem+env(safe-area-inset-bottom))] z-10",
                            children: (0, n.jsx)(g.A, {
                                onClick: () => j(),
                                className: m.q.classes.flightSearchButton,
                                "data-sentry-element": "ButtonCapsule",
                                "data-sentry-source-file": "FlightSearchInputMobile.tsx",
                                children: (0, n.jsxs)("div", {
                                    className: "flex items-center gap-2",
                                    children: [(0, n.jsx)(o.Huy, {
                                        className: "w-4 h-4 text-[#FFFFFF]",
                                        "data-sentry-element": "GoSearch",
                                        "data-sentry-source-file": "FlightSearchInputMobile.tsx"
                                    }), (0, n.jsx)("span", {
                                        className: "text-base text-white",
                                        children: "Search"
                                    })]
                                })
                            })
                        })]
                    })
                })
            };
            var y = a(46431),
                b = a(53380),
                v = a(52903),
                w = a(9087),
                N = a(17772),
                j = a(92381),
                C = a(8155),
                S = a(17031);
            let D = new Date,
                A = new Date(D);
            A.setDate(D.getDate() + 7);
            let T = new Date(A);
            T.setDate(A.getDate() + 1);
            let E = e => {
                var t, a;
                let {
                    initialValues: s,
                    onFocus: r,
                    isMinimized: i = !1,
                    onSearch: d
                } = e, [c, u] = (0, l.useState)({
                    displayName: "Around your area",
                    placeId: "",
                    location: void 0,
                    checkIn: new Date,
                    checkOut: (0, j.f)(new Date, 1),
                    rooms: [{
                        adults: 2,
                        children: 0,
                        childrenAges: []
                    }],
                    guestNationality: "US",
                    currency: "USD",
                    formattedAddress: void 0
                }), [p, x] = (0, l.useState)(A), [f, y] = (0, l.useState)(T), [b, v] = (0, l.useState)([{
                    adults: 2,
                    children: 0,
                    childrenAges: []
                }]), D = (null == (t = s.hotelDestination) ? void 0 : t.currency) || "USD", E = (null == (a = s.hotelDestination) ? void 0 : a.guestNationality) || "US";
                return (0, S.Ij)(() => {
                    var e;
                    s.hotelDestination && (u(s.hotelDestination), x(s.hotelDestination.checkIn), y(s.hotelDestination.checkOut), (null == (e = s.hotelDestination) ? void 0 : e.rooms) && v(s.hotelDestination.rooms.map(e => ({
                        adults: e.adults,
                        children: e.children,
                        childrenAges: e.childrenAges
                    }))))
                }, [s]), (0, n.jsxs)("div", {
                    className: "flex flex-col gap-3 pt-6 px-7",
                    "data-sentry-component": "HotelSearchInputMobile",
                    "data-sentry-source-file": "HotelSearchInputMobile.tsx",
                    children: [(0, n.jsx)(w.A, {
                        label: "",
                        value: c,
                        onChange: u,
                        onFocus: r,
                        placeholder: i ? "Destination" : "Enter city or hotel name",
                        isMinimized: i,
                        variant: "bordered-mobile",
                        className: "py-2",
                        "data-sentry-element": "HotelLocationInput",
                        "data-sentry-source-file": "HotelSearchInputMobile.tsx"
                    }), (0, n.jsx)("div", {
                        className: "px-1 py-1 border-white/10 flex items-center rounded-lg border-solid border",
                        children: (0, n.jsx)(h.A, {
                            label: "Check in",
                            value: p,
                            onChange: e => {
                                x(e), e ? y((0, j.f)(e, 1)) : y(null)
                            },
                            onFocus: r,
                            placeholder: i ? "Check in" : "Add date",
                            isExpanded: !1,
                            isMinimized: i,
                            size: "large",
                            "data-sentry-element": "DateInput",
                            "data-sentry-source-file": "HotelSearchInputMobile.tsx"
                        })
                    }), (0, n.jsx)("div", {
                        className: "px-1 py-1 border-white/10 flex items-center rounded-lg border-solid border",
                        children: (0, n.jsx)(h.A, {
                            label: "Check out",
                            value: f,
                            onChange: y,
                            onFocus: r,
                            placeholder: i ? "Check out" : "Add date",
                            isExpanded: !1,
                            isMinimized: i,
                            isReturnDate: !0,
                            dateRange: p ? {
                                startDate: p,
                                endDate: f
                            } : void 0,
                            size: "large",
                            "data-sentry-element": "DateInput",
                            "data-sentry-source-file": "HotelSearchInputMobile.tsx"
                        })
                    }), (0, n.jsx)("div", {
                        className: "px-1 border-white/10 flex items-center rounded-lg border-solid border py-1",
                        children: (0, n.jsx)(N.A, {
                            value: b,
                            onChange: v,
                            isMinimized: i,
                            size: "large",
                            "data-sentry-element": "HotelGuests",
                            "data-sentry-source-file": "HotelSearchInputMobile.tsx"
                        })
                    }), (0, n.jsx)("div", {
                        className: "flex justify-start w-full pt-3 pb-[calc(1.5rem+env(safe-area-inset-bottom))] z-10",
                        children: (0, n.jsx)(g.A, {
                            onClick: () => {
                                let e = { ...s
                                };
                                (0, C.s)(C.b.HOTEL_SEARCH_CLICK), d({ ...e,
                                    hotelDestination: {
                                        checkIn: p || A,
                                        checkOut: f || T,
                                        placeId: (null == c ? void 0 : c.placeId) || "",
                                        displayName: (null == c ? void 0 : c.displayName) || "",
                                        location: null == c ? void 0 : c.location,
                                        rooms: b.map(e => ({
                                            adults: e.adults,
                                            children: e.children,
                                            childrenAges: e.childrenAges
                                        })),
                                        currency: D,
                                        guestNationality: E
                                    }
                                })
                            },
                            className: m.q.classes.hotelSearchButton,
                            "data-sentry-element": "ButtonCapsule",
                            "data-sentry-source-file": "HotelSearchInputMobile.tsx",
                            children: (0, n.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, n.jsx)(o.Huy, {
                                    className: "w-4 h-4 text-[#FFFFFF]",
                                    "data-sentry-element": "GoSearch",
                                    "data-sentry-source-file": "HotelSearchInputMobile.tsx"
                                }), (0, n.jsx)("span", {
                                    className: "text-base text-white",
                                    children: "Search"
                                })]
                            })
                        })
                    })]
                })
            };
            var F = a(72473),
                z = a(56041),
                I = a(51452),
                k = a(85163),
                M = a(980),
                P = a(25950),
                O = a(5804);
            let L = e => {
                    let {
                        isOpen: t,
                        children: a
                    } = e;
                    return (0, l.useEffect)(() => (document.body.style.overflow = t ? "hidden" : "unset", () => {
                        document.body.style.overflow = "unset"
                    }), [t]), (0, n.jsx)(v.ZL, {
                        "data-sentry-element": "Portal",
                        "data-sentry-component": "SearchDialogContainer",
                        "data-sentry-source-file": "mobile.tsx",
                        children: (0, n.jsxs)("div", {
                            className: (0, i.cn)("fixed inset-0 items-center justify-center h-screen overflow-y-auto z-50", t ? "flex" : "hidden"),
                            children: [(0, n.jsx)("div", {
                                className: "absolute inset-0 bg-[#0D0D0D]"
                            }), (0, n.jsx)("div", {
                                className: "relative z-10 w-full bg-[#111]/80 shadow-lg text-white rounded-xl backdrop-blur-lg h-full flex flex-col",
                                children: a
                            })]
                        })
                    })
                },
                R = e => {
                    if (e.length > 9) {
                        var t;
                        let a = null == (t = e.split(" ")[0]) ? void 0 : t.replace(",", "");
                        return (null == a ? void 0 : a.length) < 4 || (null == a ? void 0 : a.length) > 11 ? e.substring(0, 11) + "..." : a
                    }
                    return e
                },
                _ = e => {
                    var t;
                    let {
                        values: a
                    } = e, l = null == a || null == (t = a.city) ? void 0 : t.replaceAll(/[()]/g, "");
                    return (0, n.jsxs)("div", {
                        className: "flex items-center gap-1 whitespace-nowrap text-sm overflow-hidden text-white/80",
                        "data-sentry-component": "FlightSearchPreview",
                        "data-sentry-source-file": "mobile.tsx",
                        children: [!a && (0, n.jsx)("span", {
                            className: "text-white/50",
                            children: "Loading..."
                        }), R(l || ""), (null == a ? void 0 : a.type) === "airport" && (0, n.jsxs)("span", {
                            className: "text-white/50",
                            children: ["(", null == a ? void 0 : a.code, ")"]
                        })]
                    })
                },
                B = e => {
                    var t;
                    let {
                        variant: a = "default",
                        onSearch: i,
                        initialValues: c,
                        loading: u,
                        from: h,
                        isMinimized: g = !1,
                        showRegions: m = !1,
                        isExpanded: p,
                        setIsExpanded: x
                    } = e, v = (0, I.b2)(), w = (0, s.useRouter)(), N = (0, l.useRef)(null), {
                        activeTab: j
                    } = (0, P.F7)(), [C, S] = (0, l.useState)(!1), D = "boolean" == typeof p ? p : C, A = x || S, {
                        trackMixPanelEvent: T
                    } = (0, M.s)(), R = (0, l.useCallback)(e => {
                        if (i) {
                            var t, a;
                            if (i({ ...e,
                                    tab: j
                                }), "flights" === j) {
                                let {
                                    origin: t,
                                    destination: a,
                                    paymentType: n
                                } = e, l = null == t ? void 0 : t.city, s = null == a ? void 0 : a.city, r = e.returnDate ? "round_trip" : "one_way";
                                l && s && n && r && T(k.$.FLIGHT_SEARCH_PERFORMED, {
                                    departure_city: l,
                                    arrival_city: s,
                                    search_type: n,
                                    trip_type: r
                                })
                            }
                            if ("hotels" === j) {
                                let {
                                    destination: t,
                                    dates: {
                                        endDate: a,
                                        startDate: n
                                    }
                                } = e;
                                (null == t ? void 0 : t.name) && a && n && T(k.$.HOTEL_SEARCH_PERFORMED, {
                                    destination: t.name,
                                    checkin_date: n.toDateString(),
                                    checkout_date: a.toDateString()
                                });
                                let l = (0, r.mp)({ ...e,
                                    tab: j
                                });
                                if (!l) return;
                                w.push(l)
                            }[null == (t = e.origin) ? void 0 : t.type, null == (a = e.destination) ? void 0 : a.type].every(e => "airport" === e || "city" === e) && "live-search" !== h || A(!1);
                            return
                        }
                        let n = e.origin,
                            l = e.destination;
                        if (n && (A(!1), "airport" === n.type && (null == l ? void 0 : l.type) === "airport")) {
                            let t = (0, r.mp)(e);
                            if (!t) return;
                            w.push(t)
                        }
                    }, [i, w, j, A]);
                    return (0, n.jsxs)("div", {
                        className: "w-full relative",
                        "data-sentry-component": "SearchBarMobileV2",
                        "data-sentry-source-file": "mobile.tsx",
                        children: [(0, n.jsx)(L, {
                            isOpen: D,
                            "data-sentry-element": "SearchDialogContainer",
                            "data-sentry-source-file": "mobile.tsx",
                            children: (0, n.jsxs)("div", {
                                ref: N,
                                className: "flex flex-col relative h-full",
                                children: [(0, n.jsxs)("div", {
                                    className: "w-full py-3 border-solid border-b border-white/10 flex items-center justify-center",
                                    style: {
                                        marginTop: v ? z.W9 : "0"
                                    },
                                    children: [(0, n.jsx)(O.e, {
                                        "data-sentry-element": "SearchBarV2TabsMobile",
                                        "data-sentry-source-file": "mobile.tsx"
                                    }), (0, n.jsx)("button", {
                                        onClick: () => A(!1),
                                        className: "absolute left-5",
                                        children: (0, n.jsx)(d.A, {
                                            className: "text-[12px] opacity-90",
                                            "data-sentry-element": "X",
                                            "data-sentry-source-file": "mobile.tsx"
                                        })
                                    })]
                                }), (() => {
                                    switch (j) {
                                        case "flights":
                                            return (0, n.jsx)(f, {
                                                isExpanded: D,
                                                initialValues: c,
                                                onFocus: () => {},
                                                onSearch: R,
                                                isLoading: u,
                                                isMinimized: g,
                                                showRegions: m
                                            });
                                        case "hotels":
                                            return (0, n.jsx)(E, {
                                                initialValues: c,
                                                isExpanded: D,
                                                onFocus: () => {},
                                                isLoading: u,
                                                onSearch: R
                                            });
                                        default:
                                            return null
                                    }
                                })()]
                            })
                        }), "default" === a ? (0, n.jsx)("div", {
                            className: "rounded-xl shadow-lg py-4 mx-4",
                            children: (0, n.jsx)("div", {
                                className: "search-dummy-box rounded-lg w-full h-14 flex bg-[#333333] cursor-pointer",
                                style: {
                                    padding: "1px"
                                },
                                onClick: () => {
                                    A(!0)
                                },
                                children: (0, n.jsxs)("div", {
                                    className: "flex w-full items-center justify-between px-5 bg-[#0D0D0D] rounded-lg",
                                    children: [(0, n.jsxs)("div", {
                                        className: "flex items-center text-white/50 gap-2 max-w-[calc(100%-44px)]",
                                        children: [(0, n.jsx)(_, {
                                            values: c.origin
                                        }), (0, n.jsx)(b.CqI, {
                                            className: "w-4 h-4 text-white/40 aspect-square min-w-4"
                                        }), (null == (t = c.destination) ? void 0 : t.name) === "Anywhere" ? (0, n.jsx)("span", {
                                            children: "Anywhere"
                                        }) : (0, n.jsx)(_, {
                                            values: c.destination
                                        })]
                                    }), (0, n.jsx)("button", {
                                        className: "text-white bg-[#3E3A4B] rounded-full w-9 h-9 min-w-9 flex items-center justify-center ml-2",
                                        children: (0, n.jsx)(o.Huy, {
                                            size: 16
                                        })
                                    })]
                                })
                            })
                        }) : (0, n.jsx)("div", {
                            className: "flex justify-center",
                            children: (() => {
                                var e, t, a, l, s, r, i, o;
                                return (0, n.jsx)("div", {
                                    className: "relative shadow flex items-center rounded-xl min-w-[200px] m-2",
                                    style: {
                                        background: "linear-gradient(90deg, #464646 0%, #333333 28%, #9C9C9C 66%, #464646 100%)",
                                        padding: "1px"
                                    },
                                    "data-sentry-component": "renderBoxPreviewNavbar",
                                    "data-sentry-source-file": "mobile.tsx",
                                    children: (0, n.jsx)("div", {
                                        className: "flex items-center py-3 px-6 w-full h-full bg-gradient-to-r from-[#101010] to-[#0F1011] rounded-xl cursor-pointer",
                                        onClick: () => {
                                            A(!0)
                                        },
                                        children: "flights" === j ? (0, n.jsxs)(n.Fragment, {
                                            children: [(0, n.jsx)(_, {
                                                values: c.origin
                                            }), (0, n.jsx)("button", {
                                                onClick: () => {},
                                                className: "px-2 py-1 hover:opacity-75 transition-opacity ".concat((null == (e = c.destination) ? void 0 : e.type) === "region" ? "cursor-not-allowed opacity-40" : ""),
                                                disabled: (null == (t = c.destination) ? void 0 : t.type) === "region",
                                                children: (0, n.jsx)(b.CqI, {
                                                    className: "w-4 h-4 text-white/40"
                                                })
                                            }), (0, n.jsx)(_, {
                                                values: c.destination
                                            })]
                                        }) : (0, n.jsxs)("div", {
                                            className: "flex flex-col w-full",
                                            children: [(0, n.jsx)("div", {
                                                className: "text-white/80 text-sm whitespace-nowrap overflow-hidden text-ellipsis",
                                                children: (null == (a = c.hotelDestination) ? void 0 : a.displayName) || "Around your area"
                                            }), (0, n.jsxs)("div", {
                                                className: "text-white/50 text-xs flex items-center gap-1",
                                                children: [(0, n.jsxs)("span", {
                                                    children: [(null == (l = c.hotelDestination) ? void 0 : l.checkIn) ? (0, F.GP)(c.hotelDestination.checkIn, "MMM d") : "Check in", " ", "-", " ", (null == (s = c.hotelDestination) ? void 0 : s.checkOut) ? (0, F.GP)(c.hotelDestination.checkOut, "MMM d") : "Check out"]
                                                }), (0, n.jsx)("span", {
                                                    children: "•"
                                                }), (0, n.jsxs)("span", {
                                                    children: [(null == (r = c.hotelDestination) ? void 0 : r.rooms.length) || 0, " Room", (null == (i = c.hotelDestination) ? void 0 : i.rooms.length) ? "s" : "", " •", " ", (null == (o = c.hotelDestination) ? void 0 : o.rooms.reduce((e, t) => e + t.adults + t.children, 0)) || 0, " ", "Guests"]
                                                })]
                                            })]
                                        })
                                    })
                                })
                            })()
                        }), "default" === a && (0, n.jsx)(y.b, {
                            isVisible: !!u
                        })]
                    })
                }
        },
        56041: (e, t, a) => {
            a.d(t, {
                J2: () => s,
                Pb: () => l,
                W9: () => r
            });
            var n = a(11607);
            let l = 56,
                s = "--banner-height",
                r = n.y ? "var(".concat(s, ", ").concat(l, "px)") : "0"
        },
        56317: (e, t, a) => {
            a.d(t, {
                BH: () => g,
                D3: () => u,
                MP: () => w,
                TA: () => p,
                Vh: () => r,
                WU: () => x,
                YI: () => y,
                Yq: () => d,
                a3: () => h,
                aQ: () => b,
                dj: () => m,
                pP: () => i,
                s_: () => v,
                wN: () => c,
                yF: () => f
            });
            var n = a(70682),
                l = a(79189),
                s = a(45718);
            let r = e => {
                let {
                    profile: t,
                    additionalSearches: a
                } = e, n = Math.min(s.C2, a);
                return t.booking_count ? t.search_count <= s.NY + n : t.search_count <= s.pP + n
            };

            function i(e, t, a, n) {
                if ((null == n ? void 0 : n.toLowerCase()) === "duffel") return "Includes";
                if (!e) return "Some";
                let l = (e / 100).toFixed(2),
                    s = null != a ? a : "";
                return "".concat(null != t ? t : "$").concat(l).concat(s ? " ".concat(s) : "")
            }

            function o(e) {
                return (0, n.GP)(e, "h:mm a")
            }

            function d(e) {
                return (0, n.GP)(e, "MMM d")
            }

            function c(e) {
                return (0, n.GP)(e, "EEE, MMM d")
            }

            function u(e) {
                let {
                    arrivalTimestamp: t,
                    departureTimestamp: a
                } = e, n = new Date(t.replace("Z", "")), l = new Date(a.replace("Z", "")), s = new Date(n.getFullYear(), n.getMonth(), n.getDate()), r = new Date(l.getFullYear(), l.getMonth(), l.getDate());
                return {
                    dayDelta: Math.round((s.getTime() - r.getTime()) / 864e5),
                    arrivalTime: o(n),
                    arrivalDate: d(n),
                    departureTime: o(l),
                    departureDate: d(l)
                }
            }

            function h(e) {
                let t = Math.floor(e / 60);
                return "".concat(t, "hr ").concat(e % 60, "min")
            }

            function g(e) {
                return 0 === e ? "Nonstop" : "".concat(e, " stop").concat(e > 1 ? "s" : "")
            }

            function m(e) {
                return "eco" == e.toLowerCase() ? "Economy" : e.split("&").map(e => e.trim()).map(e => e.charAt(0).toUpperCase() + e.slice(1).toLowerCase()).join(" & ")
            }

            function p(e) {
                return (0, n.qD)(e, "UTC", "h:mm a")
            }

            function x(e) {
                return (0, n.qD)(e, "UTC", "MMM d")
            }

            function f(e) {
                return (0, n.qD)(e, "UTC", "EEE, MMM d")
            }
            let y = (e, t) => {
                    let a = e => !isNaN(Date.parse(e)),
                        n = new Map;
                    for (let o of e) {
                        var s, r, i;
                        if (!(null == (i = t.sources[o.isDuffel ? (null == (r = o.AvailabilitySegments) || null == (s = r[0]) ? void 0 : s.OperatingCarrierName) || o.Carriers : o.Source]) || i) || t.bookingMethod !== l.dP.ALL && (o.isDuffel && t.bookingMethod === l.dP.INDIRECT || !o.isDuffel && t.bookingMethod === l.dP.DIRECT) || t.cabinClass && o.Cabin.toLowerCase() !== t.cabinClass.toLowerCase()) continue;
                        switch (t.stops) {
                            case l.ys.NONSTOP:
                                if (0 !== o.Stops) continue;
                                break;
                            case l.ys.ONE_STOP:
                                if (o.Stops > 1) continue;
                                break;
                            case l.ys.TWO_STOPS:
                                if (o.Stops > 2) continue
                        }
                        if (t.times.length > 0 && a(o.DepartsAt)) {
                            let e = o.isDuffel ? new Date(o.DepartsAt).getHours() : new Date(o.DepartsAt).getUTCHours();
                            if (!t.times.some(t => {
                                    let {
                                        range: a
                                    } = l.fi[t], [n, s] = a;
                                    return e >= n && e < s
                                })) continue
                        }
                        let e = v(o);
                        n.set(e, o)
                    }
                    return Array.from(n.values())
                },
                b = (e, t) => [...e].sort((e, a) => {
                    switch (t) {
                        case l._6.CHEAPEST:
                            return e.MileageCost - a.MileageCost;
                        case l._6.FASTEST:
                            return e.TotalDuration - a.TotalDuration;
                        case l._6.BEST:
                            var n, s;
                            return (null != (n = a.cpp) ? n : 0) - (null != (s = e.cpp) ? s : 0);
                        default:
                            return e.MileageCost - a.MileageCost
                    }
                }),
                v = e => {
                    let t = Math.random().toString(36).substring(2, 6);
                    return "".concat(e.FlightNumbers, "|").concat(e.Cabin, "|").concat(e.DepartsAt, "|").concat(e.Source, "|").concat(e.MileageCost, "|").concat(e.ArrivesAt, "|").concat(t)
                };

            function w(e, t) {
                let a = e ? i(e.TotalTaxes, e.TaxesCurrencySymbol, e.TaxesCurrency, e.Source) : "",
                    n = t ? i(t.TotalTaxes, t.TaxesCurrencySymbol, t.TaxesCurrency, t.Source) : "";
                return a ? n ? e && t && e.TaxesCurrency === t.TaxesCurrency ? i((e.TotalTaxes || 0) + (t.TotalTaxes || 0), e.TaxesCurrencySymbol, e.TaxesCurrency, e.Source) : "".concat(a, " + ").concat(n) : a : n
            }
        },
        56468: (e, t, a) => {
            a.d(t, {
                A: () => l
            });
            var n = a(20063);
            let l = () => ({
                onLandingPage: "/" === (0, n.usePathname)()
            })
        },
        60077: (e, t, a) => {
            a.d(t, {
                B: () => d
            });
            var n = a(12115),
                l = a(8772);
            let s = {
                    SET_HEADER_CONTENT: "SET_HEADER_CONTENT",
                    SET_NAVBAR_CLASSNAME: "SET_NAVBAR_CLASSNAME",
                    SET_CONTAINER_CLASSNAME: "SET_CONTAINER_CLASSNAME"
                },
                r = {
                    setHeaderContent: e => ({
                        type: s.SET_HEADER_CONTENT,
                        payload: e
                    }),
                    setClassName: e => ({
                        type: s.SET_NAVBAR_CLASSNAME,
                        payload: e
                    }),
                    setContainerClassName: e => ({
                        type: s.SET_CONTAINER_CLASSNAME,
                        payload: e
                    })
                };
            var i = a(20063),
                o = a(64269);
            let d = e => {
                let {
                    content: t,
                    cleanupOnUnmount: a = !0,
                    className: s,
                    containerClassName: d,
                    transparent: c = !1,
                    slim: u = !1,
                    noBorder: h = !1
                } = e, g = (0, l.Iz)(), m = (0, i.usePathname)(), p = (0, n.useRef)(null), x = (0, n.useRef)(void 0), f = (0, n.useRef)(void 0);
                (0, n.useEffect)(() => {
                    if (p.current !== t && (g(r.setHeaderContent(t)), p.current = t), f.current !== d) {
                        let e = (0, o.cn)(d, h && "border-none");
                        g(r.setContainerClassName(e)), f.current = e
                    }
                    if (x.current !== s) {
                        let e = (0, o.cn)(s, u && "py-2", c && "bg-transparent");
                        e ? g(r.setClassName(e)) : g(r.setClassName(void 0)), x.current = e
                    }
                    if (a) return () => {
                        g(r.setHeaderContent(null)), p.current = null, x.current = void 0
                    }
                }, [t, s, g, a, d, c, u, h]), (0, n.useEffect)(() => {
                    a && g(r.setHeaderContent(null))
                }, [m, a, g])
            }
        },
        67548: (e, t, a) => {
            a.d(t, {
                A: () => s
            });
            var n = a(95155);
            a(12115);
            var l = a(64269);
            let s = e => {
                let {
                    children: t,
                    fullWidth: a = !1,
                    isLoading: s = !1,
                    isValid: r = !0,
                    isFinalStep: i = !1,
                    disabled: o = !1,
                    variant: d = "default",
                    className: c = "",
                    ...u
                } = e, h = o || !r && !i, g = {
                    default: {
                        className: "text-black bg-gradient-to-br from-[#FAF9FA] via-[#CBC0E7] to-[#A4AFD0]",
                        style: {
                            background: "radial-gradient(77.05% 77.05% at 50% 22.95%, #FAF9FA 42.65%, #CBC0E7 79.17%, #A4AFD0 100%)",
                            filter: h ? "brightness(0.7)" : "none"
                        }
                    },
                    outline: {
                        className: "text-white border border-[#605973] bg-transparent hover:bg-white/10 font-light",
                        style: {
                            borderWidth: "0.5px"
                        }
                    },
                    ghost: {
                        className: "text-white bg-transparent hover:bg-white/10",
                        style: {}
                    },
                    dashed: {
                        className: "text-sm text-white/80 font-normal hover:opacity-1",
                        style: {
                            backgroundImage: "repeating-linear-gradient(90deg, #FFFFFF1A, #FFFFFF1A 12px, transparent 12px, transparent 16px), repeating-linear-gradient(180deg, #FFFFFF1A, #FFFFFF1A 12px, transparent 12px, transparent 16px), repeating-linear-gradient(90deg, #FFFFFF1A, #FFFFFF1A 12px, transparent 12px, transparent 16px), repeating-linear-gradient(180deg, #FFFFFF1A, #FFFFFF1A 12px, transparent 12px, transparent 16px)",
                            backgroundPosition: "left top, right top, left bottom, left top",
                            backgroundRepeat: "repeat-x, repeat-y, repeat-x, repeat-y",
                            backgroundSize: "100% 1px, 1px 100%, 100% 1px, 1px 100%"
                        }
                    },
                    icon: {
                        className: "h-10 w-10 p-0 rounded-full flex items-center justify-center",
                        style: {}
                    }
                };
                return (0, n.jsx)("button", {
                    className: (0, l.cn)("px-4 py-2 rounded-md transition font-medium", a && "w-full", h ? "opacity-50 cursor-not-allowed" : "hover:opacity-80", g[d].className, c),
                    style: g[d].style,
                    disabled: h,
                    ...u,
                    "data-sentry-component": "Button",
                    "data-sentry-source-file": "Button.tsx",
                    children: s ? "Loading..." : t
                })
            }
        },
        73788: (e, t, a) => {
            a.d(t, {
                $2: () => c,
                V3: () => u,
                Q6: () => o,
                vm: () => d
            });
            var n = a(37171),
                l = a(89402);
            let s = JSON.parse('{"NYC":{"lat":40.7128,"long":-74.006},"SYD":{"lat":-33.9344,"long":151.168},"CAI":{"lat":30.1206,"long":31.4078},"BUD":{"lat":47.4453,"long":19.2195},"LIN":{"lat":45.4558,"long":9.27269},"CKG":{"lat":29.5833,"long":106.5},"SAN":{"lat":32.7299,"long":-117.195},"IKA":{"lat":35.5683,"long":51.4436},"DUB":{"lat":53.4272,"long":-6.24418},"MSY":{"lat":29.983,"long":-90.2569},"AEP":{"lat":-34.5617,"long":-58.4113},"BLQ":{"lat":44.5345,"long":11.2903},"MLA":{"lat":35.8586,"long":14.4781},"GRU":{"lat":-23.435,"long":-46.4728},"YVR":{"lat":49.1931,"long":-123.172},"MRS":{"lat":43.4411,"long":5.22087},"CGH":{"lat":-23.6285,"long":-46.6589},"GVA":{"lat":46.2329,"long":6.10682},"RSW":{"lat":26.5228,"long":-81.7531},"MAD":{"lat":40.4684,"long":-3.56769},"DOH":{"lat":25.2592,"long":51.5658},"ITM":{"lat":34.7857,"long":135.439},"NCL":{"lat":55.0374,"long":-1.70962},"CVG":{"lat":39.0571,"long":-84.6625},"STL":{"lat":38.7414,"long":-90.3647},"AMS":{"lat":52.3122,"long":4.77511},"MNL":{"lat":14.5114,"long":121.016},"CLT":{"lat":35.2226,"long":-80.946},"RDU":{"lat":35.8729,"long":-78.7923},"DME":{"lat":55.4025,"long":37.9136},"MCI":{"lat":39.2992,"long":-94.7171},"YUL":{"lat":45.4562,"long":-73.7473},"SGN":{"lat":10.8191,"long":106.658},"ICN":{"lat":37.4534,"long":126.657},"YYZ":{"lat":43.685,"long":-79.6142},"YYC":{"lat":51.1343,"long":-114.007},"BWI":{"lat":39.1841,"long":-76.6745},"MXP":{"lat":45.6314,"long":8.72284},"OSL":{"lat":60.1947,"long":11.1005},"PDX":{"lat":45.5867,"long":-122.587},"EDI":{"lat":55.9486,"long":-3.36431},"PMI":{"lat":39.5495,"long":2.73188},"LAX":{"lat":33.9456,"long":-118.391},"JNB":{"lat":-26.1219,"long":28.2467},"TFS":{"lat":28.0474,"long":-16.5705},"BNE":{"lat":-27.3589,"long":153.122},"PEK":{"lat":40.0724,"long":116.583},"KIX":{"lat":34.4295,"long":135.244},"TLV":{"lat":32.0117,"long":34.8861},"ALG":{"lat":36.6993,"long":3.21935},"LAS":{"lat":36.0806,"long":-115.143},"SFO":{"lat":37.6148,"long":-122.392},"VIE":{"lat":48.1036,"long":16.5804},"EZE":{"lat":-34.82,"long":-58.5333},"IBZ":{"lat":38.8755,"long":1.36851},"AKL":{"lat":-37.0085,"long":174.782},"IST":{"lat":40.9857,"long":28.8163},"DTW":{"lat":42.2327,"long":-83.3412},"DCA":{"lat":38.849,"long":-77.0438},"DEL":{"lat":28.5603,"long":77.1027},"CPT":{"lat":-33.9647,"long":18.6022},"HEL":{"lat":60.3243,"long":24.9688},"HND":{"lat":35.5533,"long":139.771},"MAN":{"lat":53.365,"long":-2.27089},"CTU":{"lat":30.5775,"long":103.941},"KRK":{"lat":50.0741,"long":19.8011},"IAH":{"lat":29.9784,"long":-95.3424},"SOF":{"lat":42.6895,"long":23.4024},"ZRH":{"lat":47.454,"long":8.56137},"TPE":{"lat":25.081,"long":121.237},"CAN":{"lat":23.3925,"long":113.299},"AUS":{"lat":30.2027,"long":-97.6653},"IAD":{"lat":38.9556,"long":-77.4484},"GIG":{"lat":-22.8094,"long":-43.25},"ATL":{"lat":33.6558,"long":-84.4333},"ADD":{"lat":8.9783,"long":38.8011},"RUH":{"lat":24.9625,"long":46.7078},"BSB":{"lat":-15.8622,"long":-47.9122},"MIA":{"lat":25.7953,"long":-80.2727},"WAW":{"lat":52.17,"long":20.9725},"TUN":{"lat":36.8435,"long":10.2348},"MCO":{"lat":28.4418,"long":-81.3115},"MTY":{"lat":25.7783,"long":-100.107},"BEG":{"lat":44.8192,"long":20.3122},"KUL":{"lat":2.77859,"long":101.689},"NAP":{"lat":40.8837,"long":14.2815},"WUH":{"lat":30.5069,"long":114.31},"LIS":{"lat":38.7701,"long":-9.13775},"PTY":{"lat":9.07,"long":-79.3836},"NBO":{"lat":-1.31697,"long":36.9222},"HAV":{"lat":22.9894,"long":-82.4075},"SLC":{"lat":40.7862,"long":-111.982},"PIT":{"lat":40.4914,"long":-80.2328},"BKK":{"lat":13.9144,"long":100.608},"NCE":{"lat":43.6638,"long":7.21286},"TIJ":{"lat":32.5411,"long":-116.972},"CMN":{"lat":33.365,"long":-7.5817},"DEN":{"lat":39.8396,"long":-104.672},"BOS":{"lat":42.3717,"long":-71.0281},"MEX":{"lat":19.4344,"long":-99.0742},"BHX":{"lat":52.4531,"long":-1.73847},"HOU":{"lat":29.6572,"long":-95.2795},"VCE":{"lat":45.505,"long":12.3433},"ARN":{"lat":59.6521,"long":17.9317},"HKT":{"lat":8.1106,"long":98.3125},"HYD":{"lat":17.4522,"long":78.4629},"DXB":{"lat":25.2509,"long":55.3629},"GDL":{"lat":20.5347,"long":-103.322},"BNA":{"lat":36.1342,"long":-86.6682},"BOG":{"lat":4.69895,"long":-74.1435},"LOS":{"lat":6.575,"long":3.3222},"HAN":{"lat":21.2263,"long":105.815},"RIX":{"lat":56.9231,"long":23.9717},"MEL":{"lat":-37.6759,"long":144.844},"KEF":{"lat":63.9853,"long":-22.6042},"CDG":{"lat":49.0175,"long":2.5564},"CLE":{"lat":41.4115,"long":-81.8339},"FCO":{"lat":41.8026,"long":12.2551},"FRA":{"lat":50.0483,"long":8.57041},"AUH":{"lat":24.4331,"long":54.6489},"LED":{"lat":59.9667,"long":30.3},"MSP":{"lat":44.8793,"long":-93.1987},"DFW":{"lat":32.9222,"long":-97.0409},"HKG":{"lat":22.3124,"long":113.929},"IND":{"lat":39.7322,"long":-86.2707},"MUC":{"lat":48.354,"long":11.7816},"PHX":{"lat":33.4376,"long":-112.03},"SIN":{"lat":1.3578,"long":103.991},"PRG":{"lat":50.1079,"long":14.2675},"HNL":{"lat":21.3358,"long":-157.919},"SEA":{"lat":47.4405,"long":-122.296},"SCL":{"lat":-33.39,"long":-70.785},"NRT":{"lat":35.7491,"long":140.389},"CUN":{"lat":21.0406,"long":-86.8744},"BRU":{"lat":50.899,"long":4.4859},"BLR":{"lat":12.9526,"long":77.6656},"SAT":{"lat":29.5252,"long":-98.4729},"JED":{"lat":21.706,"long":39.1386},"BOM":{"lat":19.0932,"long":72.8654},"CPH":{"lat":55.6205,"long":12.6495},"LHR":{"lat":51.4703,"long":-0.45342},"CGK":{"lat":-6.11964,"long":106.656},"BCN":{"lat":41.3006,"long":2.07976},"PVG":{"lat":31.1156,"long":121.803},"ATH":{"lat":37.8937,"long":23.7235},"ORD":{"lat":41.9796,"long":-87.8825},"TPA":{"lat":27.9744,"long":-82.5356},"LIM":{"lat":-12.0228,"long":-77.1081},"DPS":{"lat":-8.7486,"long":115.165},"SZX":{"lat":22.5333,"long":113.967},"OTP":{"lat":44.5656,"long":26.1029},"PHL":{"lat":39.8768,"long":-75.2419},"FLL":{"lat":26.0722,"long":-80.1354},"LGW":{"lat":51.1568,"long":-0.16988}}');
            var r = a(79435);
            let i = () => ({
                    adults: 1,
                    children: 0,
                    infants: 0
                }),
                o = () => ({
                    tab: "flights",
                    origin: null,
                    destination: {
                        code: "ANY",
                        name: "Anywhere",
                        type: "region"
                    },
                    dates: (0, n.XT)(),
                    passengers: i(),
                    cabin: void 0,
                    paymentType: "miles"
                }),
                d = () => ({
                    tab: "flights",
                    origin: {
                        code: "JFK",
                        name: "John F. Kennedy International Airport",
                        city: "New York",
                        type: "airport"
                    },
                    destination: {
                        code: "ANY",
                        name: "Anywhere",
                        type: "region"
                    },
                    dates: (0, n.XT)(),
                    passengers: i(),
                    cabin: "economy",
                    paymentType: "miles"
                });
            async function c(e) {
                let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                    a = "airport_".concat(e) + (t ? "_region" : "");
                if ((0, r.e7)(a, 864e5))(0, r.fl)(a);
                else {
                    let e = (0, r.$E)(a);
                    if (e) return {
                        code: e.iata_code,
                        name: e.name,
                        city: e.municipality || "",
                        type: e.type || "airport"
                    }
                }
                let n = await (0, l.K9)(e, t);
                if (!n) return null;
                let s = { ...n,
                    type: n.type || "airport",
                    timestamp: Date.now()
                };
                return (0, r.ni)(a, s), {
                    code: n.iata_code,
                    name: n.name,
                    city: n.municipality || "",
                    type: "airport"
                }
            }

            function u(e, t) {
                let a = null,
                    n = 1 / 0;
                for (let [l, r] of Object.entries(s)) {
                    let s = Math.sqrt(Math.pow(e - r.lat, 2) + Math.pow(t - r.long, 2));
                    s < n && (n = s, a = {
                        code: l,
                        ...r
                    })
                }
                return a
            }
        },
        76433: (e, t, a) => {
            a.d(t, {
                A: () => d
            });
            var n = a(12115),
                l = a(24034),
                s = a(17031);
            let r = (e, t) => {
                let [a, r] = (0, n.useState)(e);
                (0, s.Ij)(() => {
                    JSON.stringify(a) !== JSON.stringify(e) && r(e)
                }, [e]);
                let i = (0, n.useCallback)((e, t) => {
                        r(a => ({ ...a,
                            [e]: t
                        }))
                    }, []),
                    o = (0, n.useMemo)(() => {
                        let e = l.KI.refine(e => null !== e.origin, {
                            message: "Origin is required",
                            path: ["origin"]
                        }).refine(e => null !== e.destination, {
                            message: "Destination is required",
                            path: ["destination"]
                        }).refine(e => "roundTrip" !== t || !!e.returnDate || !!e.dates.endDate, {
                            message: "Return date is required for round trips",
                            path: ["dates"]
                        }).safeParse(a);
                        return e.success ? {
                            isValid: !0,
                            errors: {}
                        } : {
                            isValid: !1,
                            errors: e.error.formErrors.fieldErrors
                        }
                    }, [a, t]);
                return {
                    values: a,
                    updateField: i,
                    ...o
                }
            };
            var i = a(81264),
                o = a(8155);
            let d = e => {
                var t;
                let {
                    initialValues: a,
                    onSearch: l
                } = e, [s, d] = (0, n.useState)(a.returnDate ? "roundTrip" : "oneWay"), [c, u] = (0, n.useState)(a.passengers), [h, g] = (0, n.useState)(a.cabin), {
                    values: m,
                    updateField: p,
                    isValid: x
                } = r(a, s), f = (null == (t = m.destination) ? void 0 : t.type) === "region", y = f ? "oneWay" : s;
                (0, n.useEffect)(() => {
                    m.returnDate && d("roundTrip")
                }, [m.returnDate]), (0, n.useEffect)(() => {
                    m.cabin ? g(m.cabin) : g(void 0)
                }, [m.cabin]);
                let b = (0, n.useCallback)((e, t) => {
                        p(e, t)
                    }, [p]),
                    v = (0, n.useCallback)(e => {
                        var t;
                        let a = e || m;
                        if (!x) {
                            i.o.dismiss("search-error"), i.o.error("Please fill in all required fields", {
                                id: "search-error"
                            });
                            return
                        }
                        let n = { ...a
                        };
                        (null == (t = a.destination) ? void 0 : t.type) === "region" && !a.dates.endDate && a.dates.startDate && (n = { ...n,
                            dates: { ...a.dates,
                                endDate: a.dates.startDate
                            }
                        }), (0, o.s)(o.b.FLIGHT_SEARCH_CLICK), l({ ...n,
                            tab: "flights",
                            returnDate: "roundTrip" === s ? a.returnDate : null,
                            passengers: c,
                            cabin: h
                        })
                    }, [m, c, h, x, l, s]);
                return {
                    mode: s,
                    passengers: c,
                    setPassengers: u,
                    selectedCabin: h,
                    handleCabinChange: e => {
                        g(e), p("cabin", e)
                    },
                    handleLocationChange: b,
                    handleSearch: v,
                    handleSwapLocations: () => {
                        let {
                            origin: e,
                            destination: t
                        } = m;
                        p("origin", (null == t ? void 0 : t.type) !== "region" ? t : null), p("destination", e)
                    },
                    handleDepartDateChange: e => {
                        if ("roundTrip" === s && m.dates.endDate && e && e > m.dates.endDate) return void p("dates", {
                            startDate: e,
                            endDate: null
                        });
                        p("dates", { ...m.dates,
                            startDate: e
                        })
                    },
                    values: m,
                    isValid: x,
                    effectiveMode: y,
                    isDestinationRegion: f,
                    updateField: p,
                    handlePaymentTypeChange: e => {
                        var t;
                        "cash" === e && (null == (t = m.destination) ? void 0 : t.type) === "region" && p("destination", null), p("paymentType", e)
                    },
                    handleChangeMode: e => {
                        var t;
                        d(e), "roundTrip" === e && (null == (t = m.destination) ? void 0 : t.type) === "region" && p("destination", null)
                    }
                }
            }
        },
        78718: (e, t, a) => {
            a.d(t, {
                mp: () => n.mp
            }), a(73788);
            var n = a(94523);
            a(24034)
        },
        79189: (e, t, a) => {
            a.d(t, {
                _6: () => n,
                dP: () => d,
                fi: () => r,
                fj: () => l,
                hq: () => s,
                rS: () => o,
                ys: () => i
            });
            var n = function(e) {
                return e.CHEAPEST = "CHEAPEST", e.FASTEST = "FASTEST", e.BEST = "BEST", e
            }({});
            let l = {
                CHEAPEST: "Cheapest",
                FASTEST: "Fastest",
                BEST: "Best"
            };
            var s = function(e) {
                return e.EARLY_MORNING = "EARLY_MORNING", e.MORNING = "MORNING", e.AFTERNOON = "AFTERNOON", e.EVENING = "EVENING", e
            }({});
            let r = {
                EARLY_MORNING: {
                    label: "Early Morning (12AM - 6AM)",
                    range: [0, 6]
                },
                MORNING: {
                    label: "Morning (6AM - 12PM)",
                    range: [6, 12]
                },
                AFTERNOON: {
                    label: "Afternoon (12PM - 6PM)",
                    range: [12, 18]
                },
                EVENING: {
                    label: "Evening (6PM - 12AM)",
                    range: [18, 24]
                }
            };
            var i = function(e) {
                return e.ANY = "ANY", e.NONSTOP = "NONSTOP", e.ONE_STOP = "ONE_STOP", e.TWO_STOPS = "TWO_STOPS", e
            }({});
            let o = {
                ANY: "Any number of stops",
                NONSTOP: "Nonstop only",
                ONE_STOP: "1 stop or fewer",
                TWO_STOPS: "2 stops or fewer"
            };
            var d = function(e) {
                return e.ALL = "all", e.DIRECT = "direct", e.INDIRECT = "indirect", e
            }({})
        },
        79435: (e, t, a) => {
            function n(e) {
                try {
                    let t = localStorage.getItem(e);
                    return t ? JSON.parse(t) : null
                } catch (t) {
                    return console.error("Error retrieving item '".concat(e, "' from localStorage:"), t), null
                }
            }

            function l(e, t) {
                try {
                    return localStorage.setItem(e, JSON.stringify(t)), !0
                } catch (t) {
                    return console.error("Error saving item '".concat(e, "' to localStorage:"), t), !1
                }
            }

            function s(e) {
                try {
                    localStorage.removeItem(e)
                } catch (t) {
                    console.error("Error removing item '".concat(e, "' from localStorage:"), t)
                }
            }

            function r(e, t) {
                let a = n(e);
                return !a || !a.timestamp || Date.now() - a.timestamp > t
            }
            a.d(t, {
                $E: () => n,
                e7: () => r,
                fl: () => s,
                ni: () => l
            })
        },
        83871: (e, t, a) => {
            a.d(t, {
                A: () => m
            });
            var n = a(95155),
                l = a(12115),
                s = a(59007),
                r = a(30848),
                i = a(31475),
                o = a(81264);
            let d = (0, l.memo)(e => {
                let {
                    passengers: t,
                    onChange: a
                } = e, l = e => {
                    9 > Object.values(t).reduce((e, t) => e + t) ? a({ ...t,
                        [e]: t[e] + 1
                    }) : (o.o.dismiss("passenger-exceeded-error"), o.o.error("Passenger total can't exceed 9", {
                        duration: 1e3,
                        id: "passenger-exceeded-error"
                    }))
                }, s = e => {
                    t[e] > +("adults" === e) && a({ ...t,
                        [e]: t[e] - 1
                    })
                };
                return (0, n.jsx)("div", {
                    className: "flex flex-col gap-2 p-3 bg-[#101010] text-white rounded-lg",
                    "data-sentry-component": "PassengerPicker",
                    "data-sentry-source-file": "PassengerPicker.tsx",
                    children: [{
                        key: "adults",
                        label: "Adults"
                    }, {
                        key: "children",
                        label: "Children"
                    }, {
                        key: "infants",
                        label: "Infants"
                    }].map(e => {
                        let {
                            key: a,
                            label: r
                        } = e;
                        return (0, n.jsxs)("div", {
                            className: "flex items-center justify-between",
                            children: [(0, n.jsx)("div", {
                                className: "text-sm pr-2",
                                children: r
                            }), (0, n.jsxs)("div", {
                                className: "flex items-center gap-2",
                                children: [(0, n.jsx)("button", {
                                    onClick: () => s(a),
                                    className: "h-6 w-6 flex items-center justify-center bg-white/10 rounded",
                                    disabled: "adults" === a ? t[a] <= 1 : t[a] <= 0,
                                    children: "-"
                                }), (0, n.jsx)("span", {
                                    className: "min-w-[1.5rem] text-center text-sm",
                                    children: t[a]
                                }), (0, n.jsx)("button", {
                                    onClick: () => l(a),
                                    className: "h-6 w-6 flex items-center justify-center bg-white/10 rounded",
                                    children: "+"
                                })]
                            })]
                        }, a)
                    })
                })
            });
            var c = a(24034);

            function u(e) {
                if (void 0 === e) return "All cabins";
                switch (e) {
                    case "economy":
                        return "Economy";
                    case "premium_economy":
                        return "Premium Economy";
                    case "business_first":
                        return "Business/First"
                }
            }
            let h = (0, l.memo)(e => {
                let {
                    selected: t,
                    onChange: a,
                    multiSelect: l = !0
                } = e, s = e => void 0 === e ? void 0 === t || Array.isArray(t) && 0 === t.length : l ? Array.isArray(t) && t.includes(e) : t === e, r = e => {
                    if (void 0 === e) return void a(void 0);
                    if (l) {
                        let n = t || [];
                        n.includes(e) ? 1 === n.length ? a([...c.bS]) : a(n.filter(t => t !== e)) : a([...n, e])
                    } else a(e)
                };
                return (0, n.jsxs)("div", {
                    className: "p-1 flex flex-col gap-1",
                    "data-sentry-component": "CabinPicker",
                    "data-sentry-source-file": "CabinPicker.tsx",
                    children: [(0, n.jsx)("button", {
                        onClick: () => r(void 0),
                        className: "w-full text-left px-3 py-1.5 text-xs rounded-md hidden ".concat(s(void 0) ? "bg-white/10 text-white" : "text-white/70 hover:bg-white/5"),
                        children: u(void 0)
                    }), c.bS.map(e => (0, n.jsx)("button", {
                        onClick: () => r(e),
                        className: "w-full text-left px-3 py-1.5 text-xs rounded-md ".concat(s(e) ? "bg-white/10 text-white" : "text-white/70 hover:bg-white/5"),
                        children: u(e)
                    }, e))]
                })
            });
            var g = a(64269);
            let m = e => {
                let {
                    size: t = "small",
                    mode: a,
                    passengers: o,
                    onPassengersChange: c,
                    selectedCabin: m,
                    onCabinChange: p,
                    isExpanded: x,
                    handleChangeMode: f
                } = e, [y, b] = (0, l.useState)(null), v = e => {
                    f(e), b(null)
                }, w = o.adults + o.children + o.infants, N = u(m);
                return (0, n.jsxs)("div", {
                    className: "grid grid-cols-3 gap-2 px-1 transition-all duration-200 ".concat(x ? "h-8 opacity-100" : "h-0 opacity-0"),
                    "data-sentry-component": "TripOptionsBar",
                    "data-sentry-source-file": "TripOptionsBar.tsx",
                    children: [(0, n.jsx)("div", {
                        className: "relative flex justify-center",
                        children: (0, n.jsxs)(i.AM, {
                            open: "mode" === y,
                            onOpenChange: e => b(e ? "mode" : null),
                            "data-sentry-element": "Popover",
                            "data-sentry-source-file": "TripOptionsBar.tsx",
                            children: [(0, n.jsx)(i.Wv, {
                                asChild: !0,
                                "data-sentry-element": "PopoverTrigger",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: (0, n.jsxs)("button", {
                                    className: (0, g.cn)("flex items-center justify-between w-28 px-2 py-1 rounded-md text-white/70 hover:bg-white/5", "small" === t ? "text-xs" : "text-sm"),
                                    children: [(0, n.jsx)("span", {
                                        className: "truncate",
                                        children: "oneWay" === a ? "One Way" : "Round Trip"
                                    }), (0, n.jsx)(s.A, {
                                        className: "w-3 h-3 flex-shrink-0 ml-1",
                                        "data-sentry-element": "ChevronDown",
                                        "data-sentry-source-file": "TripOptionsBar.tsx"
                                    })]
                                })
                            }), (0, n.jsxs)(i.hl, {
                                className: "w-32 p-1 bg-[#101010] backdrop-blur-xl border border-[#636363]/60 rounded-lg shadow-lg",
                                "data-sentry-element": "PopoverContent",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: [(0, n.jsx)("button", {
                                    onClick: () => {
                                        v("oneWay"), b(null)
                                    },
                                    className: (0, g.cn)("w-full text-left px-3 py-1.5 text-xs rounded-md", "oneWay" === a ? "bg-white/10 text-white" : "text-white/70 hover:bg-white/5"),
                                    children: "One Way"
                                }), (0, n.jsx)("button", {
                                    onClick: () => {
                                        v("roundTrip"), b(null)
                                    },
                                    className: (0, g.cn)("w-full text-left px-3 py-1.5 text-xs rounded-md", "roundTrip" === a ? "bg-white/10 text-white" : "text-white/70 hover:bg-white/5"),
                                    children: "Round Trip"
                                })]
                            })]
                        })
                    }), (0, n.jsx)("div", {
                        className: "relative flex justify-center",
                        children: (0, n.jsxs)(i.AM, {
                            open: "passengers" === y,
                            onOpenChange: e => b(e ? "passengers" : null),
                            "data-sentry-element": "Popover",
                            "data-sentry-source-file": "TripOptionsBar.tsx",
                            children: [(0, n.jsx)(i.Wv, {
                                asChild: !0,
                                "data-sentry-element": "PopoverTrigger",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: (0, n.jsxs)("button", {
                                    className: (0, g.cn)("flex items-center justify-between w-28 px-2 py-1 rounded-md text-white/70 hover:bg-white/5", "small" === t ? "text-xs" : "text-sm"),
                                    children: [(0, n.jsxs)("span", {
                                        className: "truncate",
                                        children: [w, " Passenger", 1 !== w ? "s" : ""]
                                    }), (0, n.jsx)(r.A, {
                                        className: "w-3 h-3 flex-shrink-0 ml-1",
                                        "data-sentry-element": "ChevronsUpDown",
                                        "data-sentry-source-file": "TripOptionsBar.tsx"
                                    })]
                                })
                            }), (0, n.jsx)(i.hl, {
                                className: "p-0 bg-[#101010] backdrop-blur-xl border border-[#636363]/60 rounded-lg shadow-lg",
                                "data-sentry-element": "PopoverContent",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: (0, n.jsx)(d, {
                                    passengers: o,
                                    onChange: c,
                                    "data-sentry-element": "PassengerPicker",
                                    "data-sentry-source-file": "TripOptionsBar.tsx"
                                })
                            })]
                        })
                    }), (0, n.jsx)("div", {
                        className: "relative flex justify-center",
                        children: (0, n.jsxs)(i.AM, {
                            open: "cabins" === y,
                            onOpenChange: e => b(e ? "cabins" : null),
                            "data-sentry-element": "Popover",
                            "data-sentry-source-file": "TripOptionsBar.tsx",
                            children: [(0, n.jsx)(i.Wv, {
                                asChild: !0,
                                "data-sentry-element": "PopoverTrigger",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: (0, n.jsxs)("button", {
                                    className: (0, g.cn)("flex items-center justify-between w-28 px-2 py-1 rounded-md text-white/70 hover:bg-white/5", "small" === t ? "text-xs" : "text-sm"),
                                    children: [(0, n.jsx)("span", {
                                        className: "truncate",
                                        children: N
                                    }), (0, n.jsx)(s.A, {
                                        className: "w-3 h-3 flex-shrink-0 ml-1",
                                        "data-sentry-element": "ChevronDown",
                                        "data-sentry-source-file": "TripOptionsBar.tsx"
                                    })]
                                })
                            }), (0, n.jsx)(i.hl, {
                                className: "w-44 p-0 bg-[#101010] backdrop-blur-xl border border-[#636363]/60 rounded-lg shadow-lg",
                                "data-sentry-element": "PopoverContent",
                                "data-sentry-source-file": "TripOptionsBar.tsx",
                                children: (0, n.jsx)(h, {
                                    selected: m,
                                    onChange: e => {
                                        Array.isArray(e) ? p(e[0]) : p(e), b(null)
                                    },
                                    multiSelect: !1,
                                    "data-sentry-element": "CabinPicker",
                                    "data-sentry-source-file": "TripOptionsBar.tsx"
                                })
                            })]
                        })
                    })]
                })
            }
        },
        89402: (e, t, a) => {
            a.d(t, {
                K9: () => h,
                e1: () => g,
                Ps: () => u
            });
            var n = a(95125),
                l = a(15653);
            let s = l.z.preprocess(e => {
                    if ("string" == typeof e) {
                        if (["1", "true"].includes(e.toLowerCase())) return !0;
                        if (["0", "false"].includes(e.toLowerCase())) return !1
                    }
                    return e
                }, l.z.coerce.boolean()),
                r = l.z.object({
                    id: l.z.string(),
                    municipality: l.z.string().nullable(),
                    iata_code: l.z.string(),
                    image_url: l.z.string().nullable(),
                    name: l.z.string(),
                    latitude_deg: l.z.number().nullish(),
                    longitude_deg: l.z.number().nullish(),
                    iso_country: l.z.string()
                }),
                i = l.z.object({
                    airports: l.z.array(r),
                    page: l.z.coerce.number(),
                    totalCount: l.z.coerce.number()
                });
            l.z.object({
                query: l.z.string().optional(),
                page: l.z.coerce.number().positive().default(1),
                size: l.z.coerce.number().positive().default(10),
                withCoordinates: s.default(!1),
                exact: s.default(!1),
                sort: l.z.enum(["image_url", "name"]).nullish().default(null)
            });
            let o = l.z.enum(["city", "region"]),
                d = l.z.object({
                    id: l.z.string(),
                    type: o,
                    name: l.z.string(),
                    coordinates: l.z.union([l.z.tuple([l.z.number(), l.z.number()]), l.z.string(), l.z.null()]),
                    code: l.z.string(),
                    image_url: l.z.string().nullable()
                });
            l.z.object({
                query: l.z.string().optional(),
                page: l.z.coerce.number().positive().default(1),
                size: l.z.coerce.number().positive().default(10),
                type: o.optional(),
                withCoordinates: s.default(!1),
                exact: s.optional().default(!1)
            });
            let c = l.z.object({
                    groups: l.z.array(d),
                    page: l.z.coerce.number(),
                    totalCount: l.z.coerce.number()
                }),
                u = async function(e, t) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 20,
                        l = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                        s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : null,
                        o = await n.A.get("/api/airports", {
                            params: {
                                page: t,
                                query: e,
                                size: a,
                                withCoordinates: l,
                                exact: s,
                                sort: r
                            }
                        });
                    return i.parse(o.data.data)
                },
                h = async function(e) {
                    let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    if (!t) {
                        let t = await u(e, 1, 1, !0, !0);
                        if (t.airports[0]) return t.airports[0]
                    }
                    let a = await g(e, 1, 1, !0, !0);
                    if (a.groups[0]) {
                        let e = a.groups[0],
                            [t, n] = null === e.coordinates ? [null, null] : Array.isArray(e.coordinates) ? e.coordinates : e.coordinates.slice(1, -1).split(",").map(Number);
                        return { ...e,
                            municipality: e.name,
                            iata_code: e.code,
                            iso_country: "",
                            latitude_deg: t,
                            longitude_deg: n,
                            type: e.type
                        }
                    }
                    if (t) {
                        let t = await u(e, 1, 1, !0, !0);
                        if (t.airports[0]) return t.airports[0]
                    }
                    return null
                },
                g = async function(e, t) {
                    let a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 20,
                        l = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                        s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        r = await n.A.get("/api/airports/groups", {
                            params: {
                                page: t,
                                query: e,
                                size: a,
                                withCoordinates: l,
                                exact: s
                            }
                        });
                    return c.parse(r.data.data)
                }
        },
        89568: (e, t, a) => {
            a.d(t, {
                A: () => r
            });
            var n = a(95155),
                l = a(12115),
                s = a(64269);
            let r = e => {
                let {
                    variant: t = "default",
                    selected: a,
                    onSelect: r,
                    onFocus: i
                } = e, o = (0, l.useCallback)(e => {
                    i(), r(e)
                }, [i, r]);
                return (0, n.jsxs)("div", {
                    className: (0, s.cn)("relative", "mobile" === t ? "" : "px-3 py-1.5"),
                    "data-sentry-component": "PaymentSelector",
                    "data-sentry-source-file": "PaymentSelector.tsx",
                    children: [(0, n.jsx)("div", {
                        className: (0, s.cn)("uppercase text-white/40 leading-none mb-0.5", "mobile" === t ? "text-xs mb-2" : "text-[10px]"),
                        children: "Payment"
                    }), (0, n.jsxs)("div", {
                        className: "flex items-center rounded-full relative border border-white/10 h-10 sm:h-7 w-full sm:w-[140px]",
                        onClick: i,
                        role: "tablist",
                        "aria-label": "Payment type selector",
                        children: [(0, n.jsx)("div", {
                            className: (0, s.cn)("absolute top-0 left-0 w-1/2 h-full rounded-full transition-transform duration-300 ease-in-out", "miles" === a ? "translate-x-0" : "translate-x-full"),
                            style: {
                                background: "linear-gradient(90deg, #464646 0%, #333333 28%, #9C9C9C 66%, #464646 100%)",
                                padding: "1px"
                            },
                            "aria-hidden": "true",
                            children: (0, n.jsx)("div", {
                                className: "w-full h-full bg-[#1A1A1A] rounded-full"
                            })
                        }), (0, n.jsx)("button", {
                            type: "button",
                            role: "tab",
                            id: "miles-tab",
                            "aria-selected": "miles" === a,
                            "aria-controls": "miles-panel",
                            onClick: () => o("miles"),
                            className: (0, s.cn)("relative z-10 w-1/2 px-3 py-1 rounded-full text-center transition-colors duration-200", "mobile" === t ? "text-sm" : "text-xs", "miles" === a ? "text-white" : "text-white/40 hover:text-white/80"),
                            children: "Miles"
                        }), (0, n.jsx)("button", {
                            type: "button",
                            role: "tab",
                            id: "cash-tab",
                            "aria-selected": "cash" === a,
                            "aria-controls": "cash-panel",
                            onClick: () => o("cash"),
                            className: (0, s.cn)("relative z-10 w-1/2 px-3 py-1 rounded-full text-center transition-colors duration-200", "mobile" === t ? "text-sm" : "text-xs", "cash" === a ? "text-white" : "text-white/40 hover:text-white/80"),
                            children: "Cash"
                        })]
                    })]
                })
            }
        },
        94523: (e, t, a) => {
            a.d(t, {
                Wb: () => r,
                kk: () => l,
                mp: () => s
            });
            var n = a(35918);
            let l = e => {
                    let t = new URLSearchParams;
                    return e.origin && t.set("origin", e.origin), e.destination && t.set("destination", e.destination), e.start_date && t.set("start_date", e.start_date), e.end_date && t.set("end_date", e.end_date), e.return_date && t.set("return_date", e.return_date), e.cabin && t.set("cabin", e.cabin), e.adults && t.set("adults", e.adults.toString()), e.children && t.set("children", e.children.toString()), e.infants && t.set("infants", e.infants.toString()), e.departingFlightId && t.set("departingFlightId", e.departingFlightId), e.returningFlightId && t.set("returningFlightId", e.returningFlightId), e.payment && t.set("payment", e.payment), t.toString()
                },
                s = function(e) {
                    var t, a, l, s, r, i, o, d, c, u, h, g, m, p;
                    let x = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        f = new URLSearchParams;
                    if ("flights" === e.tab) {
                        if (f = new URLSearchParams({
                                origin: null != (l = null == (t = e.origin) ? void 0 : t.code) ? l : "",
                                destination: null != (s = null == (a = e.destination) ? void 0 : a.code) ? s : "",
                                cabin: e.cabin || "economy",
                                adults: e.passengers.adults.toString(),
                                children: e.passengers.children.toString(),
                                infants: e.passengers.infants.toString(),
                                payment: e.paymentType,
                                start_date: ""
                            }), e.dates.startDate && f.set("start_date", new Date(e.dates.startDate.getTime() - 6e4 * e.dates.startDate.getTimezoneOffset()).toISOString().split("T")[0]), e.returnDate ? f.set("return_date", new Date(e.returnDate.getTime() - 6e4 * e.returnDate.getTimezoneOffset()).toISOString().split("T")[0]) : e.dates.endDate && f.set("end_date", new Date(e.dates.endDate.getTime() - 6e4 * e.dates.endDate.getTimezoneOffset()).toISOString().split("T")[0]), e.departingFlightId && f.set("departingFlightId", e.departingFlightId), e.returningFlightId && f.set("returningFlightId", e.returningFlightId), "cash" === e.paymentType) return "/search/flights/cash?".concat(f.toString())
                    } else if ("hotels" === e.tab) {
                        let t = (0, n.z4)((null == (r = e.hotelDestination) ? void 0 : r.rooms) || []);
                        if (f = new URLSearchParams({
                                destination: (null == (i = e.hotelDestination) ? void 0 : i.placeId) || "",
                                checkin: (null == (o = e.hotelDestination) ? void 0 : o.checkIn) ? new Date(e.hotelDestination.checkIn.getTime() - 6e4 * e.hotelDestination.checkIn.getTimezoneOffset()).toISOString().split("T")[0] : "",
                                checkout: (null == (d = e.hotelDestination) ? void 0 : d.checkOut) ? new Date(e.hotelDestination.checkOut.getTime() - 6e4 * e.hotelDestination.checkOut.getTimezoneOffset()).toISOString().split("T")[0] : "",
                                rooms: t,
                                nationality: (null == (c = e.hotelDestination) ? void 0 : c.guestNationality) || "",
                                currency: (null == (u = e.hotelDestination) ? void 0 : u.currency) || "",
                                coordinates: (null == (h = e.hotelDestination) ? void 0 : h.location) ? (0, n.SF)(e.hotelDestination.location) : "",
                                search_name: (null == (g = e.hotelDestination) ? void 0 : g.displayName) || "",
                                ...(null == (m = e.hotelDestination) ? void 0 : m.filters) ? {
                                    filters: JSON.stringify(e.hotelDestination.filters)
                                } : {
                                    filters: JSON.stringify({
                                        hotelName: "",
                                        facilities: [],
                                        guestRating: 0,
                                        propertyRating: [],
                                        types: [],
                                        sorting: "1",
                                        cancellation: "all",
                                        meals: void 0,
                                        priceRange: void 0
                                    })
                                }
                            }), x.toHotelDetail) return "/search/hotels/".concat(null == (p = e.hotelDestination) ? void 0 : p.placeId, "?").concat(f.toString())
                    }
                    return "/search/".concat(e.tab, "?").concat(f.toString())
                },
                r = (e, t) => {
                    let a = e.slices[0],
                        n = new URLSearchParams({
                            origin: a.segments[0].origin.iata_code || "",
                            destination: a.segments[a.segments.length - 1].destination.iata_code || "",
                            start_date: a.segments[0].departing_at || "",
                            cabin: e.slices[0].segments[0].passengers[0].cabin_class || "",
                            adults: e.passengers.filter(e => "adult" === e.type).length.toString(),
                            children: e.passengers.filter(e => "child" === e.type).length.toString(),
                            infants: e.passengers.filter(e => "child" === e.type && 0 === e.age).length.toString(),
                            payment: t
                        });
                    if (e.slices.length > 1) {
                        let t = e.slices[1].segments[0].departing_at || "";
                        t && n.set("return_date", t.split("T")[0])
                    }
                    return e.slices[0].segments[0].departing_at && n.set("start_date", e.slices[0].segments[0].departing_at.split("T")[0]), "/search/flights".concat("cash" === t ? "/cash" : "", "?").concat(n.toString())
                }
        }
    }
]);