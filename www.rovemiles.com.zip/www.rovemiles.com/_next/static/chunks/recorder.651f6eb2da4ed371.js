! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "800a89a7-e5b1-4b6a-91c4-946a4fe4b7f2", e._sentryDebugIdIdentifier = "sentry-dbid-800a89a7-e5b1-4b6a-91c4-946a4fe4b7f2")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9777], {
        22484: (e, t, n) => {
            n.r(t), n.d(t, {
                startRecording: () => et
            });
            var r = n(45350),
                o = n(85520),
                i = n(88647),
                a = n(47884),
                s = n(82120),
                l = n(98595),
                u = n(11696),
                c = n(40176),
                d = n(91625);
            let p = new WeakMap;

            function f(e) {
                return p.has(e)
            }

            function h(e) {
                return p.get(e)
            }

            function m(e, t) {
                let n = e.tagName,
                    r = e.value;
                if ((0, d.Ie)(e, t)) {
                    let t = e.type;
                    if ("INPUT" === n && ("button" === t || "submit" === t || "reset" === t)) return r;
                    if (!r || "OPTION" === n) return;
                    return d.o
                }
                return "OPTION" === n || "SELECT" === n ? e.value : "INPUT" === n || "TEXTAREA" === n ? r : void 0
            }
            let y = /url\((?:(')([^']*)'|(")([^"]*)"|([^)]*))\)/gm,
                g = /^[A-Za-z]+:|^\/\//,
                v = /^data:.*,/i,
                w = /[^a-z1-6-_]/;

            function S(e) {
                let t = e.toLowerCase().trim();
                return w.test(t) ? "div" : t
            }

            function E(e, t) {
                return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='${e}' height='${t}' style='background-color:silver'%3E%3C/svg%3E`
            }
            let b = {
                    FullSnapshot: 2,
                    IncrementalSnapshot: 3,
                    Meta: 4,
                    Focus: 6,
                    ViewEnd: 7,
                    VisualViewport: 8,
                    FrustrationRecord: 9
                },
                N = {
                    Document: 0,
                    DocumentType: 1,
                    Element: 2,
                    Text: 3,
                    CDATA: 4,
                    DocumentFragment: 11
                },
                T = {
                    Mutation: 0,
                    MouseMove: 1,
                    MouseInteraction: 2,
                    Scroll: 3,
                    ViewportResize: 4,
                    Input: 5,
                    TouchMove: 6,
                    MediaInteraction: 7,
                    StyleSheetRule: 8
                },
                I = {
                    MouseUp: 0,
                    MouseDown: 1,
                    Click: 2,
                    ContextMenu: 3,
                    DblClick: 4,
                    Focus: 5,
                    Blur: 6,
                    TouchStart: 7,
                    TouchEnd: 9
                },
                M = {
                    Play: 0,
                    Pause: 1
                };

            function x(e) {
                if (void 0 !== e && 0 !== e.length) return e.map(e => ({
                    cssRules: Array.from(e.cssRules || e.rules, e => e.cssText),
                    disabled: e.disabled || void 0,
                    media: e.media.length > 0 ? Array.from(e.media) : void 0
                }))
            }
            var R = n(30789);

            function C(e, t, n, r) {
                if (t === d.$m.HIDDEN) return null;
                let o = e.getAttribute(n);
                if (t === d.$m.MASK && n !== d.NT && !d.yF.includes(n) && n !== r.actionNameAttribute) {
                    let t = e.tagName;
                    switch (n) {
                        case "title":
                        case "alt":
                        case "placeholder":
                            return d.o
                    }
                    if ("IMG" === t && ("src" === n || "srcset" === n)) {
                        if (e.naturalWidth > 0) return E(e.naturalWidth, e.naturalHeight);
                        let {
                            width: t,
                            height: n
                        } = e.getBoundingClientRect();
                        return t > 0 || n > 0 ? E(t, n) : d.eT
                    }
                    if ("SOURCE" === t && ("src" === n || "srcset" === n)) return d.eT;
                    if ("A" === t && "href" === n || o && n.startsWith("data-") || "IFRAME" === t && "srcdoc" === n) return d.o
                }
                return o && "string" == typeof o && (0, d.YR)(o) ? (0, d.jK)(o) : o
            }

            function D(e) {
                var t, n;
                let r;
                if (!e) return null;
                try {
                    r = e.rules || e.cssRules
                } catch (e) {}
                return r ? (t = Array.from(r, (0, R.nr)() ? _ : L).join(""), n = e.href, t.replace(y, (e, t, r, o, i, a) => {
                    let s = r || i || a;
                    if (!n || !s || g.test(s) || v.test(s)) return e;
                    let l = t || o || "";
                    return `url(${l}${function(e,t){try{return(0,c.c$)(e,t).href}catch(t){return e}}(s,n)}${l})`
                })) : null
            }

            function _(e) {
                return "selectorText" in e && e.selectorText.includes(":") ? e.cssText.replace(/(\[[\w-]+[^\\])(:[^\]]+\])/g, "$1\\$2") : L(e)
            }

            function L(e) {
                return "styleSheet" in e && D(e.styleSheet) || e.cssText
            }

            function O(e, t) {
                let n = function(e, t) {
                    switch (e.nodeType) {
                        case e.DOCUMENT_NODE:
                            return n = e, r = t, {
                                type: N.Document,
                                childNodes: k(n, r),
                                adoptedStyleSheets: x(n.adoptedStyleSheets)
                            };
                        case e.DOCUMENT_FRAGMENT_NODE:
                            var n, r, o, i = e,
                                a = t;
                            let s = (0, d.p_)(i);
                            return s && a.serializationContext.shadowRootsController.addShadowRoot(i), {
                                type: N.DocumentFragment,
                                childNodes: k(i, a),
                                isShadowRoot: s,
                                adoptedStyleSheets: s ? x(i.adoptedStyleSheets) : void 0
                            };
                        case e.DOCUMENT_TYPE_NODE:
                            return o = e, {
                                type: N.DocumentType,
                                name: o.name,
                                publicId: o.publicId,
                                systemId: o.systemId
                            };
                        case e.ELEMENT_NODE:
                            return function(e, t) {
                                var n;
                                let r = S(e.tagName),
                                    o = "svg" === (n = e).tagName || n instanceof SVGElement || void 0,
                                    i = (0, d.jR)((0, d.dT)(e), t.parentNodePrivacyLevel);
                                if (i === d.$m.HIDDEN) {
                                    let {
                                        width: t,
                                        height: n
                                    } = e.getBoundingClientRect();
                                    return {
                                        type: N.Element,
                                        tagName: r,
                                        attributes: {
                                            rr_width: `${t}px`,
                                            rr_height: `${n}px`,
                                            [d.NT]: d.Wd
                                        },
                                        childNodes: [],
                                        isSVG: o
                                    }
                                }
                                if (i === d.$m.IGNORE) return;
                                let a = function(e, t, n) {
                                        let r, o;
                                        if (t === d.$m.HIDDEN) return {};
                                        let i = {},
                                            a = S(e.tagName),
                                            s = e.ownerDocument;
                                        for (let r = 0; r < e.attributes.length; r += 1) {
                                            let o = e.attributes.item(r).name,
                                                a = C(e, t, o, n.configuration);
                                            null !== a && (i[o] = a)
                                        }
                                        if (e.value && ("textarea" === a || "select" === a || "option" === a || "input" === a)) {
                                            let n = m(e, t);
                                            void 0 !== n && (i.value = n)
                                        }
                                        if ("option" === a && t === d.$m.ALLOW && e.selected && (i.selected = e.selected), "link" === a) {
                                            let t = Array.from(s.styleSheets).find(t => t.href === e.href),
                                                n = D(t);
                                            n && t && (i._cssText = n)
                                        }
                                        if ("style" === a && e.sheet) {
                                            let t = D(e.sheet);
                                            t && (i._cssText = t)
                                        }
                                        "input" === a && ("radio" === e.type || "checkbox" === e.type) && (t === d.$m.ALLOW ? i.checked = !!e.checked : (0, d.Ie)(e, t) && delete i.checked), ("audio" === a || "video" === a) && (i.rr_mediaState = e.paused ? "paused" : "played");
                                        let l = n.serializationContext;
                                        switch (l.status) {
                                            case 0:
                                                r = Math.round(e.scrollTop), o = Math.round(e.scrollLeft), (r || o) && l.elementsScrollPositions.set(e, {
                                                    scrollTop: r,
                                                    scrollLeft: o
                                                });
                                                break;
                                            case 1:
                                                l.elementsScrollPositions.has(e) && ({
                                                    scrollTop: r,
                                                    scrollLeft: o
                                                } = l.elementsScrollPositions.get(e))
                                        }
                                        return o && (i.rr_scrollLeft = o), r && (i.rr_scrollTop = r), i
                                    }(e, i, t),
                                    s = [];
                                if ((0, d.wR)(e) && "style" !== r) {
                                    let n;
                                    s = k(e, t.parentNodePrivacyLevel === i && t.ignoreWhiteSpace === ("head" === r) ? t : { ...t,
                                        parentNodePrivacyLevel: i,
                                        ignoreWhiteSpace: "head" === r
                                    })
                                }
                                return {
                                    type: N.Element,
                                    tagName: r,
                                    attributes: a,
                                    childNodes: s,
                                    isSVG: o
                                }
                            }(e, t);
                        case e.TEXT_NODE:
                            var l = e,
                                u = t;
                            let c = (0, d.rf)(l, u.ignoreWhiteSpace || !1, u.parentNodePrivacyLevel);
                            if (void 0 !== c) return {
                                type: N.Text,
                                textContent: c
                            };
                            return;
                        case e.CDATA_SECTION_NODE:
                            return {
                                type: N.CDATA,
                                textContent: ""
                            }
                    }
                }(e, t);
                if (!n) return null;
                let r = h(e) || P++;
                return n.id = r, p.set(e, r), t.serializedNodeIds && t.serializedNodeIds.add(r), n
            }
            let P = 1;

            function k(e, t) {
                let n = [];
                return (0, d.wI)(e, e => {
                    let r = O(e, t);
                    r && n.push(r)
                }), n
            }

            function $(e) {
                return !!e.changedTouches
            }

            function A(e) {
                return !0 === e.composed && (0, d.XS)(e.target) ? e.composedPath()[0] : e.target
            }
            let V = (e, t) => {
                    let n = window.visualViewport,
                        r = {
                            layoutViewportX: e,
                            layoutViewportY: t,
                            visualViewportX: e,
                            visualViewportY: t
                        };
                    return n && (! function(e) {
                        return Math.abs(e.pageTop - e.offsetTop - window.scrollY) > 25 || Math.abs(e.pageLeft - e.offsetLeft - window.scrollX) > 25
                    }(n) ? (r.visualViewportX = Math.round(e - n.offsetLeft), r.visualViewportY = Math.round(t - n.offsetTop)) : (r.layoutViewportX = Math.round(e + n.offsetLeft), r.layoutViewportY = Math.round(t + n.offsetTop))), r
                },
                F = e => ({
                    scale: e.scale,
                    offsetLeft: e.offsetLeft,
                    offsetTop: e.offsetTop,
                    pageLeft: e.pageLeft,
                    pageTop: e.pageTop,
                    height: e.height,
                    width: e.width
                });
            var H = n(26664);

            function z(e, t) {
                return {
                    data: {
                        source: e,
                        ...t
                    },
                    type: b.IncrementalSnapshot,
                    timestamp: (0, H.nx)()
                }
            }

            function W(e) {
                let {
                    clientX: t,
                    clientY: n
                } = $(e) ? e.changedTouches[0] : e;
                if (window.visualViewport) {
                    let {
                        visualViewportX: e,
                        visualViewportY: r
                    } = V(t, n);
                    t = e, n = r
                }
                if (!Number.isFinite(t) || !Number.isFinite(n)) {
                    e.isTrusted && (0, r.A2)("mouse/touch event without x/y");
                    return
                }
                return {
                    x: t,
                    y: n
                }
            }
            let B = {
                pointerup: I.MouseUp,
                mousedown: I.MouseDown,
                click: I.Click,
                contextmenu: I.ContextMenu,
                dblclick: I.DblClick,
                focus: I.Focus,
                blur: I.Blur,
                touchstart: I.TouchStart,
                touchend: I.TouchEnd
            };

            function G(e, t, n, r = document) {
                let {
                    throttled: o,
                    cancel: i
                } = (0, l.n)(r => {
                    let o = A(r);
                    if (!o || (0, d.PJ)(o, e.defaultPrivacyLevel) === d.$m.HIDDEN || !f(o)) return;
                    let i = h(o),
                        a = o === document ? {
                            scrollTop: (0, d.zL)(),
                            scrollLeft: (0, d.Gn)()
                        } : {
                            scrollTop: Math.round(o.scrollTop),
                            scrollLeft: Math.round(o.scrollLeft)
                        };
                    n.set(o, a), t(z(T.Scroll, {
                        id: i,
                        x: a.scrollLeft,
                        y: a.scrollTop
                    }))
                }, 100), {
                    stop: a
                } = (0, u.q)(e, r, "scroll", o, {
                    capture: !0,
                    passive: !0
                });
                return {
                    stop: () => {
                        a(), i()
                    }
                }
            }
            var J = n(21096);

            function U(e) {
                let t = [],
                    n = e;
                for (; n.parentRule;) {
                    let e = Array.from(n.parentRule.cssRules).indexOf(n);
                    t.unshift(e), n = n.parentRule
                }
                if (!n.parentStyleSheet) return;
                let r = Array.from(n.parentStyleSheet.cssRules).indexOf(n);
                return t.unshift(r), t
            }

            function Y(e, t, n = document) {
                let r, o = e.defaultPrivacyLevel,
                    i = new WeakMap,
                    a = n !== document,
                    {
                        stop: s
                    } = (0, u.l)(e, n, a ? ["change"] : ["input", "change"], e => {
                        let t = A(e);
                        (t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement || t instanceof HTMLSelectElement) && c(t)
                    }, {
                        capture: !0,
                        passive: !0
                    });
                if (a) r = l.l;
                else {
                    let e = [(0, J.t)(HTMLInputElement.prototype, "value", c), (0, J.t)(HTMLInputElement.prototype, "checked", c), (0, J.t)(HTMLSelectElement.prototype, "value", c), (0, J.t)(HTMLTextAreaElement.prototype, "value", c), (0, J.t)(HTMLSelectElement.prototype, "selectedIndex", c)];
                    r = () => {
                        e.forEach(e => e.stop())
                    }
                }
                return {
                    stop: () => {
                        r(), s()
                    }
                };

                function c(e) {
                    let t, n = (0, d.PJ)(e, o);
                    if (n === d.$m.HIDDEN) return;
                    let r = e.type;
                    if ("radio" === r || "checkbox" === r) {
                        if ((0, d.Ie)(e, n)) return;
                        t = {
                            isChecked: e.checked
                        }
                    } else {
                        let r = m(e, n);
                        if (void 0 === r) return;
                        t = {
                            text: r
                        }
                    }
                    p(e, t);
                    let i = e.name;
                    "radio" === r && i && e.checked && document.querySelectorAll(`input[type="radio"][name="${CSS.escape(i)}"]`).forEach(t => {
                        t !== e && p(t, {
                            isChecked: !1
                        })
                    })
                }

                function p(e, n) {
                    if (!f(e)) return;
                    let r = i.get(e);
                    r && r.text === n.text && r.isChecked === n.isChecked || (i.set(e, n), t(z(T.Input, {
                        id: h(e),
                        ...n
                    })))
                }
            }
            var X = n(85590),
                j = n(98020);

            function K(e, t, n, r) {
                let o = (0, d.W3)();
                if (!o) return {
                    stop: l.l,
                    flush: l.l
                };
                let i = function(e) {
                        let t = l.l,
                            n = [];

                        function r() {
                            t(), e(n), n = []
                        }
                        let {
                            throttled: o,
                            cancel: i
                        } = (0, l.n)(r, 16, {
                            leading: !1
                        });
                        return {
                            addMutations: e => {
                                0 === n.length && (t = (0, j.BB)(o, {
                                    timeout: 100
                                })), n.push(...e)
                            },
                            flush: r,
                            stop: () => {
                                t(), i()
                            }
                        }
                    }(r => {
                        ! function(e, t, n, r) {
                            let o = new Map;
                            e.filter(e => "childList" === e.type).forEach(e => {
                                e.removedNodes.forEach(e => {
                                    ! function e(t, n) {
                                        (0, d.XS)(t) && n(t.shadowRoot), (0, d.wI)(t, t => e(t, n))
                                    }(e, r.removeShadowRoot)
                                })
                            });
                            let i = e.filter(e => e.target.isConnected && function(e) {
                                    let t = e;
                                    for (; t;) {
                                        if (!f(t) && !(0, d.p_)(t)) return !1;
                                        t = (0, d.$4)(t)
                                    }
                                    return !0
                                }(e.target) && (0, d.PJ)(e.target, n.defaultPrivacyLevel, o) !== d.$m.HIDDEN),
                                {
                                    adds: a,
                                    removes: s,
                                    hasBeenSerialized: l
                                } = function(e, t, n, r) {
                                    let o = new Set,
                                        i = new Map;
                                    for (let t of e) t.addedNodes.forEach(e => {
                                        o.add(e)
                                    }), t.removedNodes.forEach(e => {
                                        o.has(e) || i.set(e, t.target), o.delete(e)
                                    });
                                    let a = Array.from(o);
                                    a.sort((e, t) => {
                                        let n = e.compareDocumentPosition(t);
                                        return n & Node.DOCUMENT_POSITION_CONTAINED_BY ? -1 : n & Node.DOCUMENT_POSITION_CONTAINS ? 1 : n & Node.DOCUMENT_POSITION_FOLLOWING ? 1 : n & Node.DOCUMENT_POSITION_PRECEDING ? -1 : 0
                                    });
                                    let s = new Set,
                                        l = [];
                                    for (let e of a) {
                                        if (c(e)) continue;
                                        let o = (0, d.PJ)(e.parentNode, t.defaultPrivacyLevel, r);
                                        if (o === d.$m.HIDDEN || o === d.$m.IGNORE) continue;
                                        let i = O(e, {
                                            serializedNodeIds: s,
                                            parentNodePrivacyLevel: o,
                                            serializationContext: {
                                                status: 2,
                                                shadowRootsController: n
                                            },
                                            configuration: t
                                        });
                                        if (!i) continue;
                                        let a = (0, d.$4)(e);
                                        l.push({
                                            nextId: function(e) {
                                                let t = e.nextSibling;
                                                for (; t;) {
                                                    if (f(t)) return h(t);
                                                    t = t.nextSibling
                                                }
                                                return null
                                            }(e),
                                            parentId: h(a),
                                            node: i
                                        })
                                    }
                                    let u = [];
                                    return i.forEach((e, t) => {
                                        f(t) && u.push({
                                            parentId: h(e),
                                            id: h(t)
                                        })
                                    }), {
                                        adds: l,
                                        removes: u,
                                        hasBeenSerialized: c
                                    };

                                    function c(e) {
                                        return f(e) && s.has(h(e))
                                    }
                                }(i.filter(e => "childList" === e.type), n, r, o),
                                u = function(e, t, n) {
                                    var r;
                                    let o = [],
                                        i = new Set;
                                    for (let a of e.filter(e => !i.has(e.target) && (i.add(e.target), !0))) {
                                        if (a.target.textContent === a.oldValue) continue;
                                        let e = (0, d.PJ)((0, d.$4)(a.target), t.defaultPrivacyLevel, n);
                                        e !== d.$m.HIDDEN && e !== d.$m.IGNORE && o.push({
                                            id: h(a.target),
                                            value: null != (r = (0, d.rf)(a.target, !1, e)) ? r : null
                                        })
                                    }
                                    return o
                                }(i.filter(e => "characterData" === e.type && !l(e.target)), n, o),
                                c = function(e, t, n) {
                                    let r = [],
                                        o = new Map,
                                        i = e.filter(e => {
                                            let t = o.get(e.target);
                                            return !(t && t.has(e.attributeName)) && (t ? t.add(e.attributeName) : o.set(e.target, new Set([e.attributeName])), !0)
                                        }),
                                        a = new Map;
                                    for (let e of i) {
                                        let o;
                                        if (e.target.getAttribute(e.attributeName) === e.oldValue) continue;
                                        let i = (0, d.PJ)(e.target, t.defaultPrivacyLevel, n),
                                            s = C(e.target, i, e.attributeName, t);
                                        if ("value" === e.attributeName) {
                                            let t = m(e.target, i);
                                            if (void 0 === t) continue;
                                            o = t
                                        } else o = "string" == typeof s ? s : null;
                                        let l = a.get(e.target);
                                        l || (l = {
                                            id: h(e.target),
                                            attributes: {}
                                        }, r.push(l), a.set(e.target, l)), l.attributes[e.attributeName] = o
                                    }
                                    return r
                                }(i.filter(e => "attributes" === e.type && !l(e.target)), n, o);
                            (u.length || c.length || s.length || a.length) && t(z(T.Mutation, {
                                adds: a,
                                removes: s,
                                texts: u,
                                attributes: c
                            }))
                        }(r.concat(a.takeRecords()), e, t, n)
                    }),
                    a = new o((0, X.dm)(i.addMutations));
                return a.observe(r, {
                    attributeOldValue: !0,
                    attributes: !0,
                    characterData: !0,
                    characterDataOldValue: !0,
                    childList: !0,
                    subtree: !0
                }), {
                    stop: () => {
                        a.disconnect(), i.stop()
                    },
                    flush: () => {
                        i.flush()
                    }
                }
            }
            let q = (e, t, n) => {
                let r = new Map,
                    o = {
                        addShadowRoot: i => {
                            if (r.has(i)) return;
                            let a = K(t, e, o, i),
                                s = Y(e, t, i),
                                l = G(e, t, n, i);
                            r.set(i, {
                                flush: () => a.flush(),
                                stop: () => {
                                    a.stop(), s.stop(), l.stop()
                                }
                            })
                        },
                        removeShadowRoot: e => {
                            let t = r.get(e);
                            t && (t.stop(), r.delete(e))
                        },
                        stop: () => {
                            r.forEach(({
                                stop: e
                            }) => e())
                        },
                        flush: () => {
                            r.forEach(({
                                flush: e
                            }) => e())
                        }
                    };
                return o
            };
            var Z = n(81154),
                Q = n(94357);
            let ee = 5 * H.OY;

            function et(e, t, n, c, p, m) {
                let y, g = [],
                    v = m || (0, o.sA)(t.sessionReplayEndpointBuilder, 6e4, t => {
                        e.notify(14, {
                            error: t
                        }), (0, r.A2)("Error reported to customer", {
                            "error.message": t.message
                        })
                    });
                if ((0, i.d0)())({
                    addRecord: y
                } = function(e) {
                    let t = (0, i.Y9)();
                    return {
                        addRecord: n => {
                            let r = e.findView();
                            t.send("record", n, r.id)
                        }
                    }
                }(c));
                else {
                    let r = function(e, t, n, r) {
                        let o = {
                                status: 0,
                                nextSegmentCreationReason: "init"
                            },
                            {
                                unsubscribe: i
                            } = e.subscribe(2, () => {
                                l("view_change")
                            }),
                            {
                                unsubscribe: a
                            } = e.subscribe(11, e => {
                                l(e.reason)
                            });

                        function l(e) {
                            1 === o.status && (o.segment.flush((t, r) => {
                                let o = function(e, t, n) {
                                    let r = new FormData;
                                    r.append("segment", new Blob([e], {
                                        type: "application/octet-stream"
                                    }), `${t.session.id}-${t.start}`);
                                    let o = JSON.stringify({
                                        raw_segment_size: n,
                                        compressed_segment_size: e.byteLength,
                                        ...t
                                    });
                                    return r.append("event", new Blob([o], {
                                        type: "application/json"
                                    })), {
                                        data: r,
                                        bytesCount: e.byteLength
                                    }
                                }(r.output, t, r.rawBytesCount);
                                (0, Z.Kp)(e) ? n.sendOnExit(o): n.send(o)
                            }), (0, Q.DJ)(o.expirationTimeoutId)), o = "stop" !== e ? {
                                status: 0,
                                nextSegmentCreationReason: e
                            } : {
                                status: 2
                            }
                        }
                        return {
                            addRecord: e => {
                                if (2 !== o.status) {
                                    if (0 === o.status) {
                                        let e = t();
                                        if (!e) return;
                                        o = {
                                            status: 1,
                                            segment: function({
                                                context: e,
                                                creationReason: t,
                                                encoder: n
                                            }) {
                                                let r = 0,
                                                    o = e.view.id,
                                                    i = {
                                                        start: 1 / 0,
                                                        end: -1 / 0,
                                                        creation_reason: t,
                                                        records_count: 0,
                                                        has_full_snapshot: !1,
                                                        index_in_view: s.K_(o),
                                                        source: "browser",
                                                        ...e
                                                    };
                                                return s.H5(o), {
                                                    addRecord: function(e, t) {
                                                        i.start = Math.min(i.start, e.timestamp), i.end = Math.max(i.end, e.timestamp), i.records_count += 1, i.has_full_snapshot || (i.has_full_snapshot = e.type === b.FullSnapshot);
                                                        let o = n.isEmpty ? '{"records":[' : ",";
                                                        n.write(o + JSON.stringify(e), e => {
                                                            t(r += e)
                                                        })
                                                    },
                                                    flush: function(e) {
                                                        if (n.isEmpty) throw Error("Empty segment flushed");
                                                        n.write(`],${JSON.stringify(i).slice(1)}
`), n.finish(t => {
                                                            s.L7(i.view.id, t.rawBytesCount), e(i, t)
                                                        })
                                                    }
                                                }
                                            }({
                                                encoder: r,
                                                context: e,
                                                creationReason: o.nextSegmentCreationReason
                                            }),
                                            expirationTimeoutId: (0, Q.wg)(() => {
                                                l("segment_duration_limit")
                                            }, ee)
                                        }
                                    }
                                    o.segment.addRecord(e, e => {
                                        e > 6e4 && l("segment_bytes_limit")
                                    })
                                }
                            },
                            stop: () => {
                                l("stop"), i(), a()
                            }
                        }
                    }(e, () => (function(e, t, n) {
                        let r = t.findTrackedSession(),
                            o = n.findView();
                        if (r && o) return {
                            application: {
                                id: e
                            },
                            session: {
                                id: r.id
                            },
                            view: {
                                id: o.id
                            }
                        }
                    })(t.applicationId, n, c), v, p);
                    y = r.addRecord, g.push(r.stop)
                }
                let {
                    stop: w
                } = function(e) {
                    let {
                        emit: t,
                        configuration: n,
                        lifeCycle: r
                    } = e;
                    if (!t) throw Error("emit function is required");
                    let o = n => {
                            t(n), (0, a.b)("record", {
                                record: n
                            });
                            let r = e.viewHistory.findView();
                            s.$1(r.id)
                        },
                        i = function() {
                            let e = new WeakMap;
                            return {
                                set(t, n) {
                                    (t !== document || document.scrollingElement) && e.set(t === document ? document.scrollingElement : t, n)
                                },
                                get: t => e.get(t),
                                has: t => e.has(t)
                            }
                        }(),
                        c = q(n, o, i),
                        {
                            stop: p
                        } = function(e, t, n, r, o, i) {
                            let a = (n = (0, H.nx)(), o = {
                                status: 0,
                                elementsScrollPositions: e,
                                shadowRootsController: t
                            }) => {
                                let {
                                    width: i,
                                    height: a
                                } = (0, d.pB)(), s = [{
                                    data: {
                                        height: a,
                                        href: window.location.href,
                                        width: i
                                    },
                                    type: b.Meta,
                                    timestamp: n
                                }, {
                                    data: {
                                        has_focus: document.hasFocus()
                                    },
                                    type: b.Focus,
                                    timestamp: n
                                }, {
                                    data: {
                                        node: O(document, {
                                            serializationContext: o,
                                            parentNodePrivacyLevel: r.defaultPrivacyLevel,
                                            configuration: r
                                        }),
                                        initialOffset: {
                                            left: (0, d.Gn)(),
                                            top: (0, d.zL)()
                                        }
                                    },
                                    type: b.FullSnapshot,
                                    timestamp: n
                                }];
                                return window.visualViewport && s.push({
                                    data: F(window.visualViewport),
                                    type: b.VisualViewport,
                                    timestamp: n
                                }), s
                            };
                            i(a());
                            let {
                                unsubscribe: s
                            } = n.subscribe(2, n => {
                                o(), i(a(n.startClocks.timeStamp, {
                                    shadowRootsController: t,
                                    status: 1,
                                    elementsScrollPositions: e
                                }))
                            });
                            return {
                                stop: s
                            }
                        }(i, c, r, n, m, e => e.forEach(e => o(e)));

                    function m() {
                        c.flush(), g.flush()
                    }
                    let y = function() {
                            let e = new WeakMap,
                                t = 1;
                            return {
                                getIdForEvent: n => (e.has(n) || e.set(n, t++), e.get(n))
                            }
                        }(),
                        g = K(o, n, c, document),
                        v = [g, function(e, t) {
                            let {
                                throttled: n,
                                cancel: r
                            } = (0, l.n)(e => {
                                let n = A(e);
                                if (f(n)) {
                                    let r = W(e);
                                    if (!r) return;
                                    let o = {
                                        id: h(n),
                                        timeOffset: 0,
                                        x: r.x,
                                        y: r.y
                                    };
                                    t(z($(e) ? T.TouchMove : T.MouseMove, {
                                        positions: [o]
                                    }))
                                }
                            }, 50, {
                                trailing: !1
                            }), {
                                stop: o
                            } = (0, u.l)(e, document, ["mousemove", "touchmove"], n, {
                                capture: !0,
                                passive: !0
                            });
                            return {
                                stop: () => {
                                    o(), r()
                                }
                            }
                        }(n, o), (0, u.l)(n, document, Object.keys(B), e => {
                            let t, r = A(e);
                            if ((0, d.PJ)(r, n.defaultPrivacyLevel) === d.$m.HIDDEN || !f(r)) return;
                            let i = h(r),
                                a = B[e.type];
                            if (a !== I.Blur && a !== I.Focus) {
                                let n = W(e);
                                if (!n) return;
                                t = {
                                    id: i,
                                    type: a,
                                    x: n.x,
                                    y: n.y
                                }
                            } else t = {
                                id: i,
                                type: a
                            };
                            o({
                                id: y.getIdForEvent(e),
                                ...z(T.MouseInteraction, t)
                            })
                        }, {
                            capture: !0,
                            passive: !0
                        }), G(n, o, i, document), function(e, t) {
                            let n = (0, d.g1)(e).subscribe(e => {
                                t(z(T.ViewportResize, e))
                            });
                            return {
                                stop: () => {
                                    n.unsubscribe()
                                }
                            }
                        }(n, o), Y(n, o), (0, u.l)(n, document, ["play", "pause"], e => {
                            let t = A(e);
                            t && (0, d.PJ)(t, n.defaultPrivacyLevel) !== d.$m.HIDDEN && f(t) && o(z(T.MediaInteraction, {
                                id: h(t),
                                type: "play" === e.type ? M.Play : M.Pause
                            }))
                        }, {
                            capture: !0,
                            passive: !0
                        }), function(e) {
                            function t(e, t) {
                                e && f(e.ownerNode) && t(h(e.ownerNode))
                            }
                            let n = [(0, J.H)(CSSStyleSheet.prototype, "insertRule", ({
                                target: n,
                                parameters: [r, o]
                            }) => {
                                t(n, t => e(z(T.StyleSheetRule, {
                                    id: t,
                                    adds: [{
                                        rule: r,
                                        index: o
                                    }]
                                })))
                            }), (0, J.H)(CSSStyleSheet.prototype, "deleteRule", ({
                                target: n,
                                parameters: [r]
                            }) => {
                                t(n, t => e(z(T.StyleSheetRule, {
                                    id: t,
                                    removes: [{
                                        index: r
                                    }]
                                })))
                            })];

                            function r(r) {
                                n.push((0, J.H)(r.prototype, "insertRule", ({
                                    target: n,
                                    parameters: [r, o]
                                }) => {
                                    t(n.parentStyleSheet, t => {
                                        let i = U(n);
                                        i && (i.push(o || 0), e(z(T.StyleSheetRule, {
                                            id: t,
                                            adds: [{
                                                rule: r,
                                                index: i
                                            }]
                                        })))
                                    })
                                }), (0, J.H)(r.prototype, "deleteRule", ({
                                    target: n,
                                    parameters: [r]
                                }) => {
                                    t(n.parentStyleSheet, t => {
                                        let o = U(n);
                                        o && (o.push(r), e(z(T.StyleSheetRule, {
                                            id: t,
                                            removes: [{
                                                index: o
                                            }]
                                        })))
                                    })
                                }))
                            }
                            return "undefined" != typeof CSSGroupingRule ? r(CSSGroupingRule) : (r(CSSMediaRule), r(CSSSupportsRule)), {
                                stop: () => {
                                    n.forEach(e => e.stop())
                                }
                            }
                        }(o), (0, u.l)(n, window, ["focus", "blur"], () => {
                            o({
                                data: {
                                    has_focus: document.hasFocus()
                                },
                                type: b.Focus,
                                timestamp: (0, H.nx)()
                            })
                        }), function(e, t) {
                            let n = window.visualViewport;
                            if (!n) return {
                                stop: l.l
                            };
                            let {
                                throttled: r,
                                cancel: o
                            } = (0, l.n)(() => {
                                t({
                                    data: F(n),
                                    type: b.VisualViewport,
                                    timestamp: (0, H.nx)()
                                })
                            }, 200, {
                                trailing: !1
                            }), {
                                stop: i
                            } = (0, u.l)(e, n, ["resize", "scroll"], r, {
                                capture: !0,
                                passive: !0
                            });
                            return {
                                stop: () => {
                                    i(), o()
                                }
                            }
                        }(n, o), function(e, t, n) {
                            let r = e.subscribe(12, e => {
                                var r, o;
                                "action" === e.rawRumEvent.type && "click" === e.rawRumEvent.action.type && (null == (o = null == (r = e.rawRumEvent.action.frustration) ? void 0 : r.type) ? void 0 : o.length) && "events" in e.domainContext && e.domainContext.events && e.domainContext.events.length && t({
                                    timestamp: e.rawRumEvent.date,
                                    type: b.FrustrationRecord,
                                    data: {
                                        frustrationTypes: e.rawRumEvent.action.frustration.type,
                                        recordIds: e.domainContext.events.map(e => n.getIdForEvent(e))
                                    }
                                })
                            });
                            return {
                                stop: () => {
                                    r.unsubscribe()
                                }
                            }
                        }(r, o, y), function(e, t) {
                            let n = e.subscribe(5, () => {
                                t({
                                    timestamp: (0, H.nx)(),
                                    type: b.ViewEnd
                                })
                            });
                            return {
                                stop: () => {
                                    n.unsubscribe()
                                }
                            }
                        }(r, e => {
                            m(), o(e)
                        })];
                    return {
                        stop: () => {
                            c.stop(), v.forEach(e => e.stop()), p()
                        },
                        flushMutations: m,
                        shadowRootsController: c
                    }
                }({
                    emit: y,
                    configuration: t,
                    lifeCycle: e,
                    viewHistory: c
                });
                return g.push(w), {
                    stop: () => {
                        g.forEach(e => e())
                    }
                }
            }
        }
    }
]);