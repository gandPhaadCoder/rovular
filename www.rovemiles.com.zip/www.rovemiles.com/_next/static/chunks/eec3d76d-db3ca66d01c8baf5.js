! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "5b9d44b8-ef49-43a9-bf7d-ec2e9bb910f3", e._sentryDebugIdIdentifier = "sentry-dbid-5b9d44b8-ef49-43a9-bf7d-ec2e9bb910f3")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2202], {
        53483: (e, t, d) => {
            d.d(t, {
                EgY: () => n,
                Huy: () => r
            });
            var a = d(56724);

            function n(e) {
                return (0, a.k5)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M12 2.5a5.5 5.5 0 0 1 3.096 10.047 9.005 9.005 0 0 1 5.9 8.181.75.75 0 1 1-1.499.044 7.5 7.5 0 0 0-14.993 0 .75.75 0 0 1-1.5-.045 9.005 9.005 0 0 1 5.9-8.18A5.5 5.5 0 0 1 12 2.5ZM8 8a4 4 0 1 0 8 0 4 4 0 0 0-8 0Z"
                        },
                        child: []
                    }]
                })(e)
            }

            function r(e) {
                return (0, a.k5)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M10.25 2a8.25 8.25 0 0 1 6.34 13.53l5.69 5.69a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-5.69-5.69A8.25 8.25 0 1 1 10.25 2ZM3.5 10.25a6.75 6.75 0 1 0 13.5 0 6.75 6.75 0 0 0-13.5 0Z"
                        },
                        child: []
                    }]
                })(e)
            }
        }
    }
]);