! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
            t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "c0a30ce1-3b54-495e-b742-2a22bc22b3df", e._sentryDebugIdIdentifier = "sentry-dbid-c0a30ce1-3b54-495e-b742-2a22bc22b3df")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4585], {
        5732: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            class s extends Error {
                constructor(e) {
                    super(e.message), this.name = "PostgrestError", this.details = e.details, this.hint = e.hint, this.code = e.code
                }
            }
            t.default = s
        },
        17045: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), Object.defineProperty(t, "errorOnce", {
                enumerable: !0,
                get: function() {
                    return s
                }
            });
            let s = e => {}
        },
        26294: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let i = r(s(93537)),
                n = r(s(5732));
            class a {
                constructor(e) {
                    this.shouldThrowOnError = !1, this.method = e.method, this.url = e.url, this.headers = e.headers, this.schema = e.schema, this.body = e.body, this.shouldThrowOnError = e.shouldThrowOnError, this.signal = e.signal, this.isMaybeSingle = e.isMaybeSingle, e.fetch ? this.fetch = e.fetch : "undefined" == typeof fetch ? this.fetch = i.default : this.fetch = fetch
                }
                throwOnError() {
                    return this.shouldThrowOnError = !0, this
                }
                setHeader(e, t) {
                    return this.headers = Object.assign({}, this.headers), this.headers[e] = t, this
                }
                then(e, t) {
                    void 0 === this.schema || (["GET", "HEAD"].includes(this.method) ? this.headers["Accept-Profile"] = this.schema : this.headers["Content-Profile"] = this.schema), "GET" !== this.method && "HEAD" !== this.method && (this.headers["Content-Type"] = "application/json");
                    let s = (0, this.fetch)(this.url.toString(), {
                        method: this.method,
                        headers: this.headers,
                        body: JSON.stringify(this.body),
                        signal: this.signal
                    }).then(async e => {
                        var t, s, r;
                        let i = null,
                            a = null,
                            o = null,
                            l = e.status,
                            h = e.statusText;
                        if (e.ok) {
                            if ("HEAD" !== this.method) {
                                let t = await e.text();
                                "" === t || (a = "text/csv" === this.headers.Accept || this.headers.Accept && this.headers.Accept.includes("application/vnd.pgrst.plan+text") ? t : JSON.parse(t))
                            }
                            let r = null == (t = this.headers.Prefer) ? void 0 : t.match(/count=(exact|planned|estimated)/),
                                n = null == (s = e.headers.get("content-range")) ? void 0 : s.split("/");
                            r && n && n.length > 1 && (o = parseInt(n[1])), this.isMaybeSingle && "GET" === this.method && Array.isArray(a) && (a.length > 1 ? (i = {
                                code: "PGRST116",
                                details: `Results contain ${a.length} rows, application/vnd.pgrst.object+json requires 1 row`,
                                hint: null,
                                message: "JSON object requested, multiple (or no) rows returned"
                            }, a = null, o = null, l = 406, h = "Not Acceptable") : a = 1 === a.length ? a[0] : null)
                        } else {
                            let t = await e.text();
                            try {
                                i = JSON.parse(t), Array.isArray(i) && 404 === e.status && (a = [], i = null, l = 200, h = "OK")
                            } catch (s) {
                                404 === e.status && "" === t ? (l = 204, h = "No Content") : i = {
                                    message: t
                                }
                            }
                            if (i && this.isMaybeSingle && (null == (r = null == i ? void 0 : i.details) ? void 0 : r.includes("0 rows")) && (i = null, l = 200, h = "OK"), i && this.shouldThrowOnError) throw new n.default(i)
                        }
                        return {
                            error: i,
                            data: a,
                            count: o,
                            status: l,
                            statusText: h
                        }
                    });
                    return this.shouldThrowOnError || (s = s.catch(e => {
                        var t, s, r;
                        return {
                            error: {
                                message: `${null!=(t=null==e?void 0:e.name)?t:"FetchError"}: ${null==e?void 0:e.message}`,
                                details: `${null!=(s=null==e?void 0:e.stack)?s:""}`,
                                hint: "",
                                code: `${null!=(r=null==e?void 0:e.code)?r:""}`
                            },
                            data: null,
                            count: null,
                            status: 0,
                            statusText: ""
                        }
                    })), s.then(e, t)
                }
            }
            t.default = a
        },
        28127: (e, t, s) => {
            s.d(t, {
                A: () => r
            });
            let r = (0, s(14294).A)("Calendar", [
                ["path", {
                    d: "M8 2v4",
                    key: "1cmpym"
                }],
                ["path", {
                    d: "M16 2v4",
                    key: "4m81vk"
                }],
                ["rect", {
                    width: "18",
                    height: "18",
                    x: "3",
                    y: "4",
                    rx: "2",
                    key: "1hopcy"
                }],
                ["path", {
                    d: "M3 10h18",
                    key: "8toen8"
                }]
            ])
        },
        29826: (e, t, s) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.DEFAULT_HEADERS = void 0;
            let r = s(49692);
            t.DEFAULT_HEADERS = {
                "X-Client-Info": `postgrest-js/${r.version}`
            }
        },
        32641: (e, t) => {
            t.q = function(e, t) {
                if ("string" != typeof e) throw TypeError("argument str must be a string");
                var s = {},
                    i = e.length;
                if (i < 2) return s;
                var n = t && t.decode || c,
                    a = 0,
                    o = 0,
                    u = 0;
                do {
                    if (-1 === (o = e.indexOf("=", a))) break;
                    if (-1 === (u = e.indexOf(";", a))) u = i;
                    else if (o > u) {
                        a = e.lastIndexOf(";", o - 1) + 1;
                        continue
                    }
                    var d = l(e, a, o),
                        f = h(e, o, d),
                        p = e.slice(d, f);
                    if (!r.call(s, p)) {
                        var g = l(e, o + 1, u),
                            y = h(e, u, g);
                        34 === e.charCodeAt(g) && 34 === e.charCodeAt(y - 1) && (g++, y--);
                        var m = e.slice(g, y);
                        s[p] = function(e, t) {
                            try {
                                return t(e)
                            } catch (t) {
                                return e
                            }
                        }(m, n)
                    }
                    a = u + 1
                } while (a < i);
                return s
            }, t.l = function(e, t, r) {
                var l = r && r.encode || encodeURIComponent;
                if ("function" != typeof l) throw TypeError("option encode is invalid");
                if (!i.test(e)) throw TypeError("argument name is invalid");
                var h = l(t);
                if (!n.test(h)) throw TypeError("argument val is invalid");
                var c = e + "=" + h;
                if (!r) return c;
                if (null != r.maxAge) {
                    var u = Math.floor(r.maxAge);
                    if (!isFinite(u)) throw TypeError("option maxAge is invalid");
                    c += "; Max-Age=" + u
                }
                if (r.domain) {
                    if (!a.test(r.domain)) throw TypeError("option domain is invalid");
                    c += "; Domain=" + r.domain
                }
                if (r.path) {
                    if (!o.test(r.path)) throw TypeError("option path is invalid");
                    c += "; Path=" + r.path
                }
                if (r.expires) {
                    var d, f = r.expires;
                    if (d = f, "[object Date]" !== s.call(d) || isNaN(f.valueOf())) throw TypeError("option expires is invalid");
                    c += "; Expires=" + f.toUTCString()
                }
                if (r.httpOnly && (c += "; HttpOnly"), r.secure && (c += "; Secure"), r.partitioned && (c += "; Partitioned"), r.priority) switch ("string" == typeof r.priority ? r.priority.toLowerCase() : r.priority) {
                    case "low":
                        c += "; Priority=Low";
                        break;
                    case "medium":
                        c += "; Priority=Medium";
                        break;
                    case "high":
                        c += "; Priority=High";
                        break;
                    default:
                        throw TypeError("option priority is invalid")
                }
                if (r.sameSite) switch ("string" == typeof r.sameSite ? r.sameSite.toLowerCase() : r.sameSite) {
                    case !0:
                    case "strict":
                        c += "; SameSite=Strict";
                        break;
                    case "lax":
                        c += "; SameSite=Lax";
                        break;
                    case "none":
                        c += "; SameSite=None";
                        break;
                    default:
                        throw TypeError("option sameSite is invalid")
                }
                return c
            };
            var s = Object.prototype.toString,
                r = Object.prototype.hasOwnProperty,
                i = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/,
                n = /^("?)[\u0021\u0023-\u002B\u002D-\u003A\u003C-\u005B\u005D-\u007E]*\1$/,
                a = /^([.]?[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)([.][a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/i,
                o = /^[\u0020-\u003A\u003D-\u007E]*$/;

            function l(e, t, s) {
                do {
                    var r = e.charCodeAt(t);
                    if (32 !== r && 9 !== r) return t
                } while (++t < s);
                return s
            }

            function h(e, t, s) {
                for (; t > s;) {
                    var r = e.charCodeAt(--t);
                    if (32 !== r && 9 !== r) return t + 1
                }
                return s
            }

            function c(e) {
                return -1 !== e.indexOf("%") ? decodeURIComponent(e) : e
            }
        },
        37977: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let i = r(s(72901)),
                n = r(s(54419)),
                a = s(29826);
            class o {
                constructor(e, {
                    headers: t = {},
                    schema: s,
                    fetch: r
                } = {}) {
                    this.url = e, this.headers = Object.assign(Object.assign({}, a.DEFAULT_HEADERS), t), this.schemaName = s, this.fetch = r
                }
                from(e) {
                    let t = new URL(`${this.url}/${e}`);
                    return new i.default(t, {
                        headers: Object.assign({}, this.headers),
                        schema: this.schemaName,
                        fetch: this.fetch
                    })
                }
                schema(e) {
                    return new o(this.url, {
                        headers: this.headers,
                        schema: e,
                        fetch: this.fetch
                    })
                }
                rpc(e, t = {}, {
                    head: s = !1,
                    get: r = !1,
                    count: i
                } = {}) {
                    let a, o, l = new URL(`${this.url}/rpc/${e}`);
                    s || r ? (a = s ? "HEAD" : "GET", Object.entries(t).filter(([e, t]) => void 0 !== t).map(([e, t]) => [e, Array.isArray(t) ? `{${t.join(",")}}` : `${t}`]).forEach(([e, t]) => {
                        l.searchParams.append(e, t)
                    })) : (a = "POST", o = t);
                    let h = Object.assign({}, this.headers);
                    return i && (h.Prefer = `count=${i}`), new n.default({
                        method: a,
                        url: l,
                        headers: h,
                        schema: this.schemaName,
                        body: o,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
            }
            t.default = o
        },
        49692: (e, t) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.version = void 0, t.version = "0.0.0-automated"
        },
        52619: (e, t, s) => {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), ! function(e, t) {
                for (var s in t) Object.defineProperty(e, s, {
                    enumerable: !0,
                    get: t[s]
                })
            }(t, {
                default: function() {
                    return y
                },
                useLinkStatus: function() {
                    return w
                }
            });
            let r = s(49417),
                i = s(95155),
                n = r._(s(12115)),
                a = s(47670),
                o = s(46752),
                l = s(86871),
                h = s(83011),
                c = s(62296),
                u = s(96058);
            s(94781);
            let d = s(63499),
                f = s(58607),
                p = s(11807);

            function g(e) {
                return "string" == typeof e ? e : (0, a.formatUrl)(e)
            }

            function y(e) {
                let t, s, r, [a, y] = (0, n.useOptimistic)(d.IDLE_LINK_STATUS),
                    w = (0, n.useRef)(null),
                    {
                        href: v,
                        as: b,
                        children: _,
                        prefetch: k = null,
                        passHref: S,
                        replace: T,
                        shallow: E,
                        scroll: j,
                        onClick: O,
                        onMouseEnter: P,
                        onTouchStart: A,
                        legacyBehavior: $ = !1,
                        onNavigate: C,
                        ref: x,
                        unstable_dynamicOnHover: R,
                        ...I
                    } = e;
                t = _, $ && ("string" == typeof t || "number" == typeof t) && (t = (0, i.jsx)("a", {
                    children: t
                }));
                let L = n.default.useContext(o.AppRouterContext),
                    U = !1 !== k,
                    D = null === k ? l.PrefetchKind.AUTO : l.PrefetchKind.FULL,
                    {
                        href: N,
                        as: M
                    } = n.default.useMemo(() => {
                        let e = g(v);
                        return {
                            href: e,
                            as: b ? g(b) : e
                        }
                    }, [v, b]);
                $ && (s = n.default.Children.only(t));
                let q = $ ? s && "object" == typeof s && s.ref : x,
                    B = n.default.useCallback(e => (null !== L && (w.current = (0, d.mountLinkInstance)(e, N, L, D, U, y)), () => {
                        w.current && ((0, d.unmountLinkForCurrentNavigation)(w.current), w.current = null), (0, d.unmountPrefetchableInstance)(e)
                    }), [U, N, L, D, y]),
                    F = {
                        ref: (0, h.useMergedRef)(B, q),
                        onClick(e) {
                            $ || "function" != typeof O || O(e), $ && s.props && "function" == typeof s.props.onClick && s.props.onClick(e), L && (e.defaultPrevented || function(e, t, s, r, i, a, o) {
                                let {
                                    nodeName: l
                                } = e.currentTarget;
                                if (!("A" === l.toUpperCase() && function(e) {
                                        let t = e.currentTarget.getAttribute("target");
                                        return t && "_self" !== t || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.nativeEvent && 2 === e.nativeEvent.which
                                    }(e) || e.currentTarget.hasAttribute("download"))) {
                                    if (!(0, f.isLocalURL)(t)) {
                                        i && (e.preventDefault(), location.replace(t));
                                        return
                                    }
                                    e.preventDefault(), n.default.startTransition(() => {
                                        if (o) {
                                            let e = !1;
                                            if (o({
                                                    preventDefault: () => {
                                                        e = !0
                                                    }
                                                }), e) return
                                        }(0, p.dispatchNavigateAction)(s || t, i ? "replace" : "push", null == a || a, r.current)
                                    })
                                }
                            }(e, N, M, w, T, j, C))
                        },
                        onMouseEnter(e) {
                            $ || "function" != typeof P || P(e), $ && s.props && "function" == typeof s.props.onMouseEnter && s.props.onMouseEnter(e), L && U && (0, d.onNavigationIntent)(e.currentTarget, !0 === R)
                        },
                        onTouchStart: function(e) {
                            $ || "function" != typeof A || A(e), $ && s.props && "function" == typeof s.props.onTouchStart && s.props.onTouchStart(e), L && U && (0, d.onNavigationIntent)(e.currentTarget, !0 === R)
                        }
                    };
                return (0, c.isAbsoluteUrl)(M) ? F.href = M : $ && !S && ("a" !== s.type || "href" in s.props) || (F.href = (0, u.addBasePath)(M)), r = $ ? n.default.cloneElement(s, F) : (0, i.jsx)("a", { ...I,
                    ...F,
                    children: t
                }), (0, i.jsx)(m.Provider, {
                    value: a,
                    children: r
                })
            }
            s(17045);
            let m = (0, n.createContext)(d.IDLE_LINK_STATUS),
                w = () => (0, n.useContext)(m);
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        53455: (e, t, s) => {
            s.d(t, {
                I: () => n
            });
            var r = s(2954),
                i = s(78633);

            function n(e, t) {
                return (0, i.t)(e, r.$, t)
            }
        },
        54419: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let i = r(s(76373));
            class n extends i.default {
                eq(e, t) {
                    return this.url.searchParams.append(e, `eq.${t}`), this
                }
                neq(e, t) {
                    return this.url.searchParams.append(e, `neq.${t}`), this
                }
                gt(e, t) {
                    return this.url.searchParams.append(e, `gt.${t}`), this
                }
                gte(e, t) {
                    return this.url.searchParams.append(e, `gte.${t}`), this
                }
                lt(e, t) {
                    return this.url.searchParams.append(e, `lt.${t}`), this
                }
                lte(e, t) {
                    return this.url.searchParams.append(e, `lte.${t}`), this
                }
                like(e, t) {
                    return this.url.searchParams.append(e, `like.${t}`), this
                }
                likeAllOf(e, t) {
                    return this.url.searchParams.append(e, `like(all).{${t.join(",")}}`), this
                }
                likeAnyOf(e, t) {
                    return this.url.searchParams.append(e, `like(any).{${t.join(",")}}`), this
                }
                ilike(e, t) {
                    return this.url.searchParams.append(e, `ilike.${t}`), this
                }
                ilikeAllOf(e, t) {
                    return this.url.searchParams.append(e, `ilike(all).{${t.join(",")}}`), this
                }
                ilikeAnyOf(e, t) {
                    return this.url.searchParams.append(e, `ilike(any).{${t.join(",")}}`), this
                }
                is(e, t) {
                    return this.url.searchParams.append(e, `is.${t}`), this
                } in (e, t) {
                    let s = Array.from(new Set(t)).map(e => "string" == typeof e && RegExp("[,()]").test(e) ? `"${e}"` : `${e}`).join(",");
                    return this.url.searchParams.append(e, `in.(${s})`), this
                }
                contains(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `cs.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cs.{${t.join(",")}}`) : this.url.searchParams.append(e, `cs.${JSON.stringify(t)}`), this
                }
                containedBy(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `cd.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cd.{${t.join(",")}}`) : this.url.searchParams.append(e, `cd.${JSON.stringify(t)}`), this
                }
                rangeGt(e, t) {
                    return this.url.searchParams.append(e, `sr.${t}`), this
                }
                rangeGte(e, t) {
                    return this.url.searchParams.append(e, `nxl.${t}`), this
                }
                rangeLt(e, t) {
                    return this.url.searchParams.append(e, `sl.${t}`), this
                }
                rangeLte(e, t) {
                    return this.url.searchParams.append(e, `nxr.${t}`), this
                }
                rangeAdjacent(e, t) {
                    return this.url.searchParams.append(e, `adj.${t}`), this
                }
                overlaps(e, t) {
                    return "string" == typeof t ? this.url.searchParams.append(e, `ov.${t}`) : this.url.searchParams.append(e, `ov.{${t.join(",")}}`), this
                }
                textSearch(e, t, {
                    config: s,
                    type: r
                } = {}) {
                    let i = "";
                    "plain" === r ? i = "pl" : "phrase" === r ? i = "ph" : "websearch" === r && (i = "w");
                    let n = void 0 === s ? "" : `(${s})`;
                    return this.url.searchParams.append(e, `${i}fts${n}.${t}`), this
                }
                match(e) {
                    return Object.entries(e).forEach(([e, t]) => {
                        this.url.searchParams.append(e, `eq.${t}`)
                    }), this
                }
                not(e, t, s) {
                    return this.url.searchParams.append(e, `not.${t}.${s}`), this
                }
                or(e, {
                    foreignTable: t,
                    referencedTable: s = t
                } = {}) {
                    let r = s ? `${s}.or` : "or";
                    return this.url.searchParams.append(r, `(${e})`), this
                }
                filter(e, t, s) {
                    return this.url.searchParams.append(e, `${t}.${s}`), this
                }
            }
            t.default = n
        },
        62471: (e, t, s) => {
            let r;
            s.d(t, {
                createBrowserClient: () => tN
            });
            let i = e => {
                let t;
                return t = e || ("undefined" == typeof fetch ? (...e) => Promise.resolve().then(s.bind(s, 93537)).then(({
                    default: t
                }) => t(...e)) : fetch), (...e) => t(...e)
            };
            class n extends Error {
                constructor(e, t = "FunctionsError", s) {
                    super(e), this.name = t, this.context = s
                }
            }
            class a extends n {
                constructor(e) {
                    super("Failed to send a request to the Edge Function", "FunctionsFetchError", e)
                }
            }
            class o extends n {
                constructor(e) {
                    super("Relay Error invoking the Edge Function", "FunctionsRelayError", e)
                }
            }
            class l extends n {
                constructor(e) {
                    super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e)
                }
            }! function(e) {
                e.Any = "any", e.ApNortheast1 = "ap-northeast-1", e.ApNortheast2 = "ap-northeast-2", e.ApSouth1 = "ap-south-1", e.ApSoutheast1 = "ap-southeast-1", e.ApSoutheast2 = "ap-southeast-2", e.CaCentral1 = "ca-central-1", e.EuCentral1 = "eu-central-1", e.EuWest1 = "eu-west-1", e.EuWest2 = "eu-west-2", e.EuWest3 = "eu-west-3", e.SaEast1 = "sa-east-1", e.UsEast1 = "us-east-1", e.UsWest1 = "us-west-1", e.UsWest2 = "us-west-2"
            }(J || (J = {}));
            class h {
                constructor(e, {
                    headers: t = {},
                    customFetch: s,
                    region: r = J.Any
                } = {}) {
                    this.url = e, this.headers = t, this.region = r, this.fetch = i(s)
                }
                setAuth(e) {
                    this.headers.Authorization = `Bearer ${e}`
                }
                invoke(e, t = {}) {
                    var s, r, i, n, h;
                    return r = this, i = void 0, n = void 0, h = function*() {
                        try {
                            let r, i, {
                                    headers: n,
                                    method: h,
                                    body: c
                                } = t,
                                u = {},
                                {
                                    region: d
                                } = t;
                            d || (d = this.region), d && "any" !== d && (u["x-region"] = d), c && (n && !Object.prototype.hasOwnProperty.call(n, "Content-Type") || !n) && ("undefined" != typeof Blob && c instanceof Blob || c instanceof ArrayBuffer ? (u["Content-Type"] = "application/octet-stream", r = c) : "string" == typeof c ? (u["Content-Type"] = "text/plain", r = c) : "undefined" != typeof FormData && c instanceof FormData ? r = c : (u["Content-Type"] = "application/json", r = JSON.stringify(c)));
                            let f = yield this.fetch(`${this.url}/${e}`, {
                                method: h || "POST",
                                headers: Object.assign(Object.assign(Object.assign({}, u), this.headers), n),
                                body: r
                            }).catch(e => {
                                throw new a(e)
                            }), p = f.headers.get("x-relay-error");
                            if (p && "true" === p) throw new o(f);
                            if (!f.ok) throw new l(f);
                            let g = (null != (s = f.headers.get("Content-Type")) ? s : "text/plain").split(";")[0].trim();
                            return {
                                data: "application/json" === g ? yield f.json(): "application/octet-stream" === g ? yield f.blob(): "text/event-stream" === g ? f : "multipart/form-data" === g ? yield f.formData(): yield f.text(), error: null
                            }
                        } catch (e) {
                            return {
                                data: null,
                                error: e
                            }
                        }
                    }, new(n || (n = Promise))(function(e, t) {
                        function s(e) {
                            try {
                                o(h.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function a(e) {
                            try {
                                o(h.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(t) {
                            var r;
                            t.done ? e(t.value) : ((r = t.value) instanceof n ? r : new n(function(e) {
                                e(r)
                            })).then(s, a)
                        }
                        o((h = h.apply(r, i || [])).next())
                    })
                }
            }
            let {
                PostgrestClient: c,
                PostgrestQueryBuilder: u,
                PostgrestFilterBuilder: d,
                PostgrestTransformBuilder: f,
                PostgrestBuilder: p,
                PostgrestError: g
            } = s(87843), y = {
                "X-Client-Info": "realtime-js/2.11.2"
            };
            ! function(e) {
                e[e.connecting = 0] = "connecting", e[e.open = 1] = "open", e[e.closing = 2] = "closing", e[e.closed = 3] = "closed"
            }(K || (K = {})),
            function(e) {
                e.closed = "closed", e.errored = "errored", e.joined = "joined", e.joining = "joining", e.leaving = "leaving"
            }(H || (H = {})),
            function(e) {
                e.close = "phx_close", e.error = "phx_error", e.join = "phx_join", e.reply = "phx_reply", e.leave = "phx_leave", e.access_token = "access_token"
            }(G || (G = {})), (W || (W = {})).websocket = "websocket",
                function(e) {
                    e.Connecting = "connecting", e.Open = "open", e.Closing = "closing", e.Closed = "closed"
                }(V || (V = {}));
            class m {
                constructor() {
                    this.HEADER_LENGTH = 1
                }
                decode(e, t) {
                    return e.constructor === ArrayBuffer ? t(this._binaryDecode(e)) : "string" == typeof e ? t(JSON.parse(e)) : t({})
                }
                _binaryDecode(e) {
                    let t = new DataView(e),
                        s = new TextDecoder;
                    return this._decodeBroadcast(e, t, s)
                }
                _decodeBroadcast(e, t, s) {
                    let r = t.getUint8(1),
                        i = t.getUint8(2),
                        n = this.HEADER_LENGTH + 2,
                        a = s.decode(e.slice(n, n + r));
                    n += r;
                    let o = s.decode(e.slice(n, n + i));
                    return n += i, {
                        ref: null,
                        topic: a,
                        event: o,
                        payload: JSON.parse(s.decode(e.slice(n, e.byteLength)))
                    }
                }
            }
            class w {
                constructor(e, t) {
                    this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0, this.callback = e, this.timerCalc = t
                }
                reset() {
                    this.tries = 0, clearTimeout(this.timer)
                }
                scheduleTimeout() {
                    clearTimeout(this.timer), this.timer = setTimeout(() => {
                        this.tries = this.tries + 1, this.callback()
                    }, this.timerCalc(this.tries + 1))
                }
            }! function(e) {
                e.abstime = "abstime", e.bool = "bool", e.date = "date", e.daterange = "daterange", e.float4 = "float4", e.float8 = "float8", e.int2 = "int2", e.int4 = "int4", e.int4range = "int4range", e.int8 = "int8", e.int8range = "int8range", e.json = "json", e.jsonb = "jsonb", e.money = "money", e.numeric = "numeric", e.oid = "oid", e.reltime = "reltime", e.text = "text", e.time = "time", e.timestamp = "timestamp", e.timestamptz = "timestamptz", e.timetz = "timetz", e.tsrange = "tsrange", e.tstzrange = "tstzrange"
            }(Y || (Y = {}));
            let v = (e, t, s = {}) => {
                    var r;
                    let i = null != (r = s.skipTypes) ? r : [];
                    return Object.keys(t).reduce((s, r) => (s[r] = b(r, e, t, i), s), {})
                },
                b = (e, t, s, r) => {
                    let i = t.find(t => t.name === e),
                        n = null == i ? void 0 : i.type,
                        a = s[e];
                    return n && !r.includes(n) ? _(n, a) : k(a)
                },
                _ = (e, t) => {
                    if ("_" === e.charAt(0)) return j(t, e.slice(1, e.length));
                    switch (e) {
                        case Y.bool:
                            return S(t);
                        case Y.float4:
                        case Y.float8:
                        case Y.int2:
                        case Y.int4:
                        case Y.int8:
                        case Y.numeric:
                        case Y.oid:
                            return T(t);
                        case Y.json:
                        case Y.jsonb:
                            return E(t);
                        case Y.timestamp:
                            return O(t);
                        case Y.abstime:
                        case Y.date:
                        case Y.daterange:
                        case Y.int4range:
                        case Y.int8range:
                        case Y.money:
                        case Y.reltime:
                        case Y.text:
                        case Y.time:
                        case Y.timestamptz:
                        case Y.timetz:
                        case Y.tsrange:
                        case Y.tstzrange:
                        default:
                            return k(t)
                    }
                },
                k = e => e,
                S = e => {
                    switch (e) {
                        case "t":
                            return !0;
                        case "f":
                            return !1;
                        default:
                            return e
                    }
                },
                T = e => {
                    if ("string" == typeof e) {
                        let t = parseFloat(e);
                        if (!Number.isNaN(t)) return t
                    }
                    return e
                },
                E = e => {
                    if ("string" == typeof e) try {
                        return JSON.parse(e)
                    } catch (e) {
                        console.log(`JSON parse error: ${e}`)
                    }
                    return e
                },
                j = (e, t) => {
                    if ("string" != typeof e) return e;
                    let s = e.length - 1,
                        r = e[s];
                    if ("{" === e[0] && "}" === r) {
                        let r, i = e.slice(1, s);
                        try {
                            r = JSON.parse("[" + i + "]")
                        } catch (e) {
                            r = i ? i.split(",") : []
                        }
                        return r.map(e => _(t, e))
                    }
                    return e
                },
                O = e => "string" == typeof e ? e.replace(" ", "T") : e,
                P = e => {
                    let t = e;
                    return (t = (t = t.replace(/^ws/i, "http")).replace(/(\/socket\/websocket|\/socket|\/websocket)\/?$/i, "")).replace(/\/+$/, "")
                };
            class A {
                constructor(e, t, s = {}, r = 1e4) {
                    this.channel = e, this.event = t, this.payload = s, this.timeout = r, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null
                }
                resend(e) {
                    this.timeout = e, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send()
                }
                send() {
                    this._hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
                        topic: this.channel.topic,
                        event: this.event,
                        payload: this.payload,
                        ref: this.ref,
                        join_ref: this.channel._joinRef()
                    }))
                }
                updatePayload(e) {
                    this.payload = Object.assign(Object.assign({}, this.payload), e)
                }
                receive(e, t) {
                    var s;
                    return this._hasReceived(e) && t(null == (s = this.receivedResp) ? void 0 : s.response), this.recHooks.push({
                        status: e,
                        callback: t
                    }), this
                }
                startTimeout() {
                    this.timeoutTimer || (this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref), this.channel._on(this.refEvent, {}, e => {
                        this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = e, this._matchReceive(e)
                    }), this.timeoutTimer = setTimeout(() => {
                        this.trigger("timeout", {})
                    }, this.timeout))
                }
                trigger(e, t) {
                    this.refEvent && this.channel._trigger(this.refEvent, {
                        status: e,
                        response: t
                    })
                }
                destroy() {
                    this._cancelRefEvent(), this._cancelTimeout()
                }
                _cancelRefEvent() {
                    this.refEvent && this.channel._off(this.refEvent, {})
                }
                _cancelTimeout() {
                    clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0
                }
                _matchReceive({
                    status: e,
                    response: t
                }) {
                    this.recHooks.filter(t => t.status === e).forEach(e => e.callback(t))
                }
                _hasReceived(e) {
                    return this.receivedResp && this.receivedResp.status === e
                }
            }! function(e) {
                e.SYNC = "sync", e.JOIN = "join", e.LEAVE = "leave"
            }(X || (X = {}));
            class $ {
                constructor(e, t) {
                    this.channel = e, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.caller = {
                        onJoin: () => {},
                        onLeave: () => {},
                        onSync: () => {}
                    };
                    let s = (null == t ? void 0 : t.events) || {
                        state: "presence_state",
                        diff: "presence_diff"
                    };
                    this.channel._on(s.state, {}, e => {
                        let {
                            onJoin: t,
                            onLeave: s,
                            onSync: r
                        } = this.caller;
                        this.joinRef = this.channel._joinRef(), this.state = $.syncState(this.state, e, t, s), this.pendingDiffs.forEach(e => {
                            this.state = $.syncDiff(this.state, e, t, s)
                        }), this.pendingDiffs = [], r()
                    }), this.channel._on(s.diff, {}, e => {
                        let {
                            onJoin: t,
                            onLeave: s,
                            onSync: r
                        } = this.caller;
                        this.inPendingSyncState() ? this.pendingDiffs.push(e) : (this.state = $.syncDiff(this.state, e, t, s), r())
                    }), this.onJoin((e, t, s) => {
                        this.channel._trigger("presence", {
                            event: "join",
                            key: e,
                            currentPresences: t,
                            newPresences: s
                        })
                    }), this.onLeave((e, t, s) => {
                        this.channel._trigger("presence", {
                            event: "leave",
                            key: e,
                            currentPresences: t,
                            leftPresences: s
                        })
                    }), this.onSync(() => {
                        this.channel._trigger("presence", {
                            event: "sync"
                        })
                    })
                }
                static syncState(e, t, s, r) {
                    let i = this.cloneDeep(e),
                        n = this.transformState(t),
                        a = {},
                        o = {};
                    return this.map(i, (e, t) => {
                        n[e] || (o[e] = t)
                    }), this.map(n, (e, t) => {
                        let s = i[e];
                        if (s) {
                            let r = t.map(e => e.presence_ref),
                                i = s.map(e => e.presence_ref),
                                n = t.filter(e => 0 > i.indexOf(e.presence_ref)),
                                l = s.filter(e => 0 > r.indexOf(e.presence_ref));
                            n.length > 0 && (a[e] = n), l.length > 0 && (o[e] = l)
                        } else a[e] = t
                    }), this.syncDiff(i, {
                        joins: a,
                        leaves: o
                    }, s, r)
                }
                static syncDiff(e, t, s, r) {
                    let {
                        joins: i,
                        leaves: n
                    } = {
                        joins: this.transformState(t.joins),
                        leaves: this.transformState(t.leaves)
                    };
                    return s || (s = () => {}), r || (r = () => {}), this.map(i, (t, r) => {
                        var i;
                        let n = null != (i = e[t]) ? i : [];
                        if (e[t] = this.cloneDeep(r), n.length > 0) {
                            let s = e[t].map(e => e.presence_ref),
                                r = n.filter(e => 0 > s.indexOf(e.presence_ref));
                            e[t].unshift(...r)
                        }
                        s(t, n, r)
                    }), this.map(n, (t, s) => {
                        let i = e[t];
                        if (!i) return;
                        let n = s.map(e => e.presence_ref);
                        i = i.filter(e => 0 > n.indexOf(e.presence_ref)), e[t] = i, r(t, i, s), 0 === i.length && delete e[t]
                    }), e
                }
                static map(e, t) {
                    return Object.getOwnPropertyNames(e).map(s => t(s, e[s]))
                }
                static transformState(e) {
                    return Object.getOwnPropertyNames(e = this.cloneDeep(e)).reduce((t, s) => {
                        let r = e[s];
                        return "metas" in r ? t[s] = r.metas.map(e => (e.presence_ref = e.phx_ref, delete e.phx_ref, delete e.phx_ref_prev, e)) : t[s] = r, t
                    }, {})
                }
                static cloneDeep(e) {
                    return JSON.parse(JSON.stringify(e))
                }
                onJoin(e) {
                    this.caller.onJoin = e
                }
                onLeave(e) {
                    this.caller.onLeave = e
                }
                onSync(e) {
                    this.caller.onSync = e
                }
                inPendingSyncState() {
                    return !this.joinRef || this.joinRef !== this.channel._joinRef()
                }
            }! function(e) {
                e.ALL = "*", e.INSERT = "INSERT", e.UPDATE = "UPDATE", e.DELETE = "DELETE"
            }(Q || (Q = {})),
            function(e) {
                e.BROADCAST = "broadcast", e.PRESENCE = "presence", e.POSTGRES_CHANGES = "postgres_changes", e.SYSTEM = "system"
            }(Z || (Z = {})),
            function(e) {
                e.SUBSCRIBED = "SUBSCRIBED", e.TIMED_OUT = "TIMED_OUT", e.CLOSED = "CLOSED", e.CHANNEL_ERROR = "CHANNEL_ERROR"
            }(ee || (ee = {}));
            class C {
                constructor(e, t = {
                    config: {}
                }, s) {
                    this.topic = e, this.params = t, this.socket = s, this.bindings = {}, this.state = H.closed, this.joinedOnce = !1, this.pushBuffer = [], this.subTopic = e.replace(/^realtime:/i, ""), this.params.config = Object.assign({
                        broadcast: {
                            ack: !1,
                            self: !1
                        },
                        presence: {
                            key: ""
                        },
                        private: !1
                    }, t.config), this.timeout = this.socket.timeout, this.joinPush = new A(this, G.join, this.params, this.timeout), this.rejoinTimer = new w(() => this._rejoinUntilConnected(), this.socket.reconnectAfterMs), this.joinPush.receive("ok", () => {
                        this.state = H.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach(e => e.send()), this.pushBuffer = []
                    }), this._onClose(() => {
                        this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = H.closed, this.socket._remove(this)
                    }), this._onError(e => {
                        this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, e), this.state = H.errored, this.rejoinTimer.scheduleTimeout())
                    }), this.joinPush.receive("timeout", () => {
                        this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = H.errored, this.rejoinTimer.scheduleTimeout())
                    }), this._on(G.reply, {}, (e, t) => {
                        this._trigger(this._replyEventName(t), e)
                    }), this.presence = new $(this), this.broadcastEndpointURL = P(this.socket.endPoint) + "/api/broadcast", this.private = this.params.config.private || !1
                }
                subscribe(e, t = this.timeout) {
                    var s, r;
                    if (this.socket.isConnected() || this.socket.connect(), this.joinedOnce) throw "tried to subscribe multiple times. 'subscribe' can only be called a single time per channel instance"; {
                        let {
                            config: {
                                broadcast: i,
                                presence: n,
                                private: a
                            }
                        } = this.params;
                        this._onError(t => null == e ? void 0 : e(ee.CHANNEL_ERROR, t)), this._onClose(() => null == e ? void 0 : e(ee.CLOSED));
                        let o = {},
                            l = {
                                broadcast: i,
                                presence: n,
                                postgres_changes: null != (r = null == (s = this.bindings.postgres_changes) ? void 0 : s.map(e => e.filter)) ? r : [],
                                private: a
                            };
                        this.socket.accessTokenValue && (o.access_token = this.socket.accessTokenValue), this.updateJoinPayload(Object.assign({
                            config: l
                        }, o)), this.joinedOnce = !0, this._rejoin(t), this.joinPush.receive("ok", async ({
                            postgres_changes: t
                        }) => {
                            var s;
                            if (this.socket.setAuth(), void 0 === t) {
                                null == e || e(ee.SUBSCRIBED);
                                return
                            } {
                                let r = this.bindings.postgres_changes,
                                    i = null != (s = null == r ? void 0 : r.length) ? s : 0,
                                    n = [];
                                for (let s = 0; s < i; s++) {
                                    let i = r[s],
                                        {
                                            filter: {
                                                event: a,
                                                schema: o,
                                                table: l,
                                                filter: h
                                            }
                                        } = i,
                                        c = t && t[s];
                                    if (c && c.event === a && c.schema === o && c.table === l && c.filter === h) n.push(Object.assign(Object.assign({}, i), {
                                        id: c.id
                                    }));
                                    else {
                                        this.unsubscribe(), null == e || e(ee.CHANNEL_ERROR, Error("mismatch between server and client bindings for postgres changes"));
                                        return
                                    }
                                }
                                this.bindings.postgres_changes = n, e && e(ee.SUBSCRIBED);
                                return
                            }
                        }).receive("error", t => {
                            null == e || e(ee.CHANNEL_ERROR, Error(JSON.stringify(Object.values(t).join(", ") || "error")))
                        }).receive("timeout", () => {
                            null == e || e(ee.TIMED_OUT)
                        })
                    }
                    return this
                }
                presenceState() {
                    return this.presence.state
                }
                async track(e, t = {}) {
                    return await this.send({
                        type: "presence",
                        event: "track",
                        payload: e
                    }, t.timeout || this.timeout)
                }
                async untrack(e = {}) {
                    return await this.send({
                        type: "presence",
                        event: "untrack"
                    }, e)
                }
                on(e, t, s) {
                    return this._on(e, t, s)
                }
                async send(e, t = {}) {
                    var s, r;
                    if (this._canPush() || "broadcast" !== e.type) return new Promise(s => {
                        var r, i, n;
                        let a = this._push(e.type, e, t.timeout || this.timeout);
                        "broadcast" !== e.type || (null == (n = null == (i = null == (r = this.params) ? void 0 : r.config) ? void 0 : i.broadcast) ? void 0 : n.ack) || s("ok"), a.receive("ok", () => s("ok")), a.receive("error", () => s("error")), a.receive("timeout", () => s("timed out"))
                    }); {
                        let {
                            event: i,
                            payload: n
                        } = e, a = {
                            method: "POST",
                            headers: {
                                Authorization: this.socket.accessTokenValue ? `Bearer ${this.socket.accessTokenValue}` : "",
                                apikey: this.socket.apiKey ? this.socket.apiKey : "",
                                "Content-Type": "application/json"
                            },
                            body: JSON.stringify({
                                messages: [{
                                    topic: this.subTopic,
                                    event: i,
                                    payload: n,
                                    private: this.private
                                }]
                            })
                        };
                        try {
                            let e = await this._fetchWithTimeout(this.broadcastEndpointURL, a, null != (s = t.timeout) ? s : this.timeout);
                            return await (null == (r = e.body) ? void 0 : r.cancel()), e.ok ? "ok" : "error"
                        } catch (e) {
                            if ("AbortError" === e.name) return "timed out";
                            return "error"
                        }
                    }
                }
                updateJoinPayload(e) {
                    this.joinPush.updatePayload(e)
                }
                unsubscribe(e = this.timeout) {
                    this.state = H.leaving;
                    let t = () => {
                        this.socket.log("channel", `leave ${this.topic}`), this._trigger(G.close, "leave", this._joinRef())
                    };
                    return this.rejoinTimer.reset(), this.joinPush.destroy(), new Promise(s => {
                        let r = new A(this, G.leave, {}, e);
                        r.receive("ok", () => {
                            t(), s("ok")
                        }).receive("timeout", () => {
                            t(), s("timed out")
                        }).receive("error", () => {
                            s("error")
                        }), r.send(), this._canPush() || r.trigger("ok", {})
                    })
                }
                async _fetchWithTimeout(e, t, s) {
                    let r = new AbortController,
                        i = setTimeout(() => r.abort(), s),
                        n = await this.socket.fetch(e, Object.assign(Object.assign({}, t), {
                            signal: r.signal
                        }));
                    return clearTimeout(i), n
                }
                _push(e, t, s = this.timeout) {
                    if (!this.joinedOnce) throw `tried to push '${e}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
                    let r = new A(this, e, t, s);
                    return this._canPush() ? r.send() : (r.startTimeout(), this.pushBuffer.push(r)), r
                }
                _onMessage(e, t, s) {
                    return t
                }
                _isMember(e) {
                    return this.topic === e
                }
                _joinRef() {
                    return this.joinPush.ref
                }
                _trigger(e, t, s) {
                    var r, i;
                    let n = e.toLocaleLowerCase(),
                        {
                            close: a,
                            error: o,
                            leave: l,
                            join: h
                        } = G;
                    if (s && [a, o, l, h].indexOf(n) >= 0 && s !== this._joinRef()) return;
                    let c = this._onMessage(n, t, s);
                    if (t && !c) throw "channel onMessage callbacks must return the payload, modified or unmodified";
                    ["insert", "update", "delete"].includes(n) ? null == (r = this.bindings.postgres_changes) || r.filter(e => {
                        var t, s, r;
                        return (null == (t = e.filter) ? void 0 : t.event) === "*" || (null == (r = null == (s = e.filter) ? void 0 : s.event) ? void 0 : r.toLocaleLowerCase()) === n
                    }).map(e => e.callback(c, s)) : null == (i = this.bindings[n]) || i.filter(e => {
                        var s, r, i, a, o, l;
                        if (!["broadcast", "presence", "postgres_changes"].includes(n)) return e.type.toLocaleLowerCase() === n;
                        if ("id" in e) {
                            let n = e.id,
                                a = null == (s = e.filter) ? void 0 : s.event;
                            return n && (null == (r = t.ids) ? void 0 : r.includes(n)) && ("*" === a || (null == a ? void 0 : a.toLocaleLowerCase()) === (null == (i = t.data) ? void 0 : i.type.toLocaleLowerCase()))
                        } {
                            let s = null == (o = null == (a = null == e ? void 0 : e.filter) ? void 0 : a.event) ? void 0 : o.toLocaleLowerCase();
                            return "*" === s || s === (null == (l = null == t ? void 0 : t.event) ? void 0 : l.toLocaleLowerCase())
                        }
                    }).map(e => {
                        if ("object" == typeof c && "ids" in c) {
                            let e = c.data,
                                {
                                    schema: t,
                                    table: s,
                                    commit_timestamp: r,
                                    type: i,
                                    errors: n
                                } = e;
                            c = Object.assign(Object.assign({}, {
                                schema: t,
                                table: s,
                                commit_timestamp: r,
                                eventType: i,
                                new: {},
                                old: {},
                                errors: n
                            }), this._getPayloadRecords(e))
                        }
                        e.callback(c, s)
                    })
                }
                _isClosed() {
                    return this.state === H.closed
                }
                _isJoined() {
                    return this.state === H.joined
                }
                _isJoining() {
                    return this.state === H.joining
                }
                _isLeaving() {
                    return this.state === H.leaving
                }
                _replyEventName(e) {
                    return `chan_reply_${e}`
                }
                _on(e, t, s) {
                    let r = e.toLocaleLowerCase(),
                        i = {
                            type: r,
                            filter: t,
                            callback: s
                        };
                    return this.bindings[r] ? this.bindings[r].push(i) : this.bindings[r] = [i], this
                }
                _off(e, t) {
                    let s = e.toLocaleLowerCase();
                    return this.bindings[s] = this.bindings[s].filter(e => {
                        var r;
                        return !((null == (r = e.type) ? void 0 : r.toLocaleLowerCase()) === s && C.isEqual(e.filter, t))
                    }), this
                }
                static isEqual(e, t) {
                    if (Object.keys(e).length !== Object.keys(t).length) return !1;
                    for (let s in e)
                        if (e[s] !== t[s]) return !1;
                    return !0
                }
                _rejoinUntilConnected() {
                    this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin()
                }
                _onClose(e) {
                    this._on(G.close, {}, e)
                }
                _onError(e) {
                    this._on(G.error, {}, t => e(t))
                }
                _canPush() {
                    return this.socket.isConnected() && this._isJoined()
                }
                _rejoin(e = this.timeout) {
                    this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = H.joining, this.joinPush.resend(e))
                }
                _getPayloadRecords(e) {
                    let t = {
                        new: {},
                        old: {}
                    };
                    return ("INSERT" === e.type || "UPDATE" === e.type) && (t.new = v(e.columns, e.record)), ("UPDATE" === e.type || "DELETE" === e.type) && (t.old = v(e.columns, e.old_record)), t
                }
            }
            let x = () => {},
                R = "undefined" != typeof WebSocket,
                I = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
            class L {
                constructor(e, t) {
                    var r;
                    this.accessTokenValue = null, this.apiKey = null, this.channels = [], this.endPoint = "", this.httpEndpoint = "", this.headers = y, this.params = {}, this.timeout = 1e4, this.heartbeatIntervalMs = 3e4, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.ref = 0, this.logger = x, this.conn = null, this.sendBuffer = [], this.serializer = new m, this.stateChangeCallbacks = {
                        open: [],
                        close: [],
                        error: [],
                        message: []
                    }, this.accessToken = null, this._resolveFetch = e => {
                        let t;
                        return t = e || ("undefined" == typeof fetch ? (...e) => Promise.resolve().then(s.bind(s, 93537)).then(({
                            default: t
                        }) => t(...e)) : fetch), (...e) => t(...e)
                    }, this.endPoint = `${e}/${W.websocket}`, this.httpEndpoint = P(e), (null == t ? void 0 : t.transport) ? this.transport = t.transport : this.transport = null, (null == t ? void 0 : t.params) && (this.params = t.params), (null == t ? void 0 : t.headers) && (this.headers = Object.assign(Object.assign({}, this.headers), t.headers)), (null == t ? void 0 : t.timeout) && (this.timeout = t.timeout), (null == t ? void 0 : t.logger) && (this.logger = t.logger), (null == t ? void 0 : t.heartbeatIntervalMs) && (this.heartbeatIntervalMs = t.heartbeatIntervalMs);
                    let i = null == (r = null == t ? void 0 : t.params) ? void 0 : r.apikey;
                    if (i && (this.accessTokenValue = i, this.apiKey = i), this.reconnectAfterMs = (null == t ? void 0 : t.reconnectAfterMs) ? t.reconnectAfterMs : e => [1e3, 2e3, 5e3, 1e4][e - 1] || 1e4, this.encode = (null == t ? void 0 : t.encode) ? t.encode : (e, t) => t(JSON.stringify(e)), this.decode = (null == t ? void 0 : t.decode) ? t.decode : this.serializer.decode.bind(this.serializer), this.reconnectTimer = new w(async () => {
                            this.disconnect(), this.connect()
                        }, this.reconnectAfterMs), this.fetch = this._resolveFetch(null == t ? void 0 : t.fetch), null == t ? void 0 : t.worker) {
                        if ("undefined" != typeof window && !window.Worker) throw Error("Web Worker is not supported");
                        this.worker = (null == t ? void 0 : t.worker) || !1, this.workerUrl = null == t ? void 0 : t.workerUrl
                    }
                    this.accessToken = (null == t ? void 0 : t.accessToken) || null
                }
                connect() {
                    if (!this.conn) {
                        if (this.transport) {
                            this.conn = new this.transport(this.endpointURL(), void 0, {
                                headers: this.headers
                            });
                            return
                        }
                        if (R) {
                            this.conn = new WebSocket(this.endpointURL()), this.setupConnection();
                            return
                        }
                        this.conn = new U(this.endpointURL(), void 0, {
                            close: () => {
                                this.conn = null
                            }
                        }), s.e(6793).then(s.t.bind(s, 46793, 23)).then(({
                            default: e
                        }) => {
                            this.conn = new e(this.endpointURL(), void 0, {
                                headers: this.headers
                            }), this.setupConnection()
                        })
                    }
                }
                endpointURL() {
                    return this._appendParams(this.endPoint, Object.assign({}, this.params, {
                        vsn: "1.0.0"
                    }))
                }
                disconnect(e, t) {
                    this.conn && (this.conn.onclose = function() {}, e ? this.conn.close(e, null != t ? t : "") : this.conn.close(), this.conn = null, this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.reset())
                }
                getChannels() {
                    return this.channels
                }
                async removeChannel(e) {
                    let t = await e.unsubscribe();
                    return 0 === this.channels.length && this.disconnect(), t
                }
                async removeAllChannels() {
                    let e = await Promise.all(this.channels.map(e => e.unsubscribe()));
                    return this.disconnect(), e
                }
                log(e, t, s) {
                    this.logger(e, t, s)
                }
                connectionState() {
                    switch (this.conn && this.conn.readyState) {
                        case K.connecting:
                            return V.Connecting;
                        case K.open:
                            return V.Open;
                        case K.closing:
                            return V.Closing;
                        default:
                            return V.Closed
                    }
                }
                isConnected() {
                    return this.connectionState() === V.Open
                }
                channel(e, t = {
                    config: {}
                }) {
                    let s = new C(`realtime:${e}`, t, this);
                    return this.channels.push(s), s
                }
                push(e) {
                    let {
                        topic: t,
                        event: s,
                        payload: r,
                        ref: i
                    } = e, n = () => {
                        this.encode(e, e => {
                            var t;
                            null == (t = this.conn) || t.send(e)
                        })
                    };
                    this.log("push", `${t} ${s} (${i})`, r), this.isConnected() ? n() : this.sendBuffer.push(n)
                }
                async setAuth(e = null) {
                    let t = e || this.accessToken && await this.accessToken() || this.accessTokenValue;
                    if (t) {
                        let e = null;
                        try {
                            e = JSON.parse(atob(t.split(".")[1]))
                        } catch (e) {}
                        if (e && e.exp && !(Math.floor(Date.now() / 1e3) - e.exp < 0)) return this.log("auth", `InvalidJWTToken: Invalid value for JWT claim "exp" with value ${e.exp}`), Promise.reject(`InvalidJWTToken: Invalid value for JWT claim "exp" with value ${e.exp}`);
                        this.accessTokenValue = t, this.channels.forEach(e => {
                            t && e.updateJoinPayload({
                                access_token: t
                            }), e.joinedOnce && e._isJoined() && e._push(G.access_token, {
                                access_token: t
                            })
                        })
                    }
                }
                async sendHeartbeat() {
                    var e;
                    if (this.isConnected()) {
                        if (this.pendingHeartbeatRef) {
                            this.pendingHeartbeatRef = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection"), null == (e = this.conn) || e.close(1e3, "hearbeat timeout");
                            return
                        }
                        this.pendingHeartbeatRef = this._makeRef(), this.push({
                            topic: "phoenix",
                            event: "heartbeat",
                            payload: {},
                            ref: this.pendingHeartbeatRef
                        }), this.setAuth()
                    }
                }
                flushSendBuffer() {
                    this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach(e => e()), this.sendBuffer = [])
                }
                _makeRef() {
                    let e = this.ref + 1;
                    return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString()
                }
                _leaveOpenTopic(e) {
                    let t = this.channels.find(t => t.topic === e && (t._isJoined() || t._isJoining()));
                    t && (this.log("transport", `leaving duplicate topic "${e}"`), t.unsubscribe())
                }
                _remove(e) {
                    this.channels = this.channels.filter(t => t._joinRef() !== e._joinRef())
                }
                setupConnection() {
                    this.conn && (this.conn.binaryType = "arraybuffer", this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = e => this._onConnError(e), this.conn.onmessage = e => this._onConnMessage(e), this.conn.onclose = e => this._onConnClose(e))
                }
                _onConnMessage(e) {
                    this.decode(e.data, e => {
                        let {
                            topic: t,
                            event: s,
                            payload: r,
                            ref: i
                        } = e;
                        i && i === this.pendingHeartbeatRef && (this.pendingHeartbeatRef = null), this.log("receive", `${r.status||""} ${t} ${s} ${i&&"("+i+")"||""}`, r), this.channels.filter(e => e._isMember(t)).forEach(e => e._trigger(s, r, i)), this.stateChangeCallbacks.message.forEach(t => t(e))
                    })
                }
                async _onConnOpen() {
                    if (this.log("transport", `connected to ${this.endpointURL()}`), this.flushSendBuffer(), this.reconnectTimer.reset(), this.worker) {
                        this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
                        let e = this._workerObjectUrl(this.workerUrl);
                        this.workerRef = new Worker(e), this.workerRef.onerror = e => {
                            this.log("worker", "worker error", e.message), this.workerRef.terminate()
                        }, this.workerRef.onmessage = e => {
                            "keepAlive" === e.data.event && this.sendHeartbeat()
                        }, this.workerRef.postMessage({
                            event: "start",
                            interval: this.heartbeatIntervalMs
                        })
                    } else this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), this.heartbeatIntervalMs);
                    this.stateChangeCallbacks.open.forEach(e => e())
                }
                _onConnClose(e) {
                    this.log("transport", "close", e), this._triggerChanError(), this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.reconnectTimer.scheduleTimeout(), this.stateChangeCallbacks.close.forEach(t => t(e))
                }
                _onConnError(e) {
                    this.log("transport", e.message), this._triggerChanError(), this.stateChangeCallbacks.error.forEach(t => t(e))
                }
                _triggerChanError() {
                    this.channels.forEach(e => e._trigger(G.error))
                }
                _appendParams(e, t) {
                    if (0 === Object.keys(t).length) return e;
                    let s = e.match(/\?/) ? "&" : "?",
                        r = new URLSearchParams(t);
                    return `${e}${s}${r}`
                }
                _workerObjectUrl(e) {
                    let t;
                    if (e) t = e;
                    else {
                        let e = new Blob([I], {
                            type: "application/javascript"
                        });
                        t = URL.createObjectURL(e)
                    }
                    return t
                }
            }
            class U {
                constructor(e, t, s) {
                    this.binaryType = "arraybuffer", this.onclose = () => {}, this.onerror = () => {}, this.onmessage = () => {}, this.onopen = () => {}, this.readyState = K.connecting, this.send = () => {}, this.url = null, this.url = e, this.close = s.close
                }
            }
            class D extends Error {
                constructor(e) {
                    super(e), this.__isStorageError = !0, this.name = "StorageError"
                }
            }

            function N(e) {
                return "object" == typeof e && null !== e && "__isStorageError" in e
            }
            class M extends D {
                constructor(e, t) {
                    super(e), this.name = "StorageApiError", this.status = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status
                    }
                }
            }
            class q extends D {
                constructor(e, t) {
                    super(e), this.name = "StorageUnknownError", this.originalError = t
                }
            }
            let B = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? (...e) => Promise.resolve().then(s.bind(s, 93537)).then(({
                        default: t
                    }) => t(...e)) : fetch), (...e) => t(...e)
                },
                F = () => (function(e, t, s, r) {
                    return new(s || (s = Promise))(function(i, n) {
                        function a(e) {
                            try {
                                l(r.next(e))
                            } catch (e) {
                                n(e)
                            }
                        }

                        function o(e) {
                            try {
                                l(r.throw(e))
                            } catch (e) {
                                n(e)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(a, o)
                        }
                        l((r = r.apply(e, t || [])).next())
                    })
                })(void 0, void 0, void 0, function*() {
                    return "undefined" == typeof Response ? (yield Promise.resolve().then(s.bind(s, 93537))).Response : Response
                }),
                z = e => {
                    if (Array.isArray(e)) return e.map(e => z(e));
                    if ("function" == typeof e || e !== Object(e)) return e;
                    let t = {};
                    return Object.entries(e).forEach(([e, s]) => {
                        t[e.replace(/([-_][a-z])/gi, e => e.toUpperCase().replace(/[-_]/g, ""))] = z(s)
                    }), t
                };
            var J, K, H, G, W, V, Y, X, Q, Z, ee, et = function(e, t, s, r) {
                return new(s || (s = Promise))(function(i, n) {
                    function a(e) {
                        try {
                            l(r.next(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function o(e) {
                        try {
                            l(r.throw(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                            e(t)
                        })).then(a, o)
                    }
                    l((r = r.apply(e, t || [])).next())
                })
            };
            let es = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
                er = (e, t, s) => et(void 0, void 0, void 0, function*() {
                    e instanceof(yield F()) && !(null == s ? void 0 : s.noResolveJson) ? e.json().then(s => {
                        t(new M(es(s), e.status || 500))
                    }).catch(e => {
                        t(new q(es(e), e))
                    }) : t(new q(es(e), e))
                }),
                ei = (e, t, s, r) => {
                    let i = {
                        method: e,
                        headers: (null == t ? void 0 : t.headers) || {}
                    };
                    return "GET" === e ? i : (i.headers = Object.assign({
                        "Content-Type": "application/json"
                    }, null == t ? void 0 : t.headers), r && (i.body = JSON.stringify(r)), Object.assign(Object.assign({}, i), s))
                };

            function en(e, t, s, r, i, n) {
                return et(this, void 0, void 0, function*() {
                    return new Promise((a, o) => {
                        e(s, ei(t, r, i, n)).then(e => {
                            if (!e.ok) throw e;
                            return (null == r ? void 0 : r.noResolveJson) ? e : e.json()
                        }).then(e => a(e)).catch(e => er(e, o, r))
                    })
                })
            }

            function ea(e, t, s, r) {
                return et(this, void 0, void 0, function*() {
                    return en(e, "GET", t, s, r)
                })
            }

            function eo(e, t, s, r, i) {
                return et(this, void 0, void 0, function*() {
                    return en(e, "POST", t, r, i, s)
                })
            }

            function el(e, t, s, r, i) {
                return et(this, void 0, void 0, function*() {
                    return en(e, "DELETE", t, r, i, s)
                })
            }
            var eh = s(81029).hp,
                ec = function(e, t, s, r) {
                    return new(s || (s = Promise))(function(i, n) {
                        function a(e) {
                            try {
                                l(r.next(e))
                            } catch (e) {
                                n(e)
                            }
                        }

                        function o(e) {
                            try {
                                l(r.throw(e))
                            } catch (e) {
                                n(e)
                            }
                        }

                        function l(e) {
                            var t;
                            e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                e(t)
                            })).then(a, o)
                        }
                        l((r = r.apply(e, t || [])).next())
                    })
                };
            let eu = {
                    limit: 100,
                    offset: 0,
                    sortBy: {
                        column: "name",
                        order: "asc"
                    }
                },
                ed = {
                    cacheControl: "3600",
                    contentType: "text/plain;charset=UTF-8",
                    upsert: !1
                };
            class ef {
                constructor(e, t = {}, s, r) {
                    this.url = e, this.headers = t, this.bucketId = s, this.fetch = B(r)
                }
                uploadOrUpdate(e, t, s, r) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            let i, n = Object.assign(Object.assign({}, ed), r),
                                a = Object.assign(Object.assign({}, this.headers), "POST" === e && {
                                    "x-upsert": String(n.upsert)
                                }),
                                o = n.metadata;
                            "undefined" != typeof Blob && s instanceof Blob ? ((i = new FormData).append("cacheControl", n.cacheControl), o && i.append("metadata", this.encodeMetadata(o)), i.append("", s)) : "undefined" != typeof FormData && s instanceof FormData ? ((i = s).append("cacheControl", n.cacheControl), o && i.append("metadata", this.encodeMetadata(o))) : (i = s, a["cache-control"] = `max-age=${n.cacheControl}`, a["content-type"] = n.contentType, o && (a["x-metadata"] = this.toBase64(this.encodeMetadata(o)))), (null == r ? void 0 : r.headers) && (a = Object.assign(Object.assign({}, a), r.headers));
                            let l = this._removeEmptyFolders(t),
                                h = this._getFinalPath(l),
                                c = yield this.fetch(`${this.url}/object/${h}`, Object.assign({
                                    method: e,
                                    body: i,
                                    headers: a
                                }, (null == n ? void 0 : n.duplex) ? {
                                    duplex: n.duplex
                                } : {})), u = yield c.json();
                            if (c.ok) return {
                                data: {
                                    path: l,
                                    id: u.Id,
                                    fullPath: u.Key
                                },
                                error: null
                            };
                            return {
                                data: null,
                                error: u
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                upload(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        return this.uploadOrUpdate("POST", e, t, s)
                    })
                }
                uploadToSignedUrl(e, t, s, r) {
                    return ec(this, void 0, void 0, function*() {
                        let i = this._removeEmptyFolders(e),
                            n = this._getFinalPath(i),
                            a = new URL(this.url + `/object/upload/sign/${n}`);
                        a.searchParams.set("token", t);
                        try {
                            let e, t = Object.assign({
                                    upsert: ed.upsert
                                }, r),
                                n = Object.assign(Object.assign({}, this.headers), {
                                    "x-upsert": String(t.upsert)
                                });
                            "undefined" != typeof Blob && s instanceof Blob ? ((e = new FormData).append("cacheControl", t.cacheControl), e.append("", s)) : "undefined" != typeof FormData && s instanceof FormData ? (e = s).append("cacheControl", t.cacheControl) : (e = s, n["cache-control"] = `max-age=${t.cacheControl}`, n["content-type"] = t.contentType);
                            let o = yield this.fetch(a.toString(), {
                                method: "PUT",
                                body: e,
                                headers: n
                            }), l = yield o.json();
                            if (o.ok) return {
                                data: {
                                    path: i,
                                    fullPath: l.Key
                                },
                                error: null
                            };
                            return {
                                data: null,
                                error: l
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                createSignedUploadUrl(e, t) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            let s = this._getFinalPath(e),
                                r = Object.assign({}, this.headers);
                            (null == t ? void 0 : t.upsert) && (r["x-upsert"] = "true");
                            let i = yield eo(this.fetch, `${this.url}/object/upload/sign/${s}`, {}, {
                                headers: r
                            }), n = new URL(this.url + i.url), a = n.searchParams.get("token");
                            if (!a) throw new D("No token returned by API");
                            return {
                                data: {
                                    signedUrl: n.toString(),
                                    path: e,
                                    token: a
                                },
                                error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                update(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        return this.uploadOrUpdate("PUT", e, t, s)
                    })
                }
                move(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield eo(this.fetch, `${this.url}/object/move`, {
                                    bucketId: this.bucketId,
                                    sourceKey: e,
                                    destinationKey: t,
                                    destinationBucket: null == s ? void 0 : s.destinationBucket
                                }, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                copy(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: {
                                    path: (yield eo(this.fetch, `${this.url}/object/copy`, {
                                        bucketId: this.bucketId,
                                        sourceKey: e,
                                        destinationKey: t,
                                        destinationBucket: null == s ? void 0 : s.destinationBucket
                                    }, {
                                        headers: this.headers
                                    })).Key
                                },
                                error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                createSignedUrl(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            let r = this._getFinalPath(e),
                                i = yield eo(this.fetch, `${this.url}/object/sign/${r}`, Object.assign({
                                    expiresIn: t
                                }, (null == s ? void 0 : s.transform) ? {
                                    transform: s.transform
                                } : {}), {
                                    headers: this.headers
                                }), n = (null == s ? void 0 : s.download) ? `&download=${!0===s.download?"":s.download}` : "";
                            return {
                                data: i = {
                                    signedUrl: encodeURI(`${this.url}${i.signedURL}${n}`)
                                },
                                error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                createSignedUrls(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            let r = yield eo(this.fetch, `${this.url}/object/sign/${this.bucketId}`, {
                                expiresIn: t,
                                paths: e
                            }, {
                                headers: this.headers
                            }), i = (null == s ? void 0 : s.download) ? `&download=${!0===s.download?"":s.download}` : "";
                            return {
                                data: r.map(e => Object.assign(Object.assign({}, e), {
                                    signedUrl: e.signedURL ? encodeURI(`${this.url}${e.signedURL}${i}`) : null
                                })),
                                error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                download(e, t) {
                    return ec(this, void 0, void 0, function*() {
                        let s = void 0 !== (null == t ? void 0 : t.transform),
                            r = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {}),
                            i = r ? `?${r}` : "";
                        try {
                            let t = this._getFinalPath(e),
                                r = yield ea(this.fetch, `${this.url}/${s?"render/image/authenticated":"object"}/${t}${i}`, {
                                    headers: this.headers,
                                    noResolveJson: !0
                                });
                            return {
                                data: yield r.blob(), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                info(e) {
                    return ec(this, void 0, void 0, function*() {
                        let t = this._getFinalPath(e);
                        try {
                            let e = yield ea(this.fetch, `${this.url}/object/info/${t}`, {
                                headers: this.headers
                            });
                            return {
                                data: z(e),
                                error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                exists(e) {
                    return ec(this, void 0, void 0, function*() {
                        let t = this._getFinalPath(e);
                        try {
                            return yield function(e, t, s, r) {
                                return et(this, void 0, void 0, function*() {
                                    return en(e, "HEAD", t, Object.assign(Object.assign({}, s), {
                                        noResolveJson: !0
                                    }), void 0)
                                })
                            }(this.fetch, `${this.url}/object/${t}`, {
                                headers: this.headers
                            }), {
                                data: !0,
                                error: null
                            }
                        } catch (e) {
                            if (N(e) && e instanceof q) {
                                let t = e.originalError;
                                if ([400, 404].includes(null == t ? void 0 : t.status)) return {
                                    data: !1,
                                    error: e
                                }
                            }
                            throw e
                        }
                    })
                }
                getPublicUrl(e, t) {
                    let s = this._getFinalPath(e),
                        r = [],
                        i = (null == t ? void 0 : t.download) ? `download=${!0===t.download?"":t.download}` : "";
                    "" !== i && r.push(i);
                    let n = void 0 !== (null == t ? void 0 : t.transform),
                        a = this.transformOptsToQueryString((null == t ? void 0 : t.transform) || {});
                    "" !== a && r.push(a);
                    let o = r.join("&");
                    return "" !== o && (o = `?${o}`), {
                        data: {
                            publicUrl: encodeURI(`${this.url}/${n?"render/image":"object"}/public/${s}${o}`)
                        }
                    }
                }
                remove(e) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield el(this.fetch, `${this.url}/object/${this.bucketId}`, {
                                    prefixes: e
                                }, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                list(e, t, s) {
                    return ec(this, void 0, void 0, function*() {
                        try {
                            let r = Object.assign(Object.assign(Object.assign({}, eu), t), {
                                prefix: e || ""
                            });
                            return {
                                data: yield eo(this.fetch, `${this.url}/object/list/${this.bucketId}`, r, {
                                    headers: this.headers
                                }, s), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                encodeMetadata(e) {
                    return JSON.stringify(e)
                }
                toBase64(e) {
                    return void 0 !== eh ? eh.from(e).toString("base64") : btoa(e)
                }
                _getFinalPath(e) {
                    return `${this.bucketId}/${e}`
                }
                _removeEmptyFolders(e) {
                    return e.replace(/^\/|\/$/g, "").replace(/\/+/g, "/")
                }
                transformOptsToQueryString(e) {
                    let t = [];
                    return e.width && t.push(`width=${e.width}`), e.height && t.push(`height=${e.height}`), e.resize && t.push(`resize=${e.resize}`), e.format && t.push(`format=${e.format}`), e.quality && t.push(`quality=${e.quality}`), t.join("&")
                }
            }
            let ep = {
                "X-Client-Info": "storage-js/2.7.1"
            };
            var eg = function(e, t, s, r) {
                return new(s || (s = Promise))(function(i, n) {
                    function a(e) {
                        try {
                            l(r.next(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function o(e) {
                        try {
                            l(r.throw(e))
                        } catch (e) {
                            n(e)
                        }
                    }

                    function l(e) {
                        var t;
                        e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                            e(t)
                        })).then(a, o)
                    }
                    l((r = r.apply(e, t || [])).next())
                })
            };
            class ey {
                constructor(e, t = {}, s) {
                    this.url = e, this.headers = Object.assign(Object.assign({}, ep), t), this.fetch = B(s)
                }
                listBuckets() {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield ea(this.fetch, `${this.url}/bucket`, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                getBucket(e) {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield ea(this.fetch, `${this.url}/bucket/${e}`, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                createBucket(e, t = {
                    public: !1
                }) {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield eo(this.fetch, `${this.url}/bucket`, {
                                    id: e,
                                    name: e,
                                    public: t.public,
                                    file_size_limit: t.fileSizeLimit,
                                    allowed_mime_types: t.allowedMimeTypes
                                }, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                updateBucket(e, t) {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield function(e, t, s, r, i) {
                                    return et(this, void 0, void 0, function*() {
                                        return en(e, "PUT", t, r, void 0, s)
                                    })
                                }(this.fetch, `${this.url}/bucket/${e}`, {
                                    id: e,
                                    name: e,
                                    public: t.public,
                                    file_size_limit: t.fileSizeLimit,
                                    allowed_mime_types: t.allowedMimeTypes
                                }, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                emptyBucket(e) {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield eo(this.fetch, `${this.url}/bucket/${e}/empty`, {}, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                deleteBucket(e) {
                    return eg(this, void 0, void 0, function*() {
                        try {
                            return {
                                data: yield el(this.fetch, `${this.url}/bucket/${e}`, {}, {
                                    headers: this.headers
                                }), error: null
                            }
                        } catch (e) {
                            if (N(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
            }
            class em extends ey {
                constructor(e, t = {}, s) {
                    super(e, t, s)
                }
                from(e) {
                    return new ef(this.url, this.headers, e, this.fetch)
                }
            }
            let ew = "";
            ew = "undefined" != typeof Deno ? "deno" : "undefined" != typeof document ? "web" : "undefined" != typeof navigator && "ReactNative" === navigator.product ? "react-native" : "node";
            let ev = {
                    headers: {
                        "X-Client-Info": `supabase-js-${ew}/2.47.13`
                    }
                },
                eb = {
                    schema: "public"
                },
                e_ = {
                    autoRefreshToken: !0,
                    persistSession: !0,
                    detectSessionInUrl: !0,
                    flowType: "implicit"
                },
                ek = {};
            var eS = s(93537);
            let eT = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? eS.default : fetch), (...e) => t(...e)
                },
                eE = () => "undefined" == typeof Headers ? eS.Headers : Headers,
                ej = (e, t, s) => {
                    let r = eT(s),
                        i = eE();
                    return (s, n) => (function(e, t, s, r) {
                        return new(s || (s = Promise))(function(i, n) {
                            function a(e) {
                                try {
                                    l(r.next(e))
                                } catch (e) {
                                    n(e)
                                }
                            }

                            function o(e) {
                                try {
                                    l(r.throw(e))
                                } catch (e) {
                                    n(e)
                                }
                            }

                            function l(e) {
                                var t;
                                e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                    e(t)
                                })).then(a, o)
                            }
                            l((r = r.apply(e, t || [])).next())
                        })
                    })(void 0, void 0, void 0, function*() {
                        var a;
                        let o = null != (a = yield t()) ? a : e,
                            l = new i(null == n ? void 0 : n.headers);
                        return l.has("apikey") || l.set("apikey", e), l.has("Authorization") || l.set("Authorization", `Bearer ${o}`), r(s, Object.assign(Object.assign({}, n), {
                            headers: l
                        }))
                    })
                },
                eO = "2.67.3",
                eP = {
                    "X-Client-Info": `gotrue-js/${eO}`
                },
                eA = "X-Supabase-Api-Version",
                e$ = {
                    "2024-01-01": {
                        timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
                        name: "2024-01-01"
                    }
                },
                eC = () => "undefined" != typeof window && "undefined" != typeof document,
                ex = {
                    tested: !1,
                    writable: !1
                },
                eR = () => {
                    if (!eC()) return !1;
                    try {
                        if ("object" != typeof globalThis.localStorage) return !1
                    } catch (e) {
                        return !1
                    }
                    if (ex.tested) return ex.writable;
                    let e = `lswt-${Math.random()}${Math.random()}`;
                    try {
                        globalThis.localStorage.setItem(e, e), globalThis.localStorage.removeItem(e), ex.tested = !0, ex.writable = !0
                    } catch (e) {
                        ex.tested = !0, ex.writable = !1
                    }
                    return ex.writable
                },
                eI = e => {
                    let t;
                    return t = e || ("undefined" == typeof fetch ? (...e) => Promise.resolve().then(s.bind(s, 93537)).then(({
                        default: t
                    }) => t(...e)) : fetch), (...e) => t(...e)
                },
                eL = e => "object" == typeof e && null !== e && "status" in e && "ok" in e && "json" in e && "function" == typeof e.json,
                eU = async (e, t, s) => {
                    await e.setItem(t, JSON.stringify(s))
                },
                eD = async (e, t) => {
                    let s = await e.getItem(t);
                    if (!s) return null;
                    try {
                        return JSON.parse(s)
                    } catch (e) {
                        return s
                    }
                },
                eN = async (e, t) => {
                    await e.removeItem(t)
                };
            class eM {
                constructor() {
                    this.promise = new eM.promiseConstructor((e, t) => {
                        this.resolve = e, this.reject = t
                    })
                }
            }

            function eq(e) {
                let t = e.split(".");
                if (3 !== t.length) throw Error("JWT is not valid: not a JWT structure");
                if (!/^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}=?$|[a-z0-9_-]{2}(==)?$)$/i.test(t[1])) throw Error("JWT is not valid: payload is not in base64url format");
                return JSON.parse(function(e) {
                    let t, s, r, i, n, a, o, l = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                        h = "",
                        c = 0;
                    for (e = e.replace("-", "+").replace("_", "/"); c < e.length;) i = l.indexOf(e.charAt(c++)), n = l.indexOf(e.charAt(c++)), a = l.indexOf(e.charAt(c++)), o = l.indexOf(e.charAt(c++)), t = i << 2 | n >> 4, s = (15 & n) << 4 | a >> 2, r = (3 & a) << 6 | o, h += String.fromCharCode(t), 64 != a && 0 != s && (h += String.fromCharCode(s)), 64 != o && 0 != r && (h += String.fromCharCode(r));
                    return h
                }(t[1]))
            }
            async function eB(e) {
                return await new Promise(t => {
                    setTimeout(() => t(null), e)
                })
            }

            function eF(e) {
                return ("0" + e.toString(16)).substr(-2)
            }
            async function ez(e) {
                let t = new TextEncoder().encode(e);
                return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", t))).map(e => String.fromCharCode(e)).join("")
            }
            async function eJ(e) {
                return "undefined" == typeof crypto || void 0 === crypto.subtle || "undefined" == typeof TextEncoder ? (console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), e) : btoa(await ez(e)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "")
            }
            async function eK(e, t, s = !1) {
                let r = function() {
                        let e = new Uint32Array(56);
                        if ("undefined" == typeof crypto) {
                            let e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~",
                                t = e.length,
                                s = "";
                            for (let r = 0; r < 56; r++) s += e.charAt(Math.floor(Math.random() * t));
                            return s
                        }
                        return crypto.getRandomValues(e), Array.from(e, eF).join("")
                    }(),
                    i = r;
                s && (i += "/PASSWORD_RECOVERY"), await eU(e, `${t}-code-verifier`, i);
                let n = await eJ(r),
                    a = r === n ? "plain" : "s256";
                return [n, a]
            }
            eM.promiseConstructor = Promise;
            let eH = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;
            class eG extends Error {
                constructor(e, t, s) {
                    super(e), this.__isAuthError = !0, this.name = "AuthError", this.status = t, this.code = s
                }
            }

            function eW(e) {
                return "object" == typeof e && null !== e && "__isAuthError" in e
            }
            class eV extends eG {
                constructor(e, t, s) {
                    super(e, t, s), this.name = "AuthApiError", this.status = t, this.code = s
                }
            }
            class eY extends eG {
                constructor(e, t) {
                    super(e), this.name = "AuthUnknownError", this.originalError = t
                }
            }
            class eX extends eG {
                constructor(e, t, s, r) {
                    super(e, s, r), this.name = t, this.status = s
                }
            }
            class eQ extends eX {
                constructor() {
                    super("Auth session missing!", "AuthSessionMissingError", 400, void 0)
                }
            }
            class eZ extends eX {
                constructor() {
                    super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0)
                }
            }
            class e0 extends eX {
                constructor(e) {
                    super(e, "AuthInvalidCredentialsError", 400, void 0)
                }
            }
            class e1 extends eX {
                constructor(e, t = null) {
                    super(e, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status,
                        details: this.details
                    }
                }
            }
            class e2 extends eX {
                constructor(e, t = null) {
                    super(e, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = t
                }
                toJSON() {
                    return {
                        name: this.name,
                        message: this.message,
                        status: this.status,
                        details: this.details
                    }
                }
            }
            class e3 extends eX {
                constructor(e, t) {
                    super(e, "AuthRetryableFetchError", t, void 0)
                }
            }

            function e4(e) {
                return eW(e) && "AuthRetryableFetchError" === e.name
            }
            class e6 extends eX {
                constructor(e, t, s) {
                    super(e, "AuthWeakPasswordError", t, "weak_password"), this.reasons = s
                }
            }
            var e5 = function(e, t) {
                var s = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (s[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) 0 > t.indexOf(r[i]) && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (s[r[i]] = e[r[i]]);
                return s
            };
            let e9 = e => e.msg || e.message || e.error_description || e.error || JSON.stringify(e),
                e8 = [502, 503, 504];
            async function e7(e) {
                var t;
                let s, r;
                if (!eL(e)) throw new e3(e9(e), 0);
                if (e8.includes(e.status)) throw new e3(e9(e), e.status);
                try {
                    s = await e.json()
                } catch (e) {
                    throw new eY(e9(e), e)
                }
                let i = function(e) {
                    let t = e.headers.get(eA);
                    if (!t || !t.match(eH)) return null;
                    try {
                        return new Date(`${t}T00:00:00.0Z`)
                    } catch (e) {
                        return null
                    }
                }(e);
                if (i && i.getTime() >= e$["2024-01-01"].timestamp && "object" == typeof s && s && "string" == typeof s.code ? r = s.code : "object" == typeof s && s && "string" == typeof s.error_code && (r = s.error_code), r) {
                    if ("weak_password" === r) throw new e6(e9(s), e.status, (null == (t = s.weak_password) ? void 0 : t.reasons) || []);
                    else if ("session_not_found" === r) throw new eQ
                } else if ("object" == typeof s && s && "object" == typeof s.weak_password && s.weak_password && Array.isArray(s.weak_password.reasons) && s.weak_password.reasons.length && s.weak_password.reasons.reduce((e, t) => e && "string" == typeof t, !0)) throw new e6(e9(s), e.status, s.weak_password.reasons);
                throw new eV(e9(s), e.status || 500, r)
            }
            let te = (e, t, s, r) => {
                let i = {
                    method: e,
                    headers: (null == t ? void 0 : t.headers) || {}
                };
                return "GET" === e ? i : (i.headers = Object.assign({
                    "Content-Type": "application/json;charset=UTF-8"
                }, null == t ? void 0 : t.headers), i.body = JSON.stringify(r), Object.assign(Object.assign({}, i), s))
            };
            async function tt(e, t, s, r) {
                var i;
                let n = Object.assign({}, null == r ? void 0 : r.headers);
                n[eA] || (n[eA] = e$["2024-01-01"].name), (null == r ? void 0 : r.jwt) && (n.Authorization = `Bearer ${r.jwt}`);
                let a = null != (i = null == r ? void 0 : r.query) ? i : {};
                (null == r ? void 0 : r.redirectTo) && (a.redirect_to = r.redirectTo);
                let o = Object.keys(a).length ? "?" + new URLSearchParams(a).toString() : "",
                    l = await ts(e, t, s + o, {
                        headers: n,
                        noResolveJson: null == r ? void 0 : r.noResolveJson
                    }, {}, null == r ? void 0 : r.body);
                return (null == r ? void 0 : r.xform) ? null == r ? void 0 : r.xform(l) : {
                    data: Object.assign({}, l),
                    error: null
                }
            }
            async function ts(e, t, s, r, i, n) {
                let a, o = te(t, r, i, n);
                try {
                    a = await e(s, Object.assign({}, o))
                } catch (e) {
                    throw console.error(e), new e3(e9(e), 0)
                }
                if (a.ok || await e7(a), null == r ? void 0 : r.noResolveJson) return a;
                try {
                    return await a.json()
                } catch (e) {
                    await e7(e)
                }
            }

            function tr(e) {
                var t, s, r;
                let i = null;
                (r = e).access_token && r.refresh_token && r.expires_in && (i = Object.assign({}, e), e.expires_at || (i.expires_at = (s = e.expires_in, Math.round(Date.now() / 1e3) + s)));
                return {
                    data: {
                        session: i,
                        user: null != (t = e.user) ? t : e
                    },
                    error: null
                }
            }

            function ti(e) {
                let t = tr(e);
                return !t.error && e.weak_password && "object" == typeof e.weak_password && Array.isArray(e.weak_password.reasons) && e.weak_password.reasons.length && e.weak_password.message && "string" == typeof e.weak_password.message && e.weak_password.reasons.reduce((e, t) => e && "string" == typeof t, !0) && (t.data.weak_password = e.weak_password), t
            }

            function tn(e) {
                var t;
                return {
                    data: {
                        user: null != (t = e.user) ? t : e
                    },
                    error: null
                }
            }

            function ta(e) {
                return {
                    data: e,
                    error: null
                }
            }

            function to(e) {
                let {
                    action_link: t,
                    email_otp: s,
                    hashed_token: r,
                    redirect_to: i,
                    verification_type: n
                } = e;
                return {
                    data: {
                        properties: {
                            action_link: t,
                            email_otp: s,
                            hashed_token: r,
                            redirect_to: i,
                            verification_type: n
                        },
                        user: Object.assign({}, e5(e, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]))
                    },
                    error: null
                }
            }

            function tl(e) {
                return e
            }
            var th = function(e, t) {
                var s = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && 0 > t.indexOf(r) && (s[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols)
                    for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) 0 > t.indexOf(r[i]) && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (s[r[i]] = e[r[i]]);
                return s
            };
            class tc {
                constructor({
                    url: e = "",
                    headers: t = {},
                    fetch: s
                }) {
                    this.url = e, this.headers = t, this.fetch = eI(s), this.mfa = {
                        listFactors: this._listFactors.bind(this),
                        deleteFactor: this._deleteFactor.bind(this)
                    }
                }
                async signOut(e, t = "global") {
                    try {
                        return await tt(this.fetch, "POST", `${this.url}/logout?scope=${t}`, {
                            headers: this.headers,
                            jwt: e,
                            noResolveJson: !0
                        }), {
                            data: null,
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async inviteUserByEmail(e, t = {}) {
                    try {
                        return await tt(this.fetch, "POST", `${this.url}/invite`, {
                            body: {
                                email: e,
                                data: t.data
                            },
                            headers: this.headers,
                            redirectTo: t.redirectTo,
                            xform: tn
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async generateLink(e) {
                    try {
                        let {
                            options: t
                        } = e, s = th(e, ["options"]), r = Object.assign(Object.assign({}, s), t);
                        return "newEmail" in s && (r.new_email = null == s ? void 0 : s.newEmail, delete r.newEmail), await tt(this.fetch, "POST", `${this.url}/admin/generate_link`, {
                            body: r,
                            headers: this.headers,
                            xform: to,
                            redirectTo: null == t ? void 0 : t.redirectTo
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                properties: null,
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async createUser(e) {
                    try {
                        return await tt(this.fetch, "POST", `${this.url}/admin/users`, {
                            body: e,
                            headers: this.headers,
                            xform: tn
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async listUsers(e) {
                    var t, s, r, i, n, a, o;
                    try {
                        let l = {
                                nextPage: null,
                                lastPage: 0,
                                total: 0
                            },
                            h = await tt(this.fetch, "GET", `${this.url}/admin/users`, {
                                headers: this.headers,
                                noResolveJson: !0,
                                query: {
                                    page: null != (s = null == (t = null == e ? void 0 : e.page) ? void 0 : t.toString()) ? s : "",
                                    per_page: null != (i = null == (r = null == e ? void 0 : e.perPage) ? void 0 : r.toString()) ? i : ""
                                },
                                xform: tl
                            });
                        if (h.error) throw h.error;
                        let c = await h.json(),
                            u = null != (n = h.headers.get("x-total-count")) ? n : 0,
                            d = null != (o = null == (a = h.headers.get("link")) ? void 0 : a.split(",")) ? o : [];
                        return d.length > 0 && (d.forEach(e => {
                            let t = parseInt(e.split(";")[0].split("=")[1].substring(0, 1)),
                                s = JSON.parse(e.split(";")[1].split("=")[1]);
                            l[`${s}Page`] = t
                        }), l.total = parseInt(u)), {
                            data: Object.assign(Object.assign({}, c), l),
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                users: []
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async getUserById(e) {
                    try {
                        return await tt(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
                            headers: this.headers,
                            xform: tn
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async updateUserById(e, t) {
                    try {
                        return await tt(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
                            body: t,
                            headers: this.headers,
                            xform: tn
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async deleteUser(e, t = !1) {
                    try {
                        return await tt(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
                            headers: this.headers,
                            body: {
                                should_soft_delete: t
                            },
                            xform: tn
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async _listFactors(e) {
                    try {
                        let {
                            data: t,
                            error: s
                        } = await tt(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
                            headers: this.headers,
                            xform: e => ({
                                data: {
                                    factors: e
                                },
                                error: null
                            })
                        });
                        return {
                            data: t,
                            error: s
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _deleteFactor(e) {
                    try {
                        return {
                            data: await tt(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
                                headers: this.headers
                            }),
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
            }
            let tu = {
                getItem: e => eR() ? globalThis.localStorage.getItem(e) : null,
                setItem: (e, t) => {
                    eR() && globalThis.localStorage.setItem(e, t)
                },
                removeItem: e => {
                    eR() && globalThis.localStorage.removeItem(e)
                }
            };

            function td(e = {}) {
                return {
                    getItem: t => e[t] || null,
                    setItem: (t, s) => {
                        e[t] = s
                    },
                    removeItem: t => {
                        delete e[t]
                    }
                }
            }
            let tf = {
                debug: !!(globalThis && eR() && globalThis.localStorage && "true" === globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug"))
            };
            class tp extends Error {
                constructor(e) {
                    super(e), this.isAcquireTimeout = !0
                }
            }
            class tg extends tp {}
            async function ty(e, t, s) {
                tf.debug && console.log("@supabase/gotrue-js: navigatorLock: acquire lock", e, t);
                let r = new globalThis.AbortController;
                return t > 0 && setTimeout(() => {
                    r.abort(), tf.debug && console.log("@supabase/gotrue-js: navigatorLock acquire timed out", e)
                }, t), await Promise.resolve().then(() => globalThis.navigator.locks.request(e, 0 === t ? {
                    mode: "exclusive",
                    ifAvailable: !0
                } : {
                    mode: "exclusive",
                    signal: r.signal
                }, async r => {
                    if (r) {
                        tf.debug && console.log("@supabase/gotrue-js: navigatorLock: acquired", e, r.name);
                        try {
                            return await s()
                        } finally {
                            tf.debug && console.log("@supabase/gotrue-js: navigatorLock: released", e, r.name)
                        }
                    }
                    if (0 === t) throw tf.debug && console.log("@supabase/gotrue-js: navigatorLock: not immediately available", e), new tg(`Acquiring an exclusive Navigator LockManager lock "${e}" immediately failed`);
                    if (tf.debug) try {
                        let e = await globalThis.navigator.locks.query();
                        console.log("@supabase/gotrue-js: Navigator LockManager state", JSON.stringify(e, null, "  "))
                    } catch (e) {
                        console.warn("@supabase/gotrue-js: Error when querying Navigator LockManager state", e)
                    }
                    return console.warn("@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request"), await s()
                }))
            }
            if ("object" != typeof globalThis) try {
                Object.defineProperty(Object.prototype, "__magic__", {
                    get: function() {
                        return this
                    },
                    configurable: !0
                }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
            } catch (e) {
                "undefined" != typeof self && (self.globalThis = self)
            }
            let tm = {
                url: "http://localhost:9999",
                storageKey: "supabase.auth.token",
                autoRefreshToken: !0,
                persistSession: !0,
                detectSessionInUrl: !0,
                headers: eP,
                flowType: "implicit",
                debug: !1,
                hasCustomAuthorizationHeader: !1
            };
            async function tw(e, t, s) {
                return await s()
            }
            class tv {
                constructor(e) {
                    var t, s;
                    this.memoryStorage = null, this.stateChangeEmitters = new Map, this.autoRefreshTicker = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log, this.instanceID = tv.nextInstanceID, tv.nextInstanceID += 1, this.instanceID > 0 && eC() && console.warn("Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.");
                    let r = Object.assign(Object.assign({}, tm), e);
                    if (this.logDebugMessages = !!r.debug, "function" == typeof r.debug && (this.logger = r.debug), this.persistSession = r.persistSession, this.storageKey = r.storageKey, this.autoRefreshToken = r.autoRefreshToken, this.admin = new tc({
                            url: r.url,
                            headers: r.headers,
                            fetch: r.fetch
                        }), this.url = r.url, this.headers = r.headers, this.fetch = eI(r.fetch), this.lock = r.lock || tw, this.detectSessionInUrl = r.detectSessionInUrl, this.flowType = r.flowType, this.hasCustomAuthorizationHeader = r.hasCustomAuthorizationHeader, r.lock ? this.lock = r.lock : eC() && (null == (t = null == globalThis ? void 0 : globalThis.navigator) ? void 0 : t.locks) ? this.lock = ty : this.lock = tw, this.mfa = {
                            verify: this._verify.bind(this),
                            enroll: this._enroll.bind(this),
                            unenroll: this._unenroll.bind(this),
                            challenge: this._challenge.bind(this),
                            listFactors: this._listFactors.bind(this),
                            challengeAndVerify: this._challengeAndVerify.bind(this),
                            getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this)
                        }, this.persistSession ? r.storage ? this.storage = r.storage : eR() ? this.storage = tu : (this.memoryStorage = {}, this.storage = td(this.memoryStorage)) : (this.memoryStorage = {}, this.storage = td(this.memoryStorage)), eC() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
                        try {
                            this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey)
                        } catch (e) {
                            console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", e)
                        }
                        null == (s = this.broadcastChannel) || s.addEventListener("message", async e => {
                            this._debug("received broadcast notification from other tab or client", e), await this._notifyAllSubscribers(e.data.event, e.data.session, !1)
                        })
                    }
                    this.initialize()
                }
                _debug(...e) {
                    return this.logDebugMessages && this.logger(`GoTrueClient@${this.instanceID} (${eO}) ${new Date().toISOString()}`, ...e), this
                }
                async initialize() {
                    return this.initializePromise || (this.initializePromise = (async () => await this._acquireLock(-1, async () => await this._initialize()))()), await this.initializePromise
                }
                async _initialize() {
                    var e;
                    try {
                        let t = function(e) {
                                let t = {},
                                    s = new URL(e);
                                if (s.hash && "#" === s.hash[0]) try {
                                    new URLSearchParams(s.hash.substring(1)).forEach((e, s) => {
                                        t[s] = e
                                    })
                                } catch (e) {}
                                return s.searchParams.forEach((e, s) => {
                                    t[s] = e
                                }), t
                            }(window.location.href),
                            s = "none";
                        if (this._isImplicitGrantCallback(t) ? s = "implicit" : await this._isPKCECallback(t) && (s = "pkce"), eC() && this.detectSessionInUrl && "none" !== s) {
                            let {
                                data: r,
                                error: i
                            } = await this._getSessionFromURL(t, s);
                            if (i) {
                                if (this._debug("#_initialize()", "error detecting session from URL", i), eW(i) && "AuthImplicitGrantRedirectError" === i.name) {
                                    let t = null == (e = i.details) ? void 0 : e.code;
                                    if ("identity_already_exists" === t || "identity_not_found" === t || "single_identity_not_deletable" === t) return {
                                        error: i
                                    }
                                }
                                return await this._removeSession(), {
                                    error: i
                                }
                            }
                            let {
                                session: n,
                                redirectType: a
                            } = r;
                            return this._debug("#_initialize()", "detected session in URL", n, "redirect type", a), await this._saveSession(n), setTimeout(async () => {
                                "recovery" === a ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", n) : await this._notifyAllSubscribers("SIGNED_IN", n)
                            }, 0), {
                                error: null
                            }
                        }
                        return await this._recoverAndRefresh(), {
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            error: e
                        };
                        return {
                            error: new eY("Unexpected error during initialization", e)
                        }
                    } finally {
                        await this._handleVisibilityChange(), this._debug("#_initialize()", "end")
                    }
                }
                async signInAnonymously(e) {
                    var t, s, r;
                    try {
                        let {
                            data: i,
                            error: n
                        } = await tt(this.fetch, "POST", `${this.url}/signup`, {
                            headers: this.headers,
                            body: {
                                data: null != (s = null == (t = null == e ? void 0 : e.options) ? void 0 : t.data) ? s : {},
                                gotrue_meta_security: {
                                    captcha_token: null == (r = null == e ? void 0 : e.options) ? void 0 : r.captchaToken
                                }
                            },
                            xform: tr
                        });
                        if (n || !i) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: n
                        };
                        let a = i.session,
                            o = i.user;
                        return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", a)), {
                            data: {
                                user: o,
                                session: a
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signUp(e) {
                    var t, s, r;
                    try {
                        let i;
                        if ("email" in e) {
                            let {
                                email: s,
                                password: r,
                                options: n
                            } = e, a = null, o = null;
                            "pkce" === this.flowType && ([a, o] = await eK(this.storage, this.storageKey)), i = await tt(this.fetch, "POST", `${this.url}/signup`, {
                                headers: this.headers,
                                redirectTo: null == n ? void 0 : n.emailRedirectTo,
                                body: {
                                    email: s,
                                    password: r,
                                    data: null != (t = null == n ? void 0 : n.data) ? t : {},
                                    gotrue_meta_security: {
                                        captcha_token: null == n ? void 0 : n.captchaToken
                                    },
                                    code_challenge: a,
                                    code_challenge_method: o
                                },
                                xform: tr
                            })
                        } else if ("phone" in e) {
                            let {
                                phone: t,
                                password: n,
                                options: a
                            } = e;
                            i = await tt(this.fetch, "POST", `${this.url}/signup`, {
                                headers: this.headers,
                                body: {
                                    phone: t,
                                    password: n,
                                    data: null != (s = null == a ? void 0 : a.data) ? s : {},
                                    channel: null != (r = null == a ? void 0 : a.channel) ? r : "sms",
                                    gotrue_meta_security: {
                                        captcha_token: null == a ? void 0 : a.captchaToken
                                    }
                                },
                                xform: tr
                            })
                        } else throw new e0("You must provide either an email or phone number and a password");
                        let {
                            data: n,
                            error: a
                        } = i;
                        if (a || !n) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: a
                        };
                        let o = n.session,
                            l = n.user;
                        return n.session && (await this._saveSession(n.session), await this._notifyAllSubscribers("SIGNED_IN", o)), {
                            data: {
                                user: l,
                                session: o
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signInWithPassword(e) {
                    try {
                        let t;
                        if ("email" in e) {
                            let {
                                email: s,
                                password: r,
                                options: i
                            } = e;
                            t = await tt(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                headers: this.headers,
                                body: {
                                    email: s,
                                    password: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                },
                                xform: ti
                            })
                        } else if ("phone" in e) {
                            let {
                                phone: s,
                                password: r,
                                options: i
                            } = e;
                            t = await tt(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
                                headers: this.headers,
                                body: {
                                    phone: s,
                                    password: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                },
                                xform: ti
                            })
                        } else throw new e0("You must provide either an email or phone number and a password");
                        let {
                            data: s,
                            error: r
                        } = t;
                        if (r) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: r
                        };
                        if (!s || !s.session || !s.user) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: new eZ
                        };
                        return s.session && (await this._saveSession(s.session), await this._notifyAllSubscribers("SIGNED_IN", s.session)), {
                            data: Object.assign({
                                user: s.user,
                                session: s.session
                            }, s.weak_password ? {
                                weakPassword: s.weak_password
                            } : null),
                            error: r
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signInWithOAuth(e) {
                    var t, s, r, i;
                    return await this._handleProviderSignIn(e.provider, {
                        redirectTo: null == (t = e.options) ? void 0 : t.redirectTo,
                        scopes: null == (s = e.options) ? void 0 : s.scopes,
                        queryParams: null == (r = e.options) ? void 0 : r.queryParams,
                        skipBrowserRedirect: null == (i = e.options) ? void 0 : i.skipBrowserRedirect
                    })
                }
                async exchangeCodeForSession(e) {
                    return await this.initializePromise, this._acquireLock(-1, async () => this._exchangeCodeForSession(e))
                }
                async _exchangeCodeForSession(e) {
                    let t = await eD(this.storage, `${this.storageKey}-code-verifier`),
                        [s, r] = (null != t ? t : "").split("/");
                    try {
                        let {
                            data: t,
                            error: i
                        } = await tt(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
                            headers: this.headers,
                            body: {
                                auth_code: e,
                                code_verifier: s
                            },
                            xform: tr
                        });
                        if (await eN(this.storage, `${this.storageKey}-code-verifier`), i) throw i;
                        if (!t || !t.session || !t.user) return {
                            data: {
                                user: null,
                                session: null,
                                redirectType: null
                            },
                            error: new eZ
                        };
                        return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers("SIGNED_IN", t.session)), {
                            data: Object.assign(Object.assign({}, t), {
                                redirectType: null != r ? r : null
                            }),
                            error: i
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null,
                                redirectType: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signInWithIdToken(e) {
                    try {
                        let {
                            options: t,
                            provider: s,
                            token: r,
                            access_token: i,
                            nonce: n
                        } = e, {
                            data: a,
                            error: o
                        } = await tt(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
                            headers: this.headers,
                            body: {
                                provider: s,
                                id_token: r,
                                access_token: i,
                                nonce: n,
                                gotrue_meta_security: {
                                    captcha_token: null == t ? void 0 : t.captchaToken
                                }
                            },
                            xform: tr
                        });
                        if (o) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: o
                        };
                        if (!a || !a.session || !a.user) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: new eZ
                        };
                        return a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", a.session)), {
                            data: a,
                            error: o
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signInWithOtp(e) {
                    var t, s, r, i, n;
                    try {
                        if ("email" in e) {
                            let {
                                email: r,
                                options: i
                            } = e, n = null, a = null;
                            "pkce" === this.flowType && ([n, a] = await eK(this.storage, this.storageKey));
                            let {
                                error: o
                            } = await tt(this.fetch, "POST", `${this.url}/otp`, {
                                headers: this.headers,
                                body: {
                                    email: r,
                                    data: null != (t = null == i ? void 0 : i.data) ? t : {},
                                    create_user: null == (s = null == i ? void 0 : i.shouldCreateUser) || s,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    },
                                    code_challenge: n,
                                    code_challenge_method: a
                                },
                                redirectTo: null == i ? void 0 : i.emailRedirectTo
                            });
                            return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: o
                            }
                        }
                        if ("phone" in e) {
                            let {
                                phone: t,
                                options: s
                            } = e, {
                                data: a,
                                error: o
                            } = await tt(this.fetch, "POST", `${this.url}/otp`, {
                                headers: this.headers,
                                body: {
                                    phone: t,
                                    data: null != (r = null == s ? void 0 : s.data) ? r : {},
                                    create_user: null == (i = null == s ? void 0 : s.shouldCreateUser) || i,
                                    gotrue_meta_security: {
                                        captcha_token: null == s ? void 0 : s.captchaToken
                                    },
                                    channel: null != (n = null == s ? void 0 : s.channel) ? n : "sms"
                                }
                            });
                            return {
                                data: {
                                    user: null,
                                    session: null,
                                    messageId: null == a ? void 0 : a.message_id
                                },
                                error: o
                            }
                        }
                        throw new e0("You must provide either an email or phone number.")
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async verifyOtp(e) {
                    var t, s;
                    try {
                        let r, i;
                        "options" in e && (r = null == (t = e.options) ? void 0 : t.redirectTo, i = null == (s = e.options) ? void 0 : s.captchaToken);
                        let {
                            data: n,
                            error: a
                        } = await tt(this.fetch, "POST", `${this.url}/verify`, {
                            headers: this.headers,
                            body: Object.assign(Object.assign({}, e), {
                                gotrue_meta_security: {
                                    captcha_token: i
                                }
                            }),
                            redirectTo: r,
                            xform: tr
                        });
                        if (a) throw a;
                        if (!n) throw Error("An error occurred on token verification.");
                        let o = n.session,
                            l = n.user;
                        return (null == o ? void 0 : o.access_token) && (await this._saveSession(o), await this._notifyAllSubscribers("recovery" == e.type ? "PASSWORD_RECOVERY" : "SIGNED_IN", o)), {
                            data: {
                                user: l,
                                session: o
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async signInWithSSO(e) {
                    var t, s, r;
                    try {
                        let i = null,
                            n = null;
                        return "pkce" === this.flowType && ([i, n] = await eK(this.storage, this.storageKey)), await tt(this.fetch, "POST", `${this.url}/sso`, {
                            body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? {
                                provider_id: e.providerId
                            } : null), "domain" in e ? {
                                domain: e.domain
                            } : null), {
                                redirect_to: null != (s = null == (t = e.options) ? void 0 : t.redirectTo) ? s : void 0
                            }), (null == (r = null == e ? void 0 : e.options) ? void 0 : r.captchaToken) ? {
                                gotrue_meta_security: {
                                    captcha_token: e.options.captchaToken
                                }
                            } : null), {
                                skip_http_redirect: !0,
                                code_challenge: i,
                                code_challenge_method: n
                            }),
                            headers: this.headers,
                            xform: ta
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async reauthenticate() {
                    return await this.initializePromise, await this._acquireLock(-1, async () => await this._reauthenticate())
                }
                async _reauthenticate() {
                    try {
                        return await this._useSession(async e => {
                            let {
                                data: {
                                    session: t
                                },
                                error: s
                            } = e;
                            if (s) throw s;
                            if (!t) throw new eQ;
                            let {
                                error: r
                            } = await tt(this.fetch, "GET", `${this.url}/reauthenticate`, {
                                headers: this.headers,
                                jwt: t.access_token
                            });
                            return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: r
                            }
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async resend(e) {
                    try {
                        let t = `${this.url}/resend`;
                        if ("email" in e) {
                            let {
                                email: s,
                                type: r,
                                options: i
                            } = e, {
                                error: n
                            } = await tt(this.fetch, "POST", t, {
                                headers: this.headers,
                                body: {
                                    email: s,
                                    type: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                },
                                redirectTo: null == i ? void 0 : i.emailRedirectTo
                            });
                            return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: n
                            }
                        }
                        if ("phone" in e) {
                            let {
                                phone: s,
                                type: r,
                                options: i
                            } = e, {
                                data: n,
                                error: a
                            } = await tt(this.fetch, "POST", t, {
                                headers: this.headers,
                                body: {
                                    phone: s,
                                    type: r,
                                    gotrue_meta_security: {
                                        captcha_token: null == i ? void 0 : i.captchaToken
                                    }
                                }
                            });
                            return {
                                data: {
                                    user: null,
                                    session: null,
                                    messageId: null == n ? void 0 : n.message_id
                                },
                                error: a
                            }
                        }
                        throw new e0("You must provide either an email or phone number and a type")
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async getSession() {
                    return await this.initializePromise, await this._acquireLock(-1, async () => this._useSession(async e => e))
                }
                async _acquireLock(e, t) {
                    this._debug("#_acquireLock", "begin", e);
                    try {
                        if (this.lockAcquired) {
                            let e = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(),
                                s = (async () => (await e, await t()))();
                            return this.pendingInLock.push((async () => {
                                try {
                                    await s
                                } catch (e) {}
                            })()), s
                        }
                        return await this.lock(`lock:${this.storageKey}`, e, async () => {
                            this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
                            try {
                                this.lockAcquired = !0;
                                let e = t();
                                for (this.pendingInLock.push((async () => {
                                        try {
                                            await e
                                        } catch (e) {}
                                    })()), await e; this.pendingInLock.length;) {
                                    let e = [...this.pendingInLock];
                                    await Promise.all(e), this.pendingInLock.splice(0, e.length)
                                }
                                return await e
                            } finally {
                                this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1
                            }
                        })
                    } finally {
                        this._debug("#_acquireLock", "end")
                    }
                }
                async _useSession(e) {
                    this._debug("#_useSession", "begin");
                    try {
                        let t = await this.__loadSession();
                        return await e(t)
                    } finally {
                        this._debug("#_useSession", "end")
                    }
                }
                async __loadSession() {
                    this._debug("#__loadSession()", "begin"), this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", Error().stack);
                    try {
                        let e = null,
                            t = await eD(this.storage, this.storageKey);
                        if (this._debug("#getSession()", "session from storage", t), null !== t && (this._isValidSession(t) ? e = t : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !e) return {
                            data: {
                                session: null
                            },
                            error: null
                        };
                        let s = !!e.expires_at && e.expires_at <= Date.now() / 1e3;
                        if (this._debug("#__loadSession()", `session has${s?"":" not"} expired`, "expires_at", e.expires_at), !s) {
                            if (this.storage.isServer) {
                                let t = this.suppressGetSessionWarning;
                                e = new Proxy(e, {
                                    get: (e, s, r) => (t || "user" !== s || (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), t = !0, this.suppressGetSessionWarning = !0), Reflect.get(e, s, r))
                                })
                            }
                            return {
                                data: {
                                    session: e
                                },
                                error: null
                            }
                        }
                        let {
                            session: r,
                            error: i
                        } = await this._callRefreshToken(e.refresh_token);
                        if (i) return {
                            data: {
                                session: null
                            },
                            error: i
                        };
                        return {
                            data: {
                                session: r
                            },
                            error: null
                        }
                    } finally {
                        this._debug("#__loadSession()", "end")
                    }
                }
                async getUser(e) {
                    return e ? await this._getUser(e) : (await this.initializePromise, await this._acquireLock(-1, async () => await this._getUser()))
                }
                async _getUser(e) {
                    try {
                        if (e) return await tt(this.fetch, "GET", `${this.url}/user`, {
                            headers: this.headers,
                            jwt: e,
                            xform: tn
                        });
                        return await this._useSession(async e => {
                            var t, s, r;
                            let {
                                data: i,
                                error: n
                            } = e;
                            if (n) throw n;
                            return (null == (t = i.session) ? void 0 : t.access_token) || this.hasCustomAuthorizationHeader ? await tt(this.fetch, "GET", `${this.url}/user`, {
                                headers: this.headers,
                                jwt: null != (r = null == (s = i.session) ? void 0 : s.access_token) ? r : void 0,
                                xform: tn
                            }) : {
                                data: {
                                    user: null
                                },
                                error: new eQ
                            }
                        })
                    } catch (e) {
                        if (eW(e)) return eW(e) && "AuthSessionMissingError" === e.name && (await this._removeSession(), await eN(this.storage, `${this.storageKey}-code-verifier`)), {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async updateUser(e, t = {}) {
                    return await this.initializePromise, await this._acquireLock(-1, async () => await this._updateUser(e, t))
                }
                async _updateUser(e, t = {}) {
                    try {
                        return await this._useSession(async s => {
                            let {
                                data: r,
                                error: i
                            } = s;
                            if (i) throw i;
                            if (!r.session) throw new eQ;
                            let n = r.session,
                                a = null,
                                o = null;
                            "pkce" === this.flowType && null != e.email && ([a, o] = await eK(this.storage, this.storageKey));
                            let {
                                data: l,
                                error: h
                            } = await tt(this.fetch, "PUT", `${this.url}/user`, {
                                headers: this.headers,
                                redirectTo: null == t ? void 0 : t.emailRedirectTo,
                                body: Object.assign(Object.assign({}, e), {
                                    code_challenge: a,
                                    code_challenge_method: o
                                }),
                                jwt: n.access_token,
                                xform: tn
                            });
                            if (h) throw h;
                            return n.user = l.user, await this._saveSession(n), await this._notifyAllSubscribers("USER_UPDATED", n), {
                                data: {
                                    user: n.user
                                },
                                error: null
                            }
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                _decodeJWT(e) {
                    return eq(e)
                }
                async setSession(e) {
                    return await this.initializePromise, await this._acquireLock(-1, async () => await this._setSession(e))
                }
                async _setSession(e) {
                    try {
                        if (!e.access_token || !e.refresh_token) throw new eQ;
                        let t = Date.now() / 1e3,
                            s = t,
                            r = !0,
                            i = null,
                            n = eq(e.access_token);
                        if (n.exp && (r = (s = n.exp) <= t), r) {
                            let {
                                session: t,
                                error: s
                            } = await this._callRefreshToken(e.refresh_token);
                            if (s) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: s
                            };
                            if (!t) return {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: null
                            };
                            i = t
                        } else {
                            let {
                                data: r,
                                error: n
                            } = await this._getUser(e.access_token);
                            if (n) throw n;
                            i = {
                                access_token: e.access_token,
                                refresh_token: e.refresh_token,
                                user: r.user,
                                token_type: "bearer",
                                expires_in: s - t,
                                expires_at: s
                            }, await this._saveSession(i), await this._notifyAllSubscribers("SIGNED_IN", i)
                        }
                        return {
                            data: {
                                user: i.user,
                                session: i
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                session: null,
                                user: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async refreshSession(e) {
                    return await this.initializePromise, await this._acquireLock(-1, async () => await this._refreshSession(e))
                }
                async _refreshSession(e) {
                    try {
                        return await this._useSession(async t => {
                            var s;
                            if (!e) {
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                if (i) throw i;
                                e = null != (s = r.session) ? s : void 0
                            }
                            if (!(null == e ? void 0 : e.refresh_token)) throw new eQ;
                            let {
                                session: r,
                                error: i
                            } = await this._callRefreshToken(e.refresh_token);
                            return i ? {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: i
                            } : r ? {
                                data: {
                                    user: r.user,
                                    session: r
                                },
                                error: null
                            } : {
                                data: {
                                    user: null,
                                    session: null
                                },
                                error: null
                            }
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                user: null,
                                session: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                async _getSessionFromURL(e, t) {
                    try {
                        if (!eC()) throw new e1("No browser detected.");
                        if (e.error || e.error_description || e.error_code) throw new e1(e.error_description || "Error in URL with unspecified error_description", {
                            error: e.error || "unspecified_error",
                            code: e.error_code || "unspecified_code"
                        });
                        switch (t) {
                            case "implicit":
                                if ("pkce" === this.flowType) throw new e2("Not a valid PKCE flow url.");
                                break;
                            case "pkce":
                                if ("implicit" === this.flowType) throw new e1("Not a valid implicit grant flow url.")
                        }
                        if ("pkce" === t) {
                            if (this._debug("#_initialize()", "begin", "is PKCE flow", !0), !e.code) throw new e2("No code detected.");
                            let {
                                data: t,
                                error: s
                            } = await this._exchangeCodeForSession(e.code);
                            if (s) throw s;
                            let r = new URL(window.location.href);
                            return r.searchParams.delete("code"), window.history.replaceState(window.history.state, "", r.toString()), {
                                data: {
                                    session: t.session,
                                    redirectType: null
                                },
                                error: null
                            }
                        }
                        let {
                            provider_token: s,
                            provider_refresh_token: r,
                            access_token: i,
                            refresh_token: n,
                            expires_in: a,
                            expires_at: o,
                            token_type: l
                        } = e;
                        if (!i || !a || !n || !l) throw new e1("No session defined in URL");
                        let h = Math.round(Date.now() / 1e3),
                            c = parseInt(a),
                            u = h + c;
                        o && (u = parseInt(o));
                        let d = u - h;
                        1e3 * d <= 3e4 && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${d}s, should have been closer to ${c}s`);
                        let f = u - c;
                        h - f >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", f, u, h) : h - f < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", f, u, h);
                        let {
                            data: p,
                            error: g
                        } = await this._getUser(i);
                        if (g) throw g;
                        let y = {
                            provider_token: s,
                            provider_refresh_token: r,
                            access_token: i,
                            expires_in: c,
                            expires_at: u,
                            refresh_token: n,
                            token_type: l,
                            user: p.user
                        };
                        return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), {
                            data: {
                                session: y,
                                redirectType: e.type
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: {
                                session: null,
                                redirectType: null
                            },
                            error: e
                        };
                        throw e
                    }
                }
                _isImplicitGrantCallback(e) {
                    return !!(e.access_token || e.error_description)
                }
                async _isPKCECallback(e) {
                    let t = await eD(this.storage, `${this.storageKey}-code-verifier`);
                    return !!(e.code && t)
                }
                async signOut(e = {
                    scope: "global"
                }) {
                    return await this.initializePromise, await this._acquireLock(-1, async () => await this._signOut(e))
                }
                async _signOut({
                    scope: e
                } = {
                    scope: "global"
                }) {
                    return await this._useSession(async t => {
                        var s;
                        let {
                            data: r,
                            error: i
                        } = t;
                        if (i) return {
                            error: i
                        };
                        let n = null == (s = r.session) ? void 0 : s.access_token;
                        if (n) {
                            let {
                                error: t
                            } = await this.admin.signOut(n, e);
                            if (t && !(eW(t) && "AuthApiError" === t.name && (404 === t.status || 401 === t.status || 403 === t.status))) return {
                                error: t
                            }
                        }
                        return "others" !== e && (await this._removeSession(), await eN(this.storage, `${this.storageKey}-code-verifier`)), {
                            error: null
                        }
                    })
                }
                onAuthStateChange(e) {
                    let t = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
                            let t = 16 * Math.random() | 0;
                            return ("x" == e ? t : 3 & t | 8).toString(16)
                        }),
                        s = {
                            id: t,
                            callback: e,
                            unsubscribe: () => {
                                this._debug("#unsubscribe()", "state change callback with id removed", t), this.stateChangeEmitters.delete(t)
                            }
                        };
                    return this._debug("#onAuthStateChange()", "registered callback with id", t), this.stateChangeEmitters.set(t, s), (async () => {
                        await this.initializePromise, await this._acquireLock(-1, async () => {
                            this._emitInitialSession(t)
                        })
                    })(), {
                        data: {
                            subscription: s
                        }
                    }
                }
                async _emitInitialSession(e) {
                    return await this._useSession(async t => {
                        var s, r;
                        try {
                            let {
                                data: {
                                    session: r
                                },
                                error: i
                            } = t;
                            if (i) throw i;
                            await (null == (s = this.stateChangeEmitters.get(e)) ? void 0 : s.callback("INITIAL_SESSION", r)), this._debug("INITIAL_SESSION", "callback id", e, "session", r)
                        } catch (t) {
                            await (null == (r = this.stateChangeEmitters.get(e)) ? void 0 : r.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", e, "error", t), console.error(t)
                        }
                    })
                }
                async resetPasswordForEmail(e, t = {}) {
                    let s = null,
                        r = null;
                    "pkce" === this.flowType && ([s, r] = await eK(this.storage, this.storageKey, !0));
                    try {
                        return await tt(this.fetch, "POST", `${this.url}/recover`, {
                            body: {
                                email: e,
                                code_challenge: s,
                                code_challenge_method: r,
                                gotrue_meta_security: {
                                    captcha_token: t.captchaToken
                                }
                            },
                            headers: this.headers,
                            redirectTo: t.redirectTo
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async getUserIdentities() {
                    var e;
                    try {
                        let {
                            data: t,
                            error: s
                        } = await this.getUser();
                        if (s) throw s;
                        return {
                            data: {
                                identities: null != (e = t.user.identities) ? e : []
                            },
                            error: null
                        }
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async linkIdentity(e) {
                    var t;
                    try {
                        let {
                            data: s,
                            error: r
                        } = await this._useSession(async t => {
                            var s, r, i, n, a;
                            let {
                                data: o,
                                error: l
                            } = t;
                            if (l) throw l;
                            let h = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
                                redirectTo: null == (s = e.options) ? void 0 : s.redirectTo,
                                scopes: null == (r = e.options) ? void 0 : r.scopes,
                                queryParams: null == (i = e.options) ? void 0 : i.queryParams,
                                skipBrowserRedirect: !0
                            });
                            return await tt(this.fetch, "GET", h, {
                                headers: this.headers,
                                jwt: null != (a = null == (n = o.session) ? void 0 : n.access_token) ? a : void 0
                            })
                        });
                        if (r) throw r;
                        return !eC() || (null == (t = e.options) ? void 0 : t.skipBrowserRedirect) || window.location.assign(null == s ? void 0 : s.url), {
                            data: {
                                provider: e.provider,
                                url: null == s ? void 0 : s.url
                            },
                            error: null
                        }
                    } catch (t) {
                        if (eW(t)) return {
                            data: {
                                provider: e.provider,
                                url: null
                            },
                            error: t
                        };
                        throw t
                    }
                }
                async unlinkIdentity(e) {
                    try {
                        return await this._useSession(async t => {
                            var s, r;
                            let {
                                data: i,
                                error: n
                            } = t;
                            if (n) throw n;
                            return await tt(this.fetch, "DELETE", `${this.url}/user/identities/${e.identity_id}`, {
                                headers: this.headers,
                                jwt: null != (r = null == (s = i.session) ? void 0 : s.access_token) ? r : void 0
                            })
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _refreshAccessToken(e) {
                    let t = `#_refreshAccessToken(${e.substring(0,5)}...)`;
                    this._debug(t, "begin");
                    try {
                        var s, r;
                        let i = Date.now();
                        return await (s = async s => (s > 0 && await eB(200 * Math.pow(2, s - 1)), this._debug(t, "refreshing attempt", s), await tt(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
                            body: {
                                refresh_token: e
                            },
                            headers: this.headers,
                            xform: tr
                        })), r = (e, t) => {
                            let s = 200 * Math.pow(2, e);
                            return t && e4(t) && Date.now() + s - i < 3e4
                        }, new Promise((e, t) => {
                            (async () => {
                                for (let i = 0; i < 1 / 0; i++) try {
                                    let t = await s(i);
                                    if (!r(i, null, t)) return void e(t)
                                } catch (e) {
                                    if (!r(i, e)) return void t(e)
                                }
                            })()
                        }))
                    } catch (e) {
                        if (this._debug(t, "error", e), eW(e)) return {
                            data: {
                                session: null,
                                user: null
                            },
                            error: e
                        };
                        throw e
                    } finally {
                        this._debug(t, "end")
                    }
                }
                _isValidSession(e) {
                    return "object" == typeof e && null !== e && "access_token" in e && "refresh_token" in e && "expires_at" in e
                }
                async _handleProviderSignIn(e, t) {
                    let s = await this._getUrlForProvider(`${this.url}/authorize`, e, {
                        redirectTo: t.redirectTo,
                        scopes: t.scopes,
                        queryParams: t.queryParams
                    });
                    return this._debug("#_handleProviderSignIn()", "provider", e, "options", t, "url", s), eC() && !t.skipBrowserRedirect && window.location.assign(s), {
                        data: {
                            provider: e,
                            url: s
                        },
                        error: null
                    }
                }
                async _recoverAndRefresh() {
                    var e;
                    let t = "#_recoverAndRefresh()";
                    this._debug(t, "begin");
                    try {
                        let s = await eD(this.storage, this.storageKey);
                        if (this._debug(t, "session from storage", s), !this._isValidSession(s)) {
                            this._debug(t, "session is not valid"), null !== s && await this._removeSession();
                            return
                        }
                        let r = Math.round(Date.now() / 1e3),
                            i = (null != (e = s.expires_at) ? e : 1 / 0) < r + 10;
                        if (this._debug(t, `session has${i?"":" not"} expired with margin of 10s`), i) {
                            if (this.autoRefreshToken && s.refresh_token) {
                                let {
                                    error: e
                                } = await this._callRefreshToken(s.refresh_token);
                                e && (console.error(e), e4(e) || (this._debug(t, "refresh failed with a non-retryable error, removing the session", e), await this._removeSession()))
                            }
                        } else await this._notifyAllSubscribers("SIGNED_IN", s)
                    } catch (e) {
                        this._debug(t, "error", e), console.error(e);
                        return
                    } finally {
                        this._debug(t, "end")
                    }
                }
                async _callRefreshToken(e) {
                    var t, s;
                    if (!e) throw new eQ;
                    if (this.refreshingDeferred) return this.refreshingDeferred.promise;
                    let r = `#_callRefreshToken(${e.substring(0,5)}...)`;
                    this._debug(r, "begin");
                    try {
                        this.refreshingDeferred = new eM;
                        let {
                            data: t,
                            error: s
                        } = await this._refreshAccessToken(e);
                        if (s) throw s;
                        if (!t.session) throw new eQ;
                        await this._saveSession(t.session), await this._notifyAllSubscribers("TOKEN_REFRESHED", t.session);
                        let r = {
                            session: t.session,
                            error: null
                        };
                        return this.refreshingDeferred.resolve(r), r
                    } catch (e) {
                        if (this._debug(r, "error", e), eW(e)) {
                            let s = {
                                session: null,
                                error: e
                            };
                            return e4(e) || await this._removeSession(), null == (t = this.refreshingDeferred) || t.resolve(s), s
                        }
                        throw null == (s = this.refreshingDeferred) || s.reject(e), e
                    } finally {
                        this.refreshingDeferred = null, this._debug(r, "end")
                    }
                }
                async _notifyAllSubscribers(e, t, s = !0) {
                    let r = `#_notifyAllSubscribers(${e})`;
                    this._debug(r, "begin", t, `broadcast = ${s}`);
                    try {
                        this.broadcastChannel && s && this.broadcastChannel.postMessage({
                            event: e,
                            session: t
                        });
                        let r = [],
                            i = Array.from(this.stateChangeEmitters.values()).map(async s => {
                                try {
                                    await s.callback(e, t)
                                } catch (e) {
                                    r.push(e)
                                }
                            });
                        if (await Promise.all(i), r.length > 0) {
                            for (let e = 0; e < r.length; e += 1) console.error(r[e]);
                            throw r[0]
                        }
                    } finally {
                        this._debug(r, "end")
                    }
                }
                async _saveSession(e) {
                    this._debug("#_saveSession()", e), this.suppressGetSessionWarning = !0, await eU(this.storage, this.storageKey, e)
                }
                async _removeSession() {
                    this._debug("#_removeSession()"), await eN(this.storage, this.storageKey), await this._notifyAllSubscribers("SIGNED_OUT", null)
                }
                _removeVisibilityChangedCallback() {
                    this._debug("#_removeVisibilityChangedCallback()");
                    let e = this.visibilityChangedCallback;
                    this.visibilityChangedCallback = null;
                    try {
                        e && eC() && (null == window ? void 0 : window.removeEventListener) && window.removeEventListener("visibilitychange", e)
                    } catch (e) {
                        console.error("removing visibilitychange callback failed", e)
                    }
                }
                async _startAutoRefresh() {
                    await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
                    let e = setInterval(() => this._autoRefreshTokenTick(), 3e4);
                    this.autoRefreshTicker = e, e && "object" == typeof e && "function" == typeof e.unref ? e.unref() : "undefined" != typeof Deno && "function" == typeof Deno.unrefTimer && Deno.unrefTimer(e), setTimeout(async () => {
                        await this.initializePromise, await this._autoRefreshTokenTick()
                    }, 0)
                }
                async _stopAutoRefresh() {
                    this._debug("#_stopAutoRefresh()");
                    let e = this.autoRefreshTicker;
                    this.autoRefreshTicker = null, e && clearInterval(e)
                }
                async startAutoRefresh() {
                    this._removeVisibilityChangedCallback(), await this._startAutoRefresh()
                }
                async stopAutoRefresh() {
                    this._removeVisibilityChangedCallback(), await this._stopAutoRefresh()
                }
                async _autoRefreshTokenTick() {
                    this._debug("#_autoRefreshTokenTick()", "begin");
                    try {
                        await this._acquireLock(0, async () => {
                            try {
                                let e = Date.now();
                                try {
                                    return await this._useSession(async t => {
                                        let {
                                            data: {
                                                session: s
                                            }
                                        } = t;
                                        if (!s || !s.refresh_token || !s.expires_at) return void this._debug("#_autoRefreshTokenTick()", "no session");
                                        let r = Math.floor((1e3 * s.expires_at - e) / 3e4);
                                        this._debug("#_autoRefreshTokenTick()", `access token expires in ${r} ticks, a tick lasts 30000ms, refresh threshold is 3 ticks`), r <= 3 && await this._callRefreshToken(s.refresh_token)
                                    })
                                } catch (e) {
                                    console.error("Auto refresh tick failed with error. This is likely a transient error.", e)
                                }
                            } finally {
                                this._debug("#_autoRefreshTokenTick()", "end")
                            }
                        })
                    } catch (e) {
                        if (e.isAcquireTimeout || e instanceof tp) this._debug("auto refresh token tick lock not available");
                        else throw e
                    }
                }
                async _handleVisibilityChange() {
                    if (this._debug("#_handleVisibilityChange()"), !eC() || !(null == window ? void 0 : window.addEventListener)) return this.autoRefreshToken && this.startAutoRefresh(), !1;
                    try {
                        this.visibilityChangedCallback = async () => await this._onVisibilityChanged(!1), null == window || window.addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0)
                    } catch (e) {
                        console.error("_handleVisibilityChange", e)
                    }
                }
                async _onVisibilityChanged(e) {
                    let t = `#_onVisibilityChanged(${e})`;
                    this._debug(t, "visibilityState", document.visibilityState), "visible" === document.visibilityState ? (this.autoRefreshToken && this._startAutoRefresh(), e || (await this.initializePromise, await this._acquireLock(-1, async () => {
                        if ("visible" !== document.visibilityState) return void this._debug(t, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting");
                        await this._recoverAndRefresh()
                    }))) : "hidden" === document.visibilityState && this.autoRefreshToken && this._stopAutoRefresh()
                }
                async _getUrlForProvider(e, t, s) {
                    let r = [`provider=${encodeURIComponent(t)}`];
                    if ((null == s ? void 0 : s.redirectTo) && r.push(`redirect_to=${encodeURIComponent(s.redirectTo)}`), (null == s ? void 0 : s.scopes) && r.push(`scopes=${encodeURIComponent(s.scopes)}`), "pkce" === this.flowType) {
                        let [e, t] = await eK(this.storage, this.storageKey), s = new URLSearchParams({
                            code_challenge: `${encodeURIComponent(e)}`,
                            code_challenge_method: `${encodeURIComponent(t)}`
                        });
                        r.push(s.toString())
                    }
                    if (null == s ? void 0 : s.queryParams) {
                        let e = new URLSearchParams(s.queryParams);
                        r.push(e.toString())
                    }
                    return (null == s ? void 0 : s.skipBrowserRedirect) && r.push(`skip_http_redirect=${s.skipBrowserRedirect}`), `${e}?${r.join("&")}`
                }
                async _unenroll(e) {
                    try {
                        return await this._useSession(async t => {
                            var s;
                            let {
                                data: r,
                                error: i
                            } = t;
                            return i ? {
                                data: null,
                                error: i
                            } : await tt(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
                                headers: this.headers,
                                jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                            })
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _enroll(e) {
                    try {
                        return await this._useSession(async t => {
                            var s, r;
                            let {
                                data: i,
                                error: n
                            } = t;
                            if (n) return {
                                data: null,
                                error: n
                            };
                            let a = Object.assign({
                                    friendly_name: e.friendlyName,
                                    factor_type: e.factorType
                                }, "phone" === e.factorType ? {
                                    phone: e.phone
                                } : {
                                    issuer: e.issuer
                                }),
                                {
                                    data: o,
                                    error: l
                                } = await tt(this.fetch, "POST", `${this.url}/factors`, {
                                    body: a,
                                    headers: this.headers,
                                    jwt: null == (s = null == i ? void 0 : i.session) ? void 0 : s.access_token
                                });
                            return l ? {
                                data: null,
                                error: l
                            } : ("totp" === e.factorType && (null == (r = null == o ? void 0 : o.totp) ? void 0 : r.qr_code) && (o.totp.qr_code = `data:image/svg+xml;utf-8,${o.totp.qr_code}`), {
                                data: o,
                                error: null
                            })
                        })
                    } catch (e) {
                        if (eW(e)) return {
                            data: null,
                            error: e
                        };
                        throw e
                    }
                }
                async _verify(e) {
                    return this._acquireLock(-1, async () => {
                        try {
                            return await this._useSession(async t => {
                                var s;
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                if (i) return {
                                    data: null,
                                    error: i
                                };
                                let {
                                    data: n,
                                    error: a
                                } = await tt(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
                                    body: {
                                        code: e.code,
                                        challenge_id: e.challengeId
                                    },
                                    headers: this.headers,
                                    jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                                });
                                return a ? {
                                    data: null,
                                    error: a
                                } : (await this._saveSession(Object.assign({
                                    expires_at: Math.round(Date.now() / 1e3) + n.expires_in
                                }, n)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", n), {
                                    data: n,
                                    error: a
                                })
                            })
                        } catch (e) {
                            if (eW(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                async _challenge(e) {
                    return this._acquireLock(-1, async () => {
                        try {
                            return await this._useSession(async t => {
                                var s;
                                let {
                                    data: r,
                                    error: i
                                } = t;
                                return i ? {
                                    data: null,
                                    error: i
                                } : await tt(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
                                    body: {
                                        channel: e.channel
                                    },
                                    headers: this.headers,
                                    jwt: null == (s = null == r ? void 0 : r.session) ? void 0 : s.access_token
                                })
                            })
                        } catch (e) {
                            if (eW(e)) return {
                                data: null,
                                error: e
                            };
                            throw e
                        }
                    })
                }
                async _challengeAndVerify(e) {
                    let {
                        data: t,
                        error: s
                    } = await this._challenge({
                        factorId: e.factorId
                    });
                    return s ? {
                        data: null,
                        error: s
                    } : await this._verify({
                        factorId: e.factorId,
                        challengeId: t.id,
                        code: e.code
                    })
                }
                async _listFactors() {
                    let {
                        data: {
                            user: e
                        },
                        error: t
                    } = await this.getUser();
                    if (t) return {
                        data: null,
                        error: t
                    };
                    let s = (null == e ? void 0 : e.factors) || [],
                        r = s.filter(e => "totp" === e.factor_type && "verified" === e.status),
                        i = s.filter(e => "phone" === e.factor_type && "verified" === e.status);
                    return {
                        data: {
                            all: s,
                            totp: r,
                            phone: i
                        },
                        error: null
                    }
                }
                async _getAuthenticatorAssuranceLevel() {
                    return this._acquireLock(-1, async () => await this._useSession(async e => {
                        var t, s;
                        let {
                            data: {
                                session: r
                            },
                            error: i
                        } = e;
                        if (i) return {
                            data: null,
                            error: i
                        };
                        if (!r) return {
                            data: {
                                currentLevel: null,
                                nextLevel: null,
                                currentAuthenticationMethods: []
                            },
                            error: null
                        };
                        let n = this._decodeJWT(r.access_token),
                            a = null;
                        n.aal && (a = n.aal);
                        let o = a;
                        return (null != (s = null == (t = r.user.factors) ? void 0 : t.filter(e => "verified" === e.status)) ? s : []).length > 0 && (o = "aal2"), {
                            data: {
                                currentLevel: a,
                                nextLevel: o,
                                currentAuthenticationMethods: n.amr || []
                            },
                            error: null
                        }
                    }))
                }
            }
            tv.nextInstanceID = 0;
            let tb = tv;
            class t_ extends tb {
                constructor(e) {
                    super(e)
                }
            }
            class tk {
                constructor(e, t, s) {
                    var r, i, n;
                    if (this.supabaseUrl = e, this.supabaseKey = t, !e) throw Error("supabaseUrl is required.");
                    if (!t) throw Error("supabaseKey is required.");
                    let a = e.replace(/\/$/, "");
                    this.realtimeUrl = `${a}/realtime/v1`.replace(/^http/i, "ws"), this.authUrl = `${a}/auth/v1`, this.storageUrl = `${a}/storage/v1`, this.functionsUrl = `${a}/functions/v1`;
                    let o = `sb-${new URL(this.authUrl).hostname.split(".")[0]}-auth-token`,
                        l = function(e, t) {
                            let {
                                db: s,
                                auth: r,
                                realtime: i,
                                global: n
                            } = e, {
                                db: a,
                                auth: o,
                                realtime: l,
                                global: h
                            } = t, c = {
                                db: Object.assign(Object.assign({}, a), s),
                                auth: Object.assign(Object.assign({}, o), r),
                                realtime: Object.assign(Object.assign({}, l), i),
                                global: Object.assign(Object.assign({}, h), n),
                                accessToken: () => {
                                    var e, t, s, r;
                                    return e = this, t = void 0, r = function*() {
                                        return ""
                                    }, new(s = void 0, s = Promise)(function(i, n) {
                                        function a(e) {
                                            try {
                                                l(r.next(e))
                                            } catch (e) {
                                                n(e)
                                            }
                                        }

                                        function o(e) {
                                            try {
                                                l(r.throw(e))
                                            } catch (e) {
                                                n(e)
                                            }
                                        }

                                        function l(e) {
                                            var t;
                                            e.done ? i(e.value) : ((t = e.value) instanceof s ? t : new s(function(e) {
                                                e(t)
                                            })).then(a, o)
                                        }
                                        l((r = r.apply(e, t || [])).next())
                                    })
                                }
                            };
                            return e.accessToken ? c.accessToken = e.accessToken : delete c.accessToken, c
                        }(null != s ? s : {}, {
                            db: eb,
                            realtime: ek,
                            auth: Object.assign(Object.assign({}, e_), {
                                storageKey: o
                            }),
                            global: ev
                        });
                    this.storageKey = null != (r = l.auth.storageKey) ? r : "", this.headers = null != (i = l.global.headers) ? i : {}, l.accessToken ? (this.accessToken = l.accessToken, this.auth = new Proxy({}, {
                        get: (e, t) => {
                            throw Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(t)} is not possible`)
                        }
                    })) : this.auth = this._initSupabaseAuthClient(null != (n = l.auth) ? n : {}, this.headers, l.global.fetch), this.fetch = ej(t, this._getAccessToken.bind(this), l.global.fetch), this.realtime = this._initRealtimeClient(Object.assign({
                        headers: this.headers,
                        accessToken: this._getAccessToken.bind(this)
                    }, l.realtime)), this.rest = new c(`${a}/rest/v1`, {
                        headers: this.headers,
                        schema: l.db.schema,
                        fetch: this.fetch
                    }), l.accessToken || this._listenForAuthEvents()
                }
                get functions() {
                    return new h(this.functionsUrl, {
                        headers: this.headers,
                        customFetch: this.fetch
                    })
                }
                get storage() {
                    return new em(this.storageUrl, this.headers, this.fetch)
                }
                from(e) {
                    return this.rest.from(e)
                }
                schema(e) {
                    return this.rest.schema(e)
                }
                rpc(e, t = {}, s = {}) {
                    return this.rest.rpc(e, t, s)
                }
                channel(e, t = {
                    config: {}
                }) {
                    return this.realtime.channel(e, t)
                }
                getChannels() {
                    return this.realtime.getChannels()
                }
                removeChannel(e) {
                    return this.realtime.removeChannel(e)
                }
                removeAllChannels() {
                    return this.realtime.removeAllChannels()
                }
                _getAccessToken() {
                    var e, t, s, r, i, n;
                    return s = this, r = void 0, i = void 0, n = function*() {
                        if (this.accessToken) return yield this.accessToken();
                        let {
                            data: s
                        } = yield this.auth.getSession();
                        return null != (t = null == (e = s.session) ? void 0 : e.access_token) ? t : null
                    }, new(i || (i = Promise))(function(e, t) {
                        function a(e) {
                            try {
                                l(n.next(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function o(e) {
                            try {
                                l(n.throw(e))
                            } catch (e) {
                                t(e)
                            }
                        }

                        function l(t) {
                            var s;
                            t.done ? e(t.value) : ((s = t.value) instanceof i ? s : new i(function(e) {
                                e(s)
                            })).then(a, o)
                        }
                        l((n = n.apply(s, r || [])).next())
                    })
                }
                _initSupabaseAuthClient({
                    autoRefreshToken: e,
                    persistSession: t,
                    detectSessionInUrl: s,
                    storage: r,
                    storageKey: i,
                    flowType: n,
                    lock: a,
                    debug: o
                }, l, h) {
                    var c;
                    let u = {
                        Authorization: `Bearer ${this.supabaseKey}`,
                        apikey: `${this.supabaseKey}`
                    };
                    return new t_({
                        url: this.authUrl,
                        headers: Object.assign(Object.assign({}, u), l),
                        storageKey: i,
                        autoRefreshToken: e,
                        persistSession: t,
                        detectSessionInUrl: s,
                        storage: r,
                        flowType: n,
                        lock: a,
                        debug: o,
                        fetch: h,
                        hasCustomAuthorizationHeader: ((c = "Authorization" in this.headers, true), c)
                    })
                }
                _initRealtimeClient(e) {
                    return new L(this.realtimeUrl, Object.assign(Object.assign({}, e), {
                        params: Object.assign({
                            apikey: this.supabaseKey
                        }, null == e ? void 0 : e.params)
                    }))
                }
                _listenForAuthEvents() {
                    return this.auth.onAuthStateChange((e, t) => {
                        this._handleTokenChanged(e, "CLIENT", null == t ? void 0 : t.access_token)
                    })
                }
                _handleTokenChanged(e, t, s) {
                    ("TOKEN_REFRESHED" === e || "SIGNED_IN" === e) && this.changedAccessToken !== s ? this.changedAccessToken = s : "SIGNED_OUT" === e && (this.realtime.setAuth(), "STORAGE" == t && this.auth.signOut(), this.changedAccessToken = void 0)
                }
            }
            let tS = (e, t, s) => new tk(e, t, s);
            var tT = s(32641);

            function tE() {
                return "undefined" != typeof window && void 0 !== window.document
            }
            let tj = {
                    path: "/",
                    sameSite: "lax",
                    httpOnly: !1,
                    maxAge: 3456e4
                },
                tO = /^(.*)[.](0|[1-9][0-9]*)$/;

            function tP(e, t) {
                if (e === t) return !0;
                let s = e.match(tO);
                return !!s && s[1] === t
            }

            function tA(e, t, s) {
                let r = s ? ? 3180,
                    i = encodeURIComponent(t);
                if (i.length <= r) return [{
                    name: e,
                    value: t
                }];
                let n = [];
                for (; i.length > 0;) {
                    let e = i.slice(0, r),
                        t = e.lastIndexOf("%");
                    t > r - 3 && (e = e.slice(0, t));
                    let s = "";
                    for (; e.length > 0;) try {
                        s = decodeURIComponent(e);
                        break
                    } catch (t) {
                        if (t instanceof URIError && "%" === e.at(-3) && e.length > 3) e = e.slice(0, e.length - 3);
                        else throw t
                    }
                    n.push(s), i = i.slice(e.length)
                }
                return n.map((t, s) => ({
                    name: `${e}.${s}`,
                    value: t
                }))
            }
            async function t$(e, t) {
                let s = await t(e);
                if (s) return s;
                let r = [];
                for (let s = 0;; s++) {
                    let i = `${e}.${s}`,
                        n = await t(i);
                    if (!n) break;
                    r.push(n)
                }
                return r.length > 0 ? r.join("") : null
            }
            let tC = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""),
                tx = " 	\n\r=".split(""),
                tR = (() => {
                    let e = Array(128);
                    for (let t = 0; t < e.length; t += 1) e[t] = -1;
                    for (let t = 0; t < tx.length; t += 1) e[tx[t].charCodeAt(0)] = -2;
                    for (let t = 0; t < tC.length; t += 1) e[tC[t].charCodeAt(0)] = t;
                    return e
                })();

            function tI(e) {
                let t = [],
                    s = 0,
                    r = 0;
                if (function(e, t) {
                        for (let s = 0; s < e.length; s += 1) {
                            let r = e.charCodeAt(s);
                            if (r > 55295 && r <= 56319) {
                                let t = (r - 55296) * 1024 & 65535;
                                r = (e.charCodeAt(s + 1) - 56320 & 65535 | t) + 65536, s += 1
                            }! function(e, t) {
                                if (e <= 127) return t(e);
                                if (e <= 2047) {
                                    t(192 | e >> 6), t(128 | 63 & e);
                                    return
                                }
                                if (e <= 65535) {
                                    t(224 | e >> 12), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                    return
                                }
                                if (e <= 1114111) {
                                    t(240 | e >> 18), t(128 | e >> 12 & 63), t(128 | e >> 6 & 63), t(128 | 63 & e);
                                    return
                                }
                                throw Error(`Unrecognized Unicode codepoint: ${e.toString(16)}`)
                            }(r, t)
                        }
                    }(e, e => {
                        for (s = s << 8 | e, r += 8; r >= 6;) {
                            let e = s >> r - 6 & 63;
                            t.push(tC[e]), r -= 6
                        }
                    }), r > 0)
                    for (s <<= 6 - r, r = 6; r >= 6;) {
                        let e = s >> r - 6 & 63;
                        t.push(tC[e]), r -= 6
                    }
                return t.join("")
            }

            function tL(e) {
                let t = [],
                    s = e => {
                        t.push(String.fromCodePoint(e))
                    },
                    r = {
                        utf8seq: 0,
                        codepoint: 0
                    },
                    i = 0,
                    n = 0;
                for (let t = 0; t < e.length; t += 1) {
                    let a = tR[e.charCodeAt(t)];
                    if (a > -1)
                        for (i = i << 6 | a, n += 6; n >= 8;)(function(e, t, s) {
                            if (0 === t.utf8seq) {
                                if (e <= 127) return s(e);
                                for (let s = 1; s < 6; s += 1)
                                    if ((e >> 7 - s & 1) == 0) {
                                        t.utf8seq = s;
                                        break
                                    }
                                if (2 === t.utf8seq) t.codepoint = 31 & e;
                                else if (3 === t.utf8seq) t.codepoint = 15 & e;
                                else if (4 === t.utf8seq) t.codepoint = 7 & e;
                                else throw Error("Invalid UTF-8 sequence");
                                t.utf8seq -= 1
                            } else if (t.utf8seq > 0) {
                                if (e <= 127) throw Error("Invalid UTF-8 sequence");
                                t.codepoint = t.codepoint << 6 | 63 & e, t.utf8seq -= 1, 0 === t.utf8seq && s(t.codepoint)
                            }
                        })(i >> n - 8 & 255, r, s), n -= 8;
                    else if (-2 === a) continue;
                    else throw Error(`Invalid Base64-URL character "${e.at(t)}" at position ${t}`)
                }
                return t.join("")
            }
            let tU = "base64-";
            async function tD({
                getAll: e,
                setAll: t,
                setItems: s,
                removedItems: r
            }, i) {
                let n = i.cookieEncoding,
                    a = i.cookieOptions ? ? null,
                    o = await e([...s ? Object.keys(s) : [], ...r ? Object.keys(r) : []]),
                    l = o ? .map(({
                        name: e
                    }) => e) || [],
                    h = Object.keys(r).flatMap(e => l.filter(t => tP(t, e))),
                    c = Object.keys(s).flatMap(e => {
                        let t = new Set(l.filter(t => tP(t, e))),
                            r = s[e];
                        "base64url" === n && (r = tU + tI(r));
                        let i = tA(e, r);
                        return i.forEach(e => {
                            t.delete(e.name)
                        }), h.push(...t), i
                    }),
                    u = { ...tj,
                        ...a,
                        maxAge: 0
                    },
                    d = { ...tj,
                        ...a,
                        maxAge: tj.maxAge
                    };
                delete u.name, delete d.name, await t([...h.map(e => ({
                    name: e,
                    value: "",
                    options: u
                })), ...c.map(({
                    name: e,
                    value: t
                }) => ({
                    name: e,
                    value: t,
                    options: d
                }))])
            }

            function tN(e, t, s) {
                let i = s ? .isSingleton === !0 || (!s || !("isSingleton" in s)) && tE();
                if (i && r) return r;
                if (!e || !t) throw Error(`@supabase/ssr: Your project's URL and API key are required to create a Supabase client!

Check your Supabase project's API settings to find these values

https://supabase.com/dashboard/project/_/settings/api`);
                let {
                    storage: n
                } = function(e, t) {
                    let s, r, i = e.cookies ? ? null,
                        n = e.cookieEncoding,
                        a = {},
                        o = {};
                    if (i)
                        if ("get" in i) {
                            let e = async e => {
                                let t = e.flatMap(e => [e, ...Array.from({
                                        length: 5
                                    }).map((t, s) => `${e}.${s}`)]),
                                    s = [];
                                for (let e = 0; e < t.length; e += 1) {
                                    let r = await i.get(t[e]);
                                    (r || "string" == typeof r) && s.push({
                                        name: t[e],
                                        value: r
                                    })
                                }
                                return s
                            };
                            if (s = async t => await e(t), "set" in i && "remove" in i) r = async e => {
                                for (let t = 0; t < e.length; t += 1) {
                                    let {
                                        name: s,
                                        value: r,
                                        options: n
                                    } = e[t];
                                    r ? await i.set(s, r, n) : await i.remove(s, n)
                                }
                            };
                            else if (t) r = async () => {
                                console.warn("@supabase/ssr: createServerClient was configured without set and remove cookie methods, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness. Consider switching to the getAll and setAll cookie methods instead of get, set and remove which are deprecated and can be difficult to use correctly.")
                            };
                            else throw Error("@supabase/ssr: createBrowserClient requires configuring a getAll and setAll cookie method (deprecated: alternatively both get, set and remove can be used)")
                        } else if ("getAll" in i)
                        if (s = async () => await i.getAll(), "setAll" in i) r = i.setAll;
                        else if (t) r = async () => {
                        console.warn("@supabase/ssr: createServerClient was configured without the setAll cookie method, but the client needs to set cookies. This can lead to issues such as random logouts, early session termination or increased token refresh requests. If in NextJS, check your middleware.ts file, route handlers and server actions for correctness.")
                    };
                    else throw Error("@supabase/ssr: createBrowserClient requires configuring both getAll and setAll cookie methods (deprecated: alternatively both get, set and remove can be used)");
                    else throw Error(`@supabase/ssr: ${t?"createServerClient":"createBrowserClient"} requires configuring getAll and setAll cookie methods (deprecated: alternatively use get, set and remove).${tE()?" As this is called in a browser runtime, consider removing the cookies option object to use the document.cookie API automatically.":""}`);
                    else if (!t && tE()) {
                        let e = () => {
                            let e = (0, tT.q)(document.cookie);
                            return Object.keys(e).map(t => ({
                                name: t,
                                value: e[t]
                            }))
                        };
                        s = () => e(), r = e => {
                            e.forEach(({
                                name: e,
                                value: t,
                                options: s
                            }) => {
                                document.cookie = (0, tT.l)(e, t, s)
                            })
                        }
                    } else if (t) throw Error("@supabase/ssr: createServerClient must be initialized with cookie options that specify getAll and setAll functions (deprecated, not recommended: alternatively use get, set and remove)");
                    else s = () => [], r = () => {
                        throw Error("@supabase/ssr: createBrowserClient in non-browser runtimes (including Next.js pre-rendering mode) was not initialized cookie options that specify getAll and setAll functions (deprecated: alternatively use get, set and remove), but they were needed")
                    };
                    return t ? {
                        getAll: s,
                        setAll: r,
                        setItems: a,
                        removedItems: o,
                        storage: {
                            isServer: !0,
                            getItem: async e => {
                                if ("string" == typeof a[e]) return a[e];
                                if (o[e]) return null;
                                let t = await s([e]),
                                    r = await t$(e, async e => {
                                        let s = t ? .find(({
                                            name: t
                                        }) => t === e) || null;
                                        return s ? s.value : null
                                    });
                                if (!r) return null;
                                let i = r;
                                return "string" == typeof r && r.startsWith(tU) && (i = tL(r.substring(tU.length))), i
                            },
                            setItem: async (t, i) => {
                                t.endsWith("-code-verifier") && await tD({
                                    getAll: s,
                                    setAll: r,
                                    setItems: {
                                        [t]: i
                                    },
                                    removedItems: {}
                                }, {
                                    cookieOptions: e ? .cookieOptions ? ? null,
                                    cookieEncoding: n
                                }), a[t] = i, delete o[t]
                            },
                            removeItem: async e => {
                                delete a[e], o[e] = !0
                            }
                        }
                    } : {
                        getAll: s,
                        setAll: r,
                        setItems: a,
                        removedItems: o,
                        storage: {
                            isServer: !1,
                            getItem: async e => {
                                let t = await s([e]),
                                    r = await t$(e, async e => {
                                        let s = t ? .find(({
                                            name: t
                                        }) => t === e) || null;
                                        return s ? s.value : null
                                    });
                                if (!r) return null;
                                let i = r;
                                return r.startsWith(tU) && (i = tL(r.substring(tU.length))), i
                            },
                            setItem: async (t, i) => {
                                let a = await s([t]),
                                    o = new Set((a ? .map(({
                                        name: e
                                    }) => e) || []).filter(e => tP(e, t))),
                                    l = i;
                                "base64url" === n && (l = tU + tI(i));
                                let h = tA(t, l);
                                h.forEach(({
                                    name: e
                                }) => {
                                    o.delete(e)
                                });
                                let c = { ...tj,
                                        ...e ? .cookieOptions,
                                        maxAge : 0
                                    },
                                    u = { ...tj,
                                        ...e ? .cookieOptions,
                                        maxAge : tj.maxAge
                                    };
                                delete c.name, delete u.name;
                                let d = [...[...o].map(e => ({
                                    name: e,
                                    value: "",
                                    options: c
                                })), ...h.map(({
                                    name: e,
                                    value: t
                                }) => ({
                                    name: e,
                                    value: t,
                                    options: u
                                }))];
                                d.length > 0 && await r(d)
                            },
                            removeItem: async t => {
                                let i = await s([t]),
                                    n = (i ? .map(({
                                        name: e
                                    }) => e) || []).filter(e => tP(e, t)),
                                    a = { ...tj,
                                        ...e ? .cookieOptions,
                                        maxAge : 0
                                    };
                                delete a.name, n.length > 0 && await r(n.map(e => ({
                                    name: e,
                                    value: "",
                                    options: a
                                })))
                            }
                        }
                    }
                }({ ...s,
                    cookieEncoding: s ? .cookieEncoding ? ? "base64url"
                }, !1), a = tS(e, t, { ...s,
                    global: { ...s ? .global,
                        headers : { ...s ? .global ? .headers,
                            "X-Client-Info" : "supabase-ssr/0.5.2"
                        }
                    },
                    auth: { ...s ? .auth,
                        ...s ? .cookieOptions ? .name ? {
                            storageKey: s.cookieOptions.name
                        } : null,
                        flowType : "pkce",
                        autoRefreshToken : tE(),
                        detectSessionInUrl : tE(),
                        persistSession: !0,
                        storage: n
                    }
                });
                return i && (r = a), a
            }
        },
        72901: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let i = r(s(54419));
            class n {
                constructor(e, {
                    headers: t = {},
                    schema: s,
                    fetch: r
                }) {
                    this.url = e, this.headers = t, this.schema = s, this.fetch = r
                }
                select(e, {
                    head: t = !1,
                    count: s
                } = {}) {
                    let r = !1,
                        n = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !r ? "" : ('"' === e && (r = !r), e)).join("");
                    return this.url.searchParams.set("select", n), s && (this.headers.Prefer = `count=${s}`), new i.default({
                        method: t ? "HEAD" : "GET",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                insert(e, {
                    count: t,
                    defaultToNull: s = !0
                } = {}) {
                    let r = [];
                    if (this.headers.Prefer && r.push(this.headers.Prefer), t && r.push(`count=${t}`), s || r.push("missing=default"), this.headers.Prefer = r.join(","), Array.isArray(e)) {
                        let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                        if (t.length > 0) {
                            let e = [...new Set(t)].map(e => `"${e}"`);
                            this.url.searchParams.set("columns", e.join(","))
                        }
                    }
                    return new i.default({
                        method: "POST",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                upsert(e, {
                    onConflict: t,
                    ignoreDuplicates: s = !1,
                    count: r,
                    defaultToNull: n = !0
                } = {}) {
                    let a = [`resolution=${s?"ignore":"merge"}-duplicates`];
                    if (void 0 !== t && this.url.searchParams.set("on_conflict", t), this.headers.Prefer && a.push(this.headers.Prefer), r && a.push(`count=${r}`), n || a.push("missing=default"), this.headers.Prefer = a.join(","), Array.isArray(e)) {
                        let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                        if (t.length > 0) {
                            let e = [...new Set(t)].map(e => `"${e}"`);
                            this.url.searchParams.set("columns", e.join(","))
                        }
                    }
                    return new i.default({
                        method: "POST",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                update(e, {
                    count: t
                } = {}) {
                    let s = [];
                    return this.headers.Prefer && s.push(this.headers.Prefer), t && s.push(`count=${t}`), this.headers.Prefer = s.join(","), new i.default({
                        method: "PATCH",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        body: e,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
                delete({
                    count: e
                } = {}) {
                    let t = [];
                    return e && t.push(`count=${e}`), this.headers.Prefer && t.unshift(this.headers.Prefer), this.headers.Prefer = t.join(","), new i.default({
                        method: "DELETE",
                        url: this.url,
                        headers: this.headers,
                        schema: this.schema,
                        fetch: this.fetch,
                        allowEmpty: !1
                    })
                }
            }
            t.default = n
        },
        76373: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            let i = r(s(26294));
            class n extends i.default {
                select(e) {
                    let t = !1,
                        s = (null != e ? e : "*").split("").map(e => /\s/.test(e) && !t ? "" : ('"' === e && (t = !t), e)).join("");
                    return this.url.searchParams.set("select", s), this.headers.Prefer && (this.headers.Prefer += ","), this.headers.Prefer += "return=representation", this
                }
                order(e, {
                    ascending: t = !0,
                    nullsFirst: s,
                    foreignTable: r,
                    referencedTable: i = r
                } = {}) {
                    let n = i ? `${i}.order` : "order",
                        a = this.url.searchParams.get(n);
                    return this.url.searchParams.set(n, `${a?`${a},`:""}${e}.${t?"asc":"desc"}${void 0===s?"":s?".nullsfirst":".nullslast"}`), this
                }
                limit(e, {
                    foreignTable: t,
                    referencedTable: s = t
                } = {}) {
                    let r = void 0 === s ? "limit" : `${s}.limit`;
                    return this.url.searchParams.set(r, `${e}`), this
                }
                range(e, t, {
                    foreignTable: s,
                    referencedTable: r = s
                } = {}) {
                    let i = void 0 === r ? "offset" : `${r}.offset`,
                        n = void 0 === r ? "limit" : `${r}.limit`;
                    return this.url.searchParams.set(i, `${e}`), this.url.searchParams.set(n, `${t-e+1}`), this
                }
                abortSignal(e) {
                    return this.signal = e, this
                }
                single() {
                    return this.headers.Accept = "application/vnd.pgrst.object+json", this
                }
                maybeSingle() {
                    return "GET" === this.method ? this.headers.Accept = "application/json" : this.headers.Accept = "application/vnd.pgrst.object+json", this.isMaybeSingle = !0, this
                }
                csv() {
                    return this.headers.Accept = "text/csv", this
                }
                geojson() {
                    return this.headers.Accept = "application/geo+json", this
                }
                explain({
                    analyze: e = !1,
                    verbose: t = !1,
                    settings: s = !1,
                    buffers: r = !1,
                    wal: i = !1,
                    format: n = "text"
                } = {}) {
                    var a;
                    let o = [e ? "analyze" : null, t ? "verbose" : null, s ? "settings" : null, r ? "buffers" : null, i ? "wal" : null].filter(Boolean).join("|"),
                        l = null != (a = this.headers.Accept) ? a : "application/json";
                    return this.headers.Accept = `application/vnd.pgrst.plan+${n}; for="${l}"; options=${o};`, this
                }
                rollback() {
                    var e;
                    return (null != (e = this.headers.Prefer) ? e : "").trim().length > 0 ? this.headers.Prefer += ",tx=rollback" : this.headers.Prefer = "tx=rollback", this
                }
                returns() {
                    return this
                }
            }
            t.default = n
        },
        87843: function(e, t, s) {
            var r = this && this.__importDefault || function(e) {
                return e && e.__esModule ? e : {
                    default: e
                }
            };
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.PostgrestError = t.PostgrestBuilder = t.PostgrestTransformBuilder = t.PostgrestFilterBuilder = t.PostgrestQueryBuilder = t.PostgrestClient = void 0;
            let i = r(s(37977));
            t.PostgrestClient = i.default;
            let n = r(s(72901));
            t.PostgrestQueryBuilder = n.default;
            let a = r(s(54419));
            t.PostgrestFilterBuilder = a.default;
            let o = r(s(76373));
            t.PostgrestTransformBuilder = o.default;
            let l = r(s(26294));
            t.PostgrestBuilder = l.default;
            let h = r(s(5732));
            t.PostgrestError = h.default, t.default = {
                PostgrestClient: i.default,
                PostgrestQueryBuilder: n.default,
                PostgrestFilterBuilder: a.default,
                PostgrestTransformBuilder: o.default,
                PostgrestBuilder: l.default,
                PostgrestError: h.default
            }
        },
        93537: (e, t, s) => {
            s.r(t), s.d(t, {
                Headers: () => a,
                Request: () => o,
                Response: () => l,
                default: () => n,
                fetch: () => i
            });
            var r = function() {
                if ("undefined" != typeof self) return self;
                if ("undefined" != typeof window) return window;
                if (void 0 !== s.g) return s.g;
                throw Error("unable to locate global object")
            }();
            let i = r.fetch,
                n = r.fetch.bind(r),
                a = r.Headers,
                o = r.Request,
                l = r.Response
        }
    }
]);